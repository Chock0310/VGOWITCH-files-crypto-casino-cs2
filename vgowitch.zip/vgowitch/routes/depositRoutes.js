var express = require('express');
var router = express.Router();

var depositControllers = require('@/controllers/depositControllers.js');

router.get('/', depositControllers.deposit);
router.get('/crypto/:method', depositControllers.depositCrypto);
router.get('/steam/:method', depositControllers.depositSteam);
router.get('/p2p/:method', depositControllers.depositP2p);

module.exports = router;