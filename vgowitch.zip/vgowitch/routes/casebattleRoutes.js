var express = require('express');
var router = express.Router();

var casebattleControllers = require('@/controllers/casebattleControllers.js');

router.get('/', casebattleControllers.casebattleUnset);
router.get('/list/active', casebattleControllers.casebattleLobby);
router.get('/list/finished', casebattleControllers.casebattleLobby);
router.get('/list/my', casebattleControllers.casebattleLobby);
router.get('/create', casebattleControllers.casebattleCreate);
router.get('/:id', casebattleControllers.casebattleGame);

module.exports = router;