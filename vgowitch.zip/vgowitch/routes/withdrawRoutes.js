var express = require('express');
var router = express.Router();

var withdrawControllers = require('@/controllers/withdrawControllers.js');

router.get('/', withdrawControllers.withdraw);
router.get('/crypto/:method', withdrawControllers.withdrawCrypto);
router.get('/steam/:method', withdrawControllers.withdrawSteam);
router.get('/p2p/:method', withdrawControllers.withdrawP2p);

module.exports = router;