var express = require('express');
var router = express.Router();

var upgraderControllers = require('@/controllers/upgraderControllers.js');

router.get('/', upgraderControllers.upgrader);
router.get('/:itemid', upgraderControllers.upgraderItem);

module.exports = router;