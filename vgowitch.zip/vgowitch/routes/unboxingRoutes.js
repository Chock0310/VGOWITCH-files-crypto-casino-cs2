var express = require('express');
var router = express.Router();

var unboxingControllers = require('@/controllers/unboxingControllers.js');

router.get('/', unboxingControllers.unboxingLobby);
router.get('/:id', unboxingControllers.unboxingCase);

module.exports = router;