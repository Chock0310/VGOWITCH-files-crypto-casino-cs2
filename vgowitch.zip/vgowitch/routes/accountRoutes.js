var express = require('express');
var router = express.Router();

var accountControllers = require('@/controllers/accountControllers.js');

router.get('/', accountControllers.accountUnset);
router.get('/inventory', accountControllers.accountInventory);
router.get('/settings', accountControllers.accountSettings);
router.get('/deposits', accountControllers.accountDeposits);
router.get('/withdrawals', accountControllers.accountWithdrawals);
router.get('/games', accountControllers.accountGamesUnset);
router.get('/games/roulette', accountControllers.accountGamesRoulette);
router.get('/games/crash', accountControllers.accountGamesCrash);
router.get('/games/jackpot', accountControllers.accountGamesJackpot);
router.get('/games/coinflip', accountControllers.accountGamesCoinflip);
router.get('/games/dice', accountControllers.accountGamesDice);
router.get('/games/unboxing', accountControllers.accountGamesUnboxing);
router.get('/games/casebattle', accountControllers.accountGamesCasebattle);
router.get('/games/upgrader', accountControllers.accountGamesUpgrader);
router.get('/games/tower', accountControllers.accountGamesTower);
router.get('/games/minesweeper', accountControllers.accountGamesMinesweeper);
router.get('/games/plinko', accountControllers.accountGamesPlinko);
router.get('/games/casino', accountControllers.accountGamesCasino);
router.get('/transactions', accountControllers.accountTransactions);
router.get('/exclusion', accountControllers.accountExclusion);
router.get('/security', accountControllers.accountSecurity);

module.exports = router;