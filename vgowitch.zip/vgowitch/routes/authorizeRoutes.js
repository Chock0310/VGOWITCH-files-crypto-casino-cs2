var express = require('express');
var router = express.Router();

var authorizeControllers = require('@/controllers/authorizeControllers.js');

router.get('/', authorizeControllers.authorize);

module.exports = router;