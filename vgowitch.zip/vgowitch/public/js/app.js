/*
           ______________________________________
  ________|                                      |_______
  \       |        Developed by MrCHICK          |      /
   \      |            VGOWitch.com              |     /
   /      |______________________________________|     \
  /__________)                                (_________\

*/

"use strict";

var INITIALIZED = false;

var USERID = null;
var SOCKET = null;

var RECAPTCHA = null;

var BALANCES = {
	'main': 0
};

var offers_currencyAmounts = {};
var offers_currencyFees = {};

var games_intervalAmounts = {};

//AUDIO
var audio_volume = 0.75;

var audio_names = {
	error: [ 'error' ],
	play: [ 'play' ],
	cashout: [ 'cashout' ],
	select: [ 'select' ],
	addskin: [ 'addskin' ],
	roulette_rolling: [ 'roulette_rolling' ],
	roulette_end: [ 'roulette_end' ],
	crash_stop: [ 'crash_stop' ],
	jackpot_rolling: [ 'jackpot_rolling' ],
	coinflip_start: [ 'coinflip_start' ],
	coinflip_stop: [ 'coinflip_stop' ],
	dice_stop: [ 'dice_stop' ],
	dice_win: [ 'dice_win' ],
	dice_loss: [ 'dice_loss' ],
	unboxing_rolling: [ 'unboxing_rolling' ],
	casebattle_rolling: [ 'casebattle_rolling' ],
	upgrader_rolling: [ 'upgrader_rolling' ],
	upgrader_win: [ 'upgrader_win' ],
	upgrader_loss: [ 'upgrader_loss' ],
	tower_win: [ 'tower_win' ],
	tower_loss: [ 'tower_loss' ],
	minesweeper_win: [ 'minesweeper_win' ],
	minesweeper_loss: [ 'minesweeper_loss' ],
	plinko_hit: [ 'plinko_hit1', 'plinko_hit2', 'plinko_hit3', 'plinko_hit4' ],
	plinko_win: [ 'plinko_win' ],
	dailycase_rolling: [ 'dailycase_rolling' ]
};

var audio_sounds = {};

//PROFILE SETTINGS

var profile_settings = {
	'sounds': {
		'type': 'cookie',
		'value': '1'
	},
	'channel': {
		'type': 'cookie',
		'value': 'en'
	},
	'chat': {
		'type': 'cookie',
		'value': '0'
	},
	'cart': {
		'type': 'cookie',
		'value': '1'
	},
	'anonymous': {
		'type': 'save',
		'value': '0'
	},
	'private': {
		'type': 'save',
		'value': '0'
	},
	'balance': {
		'type': 'cookie',
		'value': 'main'
	},
	'history': {
		'type': 'cookie',
		'value': 'all_bets'
	}
};

function sounds_initialize(){
	Object.keys(audio_names).forEach(function(item){
		audio_sounds[item] = [];

		audio_names[item].forEach(function(name){
			var sound = new Audio('/audio/' + name + '.wav');
			sound.load();

			audio_sounds[item].push(sound);
		})
	});
}

function sounds_play(name){
	var sounds = audio_sounds[name];

	var sound = sounds[getRandomInt(0, sounds.length - 1)].cloneNode();
	sound.volume = audio_volume;

	var play_promise = sound.play();

	if (play_promise !== undefined) {
		play_promise.then(function(){
			setTimeout(function(){
				sound = null;
			}, sound.duration * 1000);
		}).catch(function(err){
			sound.pause();
		});
	}
}

function profile_settingsChange(setting, value){
	if(profile_settings[setting] === undefined) return;

	profile_settings[setting].value = value;

	profile_settingsSave();
	profile_settingsAssign(setting, value, false);
}

function profile_settingsLoad(){
	var settings = JSON.parse(getCookie('settings'));

	if(!settings) {
		profile_settingsSave();
		profile_settingsLoad();
		return
	}

	Object.keys(settings).forEach(function(item){
		if(profile_settings[item] !== undefined){
			profile_settings[item].value = settings[item];
		}
	});

	var new_settings = false;

	Object.keys(profile_settings).forEach(function(item){
		profile_settingsAssign(item, profile_settings[item].value, true);

		if(settings[item] === undefined && profile_settings[item].type == 'cookie') new_settings = true;
	});

	if(new_settings) return profile_settingsSave();
}

function profile_settingsAssign(setting, value, first){
	if(setting == 'sounds' || setting == 'anonymous' || setting == 'private') $('.change-setting[data-setting="' + setting + '"]').prop('checked', (value == '1'));

	switch(setting) {
		case 'sounds':
			$('#profile_setting_sounds').prop('checked', (value == '1'));

			audio_volume = (value == '1') ? 0.75 : 0;

			break;

		case 'channel':
			$('#chat_channel').val(value);

			var $field = $('#chat_channel').closest('.dropdown_field');
			changeDropdownFieldElement($field);

			break;

		case 'chat':
			if(isOnMobile() && first) resize_pullout('chat', true);
			else resize_pullout('chat', value == '1');

			break;

		case 'cart':
			if(isOnMobile() && first) resize_pullout('cart', true);
			else resize_pullout('cart', value == '1');

			break;

		case 'anonymous':
			break;

		case 'private':
			break;

		case 'balance':
			$('.balances .balance[data-type="total"] .amount').countToFloat(roundedToFixed($('.balances .list .balance[data-type="' + value + '"]').attr('data-balance'), 2));

			break;

		case 'history':
			$('.bet-select .history-load').removeClass('active');
			$('.bet-select .history-load[data-type="' + value + '"]').addClass('active');

			break;
	}
}

function profile_settingsSave(){
	var settings = {};

	Object.keys(profile_settings).forEach(function(item){
		if(profile_settings[item].type == 'cookie') {
			settings[item] = profile_settings[item].value;
		}
	});

	setCookie('settings', JSON.stringify(settings));
}

function profile_settingsGet(setting){
	if(profile_settings[setting] === undefined) return '';

	return profile_settings[setting].value;
}

/* SOCKET */

$(document).ready(function() {
	profile_settingsLoad();
	sounds_initialize();

	connect_socket();

	//EXCLUSION
	$('.self_exclision').on('click', function(){
		var exclusion = $(this).data('exclusion');

		confirm_action(function(confirmed){
			if(!confirmed) return;

			requestRecaptcha(function(render){
				send_request_socket({
					'type': 'account',
					'command': 'exclusion',
					'exclusion': exclusion,
					'recaptcha': render
				});
			});
		});
	});

	//REMOVE SESSIONS
	$('.remove_session').on('click', function(){
		var session = $(this).data('session');

		confirm_action(function(confirmed){
			if(!confirmed) return;

			send_request_socket({
				'type': 'account',
				'command': 'remove_session',
				'session': session
			});
		});
	});

    $('#remove_sessions').on('click', function(){
		confirm_action(function(confirmed){
			if(!confirmed) return;

			send_request_socket({
				'type': 'account',
				'command': 'remove_sessions'
			});
		});
	});

	//ENABLE EMAIL VERIFICATION
	$('#enable_email_verification').on('click', function(){
		send_request_socket({
            'type': 'account',
            'command': 'enable_email_verification'
        });
	});

    //ACTIVATE EMAIL VERIFICATION
    $('#activate_email_verification').on('click', function(){
        var code = $('#email_verification_code').val();

		send_request_socket({
            'type': 'account',
            'command': 'activate_email_verification',
            'code': code
        });
	});

	//DISABLE EMAIL VERIFICATION
	$('#disable_email_verification').on('click', function(){
		confirm_action(function(confirmed){
			if(!confirmed) return;

            send_request_socket({
                'type': 'account',
                'command': 'disable_email_verification'
            });
        });
	});

    //ENABLE AUTHENTICATOR APP
	$('#enable_authenticator_app').on('click', function(){
		send_request_socket({
            'type': 'account',
            'command': 'enable_authenticator_app'
        });
	});

    //ACTIVATE AUTHENTICATOR APP
    $('#activate_authenticator_app').on('click', function(){
        var token = $('#authenticator_app_token').val();

		send_request_socket({
            'type': 'account',
            'command': 'activate_authenticator_app',
            'token': token
        });
	});

	//DISABLE AUTHENTICATOR APP
	$('#disable_authenticator_app').on('click', function(){
		confirm_action(function(confirmed){
			if(!confirmed) return;

            send_request_socket({
                'type': 'account',
                'command': 'disable_authenticator_app'
            });
        });
	});

	//MANAGE AUTHENTICATOR APP
	$('#manage_authenticator_app').on('click', function(){
		send_request_socket({
            'type': 'account',
            'command': 'manage_authenticator_app'
        });
	});

	//GENERATE CODES AUTHENTICATOR APP
	$('#generate_codes_authenticator_app').on('click', function(){
		send_request_socket({
            'type': 'account',
            'command': 'generate_codes_authenticator_app'
        });
	});

	//TWOFA PRIMARY METHOD
	$('.twofa_primary_method').on('click', function(){
		var method = $(this).attr('data-method');

        send_request_socket({
            'type': 'account',
            'command': 'twofa_primary_method',
            'method': method
        });
	});

    //SHOW / HIDE TWOFA METHOD OPTIONS
	$(document).on('click', '.method-open-menu', function() {
		if($(this).closest('.security-method').find('.method-menu').hasClass('hidden')){
			$('.method-menu:not(.hidden)').each(function(i, e) {
				var $MENU = $(this);

				$MENU.css('opacity', 0);

				setTimeout(function(){
					$MENU.addClass('hidden');
				}, 200);
			});

			var $MENU = $(this).closest('.security-method').find('.method-menu');

			$MENU.removeClass('hidden');

			setTimeout(function(){
				$MENU.css('opacity', 1);
			}, 10);
		}
	});

	$(document).on('click', ':not(.method-open-menu):not(.method-open-menu > *):not(.method-menu)', function(e) {
		if(e.target !== this) return;

		$('.method-menu:not(.hidden)').each(function(i, e) {
			var $MENU = $(this);

			$MENU.css('opacity', 0);

			setTimeout(function(){
				$MENU.addClass('hidden');
			}, 200);
		});
	});

	//PULLOUT
	$('.pullout_view').on('click', function(){
		var pullout = $(this).data('pullout');

		var hide = $('#page').hasClass(pullout + '-active');

		if(pullout == 'menu' || pullout == 'admin') resize_pullout(pullout, hide);
		else profile_settingsChange(pullout, hide ? '1' : '0');
	});

	var last_width = $(window).width();
	$(window).resize(function(){
		if(last_width != $(window).width()){
			last_width = $(window).width();

			resize_pullout('chat', profile_settings['chat'].value == '1');
			resize_pullout('cart', profile_settings['cart'].value == '1');
		}
	});

	//PROFILE SETTINGS
	$('.change-setting').on('change', function(){
		var setting = $(this).data('setting');

		if(profile_settings[setting].type == 'cookie') {
			profile_settingsChange(setting, (profile_settings[setting].value == '1') ? '0' : '1');
		} else {
			profile_settings[setting].value = (profile_settings[setting].value == '1') ? '0' : '1';

			send_request_socket({
				'type': 'account',
				'command': 'profile_settings',
				'data': {
					'setting': setting,
					'value': profile_settings[setting].value
				}
			});

			profile_settingsAssign(setting, profile_settings[setting].value, false);
		}
	});

	//SWITCH PANELS
	$(document).on('click', '.switch_panel', function() {
		var id = $(this).data('id');
		var panel = $(this).data('panel');

		$('.switch_panel[data-id="' + id + '"]').removeClass('active');
		$(this).addClass('active');

		$('.switch_content[data-id="' + id + '"]').addClass('hidden');
		$('.switch_content[data-id="' + id + '"][data-panel="' + panel + '"]').removeClass('hidden');
	});

	//SAVE EMAIL
	$(document).on('click', '#save_account_email', function() {
		var email = $(this).closest('.input_field').find('.account_email').val();

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'account',
				'command': 'save_email',
				'email': email,
				'recaptcha': render
			});
		});
	});

	//SAVE TRADELINK
	$(document).on('click', '#save_steam_tradelink', function() {
		var tradelink = $(this).closest('.input_field').find('.steam_tradelink').val();

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'account',
				'command': 'save_tradelink',
				'tradelink': tradelink,
				'recaptcha': render
			});
		});
	});

	//SAVE WEBAPI TOKEN
	$(document).on('click', '#save_steam_webapi_token', function() {
		var webapi_token = $(this).closest('.input_field').find('.steam_webapi_token').val();

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'account',
				'command': 'save_webapi_token',
				'webapi_token': webapi_token,
				'recaptcha': render
			});
		});
	});

	//AFFILIATES
	$(document).on('click', '#collect_affiliates_referral_available', function() {
		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'affiliates',
				'command': 'collect',
				'recaptcha': render
			});
		});
	});

	//REWARDS
	$(document).on('click', '#collect_reward_bind', function() {
		var bind = $(this).data('bind');

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'rewards',
				'command': 'bind',
				'data': {
					'bind': bind
				},
				'recaptcha': render
			});
		});
	});

	$(document).on('click', '#collect_reward_referral_redeem', function() {
		var code = $('#referral_redeem_code').val();

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'rewards',
				'command': 'referral_redeem',
				'data': {
					'code': code
				},
				'recaptcha': render
			});
		});
	});

	$(document).on('click', '#collect_reward_referral_create', function() {
		var code = $('#referral_create_code').val();

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'rewards',
				'command': 'referral_create',
				'data': {
					'code': code
				},
				'recaptcha': render
			});
		});
	});

	$(document).on('click', '#collect_reward_bonus_redeem', function() {
		var code = $('#bonus_redeem_code').val();

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'rewards',
				'command': 'bonus_redeem',
				'data': {
					'code': code,
				},
				'recaptcha': render
			});
		});
	});

    $(document).on('click', '#bonus_create_generate', function() {
		$('#bonus_create_code').val(generateCode(6));
        changeInputFieldLabel($('#bonus_create_code').closest('.input_field'));
	});

	$(document).on('click', '#collect_reward_bonus_create', function() {
		var code = $('#bonus_create_code').val();
		var amount = $('#bonus_create_amount').val();
		var uses = $('#bonus_create_uses').val();

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'rewards',
				'command': 'bonus_create',
				'data': {
					'code': code,
					'amount': amount,
					'uses': uses
				},
				'recaptcha': render
			});
		});
	});

	$(document).on('click', '#collect_reward_daily', function() {
		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'rewards',
				'command': 'daily_redeem',
				'data': {},
				'recaptcha': render
			});
		});
	});

	$(document).on('hide', '#modal_recaptcha', function(){
		grecaptcha.reset(RECAPTCHA);
		$('#modal_recaptcha .modal-body').html('<div class="flex justify-center" id="g-recaptcha"></div>');
	});
});

//CONNECT
var disconnected = false;
function connect_socket() {
	if(!SOCKET) {
		var session = getCookie('session');

		if(app.secure) SOCKET = io(':' + app.port, {
            transports: ['polling'],
            secure: true,
            withCredentials: true
        });
		else SOCKET = io(':' + app.port);

		$('.status-server *').addClass('hidden');
		$('.status-server *[data-status="connecting"]').removeClass('hidden');

		SOCKET.on('connect', function(message) {
			SOCKET.emit('join', {
				session: session,
				paths: app.paths,
				history: profile_settingsGet('history'),
				channel: profile_settingsGet('channel')
			});

			$('.status-server *').addClass('hidden');
			$('.status-server *[data-status="running"]').removeClass('hidden');

			$('#toast-container .toast').remove();

			if(disconnected) disconnected = false;
		});
		SOCKET.on('message', function(message) {
			if(message.data === undefined) onMessageSocket(message.type, message.method);
			else onMessageSocket(message.type, message.method, message.data);
		});
		SOCKET.on('connect_error', function(message) {
			if(disconnected) return;

			toastr['warning']('Reconnecting!', '', {
				timeOut: 0,
				extendedTimeOut: 0
			});

			$('.status-server *').addClass('hidden');
			$('.status-server *[data-status="connection_lost"]').removeClass('hidden');

			disconnected = true;
		});
	}
}

//SENT REQUEST
function send_request_socket(request) {
	if (SOCKET) {
		SOCKET.emit('request', request);
	}
}

function requestRecaptcha(callback){
	$('#modal_recaptcha').modal('show');

	var id = 'g-recaptcha-' + Math.floor(Math.random() * 100000);
	$('#g-recaptcha').html('<div id="' + id + '"></div>');

	RECAPTCHA = grecaptcha.render(id, {
		'sitekey': app.recaptcha.public_key,
		'callback': function() {
			var render = grecaptcha.getResponse(RECAPTCHA);

			callback(render);

			setTimeout(function(){
				$('#modal_recaptcha').modal('hide');

				grecaptcha.reset(RECAPTCHA);
				$('#modal_recaptcha .modal-body').html('<div class="flex justify-center" id="g-recaptcha"></div>');
			}, 1000);
		},
		'theme' : 'dark'
	});
}

//GET REQUEST
function onMessageSocket(type, method, data) {
	if(type == 'site'){
		if(method == 'connected' && !INITIALIZED && !data.maintenance){
            INITIALIZED = true;

			USERID = data.user.userid;

			$('#level_count').text(data.user.level.level);
			$('#level_bar').css('width', roundedToFixed((data.user.level.have - data.user.level.start) / (data.user.level.next - data.user.level.start) * 100, 2).toFixed(2) + '%');

			Object.keys(data.user.settings).forEach(function(item){
				if(profile_settings[item] !== undefined){
					profile_settings[item].value = data.user.settings[item];

					profile_settingsAssign(item, data.user.settings[item], true);
				}
			});

			data.user.balances.forEach(function(item){
				if(item.balance != BALANCES[item.type]){
					$('.balances .list > .balance[data-type="' + item.type + '"]').attr('data-balance', getFormatAmountString(item.balance));
                    $('.balances .list > .balance[data-type="' + item.type + '"] .amount').countToBalance(item.balance);

                    if(item.type == profile_settingsGet('balance')) $('.balances > .balance[data-type="total"] .amount').countToBalance(item.balance);

                    BALANCES[item.type] = item.balance;
                }
			});

			chat_ignoreList = data.chat.listignore;

			$('#chat-area').empty();

			data.chat.messages.forEach(function(message){
				chat_message(message);
			});

			games_intervalAmounts = data.amounts;
			Object.keys(games_intervalAmounts).forEach(function(item){
				var $field = $('.field_element_input[data-amount="' + item + '"]').closest('.input_field');

				if($field.length > 0) changeInputFieldLabel($field);
			});

			$('#pending-offers').empty();
			offers_refreshPendingItems();

			data.offers.p2p_pendings.forEach(function(offer){
				offers_addPending(offer, false);
			});

			data.offers.steam_pendings.forEach(function(offer){
				offers_addPending(offer, false);
			});

			/* FIRST REQUESTS */

            if((app.paths[0] == 'deposit' || app.paths[0] == 'withdraw') && app.paths.length > 1){
                if(app.paths[1] == 'steam' || app.paths[1] == 'p2p'){
                    if(app.paths[1] == 'p2p'){
                        if(app.paths[0] == 'deposit'){
                            send_request_socket({
                                type: 'p2p',
                                command: 'load_inventory',
                                game: app.paths[2]
                            });

                            offers_inventoryIsLoading = true;
                        } else if(app.paths[0] == 'withdraw'){
                            send_request_socket({
                                type: 'p2p',
                                command: 'load_shop',
                                game: app.paths[2]
                            });

                            offers_inventoryIsLoading = true;
                        }
                    } else if(app.paths[1] == 'steam'){
                        if(app.paths[0] == 'deposit'){
                            send_request_socket({
                                type: 'steam',
                                command: 'load_inventory',
                                game: app.paths[2]
                            });

                            offers_inventoryIsLoading = true;
                        } else if(app.paths[0] == 'withdraw'){
                            send_request_socket({
                                type: 'steam',
                                command: 'load_shop',
                                game: app.paths[2]
                            });

                            offers_inventoryIsLoading = true;
                        }
                    }

                    $('#refresh_inventory').addClass('disabled');

                    $('#list_items').html(createLoader());
                    $('#cart-items').empty();
                }
            }

            if(app.paths[0] == 'unboxing' && app.paths.length > 1){
                send_request_socket({
                    'type': 'unboxing',
                    'command': 'show',
                    'id': app.paths[1]
                });

                send_request_socket({
                    'type': 'unboxing',
                    'command': 'spinner',
                    'id': app.paths[1],
                    'amount': 1
                });
            }

            if(app.paths[0] == 'casebattle'){
                if(app.paths.length > 2){
                    if(app.paths[2] == 'finished'){
                        send_request_socket({
                            'type': 'casebattle',
                            'command': 'finished'
                        });
                    } else if(app.paths[2] == 'my'){
                        send_request_socket({
                            'type': 'casebattle',
                            'command': 'my'
                        });
                    }
                } else if(app.paths.length > 1){
                    if(app.paths[1] != 'create'){
                        send_request_socket({
                            'type': 'casebattle',
                            'command': 'show',
                            'id': app.paths[1]
                        });
                    }
                }
            }

            if(app.paths[0] == 'admin'){
                if(app.paths.length > 3){
                    if(app.paths[1] == 'casecreator'){
                        if(app.paths[2] == 'edit' && app.paths[4] === undefined){
                            $('#casecreator_cases').html(createLoader());

                            send_request_socket({
                                'type': 'admin',
                                'command': 'casecreator_cases',
                                'creator': app.paths[3]
                            });
                        } else {
                            if(app.paths[2] == 'edit' && app.paths[4] !== undefined){
                                send_request_socket({
                                    'type': 'admin',
                                    'command': 'casecreator_get',
                                    'creator': app.paths[3],
                                    'id': app.paths[4]
                                });
                            }

                            $('#casecreator_items').html(createLoader());

                            var order = parseInt($('#casecreator_items_order').val());
                            var game = $('#casecreator_items_game').val();
                            var search = $('#casecreator_items_search').val();

                            send_request_socket({
                                'type': 'pagination',
                                'command': 'casecreator_items',
                                'page': 1,
                                'order': order,
                                'game': game,
                                'search': search
                            });
                        }
                    }
                }

                if(app.paths.length > 1){
                    if(app.paths[1] == 'dashboard'){
                        dashboard_initialize();
                    }
                }
            }

            if(app.paths[0] == 'upgrader'){
                if(upgraderGame_inventory) {
                    upgraderGame_items = upgraderGame_inventory.itemid;
                    $('#upgrader_myitems_game').val(upgraderGame_inventory.game);

                    var $field = $('#upgrader_myitems_game').closest('.dropdown_field');
                    changeDropdownFieldElement($field);

                    upgraderGame_inventory = null;
                }

                $('#upgrader_myitems_list').html(createLoader());

                var order = parseInt($('#upgrader_myitems_order').val());
                var game = $('#upgrader_myitems_game').val();

                send_request_socket({
                    'type': 'pagination',
                    'command': 'upgrader_myitems',
                    'page': 1,
                    'order': order,
                    'game': game
                });
            }

            if(app.paths[0] == 'account' && app.paths.length > 1){
                if(app.paths[1] == 'inventory'){
                    $('#account_inventory').html(createLoader());

                    var order = parseInt($('#account_inventory_order').val());
                    var game = $('#account_inventory_game').val();
                    var search = $('#account_inventory_search').val();

                    send_request_socket({
                        'type': 'pagination',
                        'command': 'account_inventory',
                        'page': 1,
                        'order': order,
                        'game': game,
                        'search': search
                    });
                }
            }

            if(app.paths[0] == 'casino'){
                if(app.paths[1] == 'slots' || app.paths[1] == 'live' || app.paths[1] == 'favorites'){
                    if(app.paths[1] == 'slots' && app.paths.length > 3){
                        $('#casino_game').html('<div class="flex fill items-center justify-center width-full height-full text-center font-10 p-4">' + createLoader() + '</div>');

                        send_request_socket({
                            'type': 'casino',
                            'command': 'launch_demo',
                            'id': app.paths[2]
                        });
                    } else if(app.paths[1] == 'slots' && app.paths.length > 2){
                        $('#casino_game').html('<div class="flex fill items-center justify-center width-full height-full text-center font-10 p-4">' + createLoader() + '</div>');

                        send_request_socket({
                            'type': 'casino',
                            'command': 'launch_real',
                            'id': app.paths[2]
                        });
                    } else if(app.paths[1] == 'slots') {
                        var order = parseInt($('#casino_slots_games_order').val());
                        var provider = $('#casino_slots_games_provider').val();
                        var search = $('#casino_slots_games_search').val();

                        send_request_socket({
                            'type': 'pagination',
                            'command': 'casino_slots_games',
                            'page': 1,
                            'order': order,
                            'provider': provider,
                            'search': search
                        });
                    } else if(app.paths[1] == 'live') {
                        var order = parseInt($('#casino_live_games_order').val());
                        var provider = $('#casino_live_games_provider').val();
                        var search = $('#casino_live_games_search').val();

                        send_request_socket({
                            'type': 'pagination',
                            'command': 'casino_live_games',
                            'page': 1,
                            'order': order,
                            'provider': provider,
                            'search': search
                        });
                    } else if(app.paths[1] == 'favorites') {
                        var order = parseInt($('#casino_favorites_games_order').val());
                        var provider = $('#casino_favorites_games_provider').val();
                        var search = $('#casino_favorites_games_search').val();

                        send_request_socket({
                            'type': 'pagination',
                            'command': 'casino_favorites_games',
                            'page': 1,
                            'order': order,
                            'provider': provider,
                            'search': search
                        });
                    }
                }
            }

            if(app.paths[0] == 'user' && app.paths.length > 2){
                if(app.paths[2] == 'inventory'){
                    $('#user_inventory').html(createLoader());

                    var order = parseInt($('#user_inventory_order').val());
                    var game = $('#user_inventory_game').val();
                    var search = $('#user_inventory_search').val();

                    send_request_socket({
                        'type': 'pagination',
                        'command': 'user_inventory',
                        'page': 1,
                        'userid': app.paths[1],
                        'order': order,
                        'game': game,
                        'search': search
                    });
                }
            }

			/* END FIRST REQUESTS */

			if(app.page == 'admin' && app.paths[1] == 'casecreator' && ((app.paths[2] == 'edit' && app.paths.length > 4) || app.paths[2] == 'create')){
				$('#casecreator_case_category').closest('.dropdown_field').find('.field_element_dropdowns').html('<div class="field_element_dropdown" value="0" data-index="0">Unset</div>')

				data.admin.casecreator.categories.forEach(function(item, index){
					$('#casecreator_case_category').closest('.dropdown_field').find('.field_element_dropdowns').append('<div class="field_element_dropdown" value="' + item.id + '" data-index="' + (index + 1) + '">' + item.name + '</div>');
				});
			}

			if(app.page == 'roulette' && data.roulette !== undefined){
				if(data.roulette.info.id !== undefined) {
                    $('#roulette_info_id').val(data.roulette.info.id);
                    $('#roulette_info_id').attr('data-default', data.roulette.info.id);
                }

				if(data.roulette.info.public_seed !== undefined) {
                    $('#roulette_info_public_seed').val(data.roulette.info.public_seed);
                    $('#roulette_info_public_seed').attr('data-default', data.roulette.info.public_seed);
                }

                $('#roulette_hundred_box_red').replaceWith(rouletteHundredHistory({ color: 'red', count: data.roulette.hundred.red }));
                $('#roulette_hundred_box_green').replaceWith(rouletteHundredHistory({ color: 'green', count: data.roulette.hundred.green }));
                $('#roulette_hundred_box_black').replaceWith(rouletteHundredHistory({ color: 'black', count: data.roulette.hundred.black }));
                $('#roulette_hundred_box_bait').replaceWith(rouletteHundredHistory({ color: 'bait', count: data.roulette.hundred.bait }));

				$('#roulette_rolls').empty();
				data.roulette.history.forEach(function(item){
					rouletteGame_addHistory(item);
				});

                $('#roulette_case').replaceWith(rouletteCase());
				initializingSpinner_Roulette(data.roulette.last);

				$('.roulette-betslist').empty();
				data.roulette.bets.forEach(function(item){
					rouletteGame_addBet(item);
				});

                [ 'red', 'green', 'black', 'bait' ].forEach(function(item){
                    $('#roulette_panel_' + item + ' .roulette-betstotal').replaceWith(rouletteTotalBets({ count: data.roulette.totals[item].count, amount: getFormatAmountString(data.roulette.totals[item].amount) }));
                });

                $('#roulette_jackpot').replaceWith(rouletteJackpot({ greens: data.roulette.jackpot.greens, amount: getFormatAmountString(data.roulette.jackpot.total) }));
            } else if(app.page == 'crash' && data.crash !== undefined){
				$('#crash_graph').replaceWith(crashGraph());

                if(data.crash.info.id !== undefined) {
                    $('#crash_info_id').val(data.crash.info.id);
                    $('#crash_info_id').attr('data-default', data.crash.info.id);
                }

				if(data.crash.info.public_seed !== undefined) {
                    $('#crash_info_public_seed').val(data.crash.info.public_seed);
                    $('#crash_info_public_seed').attr('data-default', data.crash.info.public_seed);
                }

				$('#crash_history').empty();
				data.crash.history.forEach(function(crash){
					crashGame_addHistory(crash);
				});

				$('#crash_betlist').html('<div class="table-row height-full history_message"><div class="table-column text-center">No users in game</div></div>');

				data.crash.bets.forEach(function(bet){
					crashGame_addGame(bet);
				});
			} else if(app.page == 'jackpot' && data.jackpot !== undefined){
				$('#jackpot_case').replaceWith(jackpotCase());

                $('#jackpot_field').empty();

				if(data.jackpot.avatars.length > 0){
					for(var i = 0; i < 2; i++){
						data.jackpot.avatars.forEach(function(item){
							var DIV = '<div class="reel-item flex justify-center items-center"><img class="width-full height-full" src="' + item + '"></div>';

							$('#jackpot_field').append(DIV);
						});
					}
				} else {
					for(var i = 0; i < 50; i++){
						var DIV = '<div class="reel-item flex justify-center items-center"><img class="width-full height-full" src="/img/jackpot/avatar.jpg"></div>';

						$('#jackpot_field').append(DIV);
					}
				}

				idleSpinner_Jackpot = true;

				$('#jackpot_betlist').html('<div class="in-grid flex justify-center items-center font-8 history_message">No users in game</div>');

				data.jackpot.bets.forEach(function(bet){
					jackpotGame_addBet(bet);
				});

				$('#jackpot_info_hash').text(data.jackpot.hash);
				$('#jackpot_total').countToFloat(data.jackpot.total);
				$('#jackpot_mychange').countToFloat(data.jackpot.chance);

				$('#jackpot_histories').empty();

				data.jackpot.history.forEach(function(history){
					jackpotGame_addHistory(history);
				});

                $('#fair_jackpot_results').attr('data-fair', JSON.stringify({ game: data.jackpot.fair, draw: null }));
			} else if(app.page == 'coinflip' && data.coinflip !== undefined){
				$('#coinflip_betlist').empty();
				for(var i = 0; i < 5; i++){
					$('#coinflip_betlist').append('<div class="coinflip-game bg-secondary rounded-1 b-l2"></div>');
				}

				data.coinflip.bets.forEach(function(bet){
					coinflipGame_addCoinFlip(bet.coinflip);
					if(bet.status > 0) coinflipGame_editCoinFlip(bet.coinflip, bet.status);
				});
			} else if(app.page == 'dice' && data.dice !== undefined){

			} else if(app.page == 'unboxing' && data.unboxing !== undefined){
				$('#unboxing_list_categories').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases available for unboxing</div>');

				data.unboxing.categories.forEach(function(item){
					unboxingGame_addCategory(item);
				});

				data.unboxing.cases.forEach(function(item){
					unboxingGame_addCase(item);
				});

				$('#unboxing_history').html('<div class="history_message flex justify-center items-center width-full height-full">No cases unboxed</div>');

				data.unboxing.history.forEach(function(history){
					unboxingGame_addHistory(history);
				});
			} else if(app.page == 'upgrader' && data.upgrader !== undefined){

			} else if(app.page == 'casebattle' && data.casebattle !== undefined){
				$('#casebattle_betlist').html('<div class="in-grid bg-card flex justify-center items-center font-8 p-4 history_message">No active case battles</div>');

				if(app.paths.length > 2){
					if(app.paths[2] == 'active'){
						data.casebattle.bets.forEach(function(bet){
							caseBattleGame_addCaseBattle(bet.casebattle);
							if(bet.status > 0) caseBattleGame_editCaseBattle(bet.casebattle, bet.status, true);
						});

						caseBattleGame_filterHide();
						caseBattleGame_filterOrder();
					}
				}

				$('#casebattle_stats_active').text(data.casebattle.stats.active);
				$('#casebattle_stats_total').text(data.casebattle.stats.total);
			} else if(app.page == 'minesweeper' && data.minesweeper !== undefined){
				$('#minesweeper_bombs .item').removeClass('danger').removeClass('success').addClass('disabled');
				$('#minesweeper_bombs .item .multiplier').text('');

				$('#minesweeper_bet').removeClass('hidden').removeClass('disabled');
				$('#minesweeper_cashout').addClass('hidden');

				$('.bet-cashout').addClass('disabled');

				if(data.minesweeper.game.active){
					$('#minesweeper_bombs .item').removeClass('disabled');

					$('#minesweeper_bet').addClass('hidden');
					$('#minesweeper_cashout').removeClass('hidden').removeClass('disabled');

					$('#bombsamount_minesweeper').closest('.input_field').addClass('disabled');
					$('.minesweeper-bombsamount').addClass('disabled');

					$('.bet-cashout').removeClass('disabled');

					$('#minesweeper_cashout_amount').countToFloat(data.minesweeper.game.total);
					$('#minesweeper_cashout_profit').countToProfit(data.minesweeper.game.profit);

					data.minesweeper.game.route.forEach(function(button, stage){
						$('#minesweeper_bombs .item[data-bomb="' + button + '"]').addClass('success');
						$('#minesweeper_bombs .item[data-bomb="' + button + '"] .multiplier').text('x' + data.minesweeper.game.multipliers[stage].toFixed(2));
					});
				}
			} else if(app.page == 'tower' && data.tower !== undefined){
				$('#tower_grid .item').removeClass('danger').removeClass('success').removeClass('checked');
				$('#tower_grid .item').addClass('disabled');

				$('#tower_bet').removeClass('hidden');
				$('#tower_cashout').addClass('hidden');

				$('.bet-cashout').addClass('disabled');

				towerGame_multipliers = data.tower.multipliers;

				if(data.tower.game.active){
					towerGame_difficulty = data.tower.game.difficulty;

					$('#tower_difficulty').closest('.dropdown_field').addClass('disabled');
				}

				towerGame_generateTiles();

				if(data.tower.game.active){
					$('#tower_bet').addClass('hidden');
					$('#tower_cashout').removeClass('hidden').removeClass('disabled');

					$('#tower_difficulty').closest('.dropdown_field').addClass('disabled');

					$('.bet-cashout').removeClass('disabled');

					$('#tower_cashout_amount').countToFloat(data.tower.game.total);
					$('#tower_cashout_profit').countToProfit(data.tower.game.profit);

					data.tower.game.route.forEach(function(button, stage){
						$('#tower_grid .item[data-stage="' + stage + '"][data-button="' + button + '"]').addClass('success').removeClass('disabled');
						$('#tower_grid .item[data-stage="' + stage + '"]:not(.success)').addClass('checked').removeClass('disabled');
					});

					$('#tower_grid .item[data-stage="' + data.tower.game.route.length + '"]').removeClass('disabled');

					towerGame_generateAmounts(data.tower.game.amount);
				} else towerGame_generateAmounts(0.01);
			} else if(app.page == 'plinko' && data.plinko !== undefined){
				plinkoGame_multipliers = data.plinko.multipliers;

				plinkoGame_generateRows();
				plinkoGame_generateMultipliers();
			} else if(app.page == 'casino' && data.casino !== undefined){

			} else if(app.page == 'deposit' || app.page == 'withdraw'){
				if(app.paths[1] == 'crypto'){
					offers_currencyAmounts = data.offers.crypto.amounts;
					offers_currencyFees = data.offers.crypto.fees;

					if(app.paths.length > 1) $('.crypto-panel [data-conversion="from"]').trigger('input');
				}

				if(app.page == 'withdraw' && app.paths[1] == 'steam'){
					$('#steam_bots').empty();

					data.offers.steam_bots.forEach(function(bot){
						var DIV = '<div class="steam-bot pointer flex items-center justify-center gap-1 rounded-1 bg-card b-d2 p-1 ' + (bot.active ? '' : 'disabled') + '" data-bot="' + bot.index + '">Bot #' + (bot.index + 1) + ' - Status<div class="flex rounded-full p-1 bg-' + (bot.active ? 'success' : 'danger') + '"></div></div>'

						$('#steam_bots').append(DIV);
					});

					$('.steam-bot:not(.disabled)').first().addClass('active');
				}
			}
		} else if(method == 'online'){
			Object.keys(data.online).forEach(function(item){
				$('.online[data-channel="' + item + '"]').text(data.online[item]);
			});
		} else if(method == 'notify'){

		} else if(method == 'reload'){
			location.reload();
		} else if(method == 'refresh'){
			//site_refresh();
		}
	}

	if(type == 'message'){
		if(method == 'info'){
			notify('info', data.message);
		} else if(method == 'success'){
			notify('success', data.message);
		} else if(method == 'error'){
			if((app.page == 'deposit' || app.page == 'withdraw') && (app.paths[1] == 'steam' || app.paths[1] == 'p2p') && app.paths.length > 2 && offers_inventoryIsLoading){
				$('#refresh_inventory').removeClass('disabled');

				$('#list_items').html('<div class="in-grid font-8 history_message">' + data.message + '</div>');

				offers_inventoryIsLoading = false;
			} else if(app.page == 'casino' && app.paths.length > 2){
				$('#casino_game').html('<div class="flex fill items-center justify-center width-full height-full text-center font-10 p-4">' + data.message + '</div>');
			} else notify('error', data.message);

			if(app.page == 'roulette'){
				$('.roulette-bet.disabled').removeClass('disabled');
			} else if(app.page == 'crash'){
				$('#crash_bet.disabled').removeClass('disabled');
				$('#crash_cashout.disabled').removeClass('disabled');
			} else if(app.page == 'jackpot'){
				$('#jackpot_bet.disabled').removeClass('disabled');
			} else if(app.page == 'coinflip'){
				$('#coinflip_create.disabled').removeClass('disabled');
				$('#coinflip_join.disabled').removeClass('disabled');
			} else if(app.page == 'dice'){
				$('#dice_bet.disabled').removeClass('disabled');
				$('#dice_chanceslider').removeClass('disabled');
				$('.dice-mode').removeClass('disabled');
			} else if(app.page == 'unboxing'){
				$('#unboxing_open.disabled').removeClass('disabled');
				$('#unboxing_demo.disabled').removeClass('disabled');
			} else if(app.page == 'upgrader'){
				$('#upgrader_bet.disabled').removeClass('disabled');
				$('.upgrader-multiplier.disabled').removeClass('disabled');
				$('#upgrader_mode.disabled').removeClass('disabled');
				$('#upgrader_roll.disabled').removeClass('disabled');
				$('#upgrader_betamount').closest('.slider_field.disabled').removeClass('disabled');
				$('.upgrader-inventory.disabled').removeClass('disabled');
			} else if(app.page == 'minesweeper'){
				$('#minesweeper_bet.disabled').removeClass('disabled');
				$('#minesweeper_cashout.disabled').removeClass('disabled');
			} else if(app.page == 'tower'){
				$('#tower_bet.disabled').removeClass('disabled');
				$('#tower_cashout.disabled').removeClass('disabled');
			} else if(app.page == 'plinko'){
				$('#plinko_bet.disabled').removeClass('disabled');
			}

			$('#dailycases_open.disabled').removeClass('disabled');

			sounds_play('error');
		}
	}

	if(type == 'user'){
		if(method == 'balance'){
            if(data.balance.balance != BALANCES[data.balance.type]){
                $('.balances .list > .balance[data-type="' + data.balance.type + '"]').attr('data-balance', getFormatAmountString(data.balance.balance));
                $('.balances .list > .balance[data-type="' + data.balance.type + '"] .amount').countToBalance(data.balance.balance);

                if(data.balance.type == profile_settingsGet('balance')) $('.balances > .balance[data-type="total"] .amount').countToBalance(data.balance.balance);

                BALANCES[data.balance.type] = data.balance.balance;
            }
		} else if(method == 'level'){
			$('#level_count').text(data.level.level);
			$('#level_bar').css('width', roundedToFixed((data.level.have - data.level.start) / (data.level.next - data.level.start) * 100, 2).toFixed(2) + '%');
		}
	}

	if(type == 'account' && app.page == 'account'){
		if(method == 'remove_session'){
			$('#my_devices .device_session[data-session="' + data.session + '"]').remove();

			if($('#my_devices .device_session').length <= 0) $('#my_devices').html('<div class="table-row history_message"><div class="table-column text-center">No data found</div></div>');
		} else if(method == 'email_verification'){
            $('#modal_twofa_email_verification').modal('show');
        } else if(method == 'authenticator_app'){
            $('#authenticator_app_secret').text(data.secret);
            $('#authenticator_app_secret_copy').attr('data-text', data.secret);

            $('#authenticator_app_qrcode').empty();

            var qrcode = new QRCode($('#authenticator_app_qrcode')[0], {
                text: data.url,
                width: 192,
                height: 192,
            });

            $('#modal_twofa_authenticator_app').modal('show');
        } else if(method == 'authenticator_app_codes'){
            $('#authenticator_app_codes').empty();
            data.codes.forEach(function(item){
                if(item.used) $('#authenticator_app_codes').append('<div class="bg-card bg-opacity-50 rounded-1 p-2 text-center disabled">' + item.code + '</div>');
                else $('#authenticator_app_codes').append('<div class="bg-card bg-opacity-50 rounded-1 p-2 text-center">' + item.code + '</div>');
            });

            $('#authenticator_app_codes_copy').attr('data-text', data.codes.map(a => a.code).join('\n'));
            $('#authenticator_app_codes_download').attr('data-text', data.codes.map(a => a.code).join('\n'));

            $('#modal_twofa_authenticator_app_codes').modal('show');
        } else if(method == 'enable_twofa_method'){
            $('.account-security .security-method[data-method="' + data.method + '"]').addClass('enabled');

            $('#modal_twofa_email_verification').modal('hide');
            $('#modal_twofa_authenticator_app').modal('hide');
        } else if(method == 'disable_twofa_method'){
            $('.account-security .security-method[data-method="' + data.method + '"]').removeClass('enabled').removeClass('primary');
        } else if(method == 'primary_twofa_method'){
            $('.account-security .security-method').removeClass('primary');
            $('.account-security .security-method[data-method="' + data.method + '"]').addClass('primary');
        }
	}

	if(type == 'modal'){
		if(method == 'insufficient_balance'){
			$('#modal_error_insufficient_balance .amount').text(getFormatAmountString(data.amount));

			$('#modal_error_insufficient_balance').modal('show');
		} else if(method == 'withdraw_rollover'){
            $('#modal_error_withdraw_rollover .amount').text(getFormatAmountString(data.amount));

			$('#modal_error_withdraw_rollover').modal('show');
		} else if(method == 'auth'){
			$('#modal_error_auth').modal('show');
		} else if(method == 'bind_steam'){
			$('#modal_error_bind_steam').modal('show');
		} else if(method == 'steam_tradelink'){
			$('#modal_error_steam_tradelink').modal('show');
		} else if(method == 'steam_webapi_token'){
			$('#modal_error_steam_webapi_token').modal('show');
		} else if(method == 'command_online'){
			$('#online_list').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No players online</div>');

			var list = data.list.sort((a, b) => a.level - b.level).sort((a, b) => a.rank - b.rank).sort((a, b) => b.guest - a.guest);

			list.forEach(function(item){
				$('#online_list .history_message').remove();

				var DIV = '<div class="flex justify-center items-center height-full width-full">';
					DIV += '<a href="/user/' + item.user.userid + '" target="_blank">' + createAvatarField(item.user, 'medium', '', '') + '</a>';
				DIV += '</div>';

				$('#online_list').prepend(DIV);
			});

			$('#modal_command_online').modal('show');
		} else if(method == 'command_help'){
			$('#chat_commands').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No commands available</div>');

			data.commands.forEach(function(item){
				$('#chat_commands .history_message').remove();

				var name = item.command;
				if(item.arguments.length > 0) name += ' ' + item.arguments.join(' ').replaceAll('<', '&lt').replaceAll('>', '&gt');

				var DIV = '<div class="acordeon-item transition-2">';
					DIV += '<div class="acordeon-trigger font-8 text-space-1 p-4 pointer">/' + name + '</div>';

					DIV += '<div class="acordeon-content transition-2 overflow-h pr-4 pl-4">';
						DIV += '<div class="flex column gap-2 pb-4">';
							item.help.forEach(function(help){
								DIV += '<div>' + help.replaceAll('<', '&lt').replaceAll('>', '&gt') + '</div>';
							});
						DIV += '</div>';
					DIV += '</div>';
				DIV += '</div>';

				$('#chat_commands').append(DIV);
			});

			$('#modal_command_help').modal('show');
		} else if(method == 'command_tip'){
			$('#tip_player_avatar').html(createAvatarField(data.user, 'small', '', ''));
			$('#tip_player_name').text(data.user.name);
			$('#send_tip_player').attr('data-userid', data.user.userid);

			$('#modal_command_tip').modal('show');
		} else if(method == 'command_mute'){
			$('#mute_player_avatar').html(createAvatarField(data.user, 'small', '', ''));
			$('#mute_player_name').text(data.user.name);
			$('#mute_player_set').attr('data-userid', data.user.userid);
			$('#mute_player_permanently').attr('data-userid', data.user.userid);

			$('#modal_command_mute').modal('show');
		} else if(method == 'command_ignorelist'){
			$('#chat_ignorelist').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No ignored players</div>');

			data.list.forEach(function(item){
				chat_addIgnore(item.user, item.time);
			});

			$('#modal_command_ignorelist').modal('show');
		}
	}

	if(type == 'rewards' && app.page == 'rewards'){
		if(method == 'timer'){
			var time_daily = data.time;

			clearInterval(interval_daily);

			var interval_daily = setInterval( function(){
				if(time_daily <= 0){
					$('#collect_reward_daily').text('Collect').removeClass('disabled');
					clearInterval(interval_daily);

					return;
				}

				$('#collect_reward_daily').text(getFormatSeconds(time_daily).hours + ':' + getFormatSeconds(time_daily).minutes + ':' + getFormatSeconds(time_daily).seconds).addClass('disabled');
				time_daily--;
			},1000);
		}
	}

	if(type == 'chat'){
		if(method == 'message'){
			chat_message(data.message);
		} else if(method == 'messages'){
			$('#chat-area').empty();

			data.messages.forEach(function(message){
				chat_message(message);
			});
		} else if(method == 'delete'){
			$('.chat-message[data-message="' + data.id + '"]').remove();
		} else if(method == 'ignorelist'){
			chat_ignoreList = data.list;

			$('#chat_ignorelist .chat-ignore').each(function(i, e){
				if(!chat_ignoreList.includes($(this).attr('data-userid'))) $(this).remove();
			});

			if($('#chat_ignorelist .chat-ignore').length <= 0) $('#chat_ignorelist').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No ignored players</div>');
		} else if(method == 'clean'){
			$('#chat-area').empty();
		} else if(method == 'channel'){
			$('#chat-area').empty();

			profile_settingsChange('channel', data.channel);

			data.messages.forEach(function(message){
				chat_message(message);
			});
		} else if(method == 'commands'){
			$('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').empty();

			if(!data.message['private']) $('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<a class="chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" href="/user/' + data.message.user.userid + '"><i class="fa fa-user" aria-hidden="true"></i><span class="text-bold">View Profile</span></a>');
			$('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_write_command chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-command="@' + data.message.user.userid + '"><i class="fa fa-bell" aria-hidden="true"></i><span class="text-bold">Mention</span></div>');
			$('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_reply_message chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-reply="' + stringEscape(JSON.stringify({ id: data.message.id, message: data.message.message, user: { avatar: data.message.user.avatar, name: data.message.user.name } })) + '"><i class="fa fa-reply" aria-hidden="true"></i><span class="text-bold">Reply Message</span></div>');

			if(data.commands.some(a => a == 'tip')) $('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_send_command chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-command="/tip ' + data.message.user.userid + '"><i class="fa fa-gift" aria-hidden="true"></i><span class="text-bold">Tip Player</span></div>');

			if(data.commands.some(a => a == 'ignore')) {
				if(data.ignored) $('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_send_command chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-command="/unignore ' + data.message.user.userid + '"><i class="fa fa-eye" aria-hidden="true"></i><span class="text-bold">Unignore Player</span></div>');
				else $('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_send_command chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-command="/ignore ' + data.message.user.userid + '"><i class="fa fa-eye-slash" aria-hidden="true"></i><span class="text-bold">Ignore Player</span></div>');
			}

			if(data.commands.some(a => a == 'mute')) {
				if(data.muted) $('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_send_command chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-command="/unmute ' + data.message.user.userid + '"><i class="fa fa-volume-up" aria-hidden="true"></i><span class="text-bold">Unute Player</span></div>');
				else $('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_send_command chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-command="/mute ' + data.message.user.userid + '"><i class="fa fa-volume-off" aria-hidden="true"></i><span class="text-bold">Mute Player</span></div>');
			}

			if(data.commands.some(a => a == 'pinmessage')) $('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_send_command chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-command="/pinmessage ' + data.message.id + '"><i class="fa fa-flag" aria-hidden="true"></i><span class="text-bold">Pin Message</span></div>');
			if(data.commands.some(a => a == 'deletemessage')) $('#chat-area .chat-message[data-message="' + data.message.id + '"] .chat-message-menu').append('<div class="chat_send_command chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1" data-command="/deletemessage ' + data.message.id + '"><i class="fa fa-trash" aria-hidden="true"></i><span class="text-bold">Delete Message</span></div>');
		}
	}

	if(type == 'rain'){
		if(method == 'started'){
			$('#chat_rain').removeClass('waiting').addClass('started');

			$('#chat_rain .started .amount').text(getFormatAmountString(data.amount));

			if(data.joined) {
				$('#chat_rain_join').addClass('hidden');
				$('#chat_rain_joined').removeClass('hidden');
			} else {
				$('#chat_rain_joined').addClass('hidden');
				$('#chat_rain_join').removeClass('hidden');
			}

			if(chat_rainInterval) clearInterval(chat_rainInterval);

			$('#chat_rain_progress').animate({
				'width': '0'
			}, {
				'duration': data.time * 1000,
				'easing': 'linear',
				'progress': function(animation, progress, remaining) {
					var las = remaining / 1000 * 100 / data.cooldown;

					$('#chat_rain_progress').css('width', las + '%');
				}
			});

			$('#chat_rain_tip').addClass('disabled');
		} else if(method == 'waiting'){
			$('#chat_rain').removeClass('started').addClass('waiting');

			if(chat_rainInterval) clearInterval(chat_rainInterval);

			if(data.last != null) {
				$('#chat_rain .waiting .description').removeClass('hidden');
				$('#chat_rain_first').addClass('hidden');

				var TIMER = '<script>';
					TIMER += 'var chat_rain_last = ' + data.last + ';';
					TIMER += 'chat_rainInterval = setInterval(function(){';
						TIMER += '$("#chat_rain_last").text(parseInt((time() - chat_rain_last) / 60) + " minutes ago");';
					TIMER += '}, 1000);';
				TIMER += '</script>';
				TIMER += '<span id="chat_rain_last">' + Math.floor((time() - data.last) / 60) + ' minutes ago</span>';

				$('#chat_rain_timer').html(TIMER);
			} else {
				$('#chat_rain .waiting .description').addClass('hidden');
				$('#chat_rain_first').removeClass('hidden');
			}

			$('#chat_rain .waiting .amount').countToFloat(data.amount);

			$('#chat_rain_progress').finish();

			$('#chat_rain_tip').removeClass('disabled');
		} else if(method == 'joined'){
			$('#chat_rain_join').addClass('hidden');
			$('#chat_rain_joined').removeClass('hidden');
		} else if(method == 'amount'){
			$('#chat_rain .waiting .amount').countToFloat(data.amount);
		}
	}

	if(type == 'inventory'){
		if(method == 'sell_item'){
			$('#inventory_list .inventory-item[data-id="' + data.id + '"]').remove();

			$('#account_inventory .inventory-item[data-id="' + data.id + '"]').addClass('notaccepted');
			$('#account_inventory .inventory-item[data-id="' + data.id + '"]').attr('data-status', -1);
			$('#account_inventory .inventory-item[data-id="' + data.id + '"] .item-info').replaceWith('<div class="item-info text-danger text-right">Sold</div>');

            tinysort('#account_inventory .listing-item', {
                data: 'status',
                order: 'desc'
            });

			if(data.inventory.count > 0) $('#inventory_sell_all').removeClass('hidden');
			else $('#inventory_sell_all').addClass('hidden');

			$('#inventory_value').text(getFormatAmountString(data.inventory.value));
		} else if(method == 'sell_items'){
			$('#inventory_list').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No data found</div></div>');

            data.ids.forEach(function(id){
				$('#account_inventory .inventory-item[data-id="' + id + '"]').addClass('notaccepted');
			    $('#account_inventory .inventory-item[data-id="' + id + '"]').attr('data-status', -1);
			    $('#account_inventory .inventory-item[data-id="' + id + '"] .item-info').replaceWith('<div class="item-info text-danger text-right">Sold</div>');
			});

            tinysort('#account_inventory .listing-item', {
                data: 'status',
                order: 'desc'
            });

	        $('#inventory_sell_all').addClass('hidden');

			$('#inventory_value').text(getFormatAmountString(0));
		}
	}

	if(type == 'dailycases'){
		if(method == 'cases'){
			$('#dailycases_cases').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No daily cases found</div>');

			data.cases.forEach(function(item){
				dailycases_addCase(item, data.level);
			});
		} else if(method == 'countdown'){
			dailycases_countdownCase(data.dailycase);
		} else if(method == 'show'){
			dailycases_showCase(data.items, data.dailycase, data.level, data.spinner);
		} else if(method == 'roll'){
			dailycases_openCase(data.items);

			sounds_play('play');
		} else if(method == 'finish'){
			$('#dailycases_open').removeClass('disabled');
		}
	}

	if(type == 'casecreator' && app.page == 'admin' && app.paths[1] == 'casecreator'){
		if(method == 'cases'){
			$('#casecreator_cases').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases found</div>');

			data.cases.forEach(function(item){
				casecreator_addCase(item, data.creator);
			});
		} else if(method == 'remove'){
			$('#casecreator_cases .case-item[data-id="' + data.id + '"]').remove();

			if($('#casecreator_cases .case-item').length <= 0) $('#casecreator_cases').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases found</div>');
		} else if(method == 'case'){
			$('#casecreator_case_name').val(data.data.name).trigger('input');
			changeInputFieldLabel($('#casecreator_case_name').closest('.input_field'));

			$('#casecreator_case_image').closest('.file_field').find('.field_file').addClass('active').find('img').attr('src', '/img/' + app.paths[3] + '/' + data.data.image);

			if(data.creator == 'cases'){
				if(data.data.battle) $('#casecreator_case_battle').attr('checked', 'true').trigger('change');

				$('#casecreator_case_category').val(data.data.category);

				var $field = $('#casecreator_case_category').closest('.dropdown_field');
				changeDropdownFieldElement($field);
			} else if(data.creator == 'dailycases'){
				$('#casecreator_case_level').val(data.data.level).trigger('input');
				changeInputFieldLabel($('#casecreator_case_level').closest('.input_field'));
			}

			$('#casecreator_case_items').empty();

			data.data.items.forEach(function(item){
				casecreator_selectItem(item.item, item.chance);
			});

			var file = new File([new Uint8Array(data.data.buffer)], {});

			var dataTransfer = new DataTransfer();
			dataTransfer.items.add(file);

			document.querySelector('#casecreator_case_image').files = dataTransfer.files;
		} else if(method == 'redirect'){
			window.location.href = '/admin/casecreator/edit/' + data.creator + '/' + data.caseid;
		} else if(method == 'categories_list'){
			$('#casecreator_categories_list').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No unboxing categories found</div>');

			data.categories.forEach(function(item){
				casecreator_addCategory(item);
			});

			initializeSwitchFields();
		} else if(method == 'categories_create'){
			initializeSwitchFields();

			casecreator_addCategory(data.category);

			initializeSwitchFields();
		} else if(method == 'categories_edit'){
			if(data.category.visible) $('#casecreator_categories_list .casecreator-categories-item[data-id="' + data.category.id + '"]').addClass('active');
			else $('#casecreator_categories_list .casecreator-categories-item[data-id="' + data.category.id + '"]').removeClass('active');

			$('#casecreator_categories_list .casecreator-categories-item[data-id="' + data.category.id + '"] .visible').text([ 'Hidden', 'Visible' ][data.category.visible]);
		} else if(method == 'categories_remove'){
			$('#casecreator_categories_list .casecreator-categories-item[data-id="' + data.category.id + '"]').remove();

			if($('#casecreator_categories_list .casecreator-categories-item').length <= 0) $('#casecreator_categories_list').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No unboxing categories found</div>');
		}
	}

	if(type == 'pagination'){
		if(method == 'admin_users'){
			pagination_addUsers(data.list);

			pagination_create('#pagination_admin_users', data.pages, data.page);
		} else if(method == 'admin_crypto_confirmations'){
			pagination_addCryptoConfirmations(data.list);

			pagination_create('#pagination_admin_crypto_confirmations', data.pages, data.page);
		} else if(method == 'admin_steam_confirmations'){
			pagination_addSteamConfirmations(data.list);

			pagination_create('#pagination_admin_steam_confirmations', data.pages, data.page);
		} else if(method == 'admin_tracking_links'){
			pagination_addTrackingLinks(data.list);

			pagination_create('#pagination_admin_tracking_links', data.pages, data.page);
		} else if(method == 'admin_deposit_bonuses'){
			pagination_addDepositBonuses(data.list);

			pagination_create('#pagination_admin_deposit_bonuses', data.pages, data.page);
		} else if(method == 'account_transactions'){
			pagination_addAccountTransactions(data.list);

			pagination_create('#pagination_account_transactions', data.pages, data.page);
		} else if(method == 'account_deposits'){
			pagination_addAccountDeposits(data.list);

			pagination_create('#pagination_account_deposits', data.pages, data.page);
		} else if(method == 'account_withdrawals'){
			pagination_addAccountWithdrawals(data.list);

			pagination_create('#pagination_account_withdrawals', data.pages, data.page);
		} else if(method == 'account_roulette_history'){
			pagination_addAccountRouletteHistory(data.list);

			pagination_create('#pagination_account_roulette_history', data.pages, data.page);
		} else if(method == 'account_crash_history'){
			pagination_addAccountCrashHistory(data.list);

			pagination_create('#pagination_account_crash_history', data.pages, data.page);
		} else if(method == 'account_jackpot_history'){
			pagination_addAccountJackpotHistory(data.list);

			pagination_create('#pagination_account_jackpot_history', data.pages, data.page);
		} else if(method == 'account_coinflip_history'){
			pagination_addAccountCoinflipHistory(data.list);

			pagination_create('#pagination_account_coinflip_history', data.pages, data.page);
		} else if(method == 'account_dice_history'){
			pagination_addAccountDiceHistory(data.list);

			pagination_create('#pagination_account_dice_history', data.pages, data.page);
		} else if(method == 'account_unboxing_history'){
			pagination_addAccountUnboxingHistory(data.list);

			pagination_create('#pagination_account_unboxing_history', data.pages, data.page);
		} else if(method == 'account_casebattle_history'){
			pagination_addAccountCasebattleHistory(data.list);

			pagination_create('#pagination_account_casebattle_history', data.pages, data.page);
		} else if(method == 'account_upgrader_history'){
			pagination_addAccountUpgraderHistory(data.list);

			pagination_create('#pagination_account_upgrader_history', data.pages, data.page);
		} else if(method == 'account_tower_history'){
			pagination_addAccountTowerHistory(data.list);

			pagination_create('#pagination_account_tower_history', data.pages, data.page);
		} else if(method == 'account_minesweeper_history'){
			pagination_addAccountMinesweeperHistory(data.list);

			pagination_create('#pagination_account_minesweeper_history', data.pages, data.page);
		} else if(method == 'account_plinko_history'){
			pagination_addAccountPlinkoHistory(data.list);

			pagination_create('#pagination_account_plinko_history', data.pages, data.page);
		} else if(method == 'account_casino_history'){
			pagination_addAccountCasinoHistory(data.list);

			pagination_create('#pagination_account_casino_history', data.pages, data.page);
		} else if(method == 'account_inventory'){
			pagination_addAccountInventory(data.list);

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_account_inventory').html(DIV);
		} else if(method == 'user_transactions'){
			pagination_addUserTransactions(data.list);

			pagination_create('#pagination_user_transactions', data.pages, data.page);
		} else if(method == 'user_deposits'){
			pagination_addUserDeposits(data.list);

			pagination_create('#pagination_user_deposits', data.pages, data.page);
		} else if(method == 'user_withdrawals'){
			pagination_addUserWithdrawals(data.list);

			pagination_create('#pagination_user_withdrawals', data.pages, data.page);
		} else if(method == 'user_roulette_history'){
			pagination_addUserRouletteHistory(data.list);

			pagination_create('#pagination_user_roulette_history', data.pages, data.page);
		} else if(method == 'user_crash_history'){
			pagination_addUserCrashHistory(data.list);

			pagination_create('#pagination_user_crash_history', data.pages, data.page);
		} else if(method == 'user_jackpot_history'){
			pagination_addUserJackpotHistory(data.list);

			pagination_create('#pagination_user_jackpot_history', data.pages, data.page);
		} else if(method == 'user_coinflip_history'){
			pagination_addUserCoinflipHistory(data.list);

			pagination_create('#pagination_user_coinflip_history', data.pages, data.page);
		} else if(method == 'user_dice_history'){
			pagination_addUserDiceHistory(data.list);

			pagination_create('#pagination_user_dice_history', data.pages, data.page);
		} else if(method == 'user_unboxing_history'){
			pagination_addUserUnboxingHistory(data.list);

			pagination_create('#pagination_user_unboxing_history', data.pages, data.page);
		} else if(method == 'user_casebattle_history'){
			pagination_addUserCasebattleHistory(data.list);

			pagination_create('#pagination_user_casebattle_history', data.pages, data.page);
		} else if(method == 'user_upgrader_history'){
			pagination_addUserUpgraderHistory(data.list);

			pagination_create('#pagination_user_upgrader_history', data.pages, data.page);
		} else if(method == 'user_tower_history'){
			pagination_addUserTowerHistory(data.list);

			pagination_create('#pagination_user_tower_history', data.pages, data.page);
		} else if(method == 'user_minesweeper_history'){
			pagination_addUserMinesweeperHistory(data.list);

			pagination_create('#pagination_user_minesweeper_history', data.pages, data.page);
		} else if(method == 'user_plinko_history'){
			pagination_addUserPlinkoHistory(data.list);

			pagination_create('#pagination_user_plinko_history', data.pages, data.page);
		} else if(method == 'user_casino_history'){
			pagination_addUserCasinoHistory(data.list);

			pagination_create('#pagination_user_casino_history', data.pages, data.page);
		} else if(method == 'user_inventory'){
			pagination_addUserInventory(data.list);

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_user_inventory').html(DIV);
		} else if(method == 'affiliates_referrals'){
			pagination_addAffiliatesReferrals(data.list);

			pagination_create('#pagination_affiliates_referrals', data.pages, data.page);
		} else if(method == 'casecreator_items'){
			pagination_addCaseCreatorItems(data.list);

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_casecreator_items').html(DIV);
		} else if(method == 'inventory_items'){
			pagination_addInventoryItems(data.list);

			if(data.inventory.count > 0) $('#inventory_sell_all').removeClass('hidden');
			else $('#inventory_sell_all').addClass('hidden');

			$('#inventory_value').text(getFormatAmountString(data.inventory.value));

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_inventory_items').html(DIV);
		} else if(method == 'upgrader_myitems'){
			pagination_addUpgraderMyItems(data.list);

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_upgrader_myitems').html(DIV);
		} else if(method == 'upgrader_siteitems'){
			pagination_addUpgraderSiteItems(data.list);

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_upgrader_siteitems').html(DIV);
		} else if(method == 'admin_gamebots'){
			pagination_addGamebots(data.list);

			pagination_create('#pagination_admin_gamebots', data.pages, data.page);
		} else if(method == 'support_requests'){
			pagination_addSupportRequests(data.list);

			pagination_create('#pagination_support_requests', data.pages, data.page);
		} else if(method == 'admin_support_requests'){
			pagination_addAdminSupportRequests(data.list);

			pagination_create('#pagination_admin_support_requests', data.pages, data.page);
		} else if(method == 'casino_slots_games'){
			pagination_addCasinoSlotsGames(data.list);

            $('#casino_slots_games_provider').closest('.dropdown_field').find('.field_element_dropdowns').html('<div class="field_element_dropdown active" value="all" data-index="0">All Providers</div>');

            data.providers.forEach(function(item, index){
                $('#casino_slots_games_provider').closest('.dropdown_field').find('.field_element_dropdowns').append('<div class="field_element_dropdown" value="' + item.id + '" data-index="' + (index + 1) + '">' + item.name + '</div>');
            });

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_casino_slots_games').html(DIV);
		} else if(method == 'casino_live_games'){
			pagination_addCasinoLiveGames(data.list);

            $('#casino_live_games_provider').closest('.dropdown_field').find('.field_element_dropdowns').html('<div class="field_element_dropdown active" value="all" data-index="0">All Providers</div>');

            data.providers.forEach(function(item, index){
                $('#casino_live_games_provider').closest('.dropdown_field').find('.field_element_dropdowns').append('<div class="field_element_dropdown" value="' + item.id + '" data-index="' + (index + 1) + '">' + item.name + '</div>');
            });

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_casino_live_games').html(DIV);
		} else if(method == 'casino_favorites_games'){
			pagination_addCasinoFavoritesGames(data.list);

            $('#casino_favorites_games_provider').closest('.dropdown_field').find('.field_element_dropdowns').html('<div class="field_element_dropdown active" value="all" data-index="0">All Providers</div>');
            data.providers.forEach(function(item, index){
                $('#casino_favorites_games_provider').closest('.dropdown_field').find('.field_element_dropdowns').append('<div class="field_element_dropdown" value="' + item.id + '" data-index="' + (index + 1) + '">' + item.name + '</div>');
            });

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_casino_favorites_games').html(DIV);
		} else if(method == 'casino_all_games'){
			pagination_addCasinoAllGames(data.list);

			var DIV = '<div class="flex row gap-2 justify-between items-center width-full">';
				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.max(1, data.page - 1) + '">«</div>';

				DIV += '<div class="bg-card rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">' + data.page + '/' + data.pages + '</div>';

				DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + Math.min(data.pages, data.page + 1) + '">»</div>';
			DIV += '</div>';

			$('#pagination_casino_all_games').html(DIV);
		}
	}

	if(type == 'dashboard'){
		if(method == 'graph'){
            var graph = data.graph.split('.')[0];

            $('#dashboard_chart_' + graph).closest('.dashboard-chart').find('.dashboard-loader').addClass('hidden');

            dashboard_updateGraph(data.data, graph);
		} else if(method == 'stats'){
			$('.dashboard-stats[data-stats="' + data.stats + '"] .stats').text(data.data);
		}
	}

	if(type == 'admin'){
        if(method == 'support_claim'){
            admin_supportSetStatus(data.closed, data.status);

            $('#admin_support_request_actions').removeClass('opened').addClass('claimed');
        } else if(method == 'support_release'){
            admin_supportSetStatus(data.closed, data.status);

            $('#admin_support_request_actions').removeClass('claimed').addClass('opened');
        } else if(method == 'support_close'){
            admin_supportSetStatus(data.closed, data.status);

            $('#admin_support_request_actions').removeClass('opened').removeClass('claimed').addClass('closed');

            $('#admin_support_request_updated').text(data.date);
        } else if(method == 'support_department'){
            $('#admin_support_request_department').text({ 0: 'General / Others', 1: 'Bug report', 2: 'Trade offer issue', 3: 'Improvements / Ideas', 4: 'Marketing / Partnership', 5: 'Ranking up' }[data.department]);

            $('#admin_support_request_updated').text(data.date);
        } else if(method == 'support_reply'){
            admin_supportAddReply(data);
            admin_supportSetStatus(data.closed, data.status);

            $('#admin_support_request_updated').text(data.date);
        }
    }

	if(type == 'history'){
		if(method == 'list'){
			$('#history_list').html('<div class="table-row history_message"><div class="table-column text-center">No data found</div></div>');

			data.list.forEach(function(history){
				history_addHistory(history);
			});
		} else if(method == 'history'){
			var allowed = true;

			if((data.history.type == 'game_bets' || data.history.type == 'my_bets') && data.history.game != app.page) allowed = false;

            //app.page == 'home'
			if(data.history.type == 'game_bets' && app.page == '') allowed = true;

			if(data.history.type == profile_settingsGet('history') && allowed) history_addHistory(data.history.history);
		}
	}

    if(type == 'support'){
        if(method == 'redirect'){
			window.location.href = '/support/requests/' + data.id;
		} else if(method == 'department'){
            $('#support_request_department').text({ 0: 'General / Others', 1: 'Bug report', 2: 'Trade offer issue', 3: 'Improvements / Ideas', 4: 'Marketing / Partnership', 5: 'Ranking up' }[data.department]);

            $('#support_request_updated').text(data.date);
        } else if(method == 'reply'){
            support_addReply(data);
            support_setStatus(data.closed, data.status);

            $('#support_request_updated').text(data.date);
        } else if(method == 'close'){
            support_setStatus(data.closed, data.status);

            $('#support_request_actions').removeClass('opened').addClass('closed');

            $('#support_request_updated').text(data.date);
        }
    }

	if(type == 'offers'){
		if(app.page == 'deposit' || app.page == 'withdraw'){
			if(method == 'add_items'){
				if(!data.offer.more){
					$('#refresh_inventory').removeClass('disabled');

					$('#list_items').empty();
					$('#cart-items').empty();

					offers_refreshCartItems();

					offers_inventoryIsLoading = false;
				}

				$('#list_items .history_message').remove();

				data.offer.items.forEach(function(item){
					if($('#list_items .listing-item[data-id="' + item.id + '"]').length > 0) $('#list_items .listing-item[data-id="' + item.id + '"]').remove();

					if(app.page == 'deposit') offers_addItemInventory(item);
					if(app.page == 'withdraw'){
						if(app.paths[1] == 'steam') offers_addItemInventory(item);
						if(app.paths[1] == 'p2p') offers_addBundleInventory(item);
					}
				});

				var search = $('#items_search').val();

				$('#list_items > .listing-item').addClass('hidden').filter(function(i, e) {
                    var name = $(this).data('name');

                    if(app.paths[0] == 'withdraw' && app.paths[1] == 'steam') {
                        if (name.toLowerCase().indexOf(search) >= 0 && $(this).data('bot') == $('.steam-bot.active').data('bot')) return true;
                    } else if (name.toLowerCase().indexOf(search) >= 0) return true;
                }).removeClass('hidden');

                if($('#list_items .listing-item:not(.hidden)').length <= 0) {
                    if(app.page == 'deposit') $('#list_items').append('<div class="in-grid font-8 history_message">Your Inventory is currently empty.</div>');
                    if(app.page == 'withdraw') $('#list_items').append('<div class="in-grid font-8 history_message">The Marketplace is currently empty. Please try to switch the bot inventory.</div>');
                } else {
                    var order = parseInt($('#items_order').val());

                    if (order == 0) {
                        tinysort('#list_items .listing-item', {
                            data: 'price',
                            order: 'desc'
                        });
                    } else if (order == 1) {
                        tinysort('#list_items .listing-item', {
                            data: 'price',
                            order: 'asc'
                        });
                    } else if (order == 2) {
                        tinysort('#list_items .listing-item', {
                            data: 'name',
                            order: 'asc'
                        });
                    } else if (order == 3) {
                        tinysort('#list_items .listing-item', {
                            data: 'name',
                            order: 'desc'
                        });
                    }

                    tinysort('#list_items .listing-item', {
                        data: "accepted",
                        order: "desc"
                    });
                }
			} else if(method == 'remove_items'){
				if(data.offer.all){
					$('#list_items').empty();
					$('#cart-items').empty();
				} else {
					data.offer.items.forEach(function(item){
						$('#cart-items .item-selected-content[data-id="' + item.id + '"]').remove();
						$('#list_items .listing-item[data-id="' + item.id + '"]').remove();
					});
				}

				if($('#list_items .listing-item').length <= 0){
					$('#refresh_inventory').removeClass('disabled');

					if(app.page == 'deposit') $('#list_items').html('<div class="in-grid font-8 history_message">Your Inventory is currently empty.</div>');
					if(app.page == 'withdraw') $('#list_items').html('<div class="in-grid font-8 history_message">The Marketplace is currently empty. Please try to switch the bot inventory.</div>');
				}

				offers_refreshCartItems();
			} else if(method == 'update'){
				$('#modal_error_bind_steam').modal('hide');
				$('#modal_error_steam_tradelink').modal('hide');
				$('#modal_error_steam_webapi_token').modal('hide');

				$('#modal_steam_webapi_token').modal('hide');

				offers_refreshInventory();
			} else if(method == 'crypto_payment'){
                $('#crypto_deposit_qrcode').empty();

				var qrcode = new QRCode($('#crypto_deposit_qrcode')[0], {
					text: data.payment.address,
					width: 192,
					height: 192,
				});

                $('#crypto_deposit_payment_value').text(data.payment.value);
                $('#crypto_deposit_payment_amount').text(getFormatAmountString(data.payment.amount));

				var $input_address = $('#crypto_deposit_payment_address');
				$input_address.val(data.payment.address);

				changeInputFieldLabel($input_address.closest('.input_field'));

                $('#crypto_deposit_panel').addClass('active');
			}
		}

		if(method == 'add_pending'){
			offers_addPending(data.offer, true);
		} else if(method == 'edit_pending'){
			offers_editPending(data.offer);
		} else if(method == 'remove_pending'){
			$('#pending-offers .bundle_offer[data-id="' + data.offer.id + '"][data-method="' + data.offer.method + '"]').remove();
			$('#modal_offers_pending').modal('hide');

			offers_refreshPendingItems();
		}
	}

	if(type == 'roulette' && app.page == 'roulette'){
		if(method == 'timer'){
			rouletteGame_timer(data.time, data.cooldown);
		} else if(method == 'bet'){
			rouletteGame_addBet(data.bet);
		} else if(method == 'total'){
			$('#roulette_panel_' + data.color + ' .roulette-betstotal .amount').text(getFormatAmountString(data.total.amount));
		    $('#roulette_panel_' + data.color + ' .roulette-betstotal .count').text(data.total.count);
		} else if(method == 'hundred'){
			$('#roulette_hundred_red').text(data.red);
            $('#roulette_hundred_green').text(data.green);
            $('#roulette_hundred_black').text(data.black);
            $('#roulette_hundred_bait').text(data.bait);
		} else if(method == 'bet_confirmed'){
			notify('success', 'Your bet has been placed!');

			$('.roulette-bet').removeClass('disabled');

			sounds_play('play');
		} else if(method == 'roll'){
			$('.roulette-bet').addClass('disabled');

			$('#roulette_counter').finish();

			sounds_play('roulette_rolling');
			startSpinner_Roulette(data.roll, data.greens, data.cooldown);
		} else if(method == 'info'){
			if(data.info.id !== undefined) {
                $('#roulette_info_id').val(data.info.id);
                $('#roulette_info_id').attr('data-default', data.info.id);
            }

			if(data.info.public_seed !== undefined) {
                $('#roulette_info_public_seed').val(data.info.public_seed);
                $('#roulette_info_public_seed').attr('data-default', data.info.public_seed);
            }

			$('#roulette_counter').finish().css('width', '100%');
		} else if(method == 'jackpot'){
			if(data.method == 'total'){
				$('#roulette_jackpot_total').countToFloat(data.total);
			} else if(data.method == 'greens'){
				$('#roulette_jackpot_greens .item').removeClass('active');
				for(var i = 1; i <= data.greens; i++) $('#roulette_jackpot_greens .item[data-green="' + i + '"]').addClass('active');
			} else if(data.method == 'history'){
				$('#roulette_jackpot_history_list').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

				if(data.history.length > 0) $('#roulette_jackpot_history_list').empty();

				data.history.forEach(function(item){
					var DIV = '<div class="table-row">';
						DIV += '<div class="table-column text-left">$' + getFormatAmountString(item.amount) + '</div>';
						DIV += '<div class="table-column text-left">' + item.winners + '</div>';
						DIV += '<div class="table-column text-left">' + item.time + '</div>';

						DIV += '<div class="table-column text-right"><button class="button button-primary shadow-2 roulette-jackpot-winners" data-id="' + item.id + '">View</button></div>';
					DIV += '</div>';

					$('#roulette_jackpot_history_list').append(DIV);
				});

				$('#modal_roulette_jackpot').modal('show');
			} else if(data.method == 'winners'){
				$('#roulette_jackpot_winners_list').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

				if(data.winners.length > 0) $('#roulette_jackpot_winners_list').empty();

				data.winners.forEach(function(item){
					var DIV = '<div class="table-row">';
						DIV += '<div class="table-column text-left">';
							DIV += '<div class="flex items-center gap-1">';
								DIV += createAvatarField(item.user, 'small', '', '');
								DIV += '<div class="text-left width-full ellipsis">' + item.user.name + '</div>';
							DIV += '</div>';
						DIV += '</div>';
						DIV += '<div class="table-column text-left">' + getFormatAmountString(item.bets) + '</div>';
						DIV += '<div class="table-column text-right">' + getFormatAmountString(item.winnings) + '</div>';
					DIV += '</div>';

					$('#roulette_jackpot_winners_list').append(DIV);
				});

				$('#modal_roulette_jackpot_winners').modal('show');
			}
		}
	}

	if(type == 'crash' && app.page == 'crash'){
		if(method == 'starting'){
			$('.crash-graph').removeClass('crashed');
			$('.crash-graph').removeClass('progress');
			$('.crash-graph').addClass('starting');

			crash_settings.stage = 'starting';

			var time_crash = data.time;
			var int_crash = setInterval(function(){
				if(time_crash < 0){
					clearInterval(int_crash);
				} else {
					$('#crash_timer').text(roundedToFixed(time_crash / 1000, 2).toFixed(2));

					time_crash -= 10;
				}
			}, 10);

			$('#crash_bet').removeClass('hidden').removeClass('disabled');
			$('#crash_cashout').addClass('hidden');

			$('.bet-cashout').addClass('disabled');

			$('#crash_cashout_amount').countToFloat(data.total);
			$('#crash_cashout_profit').countToProfit(data.profit);
		} else if(method == 'started'){
			$('.crash-graph').removeClass('starting');
			$('.crash-graph').removeClass('progress');
			$('.crash-graph').addClass('progress');

			crash_settings.stage = 'progress';
			crash_settings.start_time = new Date().getTime();
			crash_settings.difference_time = data.difference;

			$('#crash_bet').removeClass('hidden').addClass('disabled');
			$('#crash_cashout').addClass('hidden');

			$('.bet-cashout').addClass('disabled');
		} else if(method == 'crashed'){
			$('.crash-graph').removeClass('progress');
			$('.crash-graph').removeClass('starting');
			$('.crash-graph').addClass('crashed');

			crash_settings.current_progress_time = data.time;
			crash_settings.stage = 'crashed';

			$('#crash_crash').text(roundedToFixed(data.number / 100, 2).toFixed(2))

			if(!data.loaded) crashGame_addHistory(roundedToFixed(data.number / 100, 2).toFixed(2));

			$('#crash_bet').removeClass('hidden').addClass('disabled');
			$('#crash_cashout').addClass('hidden');

			$('.bet-cashout').addClass('disabled');

			if(!data.winners.includes(USERID)){
				$('#crash_cashout_amount').countToFloat(0);
				$('#crash_cashout_profit').countToProfit(0);
			}

			sounds_play('crash_stop');
		} else if(method == 'reset'){
			$('#crash_betlist').html('<div class="table-row height-full history_message"><div class="table-column text-center">No users in game</div></div>');

			$('#crash_bet').removeClass('hidden').removeClass('disabled');
			$('#crash_cashout').addClass('hidden');

			$('.bet-cashout').addClass('disabled');

			$('#crash_cashout_amount').countToFloat(0);
			$('#crash_cashout_profit').countToProfit(0);
		} else if(method == 'bet'){
			crashGame_addGame(data.bet);
		} else if(method == 'win'){
			crashGame_editBet(data.bet);
		} else if(method == 'loss'){
			data.ids.forEach(function(id){
				$('#crash_betlist .crash_betitem[data-id="' + id + '"]').removeClass('text-primary').addClass('text-danger');
			});
		} else if(method == 'bet_confirmed'){
			notify('success', 'Your bet has been placed!');

			$('#crash_bet').removeClass('hidden').addClass('disabled');
			$('#crash_cashout').addClass('hidden');

			$('.bet-cashout').addClass('disabled');

			$('#crash_cashout_amount').countToFloat(data.total);
			$('#crash_cashout_profit').countToProfit(data.profit);

			sounds_play('play');
		} else if(method == 'cashed_out'){
			$('#crash_bet').addClass('hidden');
			$('#crash_cashout').removeClass('hidden').addClass('disabled');

			$('.bet-cashout').addClass('disabled');

			$('#crash_cashout_amount').countToFloat(data.total);
			$('#crash_cashout_profit').countToProfit(data.profit);

			if(!data.loaded) sounds_play('cashout');
		} else if(method == 'cashout'){
			$('#crash_bet').addClass('hidden');
			$('#crash_cashout').removeClass('hidden').removeClass('disabled');

			$('.bet-cashout').removeClass('disabled');

			$('#crash_cashout_amount').text(roundedToFixed(data.total, 2).toFixed(2));
			$('#crash_cashout_profit').text(roundedToFixed(data.profit, 2).toFixed(2));
		} else if(method == 'info'){
			if(data.info.id !== undefined) {
                $('#crash_info_id').val(data.info.id);
                $('#crash_info_id').attr('data-default', data.info.id);
            }

			if(data.info.public_seed !== undefined) {
                $('#crash_info_public_seed').val(data.info.public_seed);
                $('#crash_info_public_seed').attr('data-default', data.info.public_seed);
            }
		}
	}

	if(type == 'jackpot' && app.page == 'jackpot'){
		if(method == 'bet_confirmed'){
			notify('success', 'Your bet has been placed!');

			$('#jackpot_bet').removeClass('disabled');

			sounds_play('play');
		} else if(method == 'avatars'){
			$('#jackpot_field').empty();

			for(var i = 0; i < 2; i++){
				data.avatars.forEach(function(item){
					var DIV = '<div class="reel-item flex justify-center items-center"><img class="width-full height-full" src="' + item + '"></div>';

					$('#jackpot_field').append(DIV);
				});
			}
		} else if(method == 'fair'){
			$('#fair_jackpot_results').attr('data-fair', JSON.stringify({ game: data.fair, draw: null }));
		} else if(method == 'chance'){
			$('#jackpot_mychange').countToFloat(data.chance);
		} else if(method == 'bet'){
			jackpotGame_addBet(data.bet);
			$('#jackpot_total').countToFloat(data.total);
		} else if(method == 'timer'){
			$('#jackpot_timer').text('Rolling in ' + parseInt(data.time) + 's');
			$('#jackpot_counter').css('width', (data.time * 100 / data.total).toFixed(2) + '%');
		} else if(method == 'picking'){
			$('#jackpot_timer').text('Waiting for EOS block...');
		} else if(method == 'reset'){
			$('#jackpot_betlist').html('<div class="in-grid flex justify-center items-center font-8 history_message">No users in game</div>');
			$('#jackpot_total').countToFloat(0);

			$('#jackpot_mychange').countToFloat(0);

			$('#jackpot_timer').text('Waiting for players...');
			$('#jackpot_counter').css('width', '100%');

			$('#jackpot_field').empty();

			for(var i = 0; i < 50; i++){
				var DIV = '<div class="reel-item flex justify-center items-center"><img class="width-full height-full" data-id="' + i + '" src="/img/jackpot/avatar.jpg"></div>';

				$('#jackpot_field').append(DIV);
			}

			idleSpinner_Jackpot = true;
		} else if(method == 'history'){
			jackpotGame_addHistory(data.history);
		} else if(method == 'roll'){
			idleSpinner_Jackpot = false;

			$('#jackpot_field').empty();

			data.avatars.forEach(function(item, index){
				var DIV = '<div class="reel-item flex justify-center items-center"><img class="width-full height-full" data-id="' + index + '" src="' + item + '"></div>';

				$('#jackpot_field').append(DIV);
			});

			$('#jackpot_timer').text('Rolling winner!');

			startSpinner_Jackpot(data.cooldown);
			sounds_play('jackpot_rolling');
		}
	}

	if(type == 'coinflip' && app.page == 'coinflip'){
		if(method == 'add'){
			coinflipGame_addCoinFlip(data.coinflip);
		} else if(method == 'bet_confirmed'){
			notify('success', 'Your bet has been placed!');

			$('#coinflip_create').removeClass('disabled');

			sounds_play('play');
		} else if(method == 'edit'){
			coinflipGame_editCoinFlip(data.coinflip, data.status);
		} else if(method == 'remove'){
			var $field = $('#coinflip_betlist .coinflip-game .coinflip_betitem[data-id="' + data.coinflip.id + '"]').parent();
			$field.removeClass('active').empty();

			var last_game = $('#coinflip_betlist .coinflip-game.active').last().index() + 1;
			var count_games = $('#coinflip_betlist .coinflip-game').length;
			for(var i = 0; (i < (count_games - (last_game > 5 ? 1 : 0)) * Math.floor((count_games - last_game) / 5) * 5) && $('#coinflip_betlist .coinflip-game').length > 5; i++){
				var $last = $('#coinflip_betlist .coinflip-game').last();

				$last.remove();
			}
		}
	}

	if(type == 'dice' && app.page == 'dice'){
		if(method == 'bet'){
			notify('success', 'Your bet has been placed!');

			diceGame_roll(data.roll);

			$('#dice_bet').addClass('disabled');

			$('#dice_chanceslider').addClass('disabled');
			$('.dice-mode').addClass('disabled');

			$('.bet-cashout').removeClass('disabled');

			$('#dice_cashout_amount').countToFloat(data.total);
			$('#dice_cashout_profit').countToProfit(data.profit);
		} else if(method == 'result'){
			$('#dice_pointer').removeClass('hidden');
			$('#dice_pointer .item').css('left', roundedToFixed(data.roll, 2) + '%');
			$('#dice_pointer .content').text(roundedToFixed(data.roll, 2).toFixed(2) + '%');

			$('#dice_bet').removeClass('disabled');

			$('#dice_chanceslider').removeClass('disabled');
			$('.dice-mode').removeClass('disabled');

			$('.bet-cashout').addClass('disabled');

			$('#dice_cashout_amount').countToFloat(data.total);
			$('#dice_cashout_profit').countToProfit(data.profit);

			if(data.win) sounds_play('dice_win');
			else sounds_play('dice_loss');
		}
	}

	if(type == 'unboxing' && app.page == 'unboxing'){
		if(method == 'show'){
			unboxingGame_showCase(data.items, data.unboxing);
		} else if(method == 'spinner'){
			unboxingGame_showSpinner(data.spinner);
		} else if(method == 'roll'){
			unboxingGame_openCase(data.spinner);
		} else if(method == 'history'){
			unboxingGame_addHistory(data.history)
		} else if(method == 'finish'){
			$('#unboxing_demo').removeClass('disabled');
			$('#unboxing_open').removeClass('disabled');
		}
	}

	if(type == 'casebattle' && app.page == 'casebattle'){
		if(method == 'add'){
			caseBattleGame_addCaseBattle(data.casebattle);

			caseBattleGame_filterHide();
			caseBattleGame_filterOrder();
		} else if(method == 'edit'){
			caseBattleGame_editCaseBattle(data.casebattle, data.status, false);
		} else if(method == 'remove'){
			$('#casebattle_betlist .casebattle_betitem[data-id="' + data.casebattle.id + '"]').remove();

			if($('#casebattle_betlist .casebattle_betitem').length <= 0) $('#casebattle_betlist').html('<div class="in-grid bg-card flex justify-center items-center font-8 p-4 history_message">No active case battles</div>');
		} else if(method == 'list'){
			data.battles.forEach(function(bet){
				caseBattleGame_addCaseBattle(bet.casebattle);
				if(bet.status > 0) caseBattleGame_editCaseBattle(bet.casebattle, bet.status, true);
			});

			caseBattleGame_filterHide();
			caseBattleGame_filterOrder();
		} else if(method == 'cases'){
			$('#casebattle_add_list').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases found</div></div>');

			if(data.cases.length > 0) $('#casebattle_add_list').empty();

			data.cases.forEach(function(item){
				$('#casebattle_add_list').append(caseBattleGame_generateCase({
					id: item.id,
					game: item.game,
					name: item.name,
					image: '/img/cases/' + item.image,
					price: item.price
				}, { count: 0 }));
			});

			var game = $('#casebattle_add_game').val();

			$('#casebattle_add_list .casebattle_item').addClass('hidden');
			$('#casebattle_add_list .casebattle_item[data-game="' + game + '"]').removeClass('hidden');

			tinysort('#casebattle_add_list .casebattle_item', {
				data: 'price',
				order: 'asc'
			});

			$('#casebattle_create_list .casebattle_item').each(function(i, e){
				var item = JSON.parse($(this).attr('data-item').replace(/'/g, '"'));
				var count = parseInt($(this).attr('data-count'));

				$('#casebattle_add_list .casebattle_item[data-id="' + item.id + '"]').addClass('active');
				$('#casebattle_add_list .casebattle_item[data-id="' + item.id + '"]').attr('data-count', count);
				$('#casebattle_add_list .casebattle_item[data-id="' + item.id + '"] .casebattle_add_count').text(count);
			});

			caseBattleGame_updateAdd();
		} else if(method == 'bet_confirmed'){
			notify('success', 'Your bet has been placed!');

			sounds_play('play');
		} else if(method == 'redirect'){
			if(data.action == 'join') window.location.href = '/casebattle/' + data.id;
			else if(data.action == 'leave') window.location.href = '/casebattle';
		} else if(method == 'stats'){
			$('#casebattle_stats_active').text(data.stats.active);
			$('#casebattle_stats_total').text(data.stats.total);
		} else if(method == 'emoji'){
			if(caseBattleGame_emojiTimeouts[data.casebattle.id + '_' + data.position]) clearTimeout(caseBattleGame_emojiTimeouts[data.casebattle.id + '_' + data.position]);

			var emoji = [ 'heart_eyes.png', 'innocent.png', 'rage.png', 'sob.png', 'joy.png' ][data.emoji];

			$('.casebattle_rounditem[data-position="' + data.position + '"] .casebattle-emojis').css('opacity', 1).addClass('active');
			$('.casebattle_rounditem[data-position="' + data.position + '"] .casebattle-emojis-arena').addClass('active').html('<div class="casebattle-emoji rounded-full"><img class="height-full" src="/img/emojis/' + emoji + '"></div></div>');

			caseBattleGame_emojiTimeouts[data.casebattle.id + '_' + data.position] = setTimeout(function(){
				$('.casebattle_rounditem[data-position="' + data.position + '"] .casebattle-emojis').css('opacity', 0).removeClass('active');
				$('.casebattle_rounditem[data-position="' + data.position + '"] .casebattle-emojis-arena').removeClass('active').empty();

				clearInterval(caseBattleGame_emojiTimeouts[data.casebattle.id + '_' + data.position]);
			}, 2000);
		} else if(method == 'show'){
			$('#casebattle_roundslist').empty();

			data.casebattle.cases.forEach(function(item, i){
				var ITEM = '<div class="casebattle-icon medium bg-card rounded-0 p-1 bl-1 flex justify-center items-center" data-round="' + i + '" title="' + item.name + '"><img src="/img/cases/' + item.image + '"></div>'

				$('#casebattle_roundslist').append(ITEM);
			});

			var total_players = [ 2, 3, 4, 4 ][data.casebattle.mode];

			$('#casebattle_roundlist').empty();

			if(data.casebattle.mode == 3){
				for(var i = 0; i < 2; i++){
					var DIV = '<div class="flex row responsive bg-secondary b-b2 p-2 rounded-1 width-full relative">';
						DIV += caseBattleGame_generateShow(data.casebattle, data.status, i * 2, true);

						DIV += caseBattleGame_generateShow(data.casebattle, data.status, i * 2 + 1, true);
					DIV += '</div>';

					$('#casebattle_roundlist').append(DIV);
				}
			} else {
				for(var i = 0; i < total_players; i++){
					var DIV = '<div class="flex row responsive bg-secondary b-b2 p-2 rounded-1 width-full relative">';
						DIV += caseBattleGame_generateShow(data.casebattle, data.status, i, true);
					DIV += '</div>';

					$('#casebattle_roundlist').append(DIV);
				}
			}

			$('#casebattle_itemslist').empty();

			for(var i = 0; i < total_players; i++){
				$('#casebattle_itemslist').append(caseBattleGame_generateItems(data.casebattle, i));
			}

			$('#casebattle_roundslist .casebattle-icon').removeClass('active');
			if(data.status == 4){
				$('#casebattle_roundslist .casebattle-icon[data-round="' + data.casebattle.data.round + '"]').addClass('active');

				setTimeout(function(){
					$('#casebattle_roundslist').css('transform', 'translateX(-' + (data.casebattle.data.round * 80) + 'px)');
				}, 200);
			}

			$('.casebattle_game_rounds').text(data.casebattle.cases.length);
			$('.casebattle_game_round').text(data.casebattle.data.round + 1);

			$('#casebattle_stats_amount').text(getFormatAmountString(data.casebattle.data.free ? total_players * data.casebattle.amount : data.casebattle.amount));
			$('#casebattle_fair').attr('data-fair', JSON.stringify({ game: data.casebattle.data.game, draw: data.casebattle.data.draw }));

			$('#casebattle_create_same').attr('data-battle', JSON.stringify({ cases: data.casebattle.cases.map(a => a.id), mode: data.casebattle.mode, privacy: data.casebattle.data.privacy, free: data.casebattle.data.free, crazy: data.casebattle.data.crazy }));

			$('#casebattle_link').removeClass('hidden').attr('data-text', app.url + '/casebattle/' + data.casebattle.id);
			$('#casebattle_link .link').text(app.url + '/casebattle/' + data.casebattle.id);
		} else if(method == 'update'){
			if(data.stage == 'position'){
				$('#casebattle_roundlist .casebattle_rounditem[data-position="' + data.position + '"] .casebattle-case').replaceWith(caseBattleGame_generateShowCase(data.casebattle, data.status, data.position, false));
				$('#casebattle_roundlist .casebattle_rounditem[data-position="' + data.position + '"] .casebattle-user').replaceWith(caseBattleGame_generateShowUser(data.casebattle, data.status, data.position));
			} else if(data.stage == 'refresh'){
				var total_players = [ 2, 3, 4, 4 ][data.casebattle.mode];

				for(var i = 0; i < total_players; i++){
					$('#casebattle_roundlist .casebattle_rounditem[data-position="' + i + '"] .casebattle-case').replaceWith(caseBattleGame_generateShowCase(data.casebattle, data.status, i, false));
					$('#casebattle_roundlist .casebattle_rounditem[data-position="' + i + '"] .casebattle-user').replaceWith(caseBattleGame_generateShowUser(data.casebattle, data.status, i));
				}

				$('#casebattle_fair').attr('data-fair', JSON.stringify({ game: data.casebattle.data.game, draw: data.casebattle.data.draw }));
			} else if(data.stage == 'roll'){
				caseBattleGame_openCase();
			} else if(data.stage == 'items'){
				data.players.forEach(function(player){
					var ITEM = caseBattleGame_generateItem(player.item);
					$('#casebattle_itemslist .casebattle-drops[data-position="' + player.position + '"]').prepend(ITEM);
					$('#casebattle_itemslist .casebattle-drops[data-position="' + player.position + '"] .listing-item').last().remove();

					$('.casebattle_rounditem[data-position="' + player.position + '"] .casebattle-total').text(getFormatAmountString(player.total));

					$('.casebattle_rounditem[data-position="' + player.position + '"] .casebattle-total').parent().removeClass('text-success');
					if(data.positions.includes(player.position)) $('.casebattle_rounditem[data-position="' + player.position + '"] .casebattle-total').parent().addClass('text-success');
				});
			} else if(data.stage == 'round'){
				$('#casebattle_roundslist .casebattle-icon').removeClass('active');
				$('#casebattle_roundslist .casebattle-icon[data-round="' + data.round + '"]').addClass('active');

				$('.casebattle_game_round').text(data.round + 1);

				setTimeout(function(){
					$('#casebattle_roundslist').css('transform', 'translateX(-' + (data.round * 80) + 'px)');
				}, 200);
			} else if(data.stage == 'finish'){
				$('#casebattle_roundslist .casebattle-icon').removeClass('active');

				$('#casebattle_roundslist').css('transform', 'translateX(0px)');
			}
		}
	}

	if(type == 'upgrader' && app.page == 'upgrader'){
		if(method == 'chance'){
			upgraderGame_changeProgress(data.chance);
		} else if(method == 'roll'){
			startSpinner_Upgrader(data.roll);

			sounds_play('play');
		} else if(method == 'finish'){
			$('#upgrader_spinner').addClass({ true: 'success', false: 'danger' }[data.win]);

			if(data.win) sounds_play('upgrader_win');
			else sounds_play('upgrader_loss');

			setTimeout(function(){
				$('#upgrader_bet').removeClass('disabled');
				$('.upgrader-multiplier').removeClass('disabled');
				$('#upgrader_mode').removeClass('disabled');
				$('#upgrader_roll').removeClass('disabled');
				$('#upgrader_betamount').closest('.slider_field').removeClass('disabled');
				$('.upgrader-inventory').removeClass('disabled');

				$('#upgrader_spinner').removeClass('success').removeClass('danger');

				$('#upgrader_spinner_1').css('transform', 'rotateZ(0deg)');
				$('#upgrader_spinner_2').css('transform', 'rotateZ(0deg)');

				upgraderGame_changeProgress(0);

				upgraderGame_items = data.items;

				$('#upgrader_myitems_selected .upgrader-item').each(function(i, e){
					var id = $(this).data('id');

					$('#upgrader_myitems_list .listing-item[data-id="' + id + '"]').removeClass('active').find('.item-selected').addClass('hidden');
					$('#upgrader_myitems_selected .upgrader-item[data-id="' + id + '"]').remove();
				});

				$('#upgrader_siteitems_selected .upgrader-item').each(function(i, e){
					var id = $(this).data('id');

					$('#upgrader_siteitems_list .listing-item[data-id="' + id + '"]').removeClass('active').find('.item-selected').addClass('hidden');
					$('#upgrader_siteitems_selected .upgrader-item[data-id="' + id + '"]').remove();
				});

				upgraderGame_refreshSelectedMyItems();
				upgraderGame_refreshSelectedSiteItems();

				$('#upgrader_myitems_list').html(createLoader());

				var order = parseInt($('#upgrader_myitems_order').val());
				var game = $('#upgrader_myitems_game').val();

				send_request_socket({
					'type': 'pagination',
					'command': 'upgrader_myitems',
					'page': 1,
					'order': order,
					'game': game
				});
			}, 4000);
		}
	}

	if(type == 'minesweeper' && app.page == 'minesweeper'){
		if(method == 'bet_confirmed'){
			notify('success', 'Your bet has been placed!');

			$('#minesweeper_bombs .item').removeClass('danger').removeClass('success').removeClass('disabled');
			$('#minesweeper_bombs .item .multiplier').text('');

			$('#minesweeper_bet').addClass('hidden');
			$('#minesweeper_cashout').removeClass('hidden').removeClass('disabled');

			$('#bombsamount_minesweeper').closest('.input_field').addClass('disabled');
			$('.minesweeper-bombsamount').addClass('disabled');

			$('.bet-cashout').removeClass('disabled');

			$('#minesweeper_cashout_amount').countToFloat(data.total);
			$('#minesweeper_cashout_profit').countToProfit(data.profit);

			sounds_play('play');
		} else if(method == 'result_bomb'){
			if(data.result == 'lose'){
				data.data.mines.forEach(function(bomb){
					$('#minesweeper_bombs .item[data-bomb="' + bomb + '"]').addClass('danger');
				});

				$('#minesweeper_bombs .item').addClass('disabled');

				$('#minesweeper_bet').removeClass('hidden').removeClass('disabled');
				$('#minesweeper_cashout').addClass('hidden');

				$('#bombsamount_minesweeper').closest('.input_field').removeClass('disabled');
				$('.minesweeper-bombsamount').removeClass('disabled');

				$('.bet-cashout').addClass('disabled');

				if(!data.data.win){
					$('#minesweeper_cashout_amount').countToFloat(0);
					$('#minesweeper_cashout_profit').countToProfit(0);

					sounds_play('minesweeper_loss');
				} else sounds_play('cashout');
			} else if(data.result == 'win'){
				$('#minesweeper_bombs .item[data-bomb="' + data.data.bomb + '"]').addClass('success');
				$('#minesweeper_bombs .item[data-bomb="' + data.data.bomb + '"] .multiplier').text('x' + data.data.multiplier.toFixed(2));

				$('#minesweeper_cashout').removeClass('hidden').removeClass('disabled');

				$('.bet-cashout').removeClass('disabled');

				$('#minesweeper_cashout_amount').countToFloat(data.data.total);
				$('#minesweeper_cashout_profit').countToProfit(data.data.profit);

				sounds_play('minesweeper_win');
			}
		}
	}

	if(type == 'tower' && app.page == 'tower'){
		if(method == 'bet_confirmed'){
			notify('success', 'Your bet has been placed!');

			$('#tower_grid .item').removeClass('danger').removeClass('success').removeClass('checked');
			$('#tower_grid .item').addClass('disabled');

			$('#tower_grid .item[data-stage="' + data.stage + '"]').removeClass('disabled');

			$('#tower_bet').addClass('hidden');
			$('#tower_cashout').removeClass('hidden').removeClass('disabled');

			$('#tower_difficulty').closest('.dropdown_field').addClass('disabled');

			$('.bet-cashout').removeClass('disabled');

			$('#tower_cashout_amount').countToFloat(data.total);
			$('#tower_cashout_profit').countToProfit(data.profit);

			$('#tower_difficulty').closest('.dropdown_field').addClass('disabled');

			sounds_play('play');
		} else if(method == 'result_stage'){
			if(data.result == 'lose'){
				data.data.tower.forEach(function(button, i){
					if([ 'expert', 'master' ].includes(data.data.difficulty)){
						for(var j = 0; j < towerGame_tiles[data.data.difficulty]; j++){
							if(j != button) $('#tower_grid .item[data-stage="' + i + '"][data-button="' + j + '"]').removeClass('success').removeClass('checked').addClass('danger');
						}
					} else $('#tower_grid .item[data-stage="' + i + '"][data-button="' + button + '"]').removeClass('success').removeClass('checked').addClass('danger');
				});

				$('#tower_grid .item').addClass('disabled');

				$('#tower_bet').removeClass('hidden').removeClass('disabled');
				$('#tower_cashout').addClass('hidden');

				$('#tower_difficulty').closest('.dropdown_field').removeClass('disabled');

				$('.bet-cashout').addClass('disabled');

				if(!data.data.win){
					$('#tower_cashout_amount').countToFloat(0);
					$('#tower_cashout_profit').countToProfit(0);

					sounds_play('tower_loss');
				} else sounds_play('cashout');

				$('#tower_difficulty').closest('.dropdown_field').removeClass('disabled');
			} else if(data.result == 'win'){
				$('#tower_grid .item[data-stage="' + data.data.stage + '"][data-button="' + data.data.button + '"]').addClass('success');
				$('#tower_grid .item[data-stage="' + data.data.stage + '"]:not(.success)').addClass('checked');

				$('#tower_grid .item[data-stage="' + (data.data.stage + 1) + '"]').removeClass('disabled');

				$('#tower_cashout').removeClass('hidden').removeClass('disabled');

				$('.bet-cashout').removeClass('disabled');

				$('#tower_cashout_amount').countToFloat(data.data.total);
				$('#tower_cashout_profit').countToProfit(data.data.profit);

				sounds_play('tower_win');
			}
		}
	}

	if(type == 'plinko' && app.page == 'plinko'){
		if(method == 'bet'){
			notify('success', 'Your bet has been placed!');

			$('#plinko_bet').addClass('disabled');

			$('#plinko_difficulty').closest('.dropdown_field').addClass('disabled');
			$('#plinko_rows_amount').closest('.dropdown_field').addClass('disabled');

			$('.bet-cashout').removeClass('disabled');

			$('#plinko_cashout_amount').countToFloat(data.total);
			$('#plinko_cashout_profit').countToProfit(data.profit);

			plinkoGame_play(data.id, data.roll);

			sounds_play('play');
		} else if(method == 'result'){
			$('#plinko_bet').removeClass('disabled');

			$('.bet-cashout').addClass('disabled');

			$('#plinko_cashout_amount').countToFloat(data.total);
			$('#plinko_cashout_profit').countToProfit(data.profit);

			if($('#plinko_balls .item:not(.active)').length <= 0){
				$('#plinko_difficulty').closest('.dropdown_field').removeClass('disabled');
				$('#plinko_rows_amount').closest('.dropdown_field').removeClass('disabled');
			}
		}
	}

    if(type == 'casino'){
        if(app.page == 'casino'){
            if(method == 'launch'){
                $('#casino_game').empty();

                var iframe = document.createElement('iframe');
                iframe.src = data.url;
                iframe.style.width = '100%';
                iframe.style.height = '600px';
                iframe.style.border = 'none';

                var container = document.getElementById('casino_game');
                container.appendChild(iframe);

                $('#casino_favorite.button').attr('data-id', data.id);
                if(data.favorite) $('#casino_favorite.button').addClass('active');
            } else if(method == 'add_favorite'){
                $('.casino-games .item[data-id="' + data.id + '"] .favorite').addClass('active');

                $('#casino_favorite.button').addClass('active');
            } else if(method == 'remove_favorite'){
                $('.casino-games .item[data-id="' + data.id + '"] .favorite').removeClass('active');

                $('#casino_favorite.button').removeClass('active');
            }
        }

        if(method == 'add_favorite'){
            $('.casino-list .item[data-id="' + data.id + '"] .favorite').addClass('active');
        } else if(method == 'remove_favorite'){
            $('.casino-list .item[data-id="' + data.id + '"] .favorite').removeClass('active');
        }
    }
}

/* END SOCKET */

/* DASHBOARD */

var dashboard_charts = {};

$(document).ready(function() {
	$('.dashboard-chart').each(function(i, e) {
        $(this).find('.dashboard-loader').removeClass('hidden');

        dashboard_startGraph({ 'labels': [], 'data': [] }, $(this).attr('data-graph'));
    });

    $('.dashboard-graph').on('change', function() {
		var date = $(this).val();
		var graph = $(this).closest('.dashboard-chart').attr('data-graph');
		var id = $(this).closest('.dashboard-chart').attr('data-id');

		dashboard_loadGraph({ date, graph: id ? graph + '.' + id : graph });
	});
});

function dashboard_initialize(){
    var graphs = [];

    $('.dashboard-chart').each(function(i, e) {
        $(this).find('.dashboard-loader').removeClass('hidden');

        dashboard_updateGraph({ 'labels': [], 'data': [] }, $(this).attr('data-graph'));

        graphs.push({
            date: $(this).find('.dashboard-graph').val(),
            graph: ($(this).attr('data-id')) ? $(this).attr('data-graph') + '.' + $(this).attr('data-id') : $(this).attr('data-graph')
        });
    });

	send_request_socket({
		'type': 'dashboard',
		'command': 'graphs',
		'graphs': graphs
	});

    var stats = [];
    $('.dashboard-stats').each(function(i, e) { stats.push($(this).attr('data-stats')); });

    send_request_socket({
        'type': 'dashboard',
        'command': 'stats',
        'stats': stats
    });
}

function dashboard_loadGraph(graph){
	$('#dashboard_chart_' + graph.graph).closest('.dashboard-chart').find('.dashboard-loader').removeClass('hidden');

	dashboard_updateGraph({ 'labels': [], 'data': [] }, graph.graph.split('.')[0]);

	send_request_socket({
		'type': 'dashboard',
		'command': 'graph',
		'graph': graph
	});
}

function dashboard_startGraph(data, graph){
	$('#dashboard_chart_' + graph.graph).closest('.dashboard-chart').find('.dashboard-loader').removeClass('hidden');

    var ctx = document.getElementById('dashboard_chart_' + graph).getContext('2d');

	var chart = new Chart(ctx, dashboard_generateCtx(data));

    dashboard_charts[graph] = chart;
}

function dashboard_updateGraph(data, graph){
	if(dashboard_charts[graph] !== undefined){
        dashboard_charts[graph].data.labels = dashboard_generateCtx(data).data.labels;
        dashboard_charts[graph].data.datasets.splice(0);
        dashboard_charts[graph].data.datasets.push(dashboard_generateCtx(data).data.datasets[0]);

        dashboard_charts[graph].update();
    }
}

function dashboard_generateCtx(stats){
	return {
		type: 'line',
		data: {
			labels: stats.labels,
			datasets: [{
				data: stats.data,
				borderColor: '#9370db',
                backgroundColor: '#42395c',
				borderWidth: 2,
				fill: true,
				spanGaps: true,
                pointBackgroundColor: 'transparent',
                pointBorderColor: 'transparent',
                hoverPointBackgroundColor: 'transparent',
                hoverPointBorderColor: 'transparent'
			}]
		},
		options: {
			scales: {
				yAxes: [{
					ticks: {
						//beginAtZero: true
					}
				}],
				xAxes: [{
					ticks: {
						display: false
					}
				}]
			},

			elements: {
				line: {
					tension: 0.5,
				},
                point:{
                    radius: 30,
                    hoverRadius: 30
                }
			},

			legend: {
				display: false,
			},

            maintainAspectRatio: false
		}
	};
}

/* END DASHBOARD */

/* PAGINATION */

$(document).ready(function() {
	$(document).on('click', '#pagination_admin_users .pagination-item', function() {
		var page = $(this).attr('data-page');
		var order = parseInt($('#admin_users_order').val());
		var search = $('#admin_users_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_users',
			'page': page,
			'order': order,
			'search': search
		});
	});

	$(document).on('change', '#admin_users_order', function() {
		var order = parseInt($('#admin_users_order').val());
		var search = $('#admin_users_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_users',
			'page': 1,
			'order': order,
			'search': search
		});
	});

	var timeout_admin_users = null;
	$('#admin_users_search').on('input', function() {
		if(timeout_admin_users) clearTimeout(timeout_admin_users);

		timeout_admin_users = setTimeout(function(){
			var order = parseInt($('#admin_users_order').val());
			var search = $('#admin_users_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'admin_users',
				'page': 1,
				'order': order,
				'search': search
			});
		}, 1000);
	});

	$(document).on('click', '#pagination_admin_crypto_confirmations .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_crypto_confirmations',
			'page': page
		});
	});

	$(document).on('click', '#pagination_admin_steam_confirmations .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_steam_confirmations',
			'page': page
		});
	});

    $(document).on('click', '#pagination_account_transactions .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_transactions',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_deposits .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_deposits',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_withdrawals .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_withdrawals',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_roulette_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_roulette_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_crash_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_crash_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_jackpot_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_jackpot_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_coinflip_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_coinflip_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_dice_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_dice_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_unboxing_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_unboxing_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_casebattle_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_casebattle_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_upgrader_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_upgrader_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_tower_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_tower_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_minesweeper_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_minesweeper_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_plinko_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_plinko_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_casino_history .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'account_casino_history',
			'page': page
		});
	});

	$(document).on('click', '#pagination_account_inventory .pagination-item', function() {
		$('#account_inventory').html(createLoader());

        var page = $(this).attr('data-page');

        var order = parseInt($('#account_inventory_order').val());
        var game = $('#account_inventory_game').val();
        var search = $('#account_inventory_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'account_inventory',
			'page': page,
            'order': order,
            'game': game,
            'search': search
		});
	});

    var timeout_account_inventory = null;
	$('#account_inventory_search').on('input', function() {
		if(timeout_account_inventory) clearTimeout(timeout_account_inventory);

		timeout_account_inventory = setTimeout(function(){
			$('#account_inventory').html(createLoader());

			var order = parseInt($('#account_inventory_order').val());
			var game = $('#account_inventory_game').val();
			var search = $('#account_inventory_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'account_inventory',
				'page': 1,
				'order': order,
				'game': game,
				'search': search
			});
		}, 1000);
	});

	$('#account_inventory_order').on('change', function() {
		$('#account_inventory').html(createLoader());

		var order = parseInt($('#account_inventory_order').val());
		var game = $('#account_inventory_game').val();
		var search = $('#account_inventory_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'account_inventory',
			'page': 1,
			'order': order,
			'game': game,
			'search': search
		});
	});

	$('#account_inventory_game').on('change', function() {
		$('#account_inventory').html(createLoader());

		var order = parseInt($('#account_inventory_order').val());
		var game = $('#account_inventory_game').val();
		var search = $('#account_inventory_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'account_inventory',
			'page': 1,
			'order': order,
			'game': game,
			'search': search
		});
	});

	$(document).on('click', '#pagination_user_transactions .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_transactions',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_deposits .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_deposits',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_withdrawals .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_withdrawals',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_roulette_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_roulette_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_crash_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_crash_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_jackpot_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_jackpot_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_coinflip_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_coinflip_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_dice_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_dice_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_unboxing_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_unboxing_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_casebattle_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_casebattle_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_upgrader_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_upgrader_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_tower_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_tower_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_minesweeper_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_minesweeper_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_plinko_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_plinko_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_casino_history .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'user_casino_history',
			'page': page,
            'userid': app.paths[1]
		});
	});

	$(document).on('click', '#pagination_user_inventory .pagination-item', function() {
		if(app.paths[1] === undefined) return;

        $('#user_inventory').html(createLoader());

        var page = $(this).attr('data-page');

        var order = parseInt($('#account_inventory_order').val());
        var game = $('#account_inventory_game').val();
        var search = $('#account_inventory_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'user_inventory',
			'page': page,
            'userid': app.paths[1],
            'order': order,
            'game': game,
            'search': search
		});
	});

	var timeout_user_inventory = null;
	$('#user_inventory_search').on('input', function() {
		if(app.paths[1] === undefined) return;

        if(timeout_user_inventory) clearTimeout(timeout_user_inventory);

		timeout_user_inventory = setTimeout(function(){
			$('#user_inventory').html(createLoader());

			var order = parseInt($('#user_inventory_order').val());
			var game = $('#user_inventory_game').val();
			var search = $('#user_inventory_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'user_inventory',
				'page': 1,
                'userid': app.paths[1],
				'order': order,
				'game': game,
				'search': search
			});
		}, 1000);
	});

	$('#user_inventory_order').on('change', function() {
		if(app.paths[1] === undefined) return;

        $('#user_inventory').html(createLoader());

		var order = parseInt($('#user_inventory_order').val());
		var game = $('#user_inventory_game').val();
		var search = $('#user_inventory_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'user_inventory',
			'page': 1,
            'userid': app.paths[1],
			'order': order,
			'game': game,
			'search': search
		});
	});

	$('#user_inventory_game').on('change', function() {
		if(app.paths[1] === undefined) return;

        $('#user_inventory').html(createLoader());

		var order = parseInt($('#user_inventory_order').val());
		var game = $('#user_inventory_game').val();
		var search = $('#user_inventory_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'user_inventory',
			'page': 1,
            'userid': app.paths[1],
			'order': order,
			'game': game,
			'search': search
		});
	});

	$(document).on('click', '#pagination_affiliates_referrals .pagination-item', function() {
		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'affiliates_referrals',
			'page': page
		});
	});

	$(document).on('click', '#pagination_admin_tracking_links .pagination-item', function() {
		var page = $(this).attr('data-page');
		var search = $('#admin_tracking_links_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_tracking_links',
			'page': page,
			'search': search
		});
	});

	var timeout_admin_tracking_links = null;
	$('#admin_tracking_links_search').on('input', function() {
		if(timeout_admin_tracking_links) clearTimeout(timeout_admin_tracking_links);

		timeout_admin_tracking_links = setTimeout(function(){
			var search = $('#admin_tracking_links_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'admin_tracking_links',
				'page': 1,
				'search': search
			});
		}, 1000);
	});

	$(document).on('click', '#pagination_admin_deposit_bonuses .pagination-item', function() {
		var page = $(this).attr('data-page');
		var search = $('#admin_deposit_bonuses_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_deposit_bonuses',
			'page': page,
			'search': search
		});
	});

	var timeout_admin_deposit_bonuses = null;
	$('#admin_deposit_bonuses_search').on('input', function() {
		if(timeout_admin_deposit_bonuses) clearTimeout(timeout_admin_deposit_bonuses);

		timeout_admin_deposit_bonuses = setTimeout(function(){
			var search = $('#admin_deposit_bonuses_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'admin_deposit_bonuses',
				'page': 1,
				'search': search
			});
		}, 1000);
	});

	$(document).on('click', '#pagination_admin_gamebots .pagination-item', function() {
		var page = $(this).attr('data-page');
		var order = parseInt($('#admin_gamebots_order').val());
		var search = $('#admin_gamebots_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_gamebots',
			'page': page,
			'order': order,
			'search': search
		});
	});

	$(document).on('change', '#admin_gamebots_order', function() {
		var order = parseInt($('#admin_gamebots_order').val());
		var search = $('#admin_gamebots_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_gamebots',
			'page': 1,
			'order': order,
			'search': search
		});
	});

	var timeout_admin_users = null;
	$('#admin_gamebots_search').on('input', function() {
		if(timeout_admin_users) clearTimeout(timeout_admin_users);

		timeout_admin_users = setTimeout(function(){
			var order = parseInt($('#admin_gamebots_order').val());
			var search = $('#admin_gamebots_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'admin_gamebots',
				'page': 1,
				'order': order,
				'search': search
			});
		}, 1000);
	});

    $(document).on('click', '#pagination_support_requests .pagination-item', function() {
		var page = $(this).attr('data-page');

		var search = $('#support_search').val();
		var status = parseInt($('#support_filter_status').val());

		send_request_socket({
			'type': 'pagination',
			'command': 'support_requests',
			'page': page,
			'status': status,
			'search': search
		});
	});

	$(document).on('change', '#support_filter_status', function() {
		var search = $('#support_search').val();
		var status = parseInt($('#support_filter_status').val());

		send_request_socket({
			'type': 'pagination',
			'command': 'support_requests',
			'page': 1,
			'status': status,
			'search': search
		});
	});

	var timeout_support_requests = null;
	$('#support_search').on('input', function() {
		if(timeout_support_requests) clearTimeout(timeout_support_requests);

		timeout_support_requests = setTimeout(function(){
			var search = $('#support_search').val();
			var status = parseInt($('#support_filter_status').val());

			send_request_socket({
				'type': 'pagination',
				'command': 'support_requests',
				'page': 1,
				'status': status,
				'search': search
			});
		}, 1000);
	});

    $(document).on('click', '#pagination_admin_support_requests .pagination-item', function() {
		var page = $(this).attr('data-page');

		var search = $('#admin_support_search').val();
		var status = parseInt($('#admin_support_filter_status').val());
		var department = parseInt($('#admin_support_filter_department').val());

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_support_requests',
			'page': page,
			'status': status,
			'department': department,
			'search': search
		});
	});

	$(document).on('change', '#admin_support_filter_status', function() {
		var search = $('#admin_support_search').val();
		var status = parseInt($('#admin_support_filter_status').val());
		var department = parseInt($('#admin_support_filter_department').val());

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_support_requests',
			'page': 1,
			'status': status,
			'department': department,
			'search': search
		});
	});

	$(document).on('change', '#admin_support_filter_department', function() {
		var search = $('#admin_support_search').val();
		var status = parseInt($('#admin_support_filter_status').val());
		var department = parseInt($('#admin_support_filter_department').val());

		send_request_socket({
			'type': 'pagination',
			'command': 'admin_support_requests',
			'page': 1,
			'status': status,
			'department': department,
			'search': search
		});
	});

	var timeout_admin_support_requests = null;
	$('#admin_support_search').on('input', function() {
		if(timeout_admin_support_requests) clearTimeout(timeout_admin_support_requests);

		timeout_admin_support_requests = setTimeout(function(){
			var search = $('#admin_support_search').val();
            var status = parseInt($('#admin_support_filter_status').val());
            var department = parseInt($('#admin_support_filter_department').val());

			send_request_socket({
				'type': 'pagination',
				'command': 'admin_support_requests',
				'page': 1,
				'status': status,
				'department': department,
				'search': search
			});
		}, 1000);
	});
});

function pagination_create(pagination, pages, page){
	var DIV = '<div class="pagination-item flex items-center justify-center" data-page="1">«</div>';

	DIV += '<div class="flex row gap-1">';
		var imin_page = page - 3;
		var imax_page = page + 3;

		var min_page = Math.max(1, (imin_page - ((imax_page > pages) ? imax_page - pages : 0)));
		var max_page = Math.min(pages, (imax_page + ((imin_page < 1) ? 1 - imin_page : 0)));

		for(var i = min_page; i <= max_page; i++){
			var class_item = '';
			if(page == i) class_item = 'active';

			DIV += '<div class="pagination-item flex items-center justify-center ' + class_item + '" data-page="' + i + '">' + i + '</div>';
		}
	DIV += '</div>';

	DIV += '<div class="pagination-item flex items-center justify-center" data-page="' + pages + '">»</div>';

	$(pagination).html(DIV);
}

function pagination_addUsers(list){
	$('#admin_users_list').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#admin_users_list').empty();

	list.forEach(function(item){
		var rank_name = { '0': 'member', '1': 'admin', '2': 'moderator', '3': 'helper', '4': 'veteran', '5': 'pro', '6': 'youtuber', '7': 'streamer', '8': 'developer', '100': 'owner' }[item.rank];

		var DIV = '<div class="table-row">';
			DIV += '<div class="table-column text-left">';
				DIV += '<div class="flex items-center gap-1">';
					DIV += createAvatarField(item.user, 'small', '', '');

					DIV += '<div class="text-left width-full ellipsis">' + item.user.name + '</div>';
				DIV += '</div>';
			DIV += '</div>';

			DIV += '<div class="table-column text-left pointer" data-copy="text" data-text="' + item.user.userid + '">' + item.user.userid + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.balance) + '$</div>';
			DIV += '<div class="table-column text-left text-bold chat-link-' + rank_name + '">' + rank_name.toUpperCase() + '</div>';
			DIV += '<div class="table-column text-left">' + item.time_create + '</div>';

			DIV += '<div class="table-column text-right"><a href="/admin/users/' + item.user.userid + '"><button class="button button-primary shadow-2">Moderate</button></a></div>';
		DIV += '</div>';

		$('#admin_users_list').append(DIV);
	});
}

function pagination_addCryptoConfirmations(list){
	$('#admin_crypto_confirmations').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#admin_crypto_confirmations').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row">';
			DIV += '<div class="table-column text-left">#' + item.id + '</div>';
			DIV += '<div class="table-column text-left pointer" data-copy="text" data-text="' + item.userid + '">' + item.userid + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
			DIV += '<div class="table-column text-left text-upper">' + item.currency + '</div>';
			DIV += '<div class="table-column text-left">' + item.time + '</div>';

			DIV += '<div class="table-column full text-right">';
				DIV += '<div class="flex responsive row justify-end gap-1">';
					DIV += '<button class="button button-primary shadow-2 admin_trades_confirm" data-method="crypto" data-trade="' + item.id + '">Confirm</button>';
					DIV += '<button class="button button-primary shadow-2 admin_trades_cancel" data-method="crypto" data-trade="' + item.id + '">Cancel</button>';
				DIV += '</div>';
			DIV += '</div>';
		DIV += '</div>';

		$('#admin_crypto_confirmations').append(DIV);
	});
}

function pagination_addSteamConfirmations(list){
	$('#admin_steam_confirmations').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#admin_steam_confirmations').empty();

	list.forEach(function(item){
		var DIV = "<div class='table-row'>";
			DIV += "<div class='table-column text-left'>#" + item.id + "</div>";
			DIV += "<div class='table-column text-left pointer' data-copy='text' data-text='" + item.userid + "'>" + item.userid + "</div>";
			DIV += "<div class='table-column text-left'>" + getFormatAmountString(item.amount) + "</div>";
			DIV += "<div class='table-column text-left text-primary pointer admin_trades_items' data-items='" + item.items.replaceAll('\'', '') + "'>View Items</div>";
			DIV += "<div class='table-column text-left text-upper'>" + item.game + "</div>";
			DIV += "<div class='table-column text-left'>" + item.time + "</div>";

			DIV += "<div class='table-column full text-right'>";
				DIV += "<div class='flex responsive row justify-end gap-1'>";
					DIV += "<button class='button button-primary shadow-2 admin_trades_confirm' data-method='crypto' data-trade='" + item.id + "'>Confirm</button>";
					DIV += "<button class='button button-primary shadow-2 admin_trades_cancel' data-method='crypto' data-trade='" + item.id + "'>Cancel</button>";
				DIV += "</div>";
			DIV += "</div>";
		DIV += "</div>";

		$('#admin_steam_confirmations').append(DIV);
	});
}

function pagination_addTrackingLinks(list){
	$('#admin_tracking_links').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#admin_tracking_links').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row">';
			DIV += '<div class="table-column text-left pointer" data-copy="text" data-text="' + item.referral + '">' + item.referral + '</div>';
			DIV += '<div class="table-column text-left pointer" data-copy="text" data-text="' + item.userid + '">' + item.userid + '</div>';
			DIV += '<div class="table-column text-left">' + item.usage + '</div>';

			DIV += '<div class="table-column full text-right">';
				DIV += '<div class="flex responsive row justify-end gap-1">';
                    DIV += '<button class="button button-primary shadow-2" data-copy="text" data-text="' + item.link + '">Copy link</button>';
					DIV += '<button class="button button-primary shadow-2 admin_tracking_joins_dashboard" data-id="' + item.id + '">Dashboard</button>';
					DIV += '<button class="button button-danger shadow-2 admin_tracking_links_remove" data-id="' + item.id + '">Remove</button>';
				DIV += '</div>';
			DIV += '</div>';
		DIV += '</div>';

		$('#admin_tracking_links').append(DIV);
	});
}

function pagination_addDepositBonuses(list){
	$('#admin_deposit_bonuses').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#admin_deposit_bonuses').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row">';
			DIV += '<div class="table-column text-left pointer" data-copy="text" data-text="' + item.code.toUpperCase() + '">' + item.code.toUpperCase() + '</div>';
			DIV += '<div class="table-column text-left pointer" data-copy="text" data-text="' + item.referral + '">' + item.referral + '</div>';
			DIV += '<div class="table-column text-left">' + item.uses + '</div>';
			DIV += '<div class="table-column text-left">' + roundedToFixed(item.amount, 5).toFixed(5) + '</div>';

			DIV += '<div class="table-column full text-right">';
				DIV += '<button class="button button-primary shadow-2 admin_deposit_bonuses_remove" data-id="' + item.id + '">Remove</button>';
			DIV += '</div>';
		DIV += '</div>';

		$('#admin_deposit_bonuses').append(DIV);
	});
}

function pagination_addAccountTransactions(list){
	$('#account_transactions').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_transactions').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row text-' + (item.amount < 0 ? "danger" : "success") + '">';
			DIV += '<div class="table-column text-left">#' + item.id + '</div>';
			DIV += '<div class="table-column text-left text-capitalised">' + item.service.split('_').join(' ') + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
			DIV += '<div class="table-column text-left">' + item.date + '</div>';
		DIV += '</div>';

		$('#account_transactions').append(DIV);
	});
}

function pagination_addAccountDeposits(list){
	$('#account_deposits').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_deposits').empty();

	list.forEach(function(item){
        var DIV = '<div class="table-row ' + { completed: 'text-success', declined: 'text-danger', pending: 'text-warning', partially_paid: 'text-warning', clearing: 'text-warning' }[item.status] + '">';
			DIV += '<div class="table-column text-left">' + item.id + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.paid) + '</div>';
			DIV += '<div class="table-column text-left">' + item.method + '</div>';
			DIV += '<div class="table-column text-left">' + { completed: 'Completed', declined: 'Declined', pending: 'Pending', partially_paid: 'Partially Paid', clearing: 'Clearing' }[item.status] + '</div>';
			DIV += '<div class="table-column text-left">' + item.date + '</div>';
		DIV += '</div>';

		$('#account_deposits').append(DIV);
	});
}

function pagination_addAccountWithdrawals(list){
	$('#account_withdrawals').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_withdrawals').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { completed: 'text-success', declined: 'text-danger', pending: 'text-warning', clearing: 'text-warning' }[item.status] + '">';
			DIV += '<div class="table-column text-left">' + item.id + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
			DIV += '<div class="table-column text-left">' + item.method + '</div>';
			DIV += '<div class="table-column text-left">' + { completed: 'Completed', declined: 'Declined', pending: 'Pending', clearing: 'Clearing' }[item.status] + '</div>';
			DIV += '<div class="table-column text-left">' + item.date + '</div>';
		DIV += '</div>';

		$('#account_withdrawals').append(DIV);
	});
}

function pagination_addAccountRouletteHistory(list){
	$('#account_roulette_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_roulette_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + item.option + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_roulette_history').append(DIV);
	});
}

function pagination_addAccountCrashHistory(list){
	$('#account_crash_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_crash_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + roundedToFixed(item.multiplier, 2).toFixed(2) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_crash_history').append(DIV);
	});
}

function pagination_addAccountJackpotHistory(list){
	$('#account_jackpot_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_jackpot_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + item.roll + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_jackpot_history').append(DIV);
	});
}

function pagination_addAccountCoinflipHistory(list){
	$('#account_coinflip_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_coinflip_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_coinflip_history').append(DIV);
	});
}

function pagination_addAccountDiceHistory(list){
	$('#account_dice_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_dice_history').empty();

	list.forEach(function(item){
        var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + roundedToFixed(item.roll, 2).toFixed(2) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_dice_history').append(DIV);
	});
}

function pagination_addAccountUnboxingHistory(list){
	$('#account_unboxing_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_unboxing_history').empty();

	list.forEach(function(item){
		 var DIV = '<div class="table-row text-success">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.winning) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_unboxing_history').append(DIV);
	});
}

function pagination_addAccountCasebattleHistory(list){
	$('#account_casebattle_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_casebattle_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.winning) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_casebattle_history').append(DIV);
	});
}

function pagination_addAccountUpgraderHistory(list){
	$('#account_upgrader_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_upgrader_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + roundedToFixed(item.roll, 2).toFixed(2) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_upgrader_history').append(DIV);
	});
}

function pagination_addAccountTowerHistory(list){
	$('#account_tower_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_tower_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left text-capitalised">' + item.difficulty + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_tower_history').append(DIV);
	});
}

function pagination_addAccountMinesweeperHistory(list){
	$('#account_minesweeper_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_minesweeper_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + item.bombs + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_minesweeper_history').append(DIV);
	});
}

function pagination_addAccountPlinkoHistory(list){
	$('#account_plinko_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_plinko_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left text-capitalised">' + item.difficulty + '</div>';
            DIV += '<div class="table-column text-left">' + item.rows + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_plinko_history').append(DIV);
	});
}

function pagination_addAccountCasinoHistory(list){
	$('#account_casino_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#account_casino_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left text-capitalised">' + item.game.split('_').join(' ') + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#account_casino_history').append(DIV);
	});
}

function pagination_addAccountInventory(list){
	$('#account_inventory').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No data found</div></div>');

	if(list.length > 0) $('#account_inventory').empty();

	list.forEach(function(item){
        var classes = '';
        if(item.status != 0) classes = 'notaccepted';

        var DIV = '<div class="listing-item inventory-item flex column ' + classes + '" data-id="' + item.id + '" data-status="' + item.status + '">';
            DIV += '<div class="listing-slot rounded-0" style="border-bottom: solid 3px ' + item.color + ' !important;">';
                var name = getInfosByItemName(item.name);

                DIV += '<div class="item-inventory-settings transition-5" style="opacity: 0; display: unset;">';
                    DIV += '<div class="flex column gap-2 items-center justify-center height-full width-full">';
                        DIV += '<button class="button button-primary shadow-2 inventory_sell_item" data-id="' + item.id + '">SELL ITEM</button>';
                        DIV += '<a href="/upgrader/' + item.id + '"><button class="button button-danger shadow-2">TO UPGRADER</button></a>';
                    DIV += '</div>';
                DIV += '</div>';

                DIV += '<div class="item-notaccepted"></div>';

                if(name.exterior != null) DIV += '<div class="item-quality text-left">' + name.exterior + '</div>';

                DIV += '<div class="item-image-content flex items-center justify-center p-2">';
                    DIV += '<img class="item-image transition-5" src="' + item.image + '">';
                DIV += '</div>';

                DIV += '<div class="item-name-content text-left">';
                    if(name.brand != null) DIV += '<div class="item-brand ellipsis">' + name.brand + '</div>';
                    if(name.name != null) DIV += '<div class="item-name ellipsis">' + name.name + '</div>';
                DIV += '</div>';

                if(item.status == -1) DIV += '<div class="item-info text-danger text-right">Sold</div>';
                else if(item.status == -2) DIV += '<div class="item-info text-danger text-right">Upgraded</div>';
                else DIV += '<div class="item-info text-right">New</div>';

                DIV += '<div class="item-price flex row items-center justify-center gap-1">';
                    DIV += '<div class="coin main"></div>';
                    DIV += '<span>' + getFormatAmountString(item.price) + '</span>';
                DIV += '</div>';
            DIV += '</div>';
        DIV += '</div>';

		$('#account_inventory').append(DIV);
	});

    tinysort('#account_inventory .listing-item', {
        data: 'status',
        order: 'desc'
    });
}

function pagination_addUserTransactions(list){
	$('#user_transactions').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_transactions').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row text-' + (item.amount < 0 ? "danger" : "success") + '">';
			DIV += '<div class="table-column text-left">#' + item.id + '</div>';
			DIV += '<div class="table-column text-left text-capitalised">' + item.service.split('_').join(' ') + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
			DIV += '<div class="table-column text-left">' + item.date + '</div>';
		DIV += '</div>';

		$('#user_transactions').append(DIV);
	});
}

function pagination_addUserDeposits(list){
	$('#user_deposits').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_deposits').empty();

	list.forEach(function(item){
        var DIV = '<div class="table-row ' + { completed: 'text-success', declined: 'text-danger', pending: 'text-warning', partially_paid: 'text-warning', clearing: 'text-warning' }[item.status] + '">';
			DIV += '<div class="table-column text-left">' + item.id + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.paid) + '</div>';
			DIV += '<div class="table-column text-left">' + item.method + '</div>';
			DIV += '<div class="table-column text-left">' + { completed: 'Completed', declined: 'Declined', pending: 'Pending', partially_paid: 'Partially Paid', clearing: 'Clearing' }[item.status] + '</div>';
			DIV += '<div class="table-column text-left">' + item.date + '</div>';
		DIV += '</div>';

		$('#user_deposits').append(DIV);
	});
}

function pagination_addUserWithdrawals(list){
	$('#user_withdrawals').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_withdrawals').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { completed: 'text-success', declined: 'text-danger', pending: 'text-warning', clearing: 'text-warning' }[item.status] + '">';
			DIV += '<div class="table-column text-left">' + item.id + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
			DIV += '<div class="table-column text-left">' + item.method + '</div>';
			DIV += '<div class="table-column text-left">' + { completed: 'Completed', declined: 'Declined', pending: 'Pending', clearing: 'Clearing' }[item.status] + '</div>';
			DIV += '<div class="table-column text-left">' + item.date + '</div>';
		DIV += '</div>';

		$('#user_withdrawals').append(DIV);
	});
}

function pagination_addUserRouletteHistory(list){
	$('#user_roulette_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_roulette_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + item.option + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_roulette_history').append(DIV);
	});
}

function pagination_addUserCrashHistory(list){
	$('#user_crash_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_crash_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + roundedToFixed(item.multiplier, 2).toFixed(2) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_crash_history').append(DIV);
	});
}

function pagination_addUserJackpotHistory(list){
	$('#user_jackpot_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_jackpot_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + item.roll + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_jackpot_history').append(DIV);
	});
}

function pagination_addUserCoinflipHistory(list){
	$('#user_coinflip_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_coinflip_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_coinflip_history').append(DIV);
	});
}

function pagination_addUserDiceHistory(list){
	$('#user_dice_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_dice_history').empty();

	list.forEach(function(item){
        var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + roundedToFixed(item.roll, 2).toFixed(2) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_dice_history').append(DIV);
	});
}

function pagination_addUserUnboxingHistory(list){
	$('#user_unboxing_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_unboxing_history').empty();

	list.forEach(function(item){
		 var DIV = '<div class="table-row text-success">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.winning) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_unboxing_history').append(DIV);
	});
}

function pagination_addUserCasebattleHistory(list){
	$('#user_casebattle_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_casebattle_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.winning) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_casebattle_history').append(DIV);
	});
}

function pagination_addUserUpgraderHistory(list){
	$('#user_upgrader_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_upgrader_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + roundedToFixed(item.roll, 2).toFixed(2) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + { win: 'Win', loss: 'Loss' }[item.status] + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_upgrader_history').append(DIV);
	});
}

function pagination_addUserTowerHistory(list){
	$('#user_tower_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_tower_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left text-capitalised">' + item.difficulty + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_tower_history').append(DIV);
	});
}

function pagination_addUserMinesweeperHistory(list){
	$('#user_minesweeper_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_minesweeper_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left">' + item.bombs + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_minesweeper_history').append(DIV);
	});
}

function pagination_addUserPlinkoHistory(list){
	$('#user_plinko_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_plinko_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left text-capitalised">' + item.difficulty + '</div>';
            DIV += '<div class="table-column text-left">' + item.rows + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_plinko_history').append(DIV);
	});
}

function pagination_addUserCasinoHistory(list){
	$('#user_casino_history').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#user_casino_history').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row ' + { win: 'text-success', loss: 'text-danger' }[item.status] + '">';
            DIV += '<div class="table-column text-left">#' + item.id + '</div>';
            DIV += '<div class="table-column text-left text-capitalised">' + item.game.split('_').join(' ') + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.amount) + '</div>';
            DIV += '<div class="table-column text-left">' + getFormatAmountString(item.profit) + '</div>';
            DIV += '<div class="table-column text-left">' + item.date + '</div>';
        DIV += '</div>';

		$('#user_casino_history').append(DIV);
	});
}

function pagination_addUserInventory(list){
	$('#user_inventory').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No data found</div></div>');

	if(list.length > 0) $('#user_inventory').empty();

	list.forEach(function(item){
        var classes = '';
        if(item.status != 0) classes = 'notaccepted';

        var DIV = '<div class="listing-item inventory-item flex column ' + classes + '" data-id="' + item.id + '" data-status="' + item.status + '">';
            DIV += '<div class="listing-slot rounded-0" style="border-bottom: solid 3px ' + item.color + ' !important;">';
                var name = getInfosByItemName(item.name);

                DIV += '<div class="item-notaccepted"></div>';

                if(name.exterior != null) DIV += '<div class="item-quality text-left">' + name.exterior + '</div>';

                DIV += '<div class="item-image-content flex items-center justify-center p-2">';
                    DIV += '<img class="item-image transition-5" src="' + item.image + '">';
                DIV += '</div>';

                DIV += '<div class="item-name-content text-left">';
                    if(name.brand != null) DIV += '<div class="item-brand ellipsis">' + name.brand + '</div>';
                    if(name.name != null) DIV += '<div class="item-name ellipsis">' + name.name + '</div>';
                DIV += '</div>';

                if(item.status == -1) DIV += '<div class="item-info text-danger text-right">Sold</div>';
                else if(item.status == -2) DIV += '<div class="item-info text-danger text-right">Upgraded</div>';
                else DIV += '<div class="item-info text-right">New</div>';

                DIV += '<div class="item-price flex row items-center justify-center gap-1">';
                    DIV += '<div class="coin main"></div>';
                    DIV += '<span>' + getFormatAmountString(item.price) + '</span>';
                DIV += '</div>';
            DIV += '</div>';
        DIV += '</div>';

		$('#user_inventory').append(DIV);
	});

    tinysort('#user_inventory .listing-item', {
        data: 'status',
        order: 'desc'
    });
}

function pagination_addAffiliatesReferrals(list){
	$('#affiliates_referrals').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#affiliates_referrals').empty();

	list.forEach(function(item){
       var DIV = ' <div class="table-row">';
            DIV += '<div class="table-column text-left">' + item.userid + '</div>';
            DIV += '<div class="table-column text-left">' + item.wagered.toFixed(5) + '</div>';
            DIV += '<div class="table-column text-left">' + item.deposited.toFixed(5) + '</div>';
            DIV += '<div class="table-column text-left">' + item.commissions.wagered.toFixed(5) + '</div>';
            DIV += '<div class="table-column text-left">' + item.commissions.deposited.toFixed(5) + '</div>';
            DIV += '<div class="table-column text-left">' + item.commissions.total.toFixed(5) + '</div>';
        DIV += '</div>';

		$('#affiliates_referrals').append(DIV);
	});
}

function pagination_addGamebots(list){
	$('#admin_gamebots_list').html('<div class="table-row table_message"><div class="table-column text-center">No data found</div></div>');

	if(list.length > 0) $('#admin_gamebots_list').empty();

	list.forEach(function(item){
		var DIV = '<div class="table-row">';
			DIV += '<div class="table-column text-left">';
				DIV += '<div class="flex items-center gap-1">';
					DIV += createAvatarField(item.user, 'small', '', '');

					DIV += '<div class="text-left width-full ellipsis">' + item.user.name + '</div>';
				DIV += '</div>';
			DIV += '</div>';

			DIV += '<div class="table-column text-left pointer" data-copy="text" data-text="' + item.user.userid + '">' + item.user.userid + '</div>';
			DIV += '<div class="table-column text-left">' + getFormatAmountString(item.balance) + '$</div>';

			DIV += '<div class="table-column text-right"><button class="button button-primary shadow-2 admin_gamebot_moderate" data-userid="' + item.user.userid + '">Moderate</button></div>';
		DIV += '</div>';

		$('#admin_gamebots_list').append(DIV);
	});
}

/* END PAGINATION */

/* ADMIN PANEL */

$(document).ready(function() {
	$(document).on('click', '#admin_maintenance_set', function() {
		var status = parseInt($('#admin_maintenance_status').val()) == 1;
		var reason = $('#admin_maintenance_reason').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'maintenance',
				'status': status,
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.admin_dropdown_settings', function() {
		var settings = $(this).attr('data-settings');
		var status = parseInt($('.admin_control_settings[data-settings="' + settings + '"]').val()) == 1;

		confirm_action(function(confirmed){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'settings',
				'settings': settings,
				'status': status
			});
		});
	});

	$(document).on('change', '.admin_switch_settings', function() {
		var settings = $(this).attr('data-settings');
		var status = $(this).is(':checked');

		send_request_socket({
			'type': 'admin',
			'command': 'settings',
			'settings': settings,
			'status': status
		});
	});

	$(document).on('click', '.admin_user_remove_bind', function() {
		var bind = $(this).attr('data-bind');

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'remove_bind',
				'userid': app.paths[2],
				'bind': bind,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_remove_exclusion', function() {
		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'remove_exclusion',
				'userid': app.paths[2],
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_remove_sessions', function() {
		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'remove_sessions',
				'userid': app.paths[2],
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_ip_ban', function() {
		var ip = $('#admin_user_ip_value').val();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'ban_ip',
				'userid': app.paths[2],
				'ip': ip,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_ip_unban', function() {
		var ip = $('#admin_user_ip_value').val();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'unban_ip',
				'userid': app.paths[2],
				'ip': ip,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_rank_set', function() {
		var rank = parseInt($('#admin_user_rank_value').val());

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_rank',
				'userid': app.paths[2],
				'rank': rank,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_balance_edit', function() {
		var amount = $('#admin_user_balance_amount').val();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'edit_balance',
				'userid': app.paths[2],
				'amount': amount,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_site_set', function() {
		var reason = $('#admin_user_restriction_site_reason').val();
		var amount = $('#admin_user_restriction_site_amount').val().toString();
		var date = $('#admin_user_restriction_site_date').val().toString();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_restriction',
				'userid': app.paths[2],
				'restriction': 'site',
				'time': amount + date,
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_site_permanently', function() {
		var reason = $('#admin_user_restriction_site_reason').val();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_restriction',
				'userid': app.paths[2],
				'restriction': 'site',
				'time': 'permanent',
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_site_unset', function() {
		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'unset_restriction',
				'userid': app.paths[2],
				'restriction': 'site',
				'secret': secret
			});
		});
	});

    $(document).on('click', '#admin_user_restriction_play_set', function() {
		var reason = $('#admin_user_restriction_play_reason').val();
		var amount = $('#admin_user_restriction_play_amount').val().toString();
		var date = $('#admin_user_restriction_play_date').val().toString();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_restriction',
				'userid': app.paths[2],
				'restriction': 'play',
				'time': amount + date,
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_play_permanently', function() {
		var reason = $('#admin_user_restriction_play_reason').val();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_restriction',
				'userid': app.paths[2],
				'restriction': 'play',
				'time': 'permanent',
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_play_unset', function() {
		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'unset_restriction',
				'userid': app.paths[2],
				'restriction': 'play',
				'secret': secret
			});
		});
	});

    $(document).on('click', '#admin_user_restriction_trade_set', function() {
		var reason = $('#admin_user_restriction_trade_reason').val();
		var amount = $('#admin_user_restriction_trade_amount').val().toString();
		var date = $('#admin_user_restriction_trade_date').val().toString();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_restriction',
				'userid': app.paths[2],
				'restriction': 'trade',
				'time': amount + date,
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_trade_permanently', function() {
		var reason = $('#admin_user_restriction_trade_reason').val();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_restriction',
				'userid': app.paths[2],
				'restriction': 'trade',
				'time': 'permanent',
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_trade_unset', function() {
		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'unset_restriction',
				'userid': app.paths[2],
				'restriction': 'trade',
				'secret': secret
			});
		});
	});

    $(document).on('click', '#admin_user_restriction_mute_set', function() {
		var reason = $('#admin_user_restriction_mute_reason').val();
		var amount = $('#admin_user_restriction_mute_amount').val().toString();
		var date = $('#admin_user_restriction_mute_date').val().toString();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_restriction',
				'userid': app.paths[2],
				'restriction': 'mute',
				'time': amount + date,
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_mute_permanently', function() {
		var reason = $('#admin_user_restriction_mute_reason').val();

		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'set_restriction',
				'userid': app.paths[2],
				'restriction': 'mute',
				'time': 'permanent',
				'reason': reason,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_user_restriction_mute_unset', function() {
		if(app.paths[2] === undefined) return;

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'unset_restriction',
				'userid': app.paths[2],
				'restriction': 'mute',
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_admin_access_set', function() {
		var userid = $('#admin_admin_access_userid').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'admin_access_set',
				'userid': userid,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_admin_access_unset', function() {
		var userid = $('#admin_admin_access_userid').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'admin_access_unset',
				'userid': userid,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_dashboard_access_set', function() {
		var userid = $('#admin_dashboard_access_userid').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'dashboard_access_set',
				'userid': userid,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_dashboard_access_unset', function() {
		var userid = $('#admin_dashboard_access_userid').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'dashboard_access_unset',
				'userid': userid,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_tracking_links_create', function() {
		var expire = $('#admin_tracking_links_expire').val();
		var usage = $('#admin_tracking_links_usage').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'tracking_links_create',
				'expire': expire,
				'usage': usage,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.admin_tracking_links_remove', function() {
		var id = $(this).attr('data-id');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'tracking_links_remove',
				'id': id,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.admin_tracking_joins_dashboard', function() {
		var id = $(this).attr('data-id');

		var $dashboard = $('#modal_tracking_joins_dashboard .dashboard-chart');

		$dashboard.attr('data-id', id);

		$('#modal_tracking_joins_dashboard').modal('show');
	});

    $(document).on('show', '#modal_tracking_joins_dashboard', function() {
        var $dashboard = $('#modal_tracking_joins_dashboard .dashboard-chart');

		dashboard_loadGraph({ date: $dashboard.find('.dashboard-graph').val(), graph: $dashboard.attr('data-graph') + '.' + $dashboard.attr('data-id') });
    });

	$(document).on('click', '#admin_deposit_bonuses_create', function() {
		var referral = $('#admin_deposit_bonuses_referral').val();
		var code = $('#admin_deposit_bonuses_code').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'deposit_bonuses_create',
				'referral': referral,
				'code': code,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.admin_deposit_bonuses_remove', function() {
		var id = $(this).attr('data-id');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'deposit_bonuses_remove',
				'id': id,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.admin_trades_confirm', function() {
		var method = $(this).attr('data-method');
		var trade = $(this).attr('data-trade');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'payment_confirm',
				'method': method,
				'trade': trade,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.admin_trades_cancel', function() {
		var method = $(this).attr('data-method');
		var trade = $(this).attr('data-trade');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'payment_cancel',
				'method': method,
				'trade': trade,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#admin_payments_manually_amount_set', function() {
		var amount = $('#admin_payments_manually_amount_value').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'payments_manually_amount',
				'amount': amount,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.admin_trades_items', function() {
		var items = $(this).data('items');

		$('#modal_view_bundle').modal('show');
		$('#modal_view_bundle .bundle-items').empty();

		items.forEach(function(item){
			$('#modal_view_bundle .bundle-items').append(paymentSkinView(item));
		});
	});

	$(document).on('click', '#admin_gamebots_create', function() {
		var name = $('#admin_gamebots_name').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'gamebots_create',
				'name': name,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.admin_gamebot_moderate', function() {
		var userid = $(this).attr('data-userid');

		$('#admin_gamebots_balance_edit').attr('data-userid', userid);

		$('#modal_gamebots_moderate').modal('show');
	});

	$(document).on('click', '#admin_gamebots_balance_edit', function() {
		var amount = $('#admin_gamebots_balance_amount').val();
		var userid = $(this).attr('data-userid');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'edit_balance',
				'userid': userid,
				'amount': amount,
				'secret': secret
			});
		});
	});

    // ADMIN SUPPORT
	$(document).on('click', '#admin_support_claim', function() {
		var id = $(this).attr('data-id');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'support_claim',
				'id': id,
				'secret': secret
			});
		});
	});

    $(document).on('click', '#admin_support_release', function() {
		var id = $(this).attr('data-id');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'support_release',
				'id': id,
				'secret': secret
			});
		});
	});

    $(document).on('click', '#admin_support_change_department', function() {
		var id = $(this).attr('data-id');
        var department = $('#admin_support_department').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'support_change_department',
				'id': id,
				'department': department,
				'secret': secret
			});
		});
	});

    $(document).on('click', '#admin_support_reply', function() {
		var id = $(this).attr('data-id');
        var message = $('#admin_support_reply_message').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'support_reply',
				'id': id,
				'message': message,
				'secret': secret
			});

            $('#admin_support_reply_message').val('');

            changeInputFieldLabel($('#admin_support_reply_message').closest('.input_field'));
            clearInputFieldError($('#admin_support_reply_message').closest('.input_field'));
		});
	});

    $(document).on('click', '#admin_support_close', function() {
		var id = $(this).attr('data-id');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'support_close',
				'id': id,
				'secret': secret
			});
		});
	});
});

function confirm_action(callback){
	$('#modal_confirm_action').modal('show');

	$(document).off('click', '#confirm_action_no');
	$(document).off('click', '#confirm_action_yes');

	$(document).on('click', '#confirm_action_no', function() { return callback(false); });

	$(document).on('click', '#confirm_action_yes', function() { return callback(true); });
}

function confirm_identity(callback){
	$('#modal_confirm_identity').modal('show');

	$(document).off('click', '#confirm_identity_no');
	$(document).off('click', '#confirm_identity_yes');

	$(document).on('click', '#confirm_identity_no', function() { return callback(false); });

	$(document).on('click', '#confirm_identity_yes', function() {
		var secret = $('#confirm_identity_secret').val();

		return callback(true, secret);
	});
}

function admin_supportAddReply(reply){
    var DIV = '<div class="flex column gap-2">';
        DIV += '<div class="flex justify-between items-center gap-2 pl-2 pr-2">';
            DIV += '<div class="flex items-center gap-1 overflow-h">';
                DIV += createAvatarField(reply.user, 'small', '', '');

                DIV += '<div class="flex column text-left overflow-h">';
                    DIV += '<div class="font-8 ellipsis">' + reply.user.name + '</div>';

                    if(reply.response) {
                        DIV += '<div class="text-success font-6">Support Staff</div>';
                    } else {
                        DIV += '<div class="text-danger font-6">He</div>';
                    }
                DIV += '</div>';
            DIV += '</div>';

            DIV += '<div class="text-muted-foreground font-6">' + reply.date + '</div>';
        DIV += '</div>';

        if(reply.response) {
            DIV += '<div class="message response bg-card p-4 text-left ml-6">';
                DIV += '<div class="flex column gap-4 text-left mt-2">';
                    DIV += '<div class="text-muted-foreground">Greetings ' + reply.requester + ',</div>';

                    DIV += '<div>' + reply.message + '</div>';

                    DIV += '<div class="text-muted-foreground">';
                        DIV += '<div>All the best,</div>';
                        DIV += '<div>' + reply.user.name + '</div>';
                    DIV += '</div>';
                DIV += '</div>';
            DIV += '</div>';
        } else {
            DIV += '<div class="message bg-card p-4 text-left ml-6">' + reply.message + '</div>';
        }
    DIV += '</div>';

    $('#admin_support_messages').append(DIV);
}

function admin_supportSetStatus(closed, status){
    $('#admin_support_request_status').removeClass('bg-danger bg-opacity-50').removeClass('bg-warning bg-opacity-50').removeClass('bg-success bg-opacity-50').removeClass('bg-info bg-opacity-50');

    $('#admin_support_request_status').addClass([ { 0: 'bg-danger bg-opacity-50', 1: 'bg-warning bg-opacity-50', 2: 'bg-success bg-opacity-50' }[status], 'bg-info bg-opacity-50' ][closed]);
    $('#admin_support_request_status').text([ { 0: 'Opened', 1: 'Unsolved', 2: 'Answered' }[status], 'Solved' ][closed]);
}

function pagination_addAdminSupportRequests(list){
	$('#admin_support_requests').html('<div class="table-row table_message"><div class="table-column text-center">No requests found</div></div>');

	if(list.length > 0) $('#admin_support_requests').empty();

	list.forEach(function(item){
        var DIV = '<div class="table-row">';
            DIV += '<div class="table-column text-left"><a class="text-underline" href="/admin/support/requests/' + item.id + '">' + item.subject + '</a></div>';
            DIV += '<div class="table-column text-left">' + { 0: 'General / Others', 1: 'Bug report', 2: 'Trade offer issue', 3: 'Improvements / Ideas', 4: 'Marketing / Partnership', 5: 'Ranking up' }[item.department] + '</div>';
            DIV += '<div class="table-column text-left">' + item.created + '</div>';
            DIV += '<div class="table-column text-left">' + item.updated + '</div>';
            DIV += '<div class="table-column text-left">';
                if(item.assigned){
                     DIV += '<div class="flex items-center gap-1">';
                        DIV += createAvatarField(item.assigned, 'small', '', '');
                        DIV += '<div class="text-left width-full ellipsis">' + item.assigned.name + '</div>';
                    DIV += '</div>';
                } else if(item.closed) DIV += '<div class="text-bold text-danger">Unavailable</div>';
                else DIV += '<div class="text-bold text-success">Available</div>';
            DIV += '</div>';
            DIV += '<div class="table-column"><div class="flex row justify-end"><div class="' + [ { 0: 'bg-danger bg-opacity-50', 1: 'bg-warning bg-opacity-50', 2: 'bg-success bg-opacity-50' }[item.status], 'bg-info bg-opacity-50' ][item.closed] + ' p-1 rounded-0">' + [ { 0: 'Opened', 1: 'Unsolved', 2: 'Answered' }[item.status], 'Solved' ][item.closed] + '</div></div></div>';
        DIV += '</div>';

		$('#admin_support_requests').append(DIV);
	});
}

/* END ADMIN PANEL */

/* HISTORY */

$(document).ready(function() {
	//app.page == 'home'
    if(profile_settingsGet('history') == 'game_bets' && app.page == '') {
		profile_settingsChange('history', 'all_bets');

		$('.bet-select .history-load').removeClass('active');
		$('.bet-select .history-load[data-type="all_bets"]').addClass('active');
	}

	$(document).on('click', '.history-load', function() {
		var history = $(this).attr('data-type');
		var game = app.paths[0];

		profile_settingsChange('history', history);

		$('.bet-select .history-load').removeClass('active');
		$('.bet-select .history-load[data-type="' + history + '"]').addClass('active');

		send_request_socket({
			'type': 'history',
			'command': 'get',
			'history': history,
			'game': game
		});
	});
});

function history_addHistory(history){
	$('#history_list .history_message').remove();

	$('#history_list').prepend(liveHistory({ ...history, ...{
        amount: getFormatAmountString(history.amount),
        multiplier: history.multiplier.toFixed(2),
        winning: getFormatAmountString(history.winning)
    }}));
	$('#history_list .item:first-child').slideUp(0).slideDown('fast');

	while($('#history_list > .item').length > 10) $('#history_list .item').last().remove();
}

/* END HISTORY */

/* FAIR */

$(document).ready(function() {
	$(document).on('click', '#save_clientseed', function() {
		var client_seed = $('#client_seed').val();

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'fair',
				'command': 'save_clientseed',
				'seed': client_seed,
				'recaptcha': render
			});
		});
	});

	$(document).on('click', '#regenerate_serverseed', function() {
		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'fair',
				'command': 'regenerate_serverseed',
				'recaptcha': render
			});
		});
	});
});

/* END FAIR */

/* SUPPORT */

$(document).ready(function() {
	$(document).on('click', '#support_create', function() {
		var subject = $('#support_subject').val();
		var department = $('#support_department').val();
		var message = $('#support_message').val();

		send_request_socket({
            'type': 'support',
            'command': 'create',
            'subject': subject,
            'department': department,
            'message': message
        });
	});

    $(document).on('click', '#support_reply', function() {
		var id = $(this).attr('data-id');
		var message = $('#support_reply_message').val();

		send_request_socket({
            'type': 'support',
            'command': 'reply',
            'id': id,
            'message': message
        });

        $('#support_reply_message').val('');

        changeInputFieldLabel($('#support_reply_message').closest('.input_field'));
        clearInputFieldError($('#support_reply_message').closest('.input_field'));
	});

    $(document).on('click', '#support_close', function() {
		var id = $(this).attr('data-id');

		send_request_socket({
            'type': 'support',
            'command': 'close',
            'id': id
        });
	});
});

function support_addReply(reply){
    var DIV = '<div class="flex column gap-2">';
        DIV += '<div class="flex justify-between items-center gap-2 pl-2 pr-2">';
            DIV += '<div class="flex items-center gap-1 overflow-h">';
                DIV += createAvatarField(reply.user, 'small', '', '');

                DIV += '<div class="flex column text-left overflow-h">';
                    DIV += '<div class="font-8 ellipsis">' + reply.user.name + '</div>';

                    if(reply.response) {
                        DIV += '<div class="text-success font-6">Support Staff</div>';
                    } else {
                        DIV += '<div class="text-danger font-6">Me</div>';
                    }
                DIV += '</div>';
            DIV += '</div>';

            DIV += '<div class="text-muted-foreground font-6">' + reply.date + '</div>';
        DIV += '</div>';

        if(reply.response) {
            DIV += '<div class="message response bg-card p-4 text-left ml-6">';
                DIV += '<div class="flex column gap-4 text-left mt-2">';
                    DIV += '<div class="text-muted-foreground">Greetings ' + reply.requester + ',</div>';

                    DIV += '<div>' + reply.message + '</div>';

                    DIV += '<div class="text-muted-foreground">';
                        DIV += '<div>All the best,</div>';
                        DIV += '<div>' + reply.user.name + '</div>';
                    DIV += '</div>';
                DIV += '</div>';
            DIV += '</div>';
        } else {
            DIV += '<div class="message bg-card p-4 text-left ml-6">' + reply.message + '</div>';
        }
    DIV += '</div>';

    $('#support_messages').append(DIV);
}

function support_setStatus(closed, status){
    $('#support_request_status').removeClass('bg-success bg-opacity-50').removeClass('bg-warning bg-opacity-50').removeClass('bg-info bg-opacity-50');

    $('#support_request_status').addClass([ { 0: 'bg-success bg-opacity-50', 1: 'bg-success bg-opacity-50', 2: 'bg-warning bg-opacity-50' }[status], 'bg-info bg-opacity-50' ][closed]);
    $('#support_request_status').text([ { 0: 'Opened', 1: 'Opened', 2: 'Awaiting your reply' }[status], 'Solved' ][closed]);
}

function pagination_addSupportRequests(list){
	$('#support_requests').html('<div class="table-row table_message"><div class="table-column text-center">No requests found</div></div>');

	if(list.length > 0) $('#support_requests').empty();

	list.forEach(function(item){
        var DIV = '<div class="table-row">';
            DIV += '<div class="table-column text-left"><a class="text-underline" href="/support/requests/' + item.id + '">' + item.subject + '</a></div>';
            DIV += '<div class="table-column text-left">' + { 0: 'General / Others', 1: 'Bug report', 2: 'Trade offer issue', 3: 'Improvements / Ideas', 4: 'Marketing / Partnership', 5: 'Ranking up' }[item.department] + '</div>';
            DIV += '<div class="table-column text-left">' + item.created + '</div>';
            DIV += '<div class="table-column text-left">' + item.updated + '</div>';
            DIV += '<div class="table-column"><div class="flex row justify-end"><div class="' + [ { 0: 'bg-success bg-opacity-50', 1: 'bg-success bg-opacity-50', 2: 'bg-warning bg-opacity-50' }[item.status], 'bg-info bg-opacity-50' ][item.closed] + ' p-1 rounded-0">' + [ { 0: 'Opened', 1: 'Opened', 2: 'Awaiting your reply' }[item.status], 'Solved' ][item.closed] + '</div></div></div>';
        DIV += '</div>';

		$('#support_requests').append(DIV);
	});
}

/* END SUPPORT */

/* CHAT */

var chat_ignoreList = [];
var chat_isPaused = false;
var chat_maxMessages = 40;

var chat_replyMessage = null;
var chat_rainInterval = null;

var timeFormats = [
	{time: 1, time_format: 1, ago: 'seconds ago', next: 'seconds from now', count: true},
	{time: 60, time_format: 60, ago: 'minute ago', next: 'minute from now', count: true},
	{time: 120, time_format: 60, ago: 'minutes ago', next: 'minutes from now', count: true},
	{time: 3600, time_format: 3600, ago: 'hour ago', next: 'hour from now', count: true},
	{time: 7200, time_format: 3600, ago: 'hours ago', next: 'hours from now', count: true},
	{time: 86400, time_format: 86400, ago: 'Yesterday', next: 'Tomorrow', count: false},
	{time: 172800, time_format: 86400, ago: 'days ago', next: 'days from now', count: true},
	{time: 604800, time_format: 604800, ago: 'Last week', next: 'Next week', count: false},
	{time: 1209600, time_format: 604800, ago: 'weeks ago', next: 'weeks from now', count: true},
	{time: 2419200, time_format: 2419200, ago: 'Last month', next: 'Next month', count: false},
	{time: 4838400, time_format: 2419200, ago: 'months ago', next: 'months from now', count: true},
	{time: 29030400, time_format: 29030400, ago: 'Last year', next: 'Next year', count: false},
	{time: 58060800, time_format: 29030400, ago: 'years ago', next: 'years from now', count: true},
	{time: 2903040000, time_format: 2903040000, ago: 'Last century', next: 'Next century', count: false},
	{time: 5806080000, time_format: 2903040000, ago: 'centuries ago', next: 'centuries from now', count: true}
]

function getFormatTime(time, type){
	var seconds = Math.floor((new Date().getTime() - time) / 1000);

	var text = 'Now';
	var count = false;
	var time_format = 1;

	for(var i = 0; i < timeFormats.length; i++){
		if(seconds >= timeFormats[i]['time']){
			text = timeFormats[i][type];
			count = timeFormats[i]['count'];
			time_format = timeFormats[i]['time_format'];
		}
	}

	if(count){
		return Math.floor(seconds / time_format) + ' ' + text;
	} else {
		return text;
	}
}

//CHAT
function chat_addIgnore(user, time){
	$('#chat_ignorelist .history_message').remove();

	var DIV = '<div class="chat-ignore bg-card rounded-1 flex row gap-2 items-center pr-2 pl-2" data-userid="' + user.userid + '">';
		DIV += createAvatarField(user, 'medium', '', '');

		DIV += '<div class="flex column gap-1 justify-center width-full overflow-h">';
			DIV += '<div class="font-8 ellipsis">' + user.name + '</div>';
			DIV += '<div class="font-6 ellipsis">' + time + '</div>';
		DIV += '</div>';

		DIV += '<button class="chat_send_command button button-primary shadow-2" data-command="/unignore ' + user.userid + '">Unignore</button>';
	DIV += '</div>';

	$('#chat_ignorelist').append(DIV);
}

function chat_message(message) {
	if(message.type == 'system'){
        var messageid = Math.floor(Math.random() * 100000);

		$('#chat-area').append(chatSystemMessage({
            id: messageid,
            message: message.message,
            time: getFormatTime(message.time * 1000, 'ago'),
            script: '<script>setInterval(function(){$(".chat-message[data-message=' + messageid + '] .chat-message-time").text(getFormatTime(' + message.time * 1000 + ', "ago"))}, 1000)</script>'
        }));
	} else if(message.type == 'player'){
		if(chat_ignoreList.includes(message.user.userid)) return;

	    $('#chat-area').append(chatUserMessage({
            id: message.id,
            user: message.user,
            rank: message.rank,
            message: chat_checkEmotes(chat_checkMention(message.message, message.mentions)),
            reply: message.reply ? {
                user: message.reply.user,
                message: chat_checkEmotes(chat_checkMention(message.reply.message, message.reply.mentions))
            } : null,
            time: getFormatTime(message.time * 1000, 'ago'),
            script: '<script>setInterval(function(){$(".chat-message[data-message=' + message.id + '] .chat-message-time").text(getFormatTime(' + message.time * 1000 + ', "ago"))}, 1000)</script>'
        }));
	}

	if(!chat_isPaused){
		while($('#chat-area .chat-message').length > chat_maxMessages) $('#chat-area .chat-message').first().remove();

		$('#chat-area').scrollTop(5000);

		setTimeout(function(){
			$('#chat-area').scrollTop(5000);
			$('#chat_paused').addClass('hidden');

			chat_isPaused = false;
		}, 200);
	}
}

//EMOTES
function chat_checkEmotes(message) {
	var emotes = {
		'smile': 'png', 'smiley': 'png', 'grin': 'png', 'pensive': 'png', 'weary': 'png', 'astonished': 'png', 'rolling_eyes': 'png', 'relaxed': 'png', 'wink': 'png', 'woozy_face': 'png', 'zany_face': 'png', 'hugging': 'png', 'joy': 'png', 'sob': 'png', 'grimacing': 'png', 'rofl': 'png', 'face_monocle': 'png', 'thinking': 'png', 'pleading_face': 'png', 'sleeping': 'png', 'sunglasses': 'png', 'heart_eyes': 'png', 'smiling_hearts': 'png', 'kissing_heart': 'png', 'star_struck': 'png', 'nerd': 'png', 'innocent': 'png', 'face_vomiting': 'png', 'money_mouth': 'png', 'cold_sweat': 'png', 'partying_face': 'png', 'exploding_head': 'png', 'rage': 'png', 'hot_face': 'png', 'cold_face': 'png', 'smiling_imp': 'png', 'alien': 'png', 'clown': 'png', 'scream_cat': 'png', 'smiley_cat': 'png', 'robot': 'png', 'ghost': 'png', 'skull': 'png', 'poop': 'png', 'jack_o_lantern': 'png', '100': 'png', 'bell': 'png', 'birthday': 'png', 'gift': 'png', 'first_place': 'png', 'trophy': 'png', 'tada': 'png', 'crown': 'png', 'fire': 'png', 'heart': 'png', 'broken_heart': 'png', 'wave': 'png', 'clap': 'png', 'raised_hands': 'png', 'thumbsup': 'png', 'peace': 'png', 'ok_hand': 'png', 'muscle': 'png', 'punch': 'png', 'moneybag': 'png',
		'crypepe': 'png', 'firinpepe': 'png', 'happepe': 'png', 'monkachrist': 'png', 'okpepe': 'png', 'sadpepe': 'png',
		'gaben': 'png', 'kappa': 'png', 'kappapride': 'png', 'kim': 'png', 'pogchamp': 'png', 'shaq': 'png',
		'alert': 'gif', 'awp': 'gif', 'bananadance': 'gif', 'carlton': 'gif', 'fortdance': 'gif', 'grenade': 'gif', 'lolizard': 'gif', 'partyblob': 'gif', 'saxguy': 'gif', 'squidab': 'gif', 'turtle': 'gif', 'zombie': 'gif',
		'bet': 'png', 'cant': 'png', 'cashout': 'png', 'doit': 'png', 'dont': 'png', 'feelsbad': 'png', 'feelsgood': 'png', 'gg': 'png', 'gl': 'png', 'highroller': 'png', 'joinme': 'png', 'letsgo': 'png', 'win': 'png', 'lose': 'png', 'nice': 'png', 'sniped': 'png', 'midtick': 'png', 'lowtick': 'png'
	};

	Object.keys(emotes).forEach(function(item){
        message = message.replace(new RegExp(":" + item + ":( |$)", "g"), "<img class='emojis-chat-icon' src='/img/emojis/" + item + "." + emotes[item] + "'> ");
    });

	return message;
}

//CHECK MENTIONS NAME
function chat_checkMention(message, mentions){
	mentions.forEach(function(mention){
		while(message.indexOf(mention.mention) != -1){
			if(mention.mention.replace('@', '') == USERID) {
				message = message.replace(mention.mention, '<div class="chat-mention inline-block bg-info rounded-0 pr-1 pl-1">' + mention.name + '</div>');
			} else {
				message = message.replace(mention.mention, mention.name);
			}
		}
	});

	return message;
}

//SCROLL CHAT
function chat_checkScroll(){
	var scroll_chat = $('#chat-area').scrollTop() + $('#chat-area').innerHeight();
	var scroll_first_message = $('#chat-area')[0].scrollHeight;

	if(Math.ceil(scroll_chat) >= Math.floor(scroll_first_message)) return true;
	return false;
}

//ON RESIZE CHAT
function resize_pullout(pullout, hide) {
    if(app.paths[0] == 'admin' && pullout != 'admin') return;

    if(hide) $('#page').removeClass(pullout + '-active');
    else $('#page').addClass(pullout + '-active');
}

$(document).ready(function() {
	$(window).resize(function() {
		if(isOnMobile()) $('.pullout.active').css('width', $(window).width() + 'px');
	});

    if(isOnMobile()) resize_pullout('admin', true);

    setTimeout(function(){
        $('.pullout').addClass('transition-5');
        $('.slider').addClass('transition-5');

        $('.main-panel').addClass('transition-5');
    }, 10);
});

$(document).ready(function() {
	$(document).on('input', '.betamount', function() {
		var amount = $(this).val();
		var game = $(this).attr('data-game');

		amount = getNumberFromString(amount);
		amount = getFormatAmount(amount);

		if(game == 'tower') towerGame_generateAmounts(amount);
	});

	$(document).on('click', '.betshort_action', function() {
		var $field = $(this).closest('.input_field');
		var $input = $field.find('.field_element_input');

		var game = $(this).data('game');

		var amount = $input.val();

		amount = getNumberFromString(amount);

		var bet_amount = getFormatAmount(amount);
		var action = $(this).data('action');

		if (action == 'clear') {
			bet_amount = 0;
		} else if (action == 'double') {
			bet_amount *= 2;
		} else if (action == 'half') {
			bet_amount /= 2;
		} else if (action == 'max') {
			bet_amount = BALANCES.main;
		} else {
			action = getNumberFromString(action);
			bet_amount += getFormatAmount(action);
		}

		$input.val(getFormatAmountString(bet_amount));

		if(game == 'tower') towerGame_generateAmounts(bet_amount);
		else if(game == 'dice') diceGame_assign();

		$input.trigger('input');
		changeInputFieldLabel($field);
	});

	$(document).on('click', '.changeshort_action', function() {
		var fixed = parseInt($(this).data('fixed'));

		var $input = $($(this).data('id'));
		var $field = $input.closest('.input_field');

		var value = $input.val();
		value = getNumberFromString(value);

		if(fixed) var new_value = roundedToFixed(value, 2);
		else var new_value = parseInt(value);

		var action = $(this).data('action');

		if (action == 'clear') {
			new_value = 0;
		} else {
			action = getNumberFromString(action);

			if(fixed) new_value += roundedToFixed(action, 2);
			else new_value += parseInt(action);
		}

		if(fixed) $input.val(roundedToFixed(new_value, 2).toFixed(2));
		else $input.val(Math.floor(new_value));

		$input.trigger('input');
		changeInputFieldLabel($field);
	});

	//SHOW / HIDE CHAT MESSAGE MENU
	$(document).on('click', '.chat-message-open-menu', function() {
		if($(this).closest('.chat-message').find('.chat-message-menu').hasClass('hidden')){
			$('.chat-message-menu:not(.hidden)').each(function(i, e) {
				var $MENU = $(this);

				$MENU.css('opacity', 0);

				setTimeout(function(){
					$MENU.addClass('hidden');
				}, 200);
			});

			var $MENU = $(this).closest('.chat-message').find('.chat-message-menu');

			$MENU.html('<div class="chat-message-menu-item bg-secondary flex row items-center gap-2 p-2 rounded-1">Loading...</div>');

            setTimeout(function(){
                $MENU.removeClass('hidden');

                setTimeout(function(){
                    $MENU.css('opacity', 1);
                }, 10);
            }, 10);

			var message = parseInt($(this).closest('.chat-message').attr('data-message'));

			send_request_socket({
				type: 'chat',
				command: 'commands',
				message: message
			});
		}
	});

	$(document).on('click', ':not(.chat-message-menu):not(.chat-message-menu > *)', function(e) {
		if(e.target !== this) return;

		$('.chat-message-menu:not(.hidden)').each(function(i, e) {
			var $MENU = $(this);

			$MENU.css('opacity', 0);

			setTimeout(function(){
				$MENU.addClass('hidden');
			}, 200);
		});
	});

	//SHOW / HIDE BALANCES
    $(document).on('click', '.balances', function() {
		if($('.balances .list').hasClass('hidden')){
            setTimeout(function(){
                $('.balances .list').removeClass('hidden');

                setTimeout(function(){
                    $('.balances .list').css('opacity', 1);
                }, 10);
            }, 10);
        }
	});

	$(document).on('click', ':not(.balances .list):not(.balances .list *)', function(e) {
		if(e.target !== this) return;

        if(!$('.balances .list').hasClass('hidden')){
            $('.balances .list').css('opacity', 0);

            setTimeout(function(){
                $('.balances .list').addClass('hidden');
            }, 200);
        }
	});

	//SELECT BALANCE
	$(document).on('click', '.balances .list .balance', function() {
		var balance = $(this).attr('data-type');

		profile_settingsChange('balance', balance);

		$('.balances .list').css('opacity', 0);

		setTimeout(function(){
			$('.balances .list').addClass('hidden');
		}, 200);
	});

	//SHOW / HIDE GAMES
    $(document).on('click', '.header .games', function() {
		if($('.header .games .select').hasClass('hidden')){
            setTimeout(function(){
                $('.header .games .select').removeClass('hidden');

                setTimeout(function(){
                    $('.header .games .select').css('opacity', 1);
                }, 10);
            }, 10);
        }
	});

	$(document).on('click', ':not(.header .games .select):not(.header .games .select *)', function(e) {
		if(e.target !== this) return;

        if(!$('.header .games .select').hasClass('hidden')){
            $('.header .games .select').css('opacity', 0);

            setTimeout(function(){
                $('.header .games .select').addClass('hidden');
            }, 200);
        }
	});

	//SHOW / HIDE SETTINGS
    $(document).on('click', '.header .user', function() {
		if($('.header .user .select').hasClass('hidden')){
            setTimeout(function(){
                $('.header .user .select').removeClass('hidden');

                setTimeout(function(){
                    $('.header .user .select').css('opacity', 1);
                }, 10);
            }, 10);
        }
	});

	$(document).on('click', ':not(.header .user .select):not(.header .user .select *)', function(e) {
		if(e.target !== this) return;

        if(!$('.header .user .select').hasClass('hidden')){
            $('.header .user .select').css('opacity', 0);

            setTimeout(function(){
                $('.header .user .select').addClass('hidden');
            }, 200);
        }
	});

	//SELLECT LANGUAGE
	$('#chat_channel').on('change', function() {
		send_request_socket({
			type: 'chat',
			command: 'channel',
			channel: $(this).val()
		});
	});

	//CHAT PAUSED
	$('#chat-area').bind('scroll', function() {
		if(chat_checkScroll()) {
			$('#chat_paused').addClass('hidden');

			chat_isPaused = false;
		} else {
			$('#chat_paused').removeClass('hidden');

			chat_isPaused = true;
		}
	});

	$('#chat_paused').on('click', function(){
		$('#chat_paused').addClass('hidden');

		chat_isPaused = false;

		$('#chat-area').animate({
			scrollTop: 5000
		},{
			duration: 500
		});
	});

	//SHOW / HIDE EMOGIES
	$(document).on('click', '#chat_emojis', function() {
		$('.emojis-panel').removeClass('hidden');

		setTimeout(function(){
			$('.emojis-panel').css('opacity', 1);
		}, 10);
	});

	$(document).on('click', ':not(#chat_emojis):not(#chat_emojis > *):not(.emojis-panel > *):not(.emojis-panel)', function(e) {
		if(e.target !== this) return;

		$('.emojis-panel').css('opacity', 0);

		setTimeout(function(){
			$('.emojis-panel').addClass('hidden');
		}, 200);
	});

	//WRITE EMOGIES
	$(document).on('click', '.chat-emoji', function() {
		var smile = $(this).data('emoji');

		$('#chat_message').val($('#chat_message').val() + smile + ' ');
		$('#chat_message').focus();
	});

	//WRITE COMMAND
	$(document).on('click', '.chat_write_command', function(){
		var command = $(this).data('command');

		if($('#chat_message').val().toString().trim().length > 0) $('#chat_message').val($('#chat_message').val().toString().trim() + ' ' + command).focus();
		else $('#chat_message').val(command).focus();
	});

	//SEND COMMAND
	$(document).on('click', '.chat_send_command', function(){
		var command = $(this).data('command');

		send_request_socket({
			type: 'chat',
			command: 'message',
			message: command,
			channel: profile_settingsGet('channel')
		});
	});

	//SEND COINS
	$(document).on('click', '#send_tip_player', function(){
		var amount = $('#tip_player_amount').val();
		var userid = $(this).attr('data-userid');

		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'account',
				'command': 'tip',
				'userid': userid,
				'amount': amount,
				'recaptcha': render
			});
		});
	});

	//MUTE PLAYER
	$(document).on('click', '#mute_player_set', function(){
		var reason = $('#mute_player_reason').val();
		var amount = $('#mute_player_amount').val().toString();
		var date = $('#mute_player_date').val().toString();

		var userid = $(this).attr('data-userid');

		send_request_socket({
			'type': 'account',
			'command': 'mute',
			'userid': userid,
			'time': amount + date,
			'reason': reason
		});
	});

	$(document).on('click', '#mute_player_permanently', function(){
		var reason = $('#mute_player_reason').val();

        var userid = $(this).attr('data-userid');

		send_request_socket({
			'type': 'account',
			'command': 'mute',
			'userid': userid,
			'time': 'permanent',
			'reason': reason
		});
	});

	//SUBMIT MESSAGE
	$('#chat-input-form').on('submit', function() {
		var message = $('#chat_message').val();

		if (message.toString().trim().length > 0) {
			send_request_socket({
				type: 'chat',
				command: 'message',
				message: message,
				channel: profile_settingsGet('channel'),
				reply: chat_replyMessage
			});

			$('#chat_message').val('');

			$('#chat_reply').addClass('hidden');

			chat_replyMessage = null;
		}

		return false;
	});

	//REPLY MESSAGE
	$(document).on('click', '.chat_reply_message', function(){
		var reply = JSON.parse($(this).attr('data-reply'));

		chat_replyMessage = reply.id;

		$('#chat_reply').find('.avatar').attr('src', reply.user.avatar);
		$('#chat_reply').find('.name').text(reply.user.name);

		$('#chat_reply').find('.message').html(reply.message);

		$('#chat_reply').removeClass('hidden');

		if(chat_checkScroll()) {
			$('#chat_paused').addClass('hidden');

			chat_isPaused = false;
		} else {
			$('#chat_paused').removeClass('hidden');

			chat_isPaused = true;
		}

		$('#chat_message').focus();
	});

	$(document).on('click', '#chat_reply_close', function(){
		$('#chat_reply').addClass('hidden');

		chat_replyMessage = null;
	});

	//RAIN
	$(document).on('click', '#chat_rain_join', function(){
		requestRecaptcha(function(render){
			send_request_socket({
				'type': 'rain',
				'command': 'join',
				'recaptcha': render
			});
		});
	});

	$(document).on('click', '#chat_rain_tip', function(){
		var amount = getFormatAmount($('#chat_rain_tip_amount').val());

		send_request_socket({
			'type': 'rain',
			'command': 'tip',
			'amount': amount
		});
	});
});

/* END CHAT */

/* ROULETTE */

var spinnerWidth_Roulette = 0;
var lastSpinner_Roulette = 0;
var timeSpinner_Roulette = 0;
var viewSpinner_Roulette = 0;
var beginTimeSpinner_Roulette = 0;
var movingSpinner_Roulette = false;
var durationSpinner_Roulette = 9;

var partSpinnerWidth_Roulette = 90;

function rouletteGame_finish(roll, greens) {
	sounds_play('roulette_end');

	$('#roulette_jackpot_greens .item').removeClass('active');
	for(var i = 1; i <= greens; i++) $('#roulette_jackpot_greens .item[data-green="' + i + '"]').addClass('active');

	rouletteGame_addHistory({ roll: roll.roll, colors: roll.colors });

	var cats = [
		[ 'green', 14 ],
		[ 'red', 2 ],
		[ 'black', 2 ],
		[ 'bait', 7 ]
	];

	var winbet = false;
	if(winbet) sounds_play('cashout');

	var order = [1, 14, 2, 13, 3, 12, 4, 0, 11, 5, 10, 6, 9, 7, 8];
	var index = order.indexOf(roll.roll);

	var distance = index * partSpinnerWidth_Roulette;

	var distance1 = distance + Math.floor(roll.progress * partSpinnerWidth_Roulette);
	var distance2 = distance + Math.floor(partSpinnerWidth_Roulette / 2);

	rotateSpinner_Roulette(distance1, false);

	setTimeout(function(){
		$('#roulette_spinner').addClass('transition-5');
		rotateSpinner_Roulette(distance2, false);

		setTimeout(function(){
			$('#roulette_spinner').removeClass('transition-5');

			$('#roulette_spinner .reel-item:not(:nth-child(' + (index + 1) + '))').addClass('loss');
			$('#roulette_spinner .reel-item:nth-child(' + (index + 1) + ')').addClass('won');
		}, 500);
	}, 100);

	setTimeout(function(){
		$('#roulette_spinner .reel-item').removeClass('loss').removeClass('won');
	}, 3000);

	setTimeout(function(){
		initializingSpinner_Roulette(roll);
	}, 1000);

	setTimeout(function() {
		$('.roulette-betstotal .amount').text(getFormatAmountString(0));
		$('.roulette-betstotal .count').text(0);
		$('.roulette-betslist').empty();
	}, 2000);
}

function rouletteGame_addHistory(roll) {
	$('#roulette_rolls').prepend(rouletteHistory(roll));

	while($('#roulette_rolls .item').length > 10) $('#roulette_rolls .item').last().remove();
}

function rouletteGame_addBet(bet) {
    var DIV = rouletteBet({ ...bet, ...{ amount: getFormatAmountString(bet.amount) }});

	$('#roulette_panel_' + bet.color + ' .roulette-betslist').prepend(DIV);
	$('#roulette_panel_' + bet.color + ' .roulette-betslist .roulette-betitem[data-id="' + bet.id + '"]').slideUp(0).slideDown('fast');

	try {
		tinysort('#roulette_panel_red > .roulette-betslist > .roulette-betitem', {
			data: 'amount',
			order: 'desc'
		});
	} catch (e) {}

    try {
		tinysort('#roulette_panel_green > .roulette-betslist > .roulette-betitem', {
			data: 'amount',
			order: 'desc'
		});
	} catch (e) {}

	try {
		tinysort('#roulette_panel_black > .roulette-betslist > .roulette-betitem', {
			data: 'amount',
			order: 'desc'
		});
	} catch (e) {}
}

function renderSpinner_Roulette() {
	var time = new Date().getTime() - beginTimeSpinner_Roulette;
	if (time > timeSpinner_Roulette) time = timeSpinner_Roulette;

	var deg = viewSpinner_Roulette * (Math.pow((0.99 + 0.001 * durationSpinner_Roulette), time) - 1) / Math.log((0.99 + 0.001 * durationSpinner_Roulette));

	rotateSpinner_Roulette(deg, true);

	if(time < timeSpinner_Roulette) {
		setTimeout(function(){
			renderSpinner_Roulette();
		}, 1);
	} else {
		lastSpinner_Roulette = deg;
		movingSpinner_Roulette = false;
	}
}

function rotateSpinner_Roulette(offset, truncate) {
	if(truncate) offset = -((offset - spinnerWidth_Roulette / 2) % (partSpinnerWidth_Roulette * 15)) - (partSpinnerWidth_Roulette * 15);
	else offset = -(offset - spinnerWidth_Roulette / 2) - (partSpinnerWidth_Roulette * 15);

	$('#roulette_spinner').css('transform', 'translate3d(' + offset + 'px, 0px, 0px)');
}

function initializingSpinner_Roulette(roll) {
	spinnerWidth_Roulette = $('#roulette_case').width();

	if(!movingSpinner_Roulette){
		if (roll === undefined) {
			rotateSpinner_Roulette(lastSpinner_Roulette, true);
		} else {
			var order = [1, 14, 2, 13, 3, 12, 4, 0, 11, 5, 10, 6, 9, 7, 8];
			var index = order.indexOf(roll.roll);

			var distance = index * partSpinnerWidth_Roulette;
			distance += Math.floor(partSpinnerWidth_Roulette / 2);

			lastSpinner_Roulette = distance;

			rotateSpinner_Roulette(lastSpinner_Roulette, false);
		}
	}
}

function startSpinner_Roulette(roll, greens, cooldown) {
	initializingSpinner_Roulette();

	var order = [1, 14, 2, 13, 3, 12, 4, 0, 11, 5, 10, 6, 9, 7, 8];
	var index = order.indexOf(roll.roll);

	var distance = index * partSpinnerWidth_Roulette;
	distance += (partSpinnerWidth_Roulette * 15) * 5;
	distance += Math.floor(roll.progress * partSpinnerWidth_Roulette);

	beginTimeSpinner_Roulette = new Date().getTime() - cooldown * 1000;
	viewSpinner_Roulette = 0.01 - distance * Math.log((0.99 + 0.001 * durationSpinner_Roulette));
	timeSpinner_Roulette = (Math.log(0.01) - Math.log(viewSpinner_Roulette)) / Math.log((0.99 + 0.001 * durationSpinner_Roulette));
	movingSpinner_Roulette = true;

	renderSpinner_Roulette();

	setTimeout(function() {
		rouletteGame_finish(roll, greens);
	}, timeSpinner_Roulette - cooldown * 1000);
}

function rouletteGame_timer(time, cooldown) {
	$('.roulette-bet').removeClass('disabled');

	$('#roulette_counter').animate({
		'width': '0'
	}, {
		'duration': time * 1000,
		'easing': 'linear',
		'progress': function(animation, progress, remaining) {
			var las = remaining / 1000 * 100 / cooldown;
			$('#roulette_counter').css('width', las + '%');
		}
	});
}

$(document).ready(function() {
	$(window).resize(function() {
		initializingSpinner_Roulette();
	});

	$('.roulette-bet').on('click', function() {
		$(this).addClass('disabled');

		var amount = $('#betamount_roulette').val();
		var color = $(this).data('color');

		send_request_socket({
			'type': 'roulette',
			'command': 'bet',
			'amount': amount,
			'color': color
		});
	});

    $(document).on('click', '#roulette_jackpot_history', function() {
		send_request_socket({
			'type': 'roulette',
			'command': 'jackpot_history'
		});
	});

	$(document).on('click', '.roulette-jackpot-winners', function() {
		var id = $(this).attr('data-id');

		send_request_socket({
			'type': 'roulette',
			'command': 'jackpot_winners',
			'id': id
		});
	});

	$(document).on('click', '.betshort_action[data-game="roulette"]', function() {
		sounds_play('select');
	});
});

/* END ROULETTE */

/* CRASH */

var crashGame_timeout = null;

function crashGame_resize(){
    if(crashGame_timeout) {
        clearTimeout(crashGame_timeout);

        crashGame_timeout = null;
    }

    crashGame_timeout = setTimeout(function(){
        $('#crash_canvas').addClass('hidden');

        var width = $('#crash_canvas').parent().width();
        var height = $('#crash_canvas').parent().height();

        if(width <= 0) width = 100;
        if(height <= 0) height = 100;

        canvas.width = width;
        canvas_responsive = 0;

        if(width > 750) {
            width = 750;

            canvas_responsive = 1;
        }

        canvas.height = height;

        $('#crash_canvas').removeClass('hidden');
    }, 10);
}

function crashGame_addGame(bet) {
	$('#crash_betlist .history_message').remove();

	var DIV = crashBet({ ...bet, ...{
        amount: getFormatAmountString(bet.amount),
        profit: bet.profit ? getFormatAmountString(bet.profit) : null,
    }});

	$('#crash_betlist').prepend(DIV);
	$('#crash_betlist .crash_betitem[data-id="' + bet.id + '"]').slideUp(0).slideDown('fast');
}

function crashGame_addHistory(crash){
	$('#crash_history').prepend(crashHistory({ value: crash }));

	while($('#crash_history .item').length > 20) $('#crash_history .item').last().remove();
}

function crashGame_editBet(bet){
	$('#crash_betlist .crash_betitem[data-id="' + bet.id + '"] .at').text(roundedToFixed(bet.cashout, 2).toFixed(2));
	$('#crash_betlist .crash_betitem[data-id="' + bet.id + '"] .profit').text(getFormatAmountString(bet.profit));
	$('#crash_betlist .crash_betitem[data-id="' + bet.id + '"]').removeClass('text-primary').addClass('text-success');
}

$(document).ready(function() {
	$('#crash_bet').on('click', function() {
		$(this).addClass('disabled');

		var amount = $('#betamount_crash').val();
		var auto = Math.floor($('#betauto_crash').val() * 100);

		send_request_socket({
			'type': 'crash',
			'command': 'bet',
			'amount': amount,
			'auto': auto
		});
	});

	$('#crash_cashout').on('click', function() {
		$(this).addClass('disabled');

		send_request_socket({
			'type': 'crash',
			'command': 'cashout'
		});
	});

	$(document).on('click', '.betshort_action[data-game="crash"]', function() {
		sounds_play('select');
	});

	$(document).on('click', '.changeshort_action[data-id="#betauto_crash"]', function() {
		sounds_play('select');
	});
});

/* END CRASH */

/* JACKPOT */

var spinnerWidth_Jackpot = 0;
var lastSpinner_Jackpot = 0;
var timeSpinner_Jackpot = 0;
var viewSpinner_Jackpot = 0;
var beginTimeSpinner_Jackpot = 0;
var movingSpinner_Jackpot = false;
var durationSpinner_Jackpot = 9;

var idleTimeSpinner_Jackpot = 0;
var idleSpinner_Jackpot = false;

var partSpinnerWidth_Jackpot = 80;

function jackpotGame_addBet(bet){
	$('#jackpot_betlist .history_message').remove();

	var DIV = jackpotBet({ ...bet, ...{ amount: getFormatAmountString(bet.amount) }});

	$('#jackpot_betlist').prepend(DIV);
}

function renderSpinner_Jackpot() {
	var time = new Date().getTime() - beginTimeSpinner_Jackpot;
	if (time > timeSpinner_Jackpot) time = timeSpinner_Jackpot;

	var deg = viewSpinner_Jackpot * (Math.pow((0.99 + 0.001 * durationSpinner_Jackpot), time) - 1) / Math.log((0.99 + 0.001 * durationSpinner_Jackpot));

	rotateSpinner_Jackpot(deg);

	if(time < timeSpinner_Jackpot) {
		setTimeout(function(){
			renderSpinner_Jackpot();
		}, 1);
	} else {
		lastSpinner_Jackpot = deg;
		movingSpinner_Jackpot = false;
	}
}

function rotateSpinner_Jackpot(offset) {
	offset = -(offset - spinnerWidth_Jackpot / 2);
	$('#jackpot_spinner').css('transform', 'translate3d(' + offset + 'px, 0px, 0px)');
}

function initializingSpinner_Jackpot() {
	spinnerWidth_Jackpot = $('#jackpot_case').width();

	if(!movingSpinner_Jackpot) rotateSpinner_Jackpot(lastSpinner_Jackpot);
}

function startSpinner_Jackpot(cooldown) {
	initializingSpinner_Jackpot();

	var distance = partSpinnerWidth_Jackpot * 99;
	distance += Math.floor(partSpinnerWidth_Jackpot / 2);

	beginTimeSpinner_Jackpot = new Date().getTime();
	viewSpinner_Jackpot = 0.01 - distance * Math.log((0.99 + 0.001 * durationSpinner_Jackpot));
	timeSpinner_Jackpot = (Math.log(0.01) - Math.log(viewSpinner_Jackpot)) / Math.log((0.99 + 0.001 * durationSpinner_Jackpot));
	movingSpinner_Jackpot = true;

	renderSpinner_Jackpot();
}

function idleAnimationSpinner_Jackpot(){
	idleTimeSpinner_Jackpot = new Date().getTime();

	setInterval(function(){
		if(idleSpinner_Jackpot){
			var distance = partSpinnerWidth_Jackpot * 12;
			distance += Math.floor(partSpinnerWidth_Jackpot / 2);

			distance += (0.1 * (new Date().getTime() - idleTimeSpinner_Jackpot)) % (partSpinnerWidth_Jackpot * 25);

			lastSpinner_Jackpot = distance;
			initializingSpinner_Jackpot();
		}
	}, 1);
}

function jackpotGame_addHistory(history){
    var DIV = jackpotHistory({ ...history, ...{
        amount: getFormatAmountString(history.amount),
        chance: history.chance.toFixed(2),
        bets: history.bets.map(a => ({ ...a, ...{ amount: getFormatAmountString(a.amount) } }))
    } });

	$('#jackpot_histories').prepend(DIV);

	while($('#jackpot_histories .jackpot_historyitem').length > 5) $('#jackpot_histories .jackpot_historyitem').last().remove();
}

$(document).ready(function() {
	idleAnimationSpinner_Jackpot();

	$(window).resize(function() {
		initializingSpinner_Jackpot();
	});

	$(document).on('click', '#jackpot_bet', function(){
		$(this).addClass('disabled');

		var amount = $('#betamount_jackpot').val();

		send_request_socket({
			'type': 'jackpot',
			'command': 'bet',
			'amount': amount
		});
	});

	$(document).on('click', '.betshort_action[data-game="jackpot"]', function() {
		sounds_play('select');
	});
});

/* END JACKPOT */

/* COINFLIP */

function coinflipGame_addCoinFlip(coinflip){
	var DIV = coinflipBet({
        id: coinflip.id,
        status: 0,
        players: coinflip.players,
        amount: getFormatAmountString(coinflip.amount),
        joined: coinflip.players.some(a => a.user.userid == USERID),
		creator: coinflip.players.some(a => a.user.userid == USERID && a.creator),
        data: coinflip.data
    });

	var $field = $('#coinflip_betlist .coinflip-game:not(.active)').first();
	$field.html(DIV).addClass('active');

	var last_game = $('#coinflip_betlist .coinflip-game.active').last().index() + 1;
	for(var i = 0; i < (last_game % 5 == 0 ? 1 : 0) * 5; i++) {
		$('#coinflip_betlist').append('<div class="coinflip-game bg-secondary rounded-1 b-l2"></div>');
	}
}

function coinflipGame_editCoinFlip(coinflip, status){
	var DIV = coinflipBet({
        id: coinflip.id,
        status,
        players: coinflip.players,
        amount: getFormatAmountString(coinflip.amount),
        joined: coinflip.players.some(a => a.user.userid == USERID),
		creator: coinflip.players.some(a => a.user.userid == USERID && a.creator),
        data: coinflip.data
    });

	var $field = $('#coinflip_betlist .coinflip-game .coinflip_betitem[data-id="' + coinflip.id + '"]').parent();
	$field.html(DIV)

    if(status == 4){
        setTimeout(function(){
            sounds_play('coinflip_start');
        }, 2000);
    }
}

$(document).ready(function() {
	$(document).on('click', '#coinflip_join', function() {
		$(this).addClass('disabled');

		var id = $(this).attr('data-id');

		send_request_socket({
			type: 'coinflip',
			command: 'join',
			id: id
		});
	});

	$(document).on('click', '.coinflip-select', function(){
		$('.coinflip-select').removeClass('active');
		$(this).addClass('active');

		sounds_play('select');
	});

	$('#coinflip_create').click(function() {
		$(this).addClass('disabled');

		var amount = $('#betamount_coinflip').val();
		var position = parseInt($('.coinflip-select.active').attr('data-position'));

		send_request_socket({
			type: 'coinflip',
			command: 'create',
			amount: amount,
			position: position
		});
	});

	$(document).on('click', '.betshort_action[data-game="coinflip"]', function() {
		sounds_play('select');
	});

	$(document).on('click', '.gamebots_confirm[data-game="coinflip"]', function() {
		sounds_play('play');
	});
});

/* END COINFLIP */

/* DICE */

var spinnerHeight_Dice = 0;
var lastSpinner_Dice = [ 0, 0, 0, 0 ];
var timeSpinner_Dice = [ 0, 0, 0, 0 ];
var viewSpinner_Dice = [ 0, 0, 0, 0 ];
var beginTimeSpinner_Dice = [ 0, 0, 0, 0 ];
var movingSpinner_Dice = [ false, false, false, false ];

var durationSpinner_Dice = 6;
var partSpinnerHeight_Dice = 110;

$(document).ready(function() {
	$(window).resize(function() {
		initializingSpinner_Dice();

		if(isOnMobile()) partSpinnerHeight_Dice = 80;
		else partSpinnerHeight_Dice = 110;
	});

	$('#dice_chanceslider').on('input', function(){
		diceGame_checkChanceSlider();
	});

	$('#dice_chanceinput').on('input', function(){
		diceGame_checkChanceInput();
	});

	$(document).on('click', '.dice-mode', function(){
		$('.dice-mode').removeClass('active');
		$(this).addClass('active');

		diceGame_assign();

		sounds_play('select');
	});

	$(document).on('click', '#dice_bet', function(){
		$(this).addClass('disabled');

		var amount = $('#betamount_dice').val();
		var chance = $('#dice_chanceslider').val();

		var mode = $('.dice-mode.active').attr('data-mode');

		send_request_socket({
			type: 'dice',
			command: 'bet',
			amount: amount,
			chance: chance,
			mode: mode
		});
	});

	diceGame_updateSlider();

	$(document).on('input', '.dice-slider .chance input:not(.disabled)', function() {
		diceGame_updateSlider();
	});

	$(document).on('change', '.dice-slider .chance input:not(.disabled)', function() {
		diceGame_updateSlider();
	});

	$(document).on('click', '.betshort_action[data-game="dice"]', function() {
		sounds_play('select');
	});
});

function renderSpinner_Dice(index) {
	var time = new Date().getTime() - beginTimeSpinner_Dice[index];
	if (time > timeSpinner_Dice[index]) time = timeSpinner_Dice[index];

	var deg = viewSpinner_Dice[index] * (Math.pow((0.99 + 0.001 * durationSpinner_Dice), time) - 1) / Math.log((0.99 + 0.001 * durationSpinner_Dice));

	rotateSpinner_Dice(deg, index);

	if(time < timeSpinner_Dice[index]) {
		setTimeout(function(){
			renderSpinner_Dice(index);
		}, 1);
	} else {
		lastSpinner_Dice[index] = deg;
		movingSpinner_Dice[index] = false;
	}
}

function initializingSpinner_Dice() {
	spinnerHeight_Dice = $('#dice_case').height();

	for(var i = 0; i < 4; i++){
		lastSpinner_Dice[i] = 9 * partSpinnerHeight_Dice + partSpinnerHeight_Dice / 2

		if(!movingSpinner_Dice[i]) rotateSpinner_Dice(lastSpinner_Dice[i], i);
	}
}

function rotateSpinner_Dice(offset, index) {
	offset = -((partSpinnerHeight_Dice * 10 * 5 - offset - spinnerHeight_Dice / 2) % (partSpinnerHeight_Dice * 10)) - (partSpinnerHeight_Dice * 10);

	$('#dice_spinner[data-id="' + index + '"]').css('transform', 'translate3d(0px, ' + offset + 'px, 0px)');
}

function startSpinner_Dice(roll, index) {
	initializingSpinner_Dice();

	var distance = (9 - roll) * partSpinnerHeight_Dice;
	distance += partSpinnerHeight_Dice * 10 * 5;
	distance += Math.floor(0.5 * partSpinnerHeight_Dice);

	beginTimeSpinner_Dice[index] = new Date().getTime();
	viewSpinner_Dice[index] = 0.01 - distance * Math.log((0.99 + 0.001 * durationSpinner_Dice));
	timeSpinner_Dice[index] = (Math.log(0.01) - Math.log(viewSpinner_Dice[index])) / Math.log((0.99 + 0.001 * durationSpinner_Dice));
	movingSpinner_Dice[index] = true;

	renderSpinner_Dice(index);
}

function diceGame_updateSlider(){
	var $slider = $('#dice_chanceslider');

	var min = parseInt($slider.prop('min') || 0);
	var max = parseInt($slider.prop('max') || 0);

	var percentage = (parseFloat($slider.val()) - min) / (max - min) * 100;

	$slider.css('backgroundSize', percentage + '% 100%');

	var mode = $('.dice-mode.active').attr('data-mode');

	if(mode == 'under') $slider.css('transform', 'rotateY(0deg)');
	else if(mode == 'over') $slider.css('transform', 'rotateY(180deg)');
}

function diceGame_checkChanceSlider() {
	var chance = $('#dice_chanceslider').val();
	chance = getNumberFromString(chance);
	chance = roundedToFixed(chance, 2);

	if(chance > 94) chance = 94;
	if(chance < 0.01) chance = 0.01;

	$('#dice_chanceslider').val(chance.toFixed(2));
	$('#dice_chanceinput').val(chance.toFixed(2));

	diceGame_assign();
}

function diceGame_checkChanceInput() {
	var chance = $('#dice_chanceinput').val();

	chance = getNumberFromString(chance);
	chance = roundedToFixed(chance, 2);

	if(chance > 94) chance = 94;
	if(chance < 0.01) chance = 0.01;

	$('#dice_chanceslider').val(chance.toFixed(2));
	$('#dice_chanceinput').val(chance);

	diceGame_assign();
}

function diceGame_assign() {
	var chance = $('#dice_chanceslider').val();
	chance = getNumberFromString(chance);
	chance = roundedToFixed(chance, 2);

	var multiplier = roundedToFixed(95 / chance, 2);
	$('#dice_multiplier').val(multiplier.toFixed(2));

	$('#dice_chanceslider').trigger('change');
}

function diceGame_roll(roll){
	for(let i = 0; i < 4; i++){
		setTimeout(function(){
			var number = Math.floor(Math.floor(roll * 100) / Math.pow(10, 3 - i)) % 10;

			startSpinner_Dice(number, i);

			setTimeout(function(){
				sounds_play('dice_stop');
			}, 1700);
		}, i * 200);
	}
}

/* END DICE */

/* UNBOXING */

var spinnerWidth_Unboxing = 0;
var lastSpinner_Unboxing = [];
var timeSpinner_Unboxing = [];
var viewSpinner_Unboxing = [];
var beginTimeSpinner_Unboxing = [];
var movingSpinner_Unboxing = false;
var durationSpinner_Unboxing = 8;

var partSpinnerWidth_Unboxing = 150;

$(document).ready(function() {
	$(document).on('click', '#unboxing_demo', function() {
		var id = $(this).attr('data-id');
		var amount = parseInt($('#unboxing_amount').val());

		$('#unboxing_demo').addClass('disabled');
		$('#unboxing_open').addClass('disabled');

		send_request_socket({
			'type': 'unboxing',
			'command': 'demo',
			'id': app.paths[1],
			'amount': amount
		});
	});

	$(document).on('click', '#unboxing_open', function() {
		var id = $(this).attr('data-id');
		var amount = parseInt($('#unboxing_amount').val());

		$('#unboxing_demo').addClass('disabled');
		$('#unboxing_open').addClass('disabled');

		send_request_socket({
			'type': 'unboxing',
			'command': 'open',
			'id': app.paths[1],
			'amount': amount
		});
	});

	$(document).on('change', '#unboxing_amount', function() {
		var amount = parseInt($(this).val());

		send_request_socket({
			'type': 'unboxing',
			'command': 'spinner',
			'id': app.paths[1],
			'amount': amount
		});

		sounds_play('select');
	});

	$(window).resize(function() {
		initializingSpinner_Unboxing();
	});
});

function renderSpinner_Unboxing(index) {
	var time = new Date().getTime() - beginTimeSpinner_Unboxing[index];
	if (time > timeSpinner_Unboxing[index]) time = timeSpinner_Unboxing[index];

	var deg = viewSpinner_Unboxing[index] * (Math.pow((0.99 + 0.001 * durationSpinner_Unboxing), time) - 1) / Math.log((0.99 + 0.001 * durationSpinner_Unboxing));

	rotateSpinner_Unboxing(deg, index);

	if(time < timeSpinner_Unboxing[index]) {
		setTimeout(function(){
			renderSpinner_Unboxing(index);
		}, 1);
	} else {
		lastSpinner_Unboxing[index] = deg;
		movingSpinner_Unboxing = false;
	}
}

function rotateSpinner_Unboxing(offset, index) {
	if(offset > 0) offset = -(offset - spinnerWidth_Unboxing / 2);

	$('#unboxing_case_spinner .unboxing-case[data-index="' + index + '"] .unboxing-spinner').css('transform', 'translate3d(' + offset + 'px, 0px, 0px)');
}

function initializingSpinner_Unboxing() {
	spinnerWidth_Unboxing = $('.unboxing-case').width();

	if(!movingSpinner_Unboxing) {
		for(var i = 0; i < $('#unboxing_case_spinner .unboxing-case').length; i++) rotateSpinner_Unboxing(lastSpinner_Unboxing[i], i);
	}
}

function startSpinner_Unboxing(index) {
	initializingSpinner_Unboxing();

	var distance = partSpinnerWidth_Unboxing * 99;
	distance += Math.floor(Math.random() * partSpinnerWidth_Unboxing);

	beginTimeSpinner_Unboxing[index] = new Date().getTime();
	viewSpinner_Unboxing[index] = 0.01 - distance * Math.log((0.99 + 0.001 * durationSpinner_Unboxing));
	timeSpinner_Unboxing[index] = (Math.log(0.01) - Math.log(viewSpinner_Unboxing[index])) / Math.log((0.99 + 0.001 * durationSpinner_Unboxing));
	movingSpinner_Unboxing = true;

	renderSpinner_Unboxing(index);
}

function unboxingGame_openCase(spinner){
	sounds_play('unboxing_rolling');

	$('#unboxing_case_spinner .unboxing-case .unboxing-spinner').css('transform', 'translate3d(0px, 0px, 0px)');

	$('#unboxing_case_spinner .unboxing-case .unboxing-field').empty();

	spinner.forEach(function(item, index){
		$('#unboxing_case_spinner .unboxing-case[data-index="' + index + '"] .unboxing-field').empty();

		item.forEach(function(a){
			var ITEM = '<div class="reel-item flex justify-center items-center">';
				ITEM += unboxingGame_generateItem(a);
			ITEM += '</div>';

			$('#unboxing_case_spinner .unboxing-case[data-index="' + index + '"] .unboxing-field').append(ITEM);
		});
	});

	lastSpinner_Unboxing = new Array(spinner.length).fill(0);
	timeSpinner_Unboxing = new Array(spinner.length).fill(0);
	viewSpinner_Unboxing = new Array(spinner.length).fill(0);
	beginTimeSpinner_Unboxing = new Array(spinner.length).fill(0);

	for(var i = 0; i < spinner.length; i++) startSpinner_Unboxing(i);
}

function unboxingGame_addCategory(category){
	$('#unboxing_list_categories > .history_message').remove();

	var DIV = '<div class="unboxing-category flex column gap-2 width-full" data-category="' + category.id + '">';
		DIV += '<div class="name">' + category.name + '</div>';
		DIV += '<div class="list">';
			DIV += '<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases available for unboxing</div>';
		DIV += '</div>';
	DIV += '</div>';

	$('#unboxing_list_categories').append(DIV);
}

function unboxingGame_addCase(unboxing){
	$('#unboxing_list_categories .unboxing-category[data-category="' + unboxing.category + '"] .list .history_message').remove();

	var DIV = '<a href="/unboxing/' + unboxing.id + '">';
		DIV += '<div class="case-item flex column gap-1">';
			DIV += '<div class="case-slot rounded-0">';
				DIV += '<div class="case-image-content flex items-center justify-center p-2">';
					DIV += '<img class="case-image transition-5" src="/img/cases/' + unboxing.image + '">';
				DIV += '</div>';

				DIV += '<div class="case-name-content text-left ellipsis">' + unboxing.name + '</div>';

                DIV += '<div class="case-price flex row items-center justify-center gap-1">';
                    DIV += '<div class="coin main"></div>';
                    DIV += '<span>' + getFormatAmountString(unboxing.price) + '</span>';
                DIV += '</div>';
			DIV += '</div>';
		DIV += '</div>';
	DIV += '</a>';

	$('#unboxing_list_categories .unboxing-category[data-category="' + unboxing.category + '"] .list').append(DIV);
}

function unboxingGame_showCase(items, unboxing){
	$('#unboxing_case_spinner .unboxing-case .unboxing-spinner').css('transform', 'translate3d(0px, 0px, 0px)');

	$('#unboxing_name').text(unboxing.name);
	$('#unboxing_price').text(getFormatAmountString(unboxing.price));

	$('#unboxing_list').empty();
	items.forEach(function(item){
		var ITEM = unboxingGame_generateItem(item);

		$('#unboxing_list').append(ITEM);
	});
}

function unboxingGame_showSpinner(spinner){
	$('#unboxing_case_spinner').empty();

	spinner.forEach(function(item, index){
		var DIV = '<div class="unboxing-case relative transition-5" data-index="' + index + '">';
			DIV += '<div class="unboxing-spinner group-reel flex">';
				DIV += '<div class="unboxing-field flex row">';
					item.forEach(function(a){
						DIV += '<div class="reel-item flex justify-center items-center">';
							DIV += unboxingGame_generateItem(a);
						DIV += '</div>';
					})
				DIV += '</div>';
			DIV += '</div>';

			DIV += '<div class="shadow shadow-left"></div>';
			DIV += '<div class="shadow shadow-right"></div>';

			DIV += '<div class="absolute top-0 bottom-0 left-0 right-0 flex justify-center">';
				DIV += '<div class="pointer flex items-center"></div>';
			DIV += '</div>';
		DIV += '</div>';

		$('#unboxing_case_spinner').append(DIV);
	});
}

function unboxingGame_generateItem(item){
	var name = getInfosByItemName(item.name);

	var ITEM = '<div class="listing-item flex column">';
		ITEM += '<div class="listing-slot rounded-0" style="border-bottom: solid 3px ' + item.color + ' !important;">';
			if(name.exterior != null) ITEM += '<div class="item-quality text-left">' + name.exterior + '</div>';

			ITEM += '<div class="item-chance text-right">' + roundedToFixed(item.chance, 2).toFixed(2) + '%</div>';

			ITEM += '<div class="item-image-content flex items-center justify-center p-2">';
				ITEM += '<img class="item-image transition-5" src="' + item.image + '">';
			ITEM += '</div>';

			ITEM += '<div class="item-name-content text-left">';
				if(name.brand != null) ITEM += '<div class="item-brand ellipsis">' + name.brand + '</div>';
				if(name.name != null) ITEM += '<div class="item-name ellipsis">' + name.name + '</div>';
			ITEM += '</div>';

            ITEM += '<div class="item-price flex row items-center justify-center gap-1">';
                ITEM += '<div class="coin main"></div>';
                ITEM += '<span>' + getFormatAmountString(item.price) + '</span>';
            ITEM += '</div>';

			if(item.tickets !== undefined) ITEM += '<div class="item-tickets text-right">' + item.tickets.min + ' - ' + item.tickets.max + '</div>';
		ITEM += '</div>';
	ITEM += '</div>';

	return ITEM;
}

function unboxingGame_addHistory(history){
	$('#unboxing_history .history_message').remove();

	var name = getInfosByItemName(history.winning.name);

	var DIV = '<div class="history-container medium success rounded-1 p-2 fade_center" style="border: 2px solid ' + history.winning.color + '80; background: linear-gradient(to top, ' + history.winning.color + '80 0%, var(--secondary) 100%);">';
		DIV += '<a href="/unboxing/' + history.unboxing.id + '" target="_blank">';
			DIV += '<div class="history-content unboxing flex justify-center items-center">';
				DIV += '<div class="unboxing transition-5">';
					DIV += '<img class="image" src="' + history.winning.image + '">';

					if(name.exterior != null) DIV += '<div class="exterior text-bold text-left pl-1">' + name.exterior + '</div>' ;
					DIV += '<div class="chance text-bold text-right pr-1">' + parseFloat(history.winning.chance).toFixed(2) + '%</div>' ;

					DIV += '<div class="name text-left pl-1">';
						if(name.brand != null) DIV += '<div class="text-bold">' + name.brand + '</div>';
						if(name.name != null) DIV += '<div>' + name.name + '</div>';
					DIV += '</div>';

                    DIV += '<div class="price flex row items-center justify-center gap-1">';
                        DIV += '<div class="coin main mini"></div>';
                        DIV += '<span>' + getFormatAmountString(history.winning.price) + '</span>';
                    DIV += '</div>';
				DIV += '</div>';

				DIV += '<div class="case transition-5">';
					DIV += '<img class="image" src="/img/cases/' + history.unboxing.image + '">';

					DIV += '<div class="name text-bold">' + history.unboxing.name + '</div>';

                    DIV += '<div class="price flex row items-center justify-center gap-1">';
                        DIV += '<div class="coin main"></div>';
                        DIV += '<span>' + getFormatAmountString(history.winning.price) + '</span>';
                    DIV += '</div>';

					DIV += '<div class="absolute top-0 bottom-0 left-0 right-0 p-1 flex items-center justify-center height-full gap-1">';
						DIV += createAvatarField(history.user, 'medium', '', '');
						DIV += '<div class="text-left ellipsis">' + history.user.name + '</div>';
					DIV += '</div>';
				DIV += '</div>';
			DIV += '</div>';
		DIV += '</a>';
	DIV += '</div>';

	$('#unboxing_history').prepend(DIV);

	while($('#unboxing_history .history-container').length > 20) $('#unboxing_history .history-container').last().remove();
}

/* END UNBOXING */

/* CASE BATTLE */

var spinnerHeight_CaseBattle = 0;
var lastSpinner_CaseBattle = 0;
var timeSpinner_CaseBattle = 0;
var viewSpinner_CaseBattle = 0;
var beginTimeSpinner_CaseBattle = 0;
var movingSpinner_CaseBattle = false;
var durationSpinner_CaseBattle = 8;

var partSpinnerHeight_CaseBattle = 120;

var caseBattleGame_emojiTimeouts = {};

$(document).ready(function() {
	$(document).on('click', '#casebattle_create_confirm', function() {
		var mode = parseInt($('.casebattle_set_mode.active').attr('data-mode'));
		var privacy = $('#casebattle_set_privacy').is(':checked') ? 1 : 0;
		var free = $('#casebattle_set_free').is(':checked') ? 1 : 0;
		var crazy = $('#casebattle_set_crazy').is(':checked') ? 1 : 0;

		var cases = [];

		$('#casebattle_create_list .casebattle_item').each(function(i, e) {
			for(var i = 0; i < parseInt($(this).attr('data-count')); i++) cases.push(JSON.parse($(this).attr('data-item').replace(/'/g, '"')).id);
		});

		send_request_socket({
			'type': 'casebattle',
			'command': 'create',
			'cases': cases,
			'mode': mode,
			'privacy': privacy,
			'free': free,
			'crazy': crazy
		});
	});

	$(document).on('click', '#casebattle_create_same', function() {
		var data = JSON.parse($(this).attr('data-battle'));

		var mode = parseInt(data.mode);
		var privacy = parseInt(data.privacy);
		var free = parseInt(data.free);
		var crazy = parseInt(data.crazy);

		var cases = data.cases;

		send_request_socket({
			'type': 'casebattle',
			'command': 'create',
			'cases': cases,
			'mode': mode,
			'privacy': privacy,
			'free': free,
			'crazy': crazy
		});
	});

	$(document).on('click', '.casebattle_join', function() {
		var id = $(this).attr('data-id');
		var position = parseInt($(this).attr('data-position'));

		send_request_socket({
			'type': 'casebattle',
			'command': 'join',
			'id': id,
			'position': position
		});
	});

	$(document).on('click', '.casebattle_leave', function() {
		var id = $(this).attr('data-id');
		var position = parseInt($(this).attr('data-position'));

		send_request_socket({
			'type': 'casebattle',
			'command': 'leave',
			'id': id,
			'position': position
		});
	});

	$(document).on('click', '.casebattle_set_mode', function() {
		$('.casebattle_set_mode').removeClass('active');
		$(this).addClass('active');

		caseBattleGame_updateCreate();

		sounds_play('select');
	});

	$('#casebattle_set_privacy').on('change', function() {
		sounds_play('select');
	});

	$('#casebattle_set_free').on('change', function() {
		caseBattleGame_updateCreate();

		sounds_play('select');
	});

	$('#casebattle_set_crazy').on('change', function() {
		sounds_play('select');
	});

	$(document).on('click', '.casebattle-add', function() {
		$('#casebattle_add_total').text(getFormatAmountString(0));

		send_request_socket({
			'type': 'casebattle',
			'command': 'cases'
		});

		$('#casebattle_add_list').html(createLoader());
		$('#modal_casebattle_add').modal('show');

		sounds_play('select');
	});

	$(document).on('click', '#casebattle_add_list .casebattle_add_more', function() {
		var more = parseInt($(this).attr('data-count'));
		var count = parseInt($(this).parent().parent().attr('data-count'));

		var have = 0;
		$('#casebattle_add_list .casebattle_item').each(function(i, e) {
			have += parseInt($(this).attr('data-count'));
		});

		var others = have - count;

		count += more;

		if(count < 0) count = 0;
		if(others + count > 20) count = 20 - others;

		$(this).parent().parent().attr('data-count', count);

		if(count > 0) $(this).parent().parent().addClass('active');
		else $(this).parent().parent().removeClass('active');

		$(this).parent().parent().find('.casebattle_add_count').text(count);

		caseBattleGame_updateAdd();

		sounds_play('addskin');
	});

	$(document).on('click', '#casebattle_create_list .casebattle_add_more', function() {
		var more = parseInt($(this).attr('data-count'));
		var count = parseInt($(this).parent().parent().attr('data-count'));

		var have = 0;
		$('#casebattle_create_list .casebattle_item').each(function(i, e) {
			have += parseInt($(this).attr('data-count'));
		});

		var others = have - count;

		count += more;

		if(count < 0) count = 0;
		if(others + count > 20) count = 20 - others;

		$(this).parent().parent().attr('data-count', count);

		$(this).parent().parent().find('.casebattle_add_count').text(count);
		if(count <= 0 && $(this).parent().parent().has('.no-selectable')) $(this).parent().parent().remove();

		caseBattleGame_updateCreate();

		sounds_play('addskin');
	});

	$(document).on('click', '#casebattle_add_confirm', function() {
		var list = [];

		$('#casebattle_add_list .casebattle_item').each(function(i, e) {
			if(parseInt($(this).attr('data-count')) > 0){
				list.push({
					item: JSON.parse($(this).attr('data-item').replace(/'/g, '"')),
					data: {
						count: parseInt($(this).attr('data-count'))
					}
				});
			}
		});

		$('#casebattle_create_list').empty();

		list.forEach(function(item){
			$('#casebattle_create_list').append(caseBattleGame_generateCase(item.item, item.data));
		});

		var DIV = '<div class="case-item flex column gap-1">';
			DIV += '<div class="case-slot rounded-0">';
				DIV += '<div class="flex justify-center items-center height-full width-full">';
					DIV += '<button class="button button-primary shadow-2 casebattle-add">Add Cases</button>';
				DIV += '</div>';
			DIV += '</div>';
		DIV += '</div>';

		$('#casebattle_create_list').append(DIV);

		caseBattleGame_updateCreate();

		$('#modal_casebattle_add').modal('hide');

		sounds_play('select');
	});

	$('#casebattle_order').on('change', function() {
		caseBattleGame_filterOrder();

		sounds_play('select');
	});

	$('#casebattle_players').on('change', function() {
		caseBattleGame_filterHide();
		caseBattleGame_filterOrder();

		sounds_play('select');
	});

	var timeout_casebattle = null;
	$('#casebattle_search').on('input', function() {
		if(timeout_casebattle) clearTimeout(timeout_casebattle);

		timeout_casebattle = setTimeout(function(){
			caseBattleGame_filterHide();
			caseBattleGame_filterOrder();
		}, 1000);
    });

	$('#casebattle_add_order').on('change', function() {
		var type = $(this).val();
		if (type == 0) {
			tinysort('#casebattle_add_list .casebattle_item', {
				data: 'name',
				order: 'asc'
			});
		} else if (type == 1) {
			tinysort('#casebattle_add_list .casebattle_item', {
				data: 'name',
				order: 'desc'
			});
		} else if (type == 2) {
			tinysort('#casebattle_add_list .casebattle_item', {
				data: 'price',
				order: 'asc'
			});
		} else if (type == 3) {
			tinysort('#casebattle_add_list .casebattle_item', {
				data: 'price',
				order: 'desc'
			});
		}

		sounds_play('select');
	});

	$('#casebattle_add_game').on('change', function() {
		var game = $(this).val();

        $('#casebattle_add_list .history_message').remove();

        var search = $('#casebattle_add_search').val().toString().toLowerCase();

        $('#casebattle_add_list .casebattle_item').addClass('hidden').filter(function(i, e) {
            var name = $(this).data('name');

            if (name.toLowerCase().indexOf(search) >= 0 && $(this).attr('data-game') == game) return true;
        }).removeClass('hidden');

        if($('#casebattle_add_list .casebattle_item:not(.hidden)').length <= 0) $('#casebattle_add_list').append('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases found</div></div>');

		sounds_play('select');
	});

	var timeout_casebattle_add = null;
	$('#casebattle_add_search').on('input', function() {
		var search = $(this).val().toString().toLowerCase();

		if(timeout_casebattle_add) clearTimeout(timeout_casebattle_add);

		timeout_casebattle_add = setTimeout(function(){
			$('#casebattle_add_list .history_message').remove();

            var game = $('#casebattle_add_game').val();

			$('#casebattle_add_list .casebattle_item').addClass('hidden').filter(function(i, e) {
				var name = $(this).data('name');

				if (name.toLowerCase().indexOf(search) >= 0 && $(this).attr('data-game') == game) return true;
			}).removeClass('hidden');

			if($('#casebattle_add_list .casebattle_item:not(.hidden)').length <= 0) $('#casebattle_add_list').append('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases found</div></div>');
		}, 1000);
	});

	$(document).on('mouseover', '.casebattle_rounditem.joined .casebattle-container', function() {
		var $DIV = $(this);

		$DIV.find('.casebattle-emojis').addClass('active');
		$DIV.find('.casebattle-emojis-list').addClass('active');

		setTimeout(function(){
			$DIV.find('.casebattle-emojis').css('opacity', 1);
		}, 10);
	});

	$(document).on('mouseleave', '.casebattle_rounditem.joined .casebattle-container', function() {
		var $DIV = $(this);

		if($DIV.closest('.casebattle-container').find('.casebattle-emojis-arena.active').length <= 0) {
			$DIV.find('.casebattle-emojis').css('opacity', 0);

			setTimeout(function(){
				$DIV.find('.casebattle-emojis').removeClass('active');
			}, 200);
		}

		setTimeout(function(){
			$DIV.find('.casebattle-emojis-list').removeClass('active');
		}, 200);
	});

	$(document).on('click', '.casebattle-emojis-list .casebattle-emoji', function() {
		var id = $(this).attr('data-id');
		var position = parseInt($(this).attr('data-position'));
		var emoji = parseInt($(this).attr('data-emoji'));

		send_request_socket({
			'type': 'casebattle',
			'command': 'emoji',
			'id': id,
			'position': position,
			'emoji': emoji
		});

		$(this).closest('.casebattle-emojis').find('.casebattle-emojis-arena').addClass('active');
	});

	$(document).on('click', '.gamebots_confirm[data-game="casebattle"]', function() {
		sounds_play('play');
	});
});

function renderSpinner_CaseBattle() {
	var time = new Date().getTime() - beginTimeSpinner_CaseBattle;
	if (time > timeSpinner_CaseBattle) time = timeSpinner_CaseBattle;

	var deg = viewSpinner_CaseBattle * (Math.pow((0.99 + 0.001 * durationSpinner_CaseBattle), time) - 1) / Math.log((0.99 + 0.001 * durationSpinner_CaseBattle));

	rotateSpinner_CaseBattle(deg);

	if(time < timeSpinner_CaseBattle) {
		setTimeout(function(){
			renderSpinner_CaseBattle();
		}, 1);
	} else {
		lastSpinner_CaseBattle = deg;
		movingSpinner_CaseBattle = false;
	}
}

function rotateSpinner_CaseBattle(offset) {
	if(offset > 0) offset = -(offset - (spinnerHeight_CaseBattle - partSpinnerHeight_CaseBattle) / 2);

	$('.casebattle-reel').css('transform', 'translate3d(0px, ' + offset + 'px, 0px)');
}

function initializingSpinner_CaseBattle() {
	spinnerHeight_CaseBattle = $('.casebattle-case').height();

	if(!movingSpinner_CaseBattle) rotateSpinner_CaseBattle(lastSpinner_CaseBattle);
}

function startSpinner_CaseBattle() {
	initializingSpinner_CaseBattle();

	var distance = partSpinnerHeight_CaseBattle * 99;

	beginTimeSpinner_CaseBattle = new Date().getTime();
	viewSpinner_CaseBattle = 0.01 - distance * Math.log((0.99 + 0.001 * durationSpinner_CaseBattle));
	timeSpinner_CaseBattle = (Math.log(0.01) - Math.log(viewSpinner_CaseBattle)) / Math.log((0.99 + 0.001 * durationSpinner_CaseBattle));
	movingSpinner_CaseBattle = true;

	renderSpinner_CaseBattle();
}

function caseBattleGame_filterOrder(){
	var value = $('#casebattle_order').val();

	if(value == 0) {
		tinysort('#casebattle_betlist .casebattle_betitem', {
			data: 'time',
			order: 'desc'
		});
	} else if(value == 1) {
		tinysort('#casebattle_betlist .casebattle_betitem', {
			data: 'amount',
			order: 'asc'
		});
	} else if(value == 2) {
		tinysort('#casebattle_betlist .casebattle_betitem', {
			data: 'amount',
			order: 'desc'
		});
	}
}

function caseBattleGame_filterHide(){
	$('#casebattle_betlist .history_message').remove();

	$('#casebattle_betlist > .casebattle_betitem').addClass('hidden').filter(function(i, e) {
		var data_cases = JSON.parse($(this).attr('data-cases').replace(/'/g, '"'));
		var data_players = parseInt($(this).attr('data-players'));

		var search = $('#casebattle_search').val().toLowerCase();
		var players = parseInt($('#casebattle_players').val());

		if((data_players == players || players == 0) && data_cases.filter(a => a.toLowerCase().indexOf(search) >= 0).length > 0) return true;
	}).removeClass('hidden');

	if($('#casebattle_betlist .casebattle_betitem:not(.hidden)').length <= 0) $('#casebattle_betlist').append('<div class="in-grid bg-card flex justify-center items-center font-8 p-4 history_message">No active case battles</div>');
}

function caseBattleGame_updateCreate(){
    var count = 0;
	var total = 0;

	$('#casebattle_create_list .casebattle_item').each(function(i, e) {
		count += parseInt($(this).attr('data-count'));
		total += getFormatAmount(getFormatAmount($(this).data('price')) * parseInt($(this).attr('data-count')));
    });

	var free = $('#casebattle_set_free').is(':checked') ? 1 : 0;
	var mode = parseInt($('.casebattle_set_mode.active').attr('data-mode'));

	var players = [ 2, 3, 4, 4 ][mode];

	$('#casebattle_create_total').countToFloat(free ? getFormatAmount(total * players) : total);

	var cashback = 1;

	$('#casebattle_create_cashback').countToFloat(free ? 0 : getFormatAmount(total * cashback / 100));
}

function caseBattleGame_updateAdd(){
    var count = 0;
	var total = 0;

    $('#casebattle_add_list .casebattle_item').each(function(i, e) {
		count++;
		total += getFormatAmount(getFormatAmount($(this).data('price')) * parseInt($(this).attr('data-count')));
    });

	$('#casebattle_add_total').countToFloat(total);
}

function caseBattleGame_generateCase(item, data){
	var DIV = '<div class="case-item casebattle_item flex column gap-1" data-id="' + item.id + '" data-game="' + item.game + '" data-count="' + data.count + '" data-name="' + item.name + '" data-price="' + getFormatAmountString(item.price) + '" data-item="' + JSON.stringify(item).replace(/'/g, '').replace(/"/g, '\'') + '">';
		DIV += '<div class="case-slot rounded-0">';
			DIV += '<div class="case-image-content flex items-center justify-center p-2">';
				DIV += '<img class="case-image transition-5" src="' + item.image + '">';
			DIV += '</div>';

			DIV += '<div class="case-name-content text-left ellipsis">' + item.name + '</div>';

            DIV += '<div class="case-price flex row items-center justify-center gap-1">';
                DIV += '<div class="coin main"></div>';
                DIV += '<span>' + getFormatAmountString(item.price) + '</span>';
            DIV += '</div>';
		DIV += '</div>';

		DIV += '<div class="bg-card bg-opacity-50 rounded-1 flex row justify-between items-center gap-2 p-2">';
			DIV += '<button class="button button-accent shadow-2 casebattle_add_more" data-count="-1"><i class="fa fa-minus" aria-hidden="true"></i></button>';

			DIV += '<div class="font-8 text-bold casebattle_add_count">' + data.count + '</div>';

			DIV += '<button class="button button-accent shadow-2 casebattle_add_more" data-count="1"><i class="fa fa-plus" aria-hidden="true"></i></button>';
		DIV += '</div>';
	DIV += '</div>';

	return DIV;
}

function caseBattleGame_addCaseBattle(casebattle){
	$('#casebattle_betlist .history_message').remove();

	var DIV = caseBattleGame_generateBet(casebattle, 0);

	$('#casebattle_betlist').prepend(DIV);

	$('#casebattle_betlist .casebattle_betitem[data-id="' + casebattle.id + '"]').addClass('fade_center');
}

function caseBattleGame_editCaseBattle(casebattle, status, first){
	var DIV = caseBattleGame_generateBet(casebattle, status);

	$('#casebattle_betlist .casebattle_betitem[data-id="' + casebattle.id + '"]').replaceWith(DIV);

	setTimeout(function(){
		if(status == 4) $('#casebattle_betlist .casebattle_betitem[data-id="' + casebattle.id + '"] .casebattle-roundslist').css('transform', 'translateX(-' + (casebattle.data.round * 55) + 'px)');
		else if(status == 6) $('#casebattle_betlist .casebattle_betitem[data-id="' + casebattle.id + '"] .casebattle-roundslist').css('transform', 'translateX(0px)');
	}, 200);

	if(first) $('#casebattle_betlist .casebattle_betitem[data-id="' + casebattle.id + '"]').addClass('fade_center');
}

function caseBattleGame_openCase(){
	if($('.casebattle-reel .reel').length <= 0) return;

	$('.casebattle-reel').css('transform', 'translate3d(0px, -' + (partSpinnerHeight_CaseBattle - ($('.casebattle-case').height() - partSpinnerHeight_CaseBattle) / 2) + 'px, 0px)');

	setTimeout(function(){
		sounds_play('casebattle_rolling');

		startSpinner_CaseBattle();
	}, 1000);
}

function caseBattleGame_generateBet(casebattle, status){
	var total_players = [ 2, 3, 4, 4 ][casebattle.mode];

	var DIV = '<div class="casebattle_betitem bg-card flex justify-center items-center row responsive gap-2 relative" data-id="' + casebattle.id + '" data-cases="' + JSON.stringify(casebattle.cases.map(a => a.name).filter(function(value, index, array){ return array.indexOf(value) === index })).replace(/'/g, '').replace(/"/g, '\'') + '" data-players="' + total_players + '" data-amount="' + casebattle.amount + '" data-time="' + casebattle.time + '">';
		var classes = '';
		if(status > 0) {
			var joined = casebattle.players.filter(a => a.user.userid == USERID).length > 0;

			if(status == 6 && joined){
				var player = casebattle.players.find(a => casebattle.data.winners.includes(a.position));

				if(player.user.userid == USERID) classes = 'success';
				else classes = 'danger';
			} else classes = 'active';
		}

		DIV += '<div class="casebattle-round rounded-full flex justify-center items-center text-bold ' + classes + '">' + casebattle.cases.length + '</div>';

		DIV += '<div class="width-2 responsive pr-4 pl-4">';
			DIV += '<div class="flex row gap-4 justify-center items-center">';
				DIV += '<div class="flex row gap-2">';
					var players = [];

					for(var i = 0; i < total_players; i++){
						players.push('<div class="avatar icon-small bd-1 bg-secondary rounded-full"></div>');
					}

					casebattle.players.forEach(function(item){
						var glowing = '';
						if(status == 6){
							if(casebattle.data.winners.includes(item.position)) glowing = 'glowing';
						}

						players[item.position] = createAvatarField(item.user, 'small', '', glowing);
					});

					if(casebattle.mode == 3){
						for(var i = 0; i < 2; i++){
							DIV += '<div class="flex row gap-2 p-1 b-m1 rounded-5">';
								DIV += players[i * 2];
								DIV += players[i * 2 + 1];
							DIV += '</div>';
						}
					} else DIV += players.join('');
				DIV += '</div>';

				DIV += '<div class="font-6 text-bold text-space-2"><span class="text-success">' + casebattle.players.length + '</span>/' + total_players + '</div>';
			DIV += '</div>';
		DIV += '</div>';

		DIV += '<div class="width-7 responsive bg-secondary overflow-h">';
			var translate = 0;
			if(status == 4) translate = Math.max(0, casebattle.data.round - 1) * 55;
			else if(status == 6) translate = (casebattle.cases.length - 1) * 55;

			DIV += '<div class="casebattle-roundslist flex row gap-1 rounded-0 p-1 transition-2" style="transform: translateX(-' + translate + 'px)">';
				casebattle.cases.forEach(function(item, i){
					var active = '';
					if(status == 4){
						if(i == casebattle.data.round) active = 'active';
					}

					DIV += '<div class="casebattle-icon small bg-card rounded-0 p-1 bl-1 flex justify-center items-center ' + active + '" title="' + item.name + '"><img src="/img/cases/' + item.image + '"></div>';
				});
			DIV += '</div>';
		DIV += '</div>';

		if(casebattle.free) DIV += '<div class="font-6 text-bold text-space-1 width-1 responsive flex justify-center items-center p-1 text-success">FREE</div>';
		else DIV += '<div class="font-6 text-bold text-space-1 width-1 responsive flex justify-center items-center p-1">$' + getFormatAmountString(casebattle.amount) + '</div>';

		DIV += '<div class="width-2 responsive pr-4 pl-4 pt-2 pb-2">';
			if(status == 0) DIV += '<a href="/casebattle/' + casebattle.id + '"><button class="button ' + (casebattle.crazy ? "button-pink" : "button-primary") + ' width-full height-full">Join the ' + (casebattle.crazy ? "crazy" : "classic") + ' battle</button></a>';
			else DIV += '<a href="/casebattle/' + casebattle.id + '"><button class="button button-accent shadow-2 width-full height-full">Watch the ' + (casebattle.crazy ? "crazy" : "classic") + ' battle</button></a>';
		DIV += '</div>';
	DIV += '</div>';

	return DIV;
}

function caseBattleGame_generateShow(casebattle, status, position, first){
	var joined = casebattle.players.filter(a => a.position == position && a.user.userid == USERID).length > 0 ? 'joined' : '';

	var DIV = '<div class="casebattle_rounditem ' + joined + ' flex column gap-2 width-full" data-position="' + position + '">';
		DIV += '<div class="casebattle-container relative overflow-h">';
			DIV += caseBattleGame_generateShowCase(casebattle, status, position, first);

			DIV += '<div class="casebattle-emojis transition-2 width-full">';
				var emojis = [ 'heart_eyes.png', 'innocent.png', 'rage.png', 'sob.png', 'joy.png' ];

				DIV += '<div class="casebattle-emojis-arena"></div>';

				DIV += '<div class="casebattle-emojis-list flex row">';
					emojis.forEach(function(item, i){
						DIV += '<div class="casebattle-emoji width-full height-full p-2 rounded-full" data-id="' + casebattle.id + '" data-position="' + position + '" data-emoji="' + i + '"><img class="height-full" src="/img/emojis/' + item + '"></div>';
					});
				DIV += '</div>';
			DIV += '</div>';
		DIV += '</div>'

		DIV += caseBattleGame_generateShowUser(casebattle, status, position);
	DIV += '</div>';

	return DIV;
}

function caseBattleGame_generateShowCase(casebattle, status, position, first){
	var DIV = '<div class="casebattle-case relative width-full height-full">';
		DIV += '<div class="bg-card rounded-0 relative width-full height-full overflow-h">';
			DIV += '<div class="shadow vertically shadow-top"></div>';
			DIV += '<div class="shadow vertically shadow-bottom"></div>';

			if(status == 0){
				var joined = casebattle.players.filter(a => a.user.userid == USERID).length > 0;
				var creator = casebattle.players.filter(a => a.user.userid == USERID && a.creator).length > 0;

				if(casebattle.players.filter(a => a.position == position).length > 0){
					var player = casebattle.players.find(a => a.position == position);

					if(player.user.userid == USERID) {
						DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
							DIV += '<div class="text-bold text-success text-space-1">READY TO BATTLE</div>';

							DIV += '<button class="button button-primary shadow-2 casebattle_leave" data-id="' + casebattle.id + '" data-position="' + position + '">Leave The Battle</button>';
						DIV += '</div>';
					} else {
						DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
							DIV += '<div class="text-bold text-success text-space-1">READY TO BATTLE</div>';
						DIV += '</div>';
					}
				} else if(joined) {
					if(creator){
						var data_gamebot = {
							id: casebattle.id,
							position: position
						};

						DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
							DIV += '<div class="text-bold text-space-1">WAITING FOR PLAYERS</div>';

							DIV += '<button class="button button-primary shadow-2 gamebots_confirm" data-game="casebattle" data-data="' + stringEscape(JSON.stringify(data_gamebot)) + '">Call a Bot</button>';
						DIV += '</div>';
					} else {
						DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
							DIV += '<div class="text-bold text-space-1">WAITING FOR PLAYERS</div>';
						DIV += '</div>';
					}
				} else {
					DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
						DIV += '<div class="text-bold text-space-1">ARE YOU READY TO PLAY</div>';

						DIV += '<button class="button button-primary shadow-2 casebattle_join" data-id="' + casebattle.id + '" data-position="' + position + '">Join The Battle</button>';
					DIV += '</div>';
				}
			} else if(status == 1){
				DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
					DIV += '<div class="text-bold text-success text-space-1">READY TO BATTLE</div>';
				DIV += '</div>';
			} else if(status == 2){
				DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
					DIV += '<div class="text-bold text-success text-space-1 font-10">EOS</div>';
				DIV += '</div>';
			} else if(status == 3){
				DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
					DIV += '<div class="text-bold text-success text-space-1 font-20" id="casebattle_timer_' + casebattle.id + '_' + position + '">' + casebattle.data.countdown + '</div>';

					DIV += '<script>';
						DIV += 'var casebattle_timer_' + casebattle.id + '_' + position + ' = ' + casebattle.data.countdown + ';';

						DIV += 'if(casebattle_interval_' + casebattle.id + '_' + position + ') clearInterval(casebattle_interval_' + casebattle.id + '_' + position + ');';
						DIV += 'var casebattle_interval_' + casebattle.id + '_' + position + ' = setInterval(function(){';
							DIV += 'casebattle_timer_' + casebattle.id + '_' + position + '--;';

							DIV += '$("#casebattle_timer_' + casebattle.id + '_' + position + '").text(casebattle_timer_' + casebattle.id + '_' + position + ');';

							DIV += 'if(casebattle_timer_' + casebattle.id + '_' + position + ' <= 0) clearInterval(casebattle_interval_' + casebattle.id + '_' + position + ');';
						DIV += '}, 1000);';
					DIV += '</script>';
				DIV += '</div>';
			} else if(status == 4){
				DIV += '<div class="casebattle-reel flex column height-full">';
					if(first) DIV += createLoader();
					else {
						casebattle.data.spinner.forEach(function(item, i){
							DIV += '<div class="casebattle-icon reel flex justify-center items-center pl-2 pr-2" data-id="' + i + '"><img src="' + item.image + '"></div>';
						});
					}
				DIV += '</div>';
			} else if(status == 5){
				DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
					if(casebattle.data.winners.includes(position)) DIV += '<div class="text-bold text-space-1">DRAW</div>';
					else DIV += '<div class="text-bold text-danger text-space-1">LOSER</div>';
				DIV += '</div>';
			} else if(status == 6){
				DIV += '<div class="flex column items-center justify-center gap-2 height-full">';
					if(casebattle.data.winners.includes(position)) {
						var total = casebattle.players.reduce(function(acc, val) { return acc + val.total }, 0);

						var winnings = total;
						if(casebattle.mode == 3){
							winnings = [
								getFormatAmount(total / 2),
								getFormatAmount(total - getFormatAmount(total / 2))
							][position % 2];
						}

						DIV += '<div class="flex column items-center gap-2 text-bold text-success text-space-1"><span>WINNER</span><span>TOTAL WIN $' + getFormatAmountString(winnings) + '</span></div>';
					} else DIV += '<div class="text-bold text-danger text-space-1">LOSER</div>';
				DIV += '</div>';
			}
		DIV += '</div>';
	DIV += '</div>';

	return DIV;
}

function caseBattleGame_generateShowUser(casebattle, status, position){
	var DIV = '<div class="casebattle-user flex row justify-between items-center gap-2 ' + (casebattle.mode == 3 ? "bg-card b-b2 p-2 rounded-1" : "") + '">';
		if(casebattle.players.filter(a => a.position == position).length > 0){
			var player = casebattle.players.find(a => a.position == position);

			DIV += '<div class="flex items-center gap-1">';
				DIV += createAvatarField(player.user, 'small', '', '');
				DIV += '<div class="text-left width-full ellipsis">' + player.user.name + '</div>';
			DIV += '</div>';

			var best = '';
			if(status == 6 && casebattle.data.winners !== undefined) {
				if(casebattle.data.winners.includes(position)) best = 'text-success';
			} else if(player.items.length > 0 && casebattle.data.positions !== undefined) {
				if(casebattle.data.positions.includes(position)) best = 'text-success';
			}

            DIV += '<div class="flex row items-center justify-center gap-1 ' + best + '">';
                DIV += '<div class="coin main"></div>';
                DIV += '<span class="casebattle-total">' + getFormatAmountString(player.total) + '</span>';
            DIV += '</div>';
		} else {
			DIV += '<div class="flex items-center gap-1">';
				DIV += '<div class="avatar-field rounded-full tier-steel relative">';
					DIV += '<img class="avatar icon-small rounded-full" src="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg">';
				DIV += '</div>';

				DIV += '<div class="text-left width-full ellipsis">None</div>';
			DIV += '</div>';

			DIV += '<div class="flex row items-center justify-center gap-1">';
                DIV += '<div class="coin main"></div>';
                DIV += '<span class="casebattle-total">0.00</span>';
            DIV += '</div>';
		}
	DIV += '</div>';

	return DIV;
}

function caseBattleGame_generateItems(casebattle, position){
	var DIV = '<div class="casebattle-drops" data-position="' + position + '">';
		var winnings = 0;

		if(casebattle.players.filter(a => a.position == position).length > 0){
			var player = casebattle.players.find(a => a.position == position);
			player.items.reverse();

			player.items.forEach(function(item, i){
				DIV += caseBattleGame_generateItem(item);

				winnings++;
			});
		}

		for(var i = 0; i < casebattle.cases.length - winnings; i++) DIV += '<div class="listing-item flex column"><div class="bg-card bg-opacity-50 height-full width-full rounded-0"></div></div>';
	DIV += '</div>';

	return DIV;
}

function caseBattleGame_generateItem(item){
	var name = getInfosByItemName(item.name);

	var ITEM = '<div class="listing-item flex column">';
		ITEM += '<div class="listing-slot rounded-0" style="border-bottom: solid 3px ' + item.color + ' !important;">';
			if(name.exterior != null) ITEM += '<div class="item-quality text-left">' + name.exterior + '</div>';

			ITEM += '<div class="item-image-content flex items-center justify-center p-2">';
				ITEM += '<img class="item-image transition-5" src="' + item.image + '">';
			ITEM += '</div>';

			ITEM += '<div class="item-name-content text-left">';
				if(name.brand != null) ITEM += '<div class="item-brand ellipsis">' + name.brand + '</div>';
				if(name.name != null) ITEM += '<div class="item-name ellipsis">' + name.name + '</div>';
			ITEM += '</div>';

            ITEM += '<div class="item-price flex row items-center justify-left gap-1">';
                ITEM += '<div class="coin main"></div>';
                ITEM += '<span>' + getFormatAmountString(item.price) + '</span>';
            ITEM += '</div>';
		ITEM += '</div>';
	ITEM += '</div>';

	return ITEM;
}

/* END CASE BATTLE */

/* UPGRADER */

var upgraderGame_game = 'under';
var upgraderGame_mode = 0;
var upgraderGame_interval = null;

var upgraderGame_items = [];

var timeSpinner_Upgrader = 0;
var viewSpinner_Upgrader = 0;
var beginTimeSpinner_Upgrader = 0;
var durationSpinner_Upgrader = 9;

function renderSpinner_Upgrader() {
	var time = new Date().getTime() - beginTimeSpinner_Upgrader;
	if (time > timeSpinner_Upgrader) time = timeSpinner_Upgrader;

	var deg = viewSpinner_Upgrader * (Math.pow((0.99 + 0.001 * durationSpinner_Upgrader), time) - 1) / Math.log((0.99 + 0.001 * durationSpinner_Upgrader));

	rotateSpinner_Upgrader(deg);

	if(time < timeSpinner_Upgrader) {
		setTimeout(function(){
			renderSpinner_Upgrader();
		}, 1);
	}
}

function rotateSpinner_Upgrader(offset) {
	$('#upgrader_spinner_' + (upgraderGame_mode + 1)).css('transform', 'rotateZ(' + [offset , -offset][upgraderGame_mode] + 'deg)');
}

function startSpinner_Upgrader(roll) {
	var distance = 360 * 5 + 360 * roll / 100;

	beginTimeSpinner_Upgrader = new Date().getTime();
	viewSpinner_Upgrader = 0.01 - distance * Math.log((0.99 + 0.001 * durationSpinner_Upgrader));
	timeSpinner_Upgrader = (Math.log(0.01) - Math.log(viewSpinner_Upgrader)) / Math.log((0.99 + 0.001 * durationSpinner_Upgrader));

	renderSpinner_Upgrader();

	sounds_play('upgrader_rolling');
}

function pagination_addUpgraderMyItems(list){
	$('#upgrader_myitems_list').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No items found</div></div>');

	if(list.length > 0) $('#upgrader_myitems_list .history_message').remove();

	list.forEach(function(item){
		$('#upgrader_myitems_list').append(upgraderGame_generateItem(item));

		if(upgraderGame_items.includes(item.id)) upgraderGame_selectMyItem(item);
	});

	$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
		var id = $(this).data('id');

		$('#upgrader_myitems_list .listing-item[data-id="' + id + '"]').addClass('active').find('.item-selected').removeClass('hidden');
	});

	upgraderGame_items = [];

	upgraderGame_refreshSelectedMyItems();
}

function pagination_addUpgraderSiteItems(list){
	$('#upgrader_siteitems_list').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No items found</div></div>');

	if(list.length > 0) $('#upgrader_siteitems_list .history_message').remove();

	list.forEach(function(item){
		$('#upgrader_siteitems_list').append(upgraderGame_generateItem(item));
	});

	$('#upgrader_siteitems_selected .upgrader-item').each(function(i, e) {
		var id = $(this).data('id');

		$('#upgrader_siteitems_list .listing-item[data-id="' + id + '"]').addClass('active').find('.item-selected').removeClass('hidden');
	});
}

function upgraderGame_generateItem(item){
	var ITEM = "<div class='listing-item flex column' data-id='" + item.id + "' data-item='" + JSON.stringify(item).replace(/'/g, '') + "'>";
		ITEM += '<div class="listing-slot rounded-0" style="border-bottom: solid 3px ' + item.color + ' !important;">';
			var name = getInfosByItemName(item.name);

			ITEM += '<div class="item-selected flex justify-center items-center hidden font-8"><i class="fa fa-check" aria-hidden="true"></i></div>';

			if(name.exterior != null) ITEM += '<div class="item-quality text-left">' + name.exterior + '</div>';

			ITEM += '<div class="item-image-content flex items-center justify-center p-2">';
				ITEM += '<img class="item-image transition-5" src="' + item.image + '">';
			ITEM += '</div>';

			ITEM += '<div class="item-name-content text-left">';
				if(name.brand != null) ITEM += '<div class="item-brand ellipsis">' + name.brand + '</div>';
				if(name.name != null) ITEM += '<div class="item-name ellipsis">' + name.name + '</div>';
			ITEM += '</div>';

			ITEM += '<div class="item-price flex row items-center justify-left gap-1">';
                ITEM += '<div class="coin main"></div>';
                ITEM += '<span>' + getFormatAmountString(item.price) + '</span>';
            ITEM += '</div>';
		ITEM += '</div>';
	ITEM += '</div>';

	return ITEM;
}

function upgraderGame_selectMyItem(item){
	$('#upgrader_myitems_list .listing-item[data-id="' + item.id + '"]').addClass('active').find('.item-selected').removeClass('hidden');

	var DIV = "<div class='upgrader-item flex items-center justify-center width-full relative' data-id='" + item.id + "' data-item='" + JSON.stringify(item).replace(/'/g, '') + "'>";
		DIV += '<div class="upgrader-item-remove bg-secondary bg-opacity-50 absolute width-full height-full font-10 pointer transition-5" style="opacity: 0; display: unset;">';
			DIV += '<div class="flex justify-center items-center width-full height-full"><i class="fa fa-trash" aria-hidden="true"></i></div>';
		DIV += '</div>';
		DIV += '<img class="width-full" src="' + item.image + '">';
	DIV += '</div>';

	$('#upgrader_myitems_selected').append(DIV);
}

function upgraderGame_selectSiteItem(item){
	$('#upgrader_siteitems_list .listing-item[data-id="' + item.id + '"]').addClass('active').find('.item-selected').removeClass('hidden');

	var DIV = "<div class='upgrader-item flex items-center justify-center width-full relative' data-id='" + item.id + "' data-item='" + JSON.stringify(item).replace(/'/g, '') + "'>";
		DIV += '<div class="upgrader-item-remove bg-secondary bg-opacity-50 absolute width-full height-full font-10 pointer transition-5" style="opacity: 0; display: unset;">';
			DIV += '<div class="flex justify-center items-center width-full height-full"><i class="fa fa-trash" aria-hidden="true"></i></div>';
		DIV += '</div>';
		DIV += '<img class="width-full" src="' + item.image + '">';
	DIV += '</div>';

	$('#upgrader_siteitems_selected').append(DIV);
}

var timeout_upgrader_siteitems_select = null;

function upgraderGame_refreshSelectedMyItems(){
	$('#upgrader_siteitems_list').html(createLoader());

	var myitems = [];
	$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
		var id = $(this).data('id');

		myitems.push(id);
	});

	var amount = $('#upgrader_betamount').val();
	var multiplier = parseInt($('.upgrader-multiplier.active').attr('data-multiplier'));

	var order = parseInt($('#upgrader_siteitems_order').val());
	var search = $('#upgrader_siteitems_search').val();

	if(timeout_upgrader_siteitems_select) clearTimeout(timeout_upgrader_siteitems_select);

	timeout_upgrader_siteitems_select = setTimeout(function(){
		send_request_socket({
			'type': 'pagination',
			'command': 'upgrader_siteitems',
			'page': 1,
			'order': order,
			'search': search,
			'items': myitems,
			'amount': amount,
			'multiplier': multiplier
		});
	}, 1000);

	var count = $('#upgrader_myitems_selected .upgrader-item').length;
	var cols = [ 1, 2, 3, 2, 3, 3, 4, 4, 3, 5, 6, 6, 5, 5, 5 ];

	if(count > 0) $('#upgrader_myitems_selected').css('--upgrader-cols', cols[count - 1].toString());

	if(count < 1){
		$('#upgrader_myside .upgrader-brand').text('Choose your item');
		$('#upgrader_myside .upgrader-name').text('Item, that you want to upgrade');
	} else if(count == 1){
		var item = $('#upgrader_myitems_selected .upgrader-item').data('item');
		var name = getInfosByItemName(item.name);

		$('#upgrader_myside .upgrader-brand').text(name.brand || '');
		$('#upgrader_myside .upgrader-name').text(name.name || '');
	} else if(count > 1){
		var item = $('#upgrader_myitems_selected .upgrader-item').data('item');
		var name = getInfosByItemName(item.name);

		$('#upgrader_myside .upgrader-brand').text($('#upgrader_myitems_selected .upgrader-item').length + ' items');
		$('#upgrader_myside .upgrader-name').text('that you want to upgrade');
	}

	var price = 0;
	$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
		price = getFormatAmount(price + getFormatAmount($(this).data('item').price));
	});

	$('#upgrader_myside .upgrader-price').text(getFormatAmountString(price));
}

function upgraderGame_refreshSelectedSiteItems(){
	var count = $('#upgrader_siteitems_selected .upgrader-item').length;
	var cols = [ 1, 2, 3, 2, 3, 3, 4, 4, 3, 5, 6, 6, 5, 5, 5 ];

	if(count > 0) $('#upgrader_siteitems_selected').css('--upgrader-cols', cols[count - 1].toString());

	if(count < 1){
		$('#upgrader_siteside .upgrader-brand').text('Choose item');
		$('#upgrader_siteside .upgrader-name').text('Item, that you want to receive');
	} else if(count == 1){
		var item = $('#upgrader_siteitems_selected .upgrader-item').data('item');
		var name = getInfosByItemName(item.name);

		$('#upgrader_siteside .upgrader-brand').text(name.brand || '');
		$('#upgrader_siteside .upgrader-name').text(name.name || '');
	} else if(count > 1){
		var item = $('#upgrader_siteitems_selected .upgrader-item').data('item');
		var name = getInfosByItemName(item.name);

		$('#upgrader_siteside .upgrader-brand').text($('#upgrader_siteitems_selected .upgrader-item').length + ' items');
		$('#upgrader_siteside .upgrader-name').text('that you want to receive');
	}

	var price = 0;
	$('#upgrader_siteitems_selected .upgrader-item').each(function(i, e) {
		price = getFormatAmount(price + getFormatAmount($(this).data('item').price));
	});

	$('#upgrader_siteside .upgrader-price').text(getFormatAmountString(price));
}

function upgraderGame_refreshChance(){
	var myitems = [];
	$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
		var id = $(this).data('id');

		myitems.push(id);
	});

	var siteitems = [];
	$('#upgrader_siteitems_selected .upgrader-item').each(function(i, e) {
		var id = $(this).data('id');

		siteitems.push(id);
	});

	var amount = $('#upgrader_betamount').val();

	send_request_socket({
		'type': 'upgrader',
		'command': 'chance',
		'myitems': myitems,
		'siteitems': siteitems,
		'amount': amount
	});
}

function upgraderGame_changeProgress(progress){
	var last = parseFloat($('#upgrader_progress').css('--upgrader-progress-end')) - parseFloat($('#upgrader_progress').css('--upgrader-progress-start'));

	var stage = 0;

	if(upgraderGame_interval) clearInterval(upgraderGame_interval);
	upgraderGame_interval = setInterval(function(){
		if(stage > 100) return clearInterval(upgraderGame_interval);

		var chance = last + (progress - last) * stage / 100;

		if(upgraderGame_game == 'under') {
			$('#upgrader_progress').css('--upgrader-progress-start', '0%');
			$('#upgrader_progress').css('--upgrader-progress-end', chance + '%');
		} else if(upgraderGame_game == 'over') {
			$('#upgrader_progress').css('--upgrader-progress-start', (100 - chance) + '%');
			$('#upgrader_progress').css('--upgrader-progress-end', '100%');
		}

		$('#upgrader_chance').text(roundedToFixed(chance, 2).toFixed(2));

		stage++;
	}, 1);
}

function upgraderGame_updateRoll(){
	$('#upgrader_progress').css('--upgrader-rotate', { 'under': 0, 'over': 360 }[upgraderGame_game] + 'deg');
}

$(document).ready(function() {
	$(document).on('click', '#upgrader_bet', function() {
		$(this).addClass('disabled');
		$('.upgrader-multiplier').addClass('disabled');
		$('#upgrader_mode').addClass('disabled');
		$('#upgrader_roll').addClass('disabled');
		$('#upgrader_betamount').closest('.slider_field').addClass('disabled');
		$('.upgrader-inventory').addClass('disabled');

		var myitems = [];
		$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
			var id = $(this).data('id');

			myitems.push(id);
		});

		var siteitems = [];
		$('#upgrader_siteitems_selected .upgrader-item').each(function(i, e) {
			var id = $(this).data('id');

			siteitems.push(id);
		});

		var amount = $('#upgrader_betamount').val();

		send_request_socket({
			'type': 'upgrader',
			'command': 'bet',
			'myitems': myitems,
			'siteitems': siteitems,
			'amount': amount,
			'game': upgraderGame_game
		});
	});

	$(document).on('click', '#upgrader_mode', function() {
		upgraderGame_mode = [ 1, 0 ][upgraderGame_mode];

		$('.upgrader-spinner-content').removeClass('upgrade-mode-animation-1').removeClass('upgrade-mode-animation-2').addClass('upgrade-mode-animation-' + (upgraderGame_mode + 1));

		$(this).text([ 'Triangle Mode', 'Circle Mode' ][upgraderGame_mode]);

		sounds_play('select');
	});

	$(document).on('click', '#upgrader_roll', function() {
		upgraderGame_game = { 'under': 'over', 'over': 'under' }[upgraderGame_game];

		var progress = parseFloat($('#upgrader_progress').css('--upgrader-progress-end')) - parseFloat($('#upgrader_progress').css('--upgrader-progress-start'));

		$(this).text('Roll ' + capitalizeText(upgraderGame_game));

		upgraderGame_changeProgress(progress);

		upgraderGame_updateRoll();

		sounds_play('select');
	});

	$(document).on('click', '.upgrader-multiplier', function() {
		$('.upgrader-multiplier').removeClass('active');
		$(this).addClass('active');

		$('#upgrader_siteitems_list').html(createLoader());

		var items = [];
		$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
			var id = $(this).data('id');

			items.push(id);
		});

		var amount = $('#upgrader_betamount').val();
		var multiplier = parseInt($('.upgrader-multiplier.active').attr('data-multiplier'));

		var order = parseInt($('#upgrader_siteitems_order').val());
		var search = $('#upgrader_siteitems_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'upgrader_siteitems',
			'page': 1,
			'order': order,
			'search': search,
			'items': items,
			'amount': amount,
			'multiplier': multiplier
		});

		sounds_play('select');
	});

	$(document).on('change', '#upgrader_betamount', function() {
		$('#upgrader_siteitems_list').html(createLoader());

		var myitems = [];
		$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
			var id = $(this).data('id');

			myitems.push(id);
		});

		var siteitems = [];
		$('#upgrader_siteitems_selected .upgrader-item').each(function(i, e) {
			var id = $(this).data('id');

			siteitems.push(id);
		});

		var amount = $('#upgrader_betamount').val();
		var multiplier = parseInt($('.upgrader-multiplier.active').attr('data-multiplier'));

		var order = parseInt($('#upgrader_siteitems_order').val());
		var search = $('#upgrader_siteitems_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'upgrader_siteitems',
			'page': 1,
			'order': order,
			'search': search,
			'items': myitems,
			'amount': amount,
			'multiplier': multiplier
		});

		send_request_socket({
			'type': 'upgrader',
			'command': 'chance',
			'myitems': myitems,
			'siteitems': siteitems,
			'amount': amount
		});
	});

	$(document).on('click', '#pagination_upgrader_myitems .pagination-item', function() {
		$('#upgrader_myitems_list').html(createLoader());

		var page = $(this).attr('data-page');
		var order = parseInt($('#upgrader_myitems_order').val());
		var game = $('#upgrader_myitems_game').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'upgrader_myitems',
			'page': page,
			'order': order,
			'game': game
		});
	});

	$(document).on('click', '#pagination_upgrader_siteitems .pagination-item', function() {
		$('#upgrader_siteitems_list').html(createLoader());

		var items = [];
		$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
			var id = $(this).data('id');

			items.push(id);
		});

		var amount = $('#upgrader_betamount').val();
		var multiplier = parseInt($('.upgrader-multiplier.active').attr('data-multiplier'));

		var page = $(this).attr('data-page');
		var order = parseInt($('#upgrader_siteitems_order').val());
		var search = $('#upgrader_siteitems_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'upgrader_siteitems',
			'page': page,
			'order': order,
			'search': search,
			'items': items,
			'amount': amount,
			'multiplier': multiplier
		});
	});

	$('#upgrader_myitems_order').on('change', function() {
		$('#upgrader_myitems_list').html(createLoader());

		var order = parseInt($('#upgrader_myitems_order').val());
		var game = $('#upgrader_myitems_game').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'upgrader_myitems',
			'page': 1,
			'order': order,
			'game': game
		});
	});

	$('#upgrader_myitems_game').on('change', function() {
		$('#upgrader_myitems_list').html(createLoader());

		upgraderGame_changeProgress(0);

		$('#upgrader_myitems_selected .upgrader-item').each(function(i, e){
			var id = $(this).data('id');

			$('#upgrader_myitems_list .listing-item[data-id="' + id + '"]').removeClass('active').find('.item-selected').addClass('hidden');
			$('#upgrader_myitems_selected .upgrader-item[data-id="' + id + '"]').remove();
		});

		$('#upgrader_siteitems_selected .upgrader-item').each(function(i, e){
			var id = $(this).data('id');

			$('#upgrader_siteitems_list .listing-item[data-id="' + id + '"]').removeClass('active').find('.item-selected').addClass('hidden');
			$('#upgrader_siteitems_selected .upgrader-item[data-id="' + id + '"]').remove();
		});

		upgraderGame_refreshSelectedMyItems();
		upgraderGame_refreshSelectedSiteItems();

		var order = parseInt($('#upgrader_myitems_order').val());
		var game = $('#upgrader_myitems_game').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'upgrader_myitems',
			'page': 1,
			'order': order,
			'game': game
		});
	});

	var timeout_upgrader_siteitems = null;
	$('#upgrader_siteitems_search').on('input', function() {
		if(timeout_upgrader_siteitems) clearTimeout(timeout_upgrader_siteitems);

		timeout_upgrader_siteitems = setTimeout(function(){
			$('#upgrader_siteitems_list').html(createLoader());

			var items = [];
			$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
				var id = $(this).data('id');

				items.push(id);
			});

			var amount = $('#upgrader_betamount').val();
			var multiplier = parseInt($('.upgrader-multiplier.active').attr('data-multiplier'));

			var order = parseInt($('#upgrader_siteitems_order').val());
			var search = $('#upgrader_siteitems_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'upgrader_siteitems',
				'page': 1,
				'order': order,
				'search': search,
				'items': items,
				'amount': amount,
				'multiplier': multiplier
			});
		}, 1000);
	});

	$('#upgrader_siteitems_order').on('change', function() {
		$('#upgrader_siteitems_list').html(createLoader());

		var items = [];
		$('#upgrader_myitems_selected .upgrader-item').each(function(i, e) {
			var id = $(this).data('id');

			items.push(id);
		});

		var amount = $('#upgrader_betamount').val();
		var multiplier = parseInt($('.upgrader-multiplier.active').attr('data-multiplier'));

		var order = parseInt($('#upgrader_siteitems_order').val());
		var search = $('#upgrader_siteitems_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'upgrader_siteitems',
			'page': 1,
			'order': order,
			'search': search,
			'items': items,
			'amount': amount,
			'multiplier': multiplier
		});
	});

	$(document).on('mouseover', '.upgrader-item', function() {
		var $DIV = $(this);

		$DIV.find('.upgrader-item-remove').css('opacity', 1);

		setTimeout(function(){
			$DIV.find('.upgrader-item-remove').css('display', 'unset');
		}, 10);
	});

	$(document).on('mouseleave', '.upgrader-item', function() {
		var $DIV = $(this);

		$DIV.find('.upgrader-item-remove').css('opacity', 0);

		setTimeout(function(){
			$DIV.find('.upgrader-item-remove').css('display', 'none');
		}, 500);
	});

	$(document).on('click', '#upgrader_myitems_selected .upgrader-item .upgrader-item-remove', function() {
		var id = $(this).closest('.upgrader-item').attr('data-id');

		$('#upgrader_myitems_list .listing-item[data-id="' + id + '"]').removeClass('active').find('.item-selected').addClass('hidden');

		$('#upgrader_myitems_selected .upgrader-item[data-id="' + id + '"]').remove();

		upgraderGame_refreshSelectedMyItems();

		upgraderGame_refreshChance();
	});

	$(document).on('click', '#upgrader_siteitems_selected .upgrader-item .upgrader-item-remove', function() {
		var id = $(this).closest('.upgrader-item').attr('data-id');

		$('#upgrader_siteitems_list .listing-item[data-id="' + id + '"]').removeClass('active').find('.item-selected').addClass('hidden');

		$('#upgrader_siteitems_selected .upgrader-item[data-id="' + id + '"]').remove();

		upgraderGame_refreshSelectedSiteItems();

		upgraderGame_refreshChance();
	});

	$(document).on('click', '#upgrader_myitems_list .listing-item', function() {
        var dataPos = $(this).attr('data-id');

		if ($(this).hasClass('active')) {
            $(this).removeClass('active').find('.item-selected').addClass('hidden');

			$('#upgrader_myitems_selected .upgrader-item[data-id="' + dataPos + '"]').remove();

			upgraderGame_refreshSelectedMyItems();

			upgraderGame_refreshChance();
		} else {
			if($('#upgrader_myitems_selected .upgrader-item').length >= 15) return;

			var item = $(this).data('item');

			upgraderGame_selectMyItem(item);

			upgraderGame_refreshSelectedMyItems();

			upgraderGame_refreshChance();
		}

		sounds_play('addskin');
	});

	$(document).on('click', '#upgrader_siteitems_list .listing-item', function() {
        var dataPos = $(this).attr('data-id');

		if ($(this).hasClass('active')) {
            $(this).removeClass('active').find('.item-selected').addClass('hidden');

			$('#upgrader_siteitems_selected .upgrader-item[data-id="' + dataPos + '"]').remove();

			upgraderGame_refreshSelectedSiteItems();

			upgraderGame_refreshChance();
		} else {
			if($('#upgrader_siteitems_selected .upgrader-item').length >= 15) return;

			var item = $(this).data('item');

			upgraderGame_selectSiteItem(item);

			upgraderGame_refreshSelectedSiteItems();

			upgraderGame_refreshChance();
		}

		sounds_play('addskin');
	});
});

/* END UPGRADER */

/* MINESWEEPER */

$(document).ready(function() {
	$(document).on('click', '#minesweeper_bet', function() {
		$(this).addClass('disabled');

		var amount = $('#betamount_minesweeper').val();
		var bombs = $('#bombsamount_minesweeper').val();

		send_request_socket({
			'type': 'minesweeper',
			'command': 'bet',
			'bombs': bombs,
			'amount': amount
		});
	});

	$(document).on('click', '#minesweeper_bombs .item', function() {
		var bomb = $(this).data('bomb');

		send_request_socket({
			'type': 'minesweeper',
			'command': 'bomb',
			'bomb': bomb
		});
	});

	$(document).on('click', '#minesweeper_cashout', function() {
		$(this).addClass('disabled');

		send_request_socket({
			'type': 'minesweeper',
			'command': 'cashout'
		});
	});

	$(document).on('click', '.minesweeper-bombsamount', function() {
		var amount = parseInt($(this).attr('data-amount'));

		$('.minesweeper-bombsamount').removeClass('active');
		$(this).addClass('active');

		$('#bombsamount_minesweeper').val(amount);

		sounds_play('select');
	});

	$(document).on('input', '#bombsamount_minesweeper', function() {
		var amount = parseInt($(this).val());

		$('.minesweeper-bombsamount').removeClass('active');
		$('.minesweeper-bombsamount[data-amount="' + amount + '"]').addClass('active');
	});

	$(document).on('click', '.changeshort_action[data-id="#bombsamount_minesweeper"]', function() {
		sounds_play('select');
	});

	$(document).on('click', '.betshort_action[data-game="minesweeper"]', function() {
		sounds_play('select');
	});
});

/* END MINESWEEPER */

/* TOWER */

var towerGame_multipliers = {};
var towerGame_difficulty = 'medium';

var towerGame_tiles = {
	'easy': 4,
	'medium': 3,
	'hard': 2,
	'expert': 3,
	'master': 4
};

function towerGame_generateTiles(){
	$('#tower_grid').removeClass('easy').removeClass('medium').removeClass('hard').removeClass('expert').removeClass('master')
	$('#tower_grid').addClass(towerGame_difficulty);

	var DIV = '';

	for(var i = 8; i >= 0; i--){
		for(var j = 0; j < towerGame_tiles[towerGame_difficulty]; j++){
			DIV += '<div class="item flex justify-center items-center disabled" data-stage="' + i + '" data-button="' + j + '">0.00</div>';
		}
	}

	$('#tower_grid').html(DIV);

	var amount = $('#betamount_tower').val();

	amount = getNumberFromString(amount);
	amount = getFormatAmount(amount);

	towerGame_generateAmounts(amount);
}

function towerGame_generateAmounts(amount){
	for(var i = 0; i < towerGame_multipliers[towerGame_difficulty].length; i++){
		$('#tower_grid .item[data-stage="' + i + '"]').text((amount * towerGame_multipliers[towerGame_difficulty][i]).toFixed(5));
	}
}

$(document).ready(function() {
	$(document).on('click', '#tower_bet', function(){
		$(this).addClass('disabled');

		var amount = $('#betamount_tower').val();

		send_request_socket({
			'type': 'tower',
			'command': 'bet',
			'amount': amount,
			'difficulty': towerGame_difficulty
		});
	});

	$(document).on('click', '#tower_grid .item', function(){
		var stage = $(this).data('stage');
		var button = $(this).data('button');

		send_request_socket({
			'type': 'tower',
			'command': 'stage',
			'stage': stage,
			'button': button
		});
	});

	$(document).on('click', '#tower_cashout', function(){
		$(this).addClass('disabled');

		send_request_socket({
			'type': 'tower',
			'command': 'cashout'
		});
	});

	$(document).on('change', '#tower_difficulty', function(){
		towerGame_difficulty = $(this).val();

		towerGame_generateTiles();

		sounds_play('select');
	});

	$(document).on('click', '.betshort_action[data-game="tower"]', function() {
		sounds_play('select');
	});
});

/* END TOWER */

/* PLINKO */

var plinkoGame_multipliers = {};

function plinkoGame_play(id, roll){
	var DIV = '<div class="item" data-id="' + id + '"></div>';
		DIV += '<script>';
			DIV += 'plinkoGame_roll_' + id + '([' + roll + ']);';

			DIV += 'function plinkoGame_roll_' + id + '(deep){';
				DIV += 'var deepY = 0;';
				DIV += 'var deepX = 0;';

				DIV += '$("#plinko_balls .item[data-id=' + id + ']").css("top", "-20px");';
				DIV += '$("#plinko_balls .item[data-id=' + id + ']").css("left", "0px");';

				DIV += '$("#plinko_balls .item[data-id=' + id + ']").css("opacity", "1");';

				DIV += 'var deeps = 0;';
				DIV += 'var length = 1;';

				DIV += 'var int_deep = setInterval(function(){';
					DIV += 'var copy_deeps = deeps;';
					DIV += 'var copy_length = length;';

					DIV += '$($($("#plinko_rows .line")[copy_deeps]).find(".bar")[copy_length]).addClass("hit");';

					DIV += 'setTimeout(function(){';
						DIV += '$($($("#plinko_rows .line")[copy_deeps]).find(".bar")[copy_length]).removeClass("hit");';
					DIV += '}, 500);';

					DIV += 'var rows_arena = $("#plinko_rows > .line").length;';

					DIV += 'var height_arena = $("#plinko_rows").height();';
					DIV += 'var width_arena = $("#plinko_rows").width();';

					DIV += 'var height_hole = height_arena / (rows_arena - 1);';
					DIV += 'var width_hole = width_arena / ((rows_arena + 1) * 2);';

					DIV += 'if(deeps >= rows_arena) {';
						DIV += 'clearInterval(int_deep);';

						DIV += '$("#plinko_balls .item[data-id=' + id + ']").css("top", (deepY * height_hole + (isOnMobile() ? 20 + 10 : 40 + 30)) + "px").addClass("active");';
						DIV += '$("#plinko_balls .item[data-id=' + id + ']").css("opacity", "0");';

						DIV += '$("#plinko_balls .item[data-id=' + id + ']").removeClass("bounce");';

						DIV += 'setTimeout(function(){';
							DIV += '$("#plinko_balls .item[data-id=' + id + ']").remove()';
						DIV += '}, 500);';

						DIV += 'sounds_play("plinko_win");';

						DIV += 'return;';
					DIV += '}';

					DIV += 'var route = deep[deeps];';

					DIV += 'if(deeps < rows_arena - 1) deepY++;';

					DIV += 'if(route == 1) deepX++;';
					DIV += 'else deepX--;';

					DIV += '$("#plinko_balls .item[data-id=' + id + ']").css("top", (deepY * height_hole - 20 + ((deeps == rows_arena - 1) ? (isOnMobile() ? 10 : 20) : 0)) + "px");';
					DIV += '$("#plinko_balls .item[data-id=' + id + ']").css("left", (deepX * width_hole) + "px");';

					DIV += '$("#plinko_balls .item[data-id=' + id + ']").addClass("bounce");';

					DIV += 'sounds_play("plinko_hit");';

					DIV += 'length += route;';

					DIV += 'deeps++;';
				DIV += '}, 300);';
			DIV += '}';
		DIV += '</script>';
	DIV += '</div>';

	$('#plinko_balls').append(DIV);
}

function plinkoGame_generateRows(){
	var rows = parseInt($('#plinko_rows_amount').val());

	var DIV = '';

	for(var i = 2; i < rows + 2; i++){
		DIV += '<div class="line flex row justify-center">';
		for(var j = 0; j <= i; j++){
			DIV += '<div class="bar"></div>';
		}
		DIV += '</div>';
	}

	$('#plinko_rows').html(DIV);

	$('#plinko_balls').empty();
}

function plinkoGame_generateMultipliers(){
	var difficulty = $('#plinko_difficulty').val();
	var rows = parseInt($('#plinko_rows_amount').val());

	var DIV = '';

	var j = 0;

	for(var i = Math.floor(rows / 2); i >= 1; i--){
		DIV += '<div class="item flex justify-center items-center" data-rarity="' + i + '">' + plinkoGame_multipliers[difficulty][rows][j++] + 'x</div>';
	}

	DIV += '<div class="item flex justify-center items-center" data-rarity="0">' + plinkoGame_multipliers[difficulty][rows][j++] + 'x</div>';

	if(rows % 2 != 0) DIV += '<div class="item flex justify-center items-center" data-rarity="0">' + plinkoGame_multipliers[difficulty][rows][j++] + 'x</div>';

	for(var i = 1; i <= Math.floor(rows / 2); i++){
		DIV += '<div class="item flex justify-center items-center" data-rarity="' + i + '">' + plinkoGame_multipliers[difficulty][rows][j++] + 'x</div>';
	}

	$('#plinko_multipliers').html(DIV);
}

$(document).ready(function() {
	$(document).on('click', '#plinko_bet', function() {
		$(this).addClass('disabled');

		var amount = $('#betamount_plinko').val();

		var difficulty = $('#plinko_difficulty').val();
		var rows = parseInt($('#plinko_rows_amount').val());

		send_request_socket({
			'type': 'plinko',
			'command': 'bet',
			'amount': amount,
			'difficulty': difficulty,
			'rows': rows
		});
	});

	$(document).on('change', '#plinko_difficulty', function(){
		plinkoGame_generateMultipliers();

		sounds_play('select');
	});

	$(document).on('change', '#plinko_rows_amount', function(){
		for(var i = 8; i <= 16; i++) $('#plinko_container').removeClass('rows-' + i);
		$('#plinko_container').addClass('rows-' + $(this).val());

		plinkoGame_generateRows();
		plinkoGame_generateMultipliers();

		sounds_play('select');
	});

	$(document).on('click', '.betshort_action[data-game="plinko"]', function() {
		sounds_play('select');
	});
});

/* END PLINKO */

/* CASINO */

function pagination_addCasinoSlotsGames(list){
    $('#casino_slots_games').empty();

	if(list.length <= 0) $('#casino_slots_games').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No games found</div></div>');
    else {
        list.forEach(function(item){
            $('#casino_slots_games').append(casinoGame(item));
        });
    }
}

function pagination_addCasinoLiveGames(list){
    $('#casino_live_games').empty();

	if(list.length <= 0) $('#casino_live_games').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No games found</div></div>');
    else {
        list.forEach(function(item){
            $('#casino_live_games').append(casinoGame(item));
        });
    }
}

function pagination_addCasinoFavoritesGames(list){
    $('#casino_favorites_games').empty();

	if(list.length <= 0) $('#casino_favorites_games').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No games found</div></div>');
    else {
        list.forEach(function(item){
            $('#casino_favorites_games').append(casinoGame(item));
        });
    }
}

function pagination_addCasinoAllGames(list){
    $('#casino_all_games').empty();

	if(list.length <= 0) $('#casino_all_games').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No games found</div></div>');
    else {
        list.forEach(function(item){
            $('#casino_all_games').append(casinoGame(item));
        });
    }
}

$(document).ready(function() {
    $(document).on('click', '#casino_favorite', function() {
        var id = $(this).attr('data-id');

		if($(this).hasClass('active')){
            send_request_socket({
                'type': 'casino',
                'command': 'unset_favorite',
                'id': id
            });
        } else {
            send_request_socket({
                'type': 'casino',
                'command': 'set_favorite',
                'id': id
            });
        }
	});

    $(document).on('change', '#casino_game_mode', function() {
        var real = $(this).is(':checked');

        if(real) window.location.href = '/casino/slots/' + app.paths[2];
        else window.location.href = '/casino/slots/' + app.paths[2] + '/demo';
    });

    $(document).on('click', '#casino_game_fullscreen', function() {
        var element = document.documentElement;

        if (element.requestFullscreen) {
            element.requestFullscreen();
        } else if (element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        } else if (element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
        } else if (element.msRequestFullscreen) {
            element.msRequestFullscreen();
        }
    });

    $(document).on("fullscreenchange webkitfullscreenchange mozfullscreenchange MSFullscreenChange", function () {
        if (document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement) {
           $('#page').addClass('fullscreen');
        } else {
            $('#page').removeClass('fullscreen');
        }
    });

    $(document).on('click', '#pagination_casino_slots_games .pagination-item', function() {
		$('#casino_slots_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_slots_games').append(casinoGameSkeleton());

		var page = $(this).attr('data-page');

		var order = parseInt($('#casino_slots_games_order').val());
		var provider = $('#casino_slots_games_provider').val();
		var search = $('#casino_slots_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_slots_games',
			'page': page,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

	var timeout_casino_slots_games = null;
	$('#casino_slots_games_search').on('input', function() {
		if(timeout_casino_slots_games) clearTimeout(timeout_casino_slots_games);

		timeout_casino_slots_games = setTimeout(function(){
			$('#casino_slots_games').empty();
            for(var i = 0; i < 100; i++) $('#casino_slots_games').append(casinoGameSkeleton());

            var order = parseInt($('#casino_slots_games_order').val());
		    var provider = $('#casino_slots_games_provider').val();
			var search = $('#casino_slots_games_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'casino_slots_games',
				'page': 1,
				'order': order,
				'provider': provider,
				'search': search
			});
		}, 1000);
	});

	$('#casino_slots_games_order').on('change', function() {
		$('#casino_slots_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_slots_games').append(casinoGameSkeleton());

		var order = parseInt($('#casino_slots_games_order').val());
		var provider = $('#casino_slots_games_provider').val();
		var search = $('#casino_slots_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_slots_games',
			'page': 1,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

	$('#casino_slots_games_provider').on('change', function() {
		$('#casino_slots_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_slots_games').append(casinoGameSkeleton());

		var order = parseInt($('#casino_slots_games_order').val());
		var provider = $('#casino_slots_games_provider').val();
		var search = $('#casino_slots_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_slots_games',
			'page': 1,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

    $(document).on('click', '#pagination_casino_live_games .pagination-item', function() {
		$('#casino_live_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_live_games').append(casinoGameSkeleton());

		var page = $(this).attr('data-page');

		var order = parseInt($('#casino_live_games_order').val());
		var provider = $('#casino_live_games_provider').val();
		var search = $('#casino_live_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_live_games',
			'page': page,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

	var timeout_casino_live_games = null;
	$('#casino_live_games_search').on('input', function() {
		if(timeout_casino_live_games) clearTimeout(timeout_casino_live_games);

		timeout_casino_live_games = setTimeout(function(){
			$('#casino_live_games').empty();
            for(var i = 0; i < 100; i++) $('#casino_live_games').append(casinoGameSkeleton());

            var order = parseInt($('#casino_live_games_order').val());
		    var provider = $('#casino_live_games_provider').val();
			var search = $('#casino_live_games_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'casino_live_games',
				'page': 1,
				'order': order,
				'provider': provider,
				'search': search
			});
		}, 1000);
	});

	$('#casino_live_games_order').on('change', function() {
		$('#casino_live_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_live_games').append(casinoGameSkeleton());

		var order = parseInt($('#casino_live_games_order').val());
		var provider = $('#casino_live_games_provider').val();
		var search = $('#casino_live_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_live_games',
			'page': 1,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

	$('#casino_live_games_provider').on('change', function() {
		$('#casino_live_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_live_games').append(casinoGameSkeleton());

		var order = parseInt($('#casino_live_games_order').val());
		var provider = $('#casino_live_games_provider').val();
		var search = $('#casino_live_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_live_games',
			'page': 1,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

    $(document).on('click', '#pagination_casino_favorites_games .pagination-item', function() {
		$('#casino_favorites_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_favorites_games').append(casinoGameSkeleton());

		var page = $(this).attr('data-page');

		var order = parseInt($('#casino_favorites_games_order').val());
		var provider = $('#casino_favorites_games_provider').val();
		var search = $('#casino_favorites_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_favorites_games',
			'page': page,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

	var timeout_casino_favorites_games = null;
	$('#casino_favorites_games_search').on('input', function() {
		if(timeout_casino_favorites_games) clearTimeout(timeout_casino_favorites_games);

		timeout_casino_favorites_games = setTimeout(function(){
			$('#casino_favorites_games').empty();
            for(var i = 0; i < 100; i++) $('#casino_favorites_games').append(casinoGameSkeleton());

            var order = parseInt($('#casino_favorites_games_order').val());
		    var provider = $('#casino_favorites_games_provider').val();
			var search = $('#casino_favorites_games_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'casino_favorites_games',
				'page': 1,
				'order': order,
				'provider': provider,
				'search': search
			});
		}, 1000);
	});

	$('#casino_favorites_games_order').on('change', function() {
		$('#casino_favorites_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_favorites_games').append(casinoGameSkeleton());

		var order = parseInt($('#casino_favorites_games_order').val());
		var provider = $('#casino_favorites_games_provider').val();
		var search = $('#casino_favorites_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_favorites_games',
			'page': 1,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

	$('#casino_favorites_games_provider').on('change', function() {
		$('#casino_favorites_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_favorites_games').append(casinoGameSkeleton());

		var order = parseInt($('#casino_favorites_games_order').val());
		var provider = $('#casino_favorites_games_provider').val();
		var search = $('#casino_favorites_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_favorites_games',
			'page': 1,
			'order': order,
			'provider': provider,
			'search': search
		});
	});

    $(document).on('click', '#pagination_casino_all_games .pagination-item', function() {
		$('#casino_all_games').empty();
        for(var i = 0; i < 100; i++) $('#casino_all_games').append(casinoGameSkeleton());

		var page = $(this).attr('data-page');

		var search = $('#casino_all_games_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casino_all_games',
			'page': page,
			'search': search
		});
	});

	var timeout_casino_all_games = null;
	$('#casino_all_games_search').on('input', function() {
        if(timeout_casino_all_games) clearTimeout(timeout_casino_all_games);

		var search = $('#casino_all_games_search').val().toString();

        if(search.length > 0){
            var first = $('#casino_lobby_games').hasClass('hidden');

		    if(first) {
                $('#casino_all_games').empty();
                for(var i = 0; i < 100; i++) $('#casino_all_games').append(casinoGameSkeleton());
            }

            timeout_casino_all_games = setTimeout(function(){
                if(!first) {
                    $('#casino_all_games').empty();
                    for(var i = 0; i < 100; i++) $('#casino_all_games').append(casinoGameSkeleton());
                }

                send_request_socket({
                    'type': 'pagination',
                    'command': 'casino_all_games',
                    'page': 1,
                    'search': search
                });
            }, 1000);

            $('#casino_lobby_games').removeClass('hidden');
            $('#casino_lobby_lists').addClass('hidden');
        } else {
            $('#casino_lobby_games').addClass('hidden');
            $('#casino_lobby_lists').removeClass('hidden');
        }
	});
});

/* END CASINO */

/* CASE CREATOR */

function pagination_addCaseCreatorItems(list){
	$('#casecreator_items').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No data found</div></div>');

	if(list.length > 0) $('#casecreator_items .history_message').remove();

	list.forEach(function(item){
		$('#casecreator_items').append(casecreator_generateItem(item));
	});

	$('#casecreator_case_items .table-row').each(function(i, e) {
		var id = $(this).data('id');

		$('#casecreator_items .listing-item[data-id="' + id + '"]').addClass('active').find('.item-selected').removeClass('hidden');
	});
}

function casecreator_generateItem(item){
	var ITEM = "<div class='listing-item flex column' data-id='" + item.id + "' data-item='" + JSON.stringify(item).replace(/'/g, '') + "'>";
		ITEM += '<div class="listing-slot rounded-0" style="border-bottom: solid 3px ' + item.color + ' !important;">';
			var name = getInfosByItemName(item.name);

			ITEM += '<div class="item-selected flex justify-center items-center hidden font-8"><i class="fa fa-check" aria-hidden="true"></i></div>';

			if(name.exterior != null) ITEM += '<div class="item-quality text-left">' + name.exterior + '</div>';

			ITEM += '<div class="item-image-content flex items-center justify-center p-2">';
				ITEM += '<img class="item-image transition-5" src="' + item.image + '">';
			ITEM += '</div>';

			ITEM += '<div class="item-name-content text-left">';
				if(name.brand != null) ITEM += '<div class="item-brand ellipsis">' + name.brand + '</div>';
				if(name.name != null) ITEM += '<div class="item-name ellipsis">' + name.name + '</div>';
			ITEM += '</div>';

			ITEM += '<div class="item-price flex row items-center justify-left gap-1">';
                ITEM += '<div class="coin main"></div>';
                ITEM += '<span>' + getFormatAmountString(item.price) + '</span>';
            ITEM += '</div>';
		ITEM += '</div>';
	ITEM += '</div>';

	return ITEM;
}

function casecreator_refreshSelectedItems() {
    var price = 0;
    var chance = 0;

	var allowed = true;

    $('#casecreator_case_items .table-row').each(function(i, e) {
		var item_price = getFormatAmount($(this).data('price'));
		var item_chance = roundedToFixed($(this).find('.casecreator_chance').val(), 5);

        price += item_price * item_chance / 100;
        chance = roundedToFixed(chance + item_chance, 5);

		if(item_chance == 0) allowed = false;
    });

	price = getFormatAmount(price);

	$('#casecreator_chance').text(roundedToFixed(chance, 5).toFixed(5));

	if(chance == 100 && allowed && $('#casecreator_case_items .table-row').length > 1) {
		$('#casecreator_case_create').removeClass('disabled');
		$('#casecreator_case_edit').removeClass('disabled');

		$('#casecreator_price').text(getFormatAmountString(price));
	} else {
		$('#casecreator_case_create').addClass('disabled');
		$('#casecreator_case_edit').addClass('disabled');

		$('#casecreator_price').text('N/A');
	}
}

function casecreator_selectItem(item, chance){
	$('#casecreator_case_items .history_message').remove();

	var name = getInfosByItemName(item.name);

	$('#casecreator_items .listing-item[data-id="' + item.id + '"]').addClass('active').find('.item-selected').removeClass('hidden');

	var DIV = '<div class="table-row" data-id="' + item.id + '" data-price="' + item.price + '">';
		DIV += '<div class="table-column text-left">';
			DIV += '<div class="flex items-center gap-2">';
				DIV += '<img style="width: 50px;" src="' + item.image + '">';
				DIV += '<div class="text-left width-full ellipsis">' + item.name + '</div>';
			DIV += '</div>';
		DIV += '</div>';

		DIV += '<div class="table-column text-center">';
            DIV += '<div class="flex row items-center justify-center gap-1">';
                DIV += '<div class="coin main"></div>';
                DIV += '<span class="casebattle-total">' + getFormatAmountString(item.price) + '</span>';
            DIV += '</div>';
        DIV += '</div>';

        DIV += '<div class="table-column text-center">';
			DIV += '<div class="input_field transition-5" data-border="#de4c41">';
				DIV += '<div class="field_container">';
					DIV += '<div class="field_content">';
						DIV += '<input type="text" class="field_element_input casecreator_chance" data-id="' + item.id + '" value="' + chance + '">';

						DIV += '<div class="field_label transition-5">Chance</div>';
					DIV += '</div>';

					DIV += '<div class="field_extra">';
						DIV += '<div class="flex column gap-1 rounded-0 overflow-h">';
							DIV += '<div class="button-count changeshort_action" data-id=".casecreator_chance[data-id=\'' + item.id + '\']" data-fixed="0" data-action="+1">˄</div>';
							DIV += '<div class="button-count changeshort_action" data-id=".casecreator_chance[data-id=\'' + item.id + '\']" data-fixed="0" data-action="-1">˅</div>';
						DIV += '</div>';
					DIV += '</div>';
				DIV += '</div>';

				DIV += '<div class="field_bottom"></div>';
			DIV += '</div>';
		DIV += '</div>';
		DIV += '<div class="table-column text-right text-danger font-10">';
			DIV += '<button class="button button-primary shadow-2 casecreator_item_remove" data-id="' + item.id + '">Remove</button>';
		DIV += '</div>';
	DIV += '</div>';

	$('#casecreator_case_items').prepend(DIV);

	changeInputFieldLabel($('#casecreator_case_items .table-row[data-id="' + item.id + '"] .input_field'));

	casecreator_refreshSelectedItems();
}

function casecreator_addCase(casecreator, creator){
	$('#casecreator_cases .history_message').remove();

	var DIV = '<div class="case-item flex column gap-1" data-id="' + casecreator.id + '">';
		DIV += '<div class="case-slot rounded-0">';
			DIV += '<div class="case-image-content flex items-center justify-center p-2">';
				DIV += '<img class="case-image transition-5" src="/img/' + creator + '/' + casecreator.image + '">';
			DIV += '</div>';

			DIV += '<div class="case-name-content text-center ellipsis">' + casecreator.name + '</div>';

			DIV += '<div class="case-action flex row gap-1">';
				DIV += '<a href="/admin/casecreator/edit/' + creator + '/' + casecreator.id + '" target="_blank"><button type="button" class="button button-primary shadow-2" >EDIT</button></a>';
				DIV += '<button type="button" class="casecreator-remove button button-danger shadow-2" data-id="' + casecreator.id + '">REMOVE</button>';
			DIV += '</div>';
		DIV += '</div>';
	DIV += '</div>';

	$('#casecreator_cases').append(DIV);
}

function casecreator_addCategory(category){
	$('#casecreator_categories_list .history_message').remove();

	var DIV = '<div class="casecreator-categories-item ' + (category.visible ? 'active' : '') + ' bg-card rounded-1 b-l2 pl-4 pr-4" data-id="' + category.id + '">';
		DIV += '<div class="flex row items-center justify-between gap-2 height-full">';
			DIV += '<div class="flex column justify-center gap-1 items-start">';
				DIV += '<div class="flex column items-start">';
					DIV += '<div class="name">' + category.name + '</div>';

					var status = [ 'Hidden', 'Visible' ][category.visible];

					DIV += '<div class="status">Status: <span class="visible">' + status + '</span></div>';
				DIV += '</div>';

				DIV += '<div class="rate">Contain ' + category.cases + ' cases</div>';
			DIV += '</div>';

			DIV += '<div class="flex row items-center gap-1">';
				DIV += '<div class="switch_field responsive transition-5 width-full">';
					DIV += '<div class="field_container">';
						DIV += '<div class="field_content">';
							DIV += '<input type="checkbox" class="casecreator-categories-visible field_element_input" data-id="' + category.id + '" ' + (category.visible ? 'checked="checked"' : '') + '>';

							DIV += '<div class="field_switch">';
								DIV += '<div class="field_switch_bar"></div>';
							DIV += '</div>';

							DIV += '<div class="field_label active transition-5 hidden"></div>';
						DIV += '</div>';

						DIV += '<div class="field_extra"></div>';
					DIV += '</div>';

					DIV += '<div class="field_bottom"></div>';
				DIV += '</div>';

				DIV += '<button type="button" class="casecreator-categories-remove button button-danger shadow-2" data-id="' + category.id + '"><i class="fa fa-trash" aria-hidden="true"></i></button>';
			DIV += '</div>';
		DIV += '</div>';
	DIV += '</div>';

	$('#casecreator_categories_list').append(DIV);
}

$(document).ready(function() {
	$(document).on('click', '#pagination_casecreator_items .pagination-item', function() {
		$('#casecreator_items').html(createLoader());

		var page = $(this).attr('data-page');
		var order = parseInt($('#casecreator_items_order').val());
		var game = $('#casecreator_items_game').val();
		var search = $('#casecreator_items_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casecreator_items',
			'page': page,
			'order': order,
			'game': game,
			'search': search
		});
	});

	var timeout_casecreator_items = null;
	$('#casecreator_items_search').on('input', function() {
		if(timeout_casecreator_items) clearTimeout(timeout_casecreator_items);

		timeout_casecreator_items = setTimeout(function(){
			$('#casecreator_items').html(createLoader());

			var order = parseInt($('#casecreator_items_order').val());
			var game = $('#casecreator_items_game').val();
			var search = $('#casecreator_items_search').val();

			send_request_socket({
				'type': 'pagination',
				'command': 'casecreator_items',
				'page': 1,
				'order': order,
				'game': game,
				'search': search
			});
		}, 1000);
	});

	$('#casecreator_items_order').on('change', function() {
		$('#casecreator_items').html(createLoader());

		var order = parseInt($('#casecreator_items_order').val());
		var game = $('#casecreator_items_game').val();
		var search = $('#casecreator_items_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casecreator_items',
			'page': 1,
			'order': order,
			'game': game,
			'search': search
		});
	});

	$('#casecreator_items_game').on('change', function() {
		$('#casecreator_items').html(createLoader());

		var order = parseInt($('#casecreator_items_order').val());
		var game = $('#casecreator_items_game').val();
		var search = $('#casecreator_items_search').val();

		send_request_socket({
			'type': 'pagination',
			'command': 'casecreator_items',
			'page': 1,
			'order': order,
			'game': game,
			'search': search
		});
	});

	$(document).on('input', '.casecreator_chance', function() {
		casecreator_refreshSelectedItems();
	});

	$(document).on('click', '#casecreator_case_create', function() {
		var name = $('#casecreator_case_name').val();
		var image = document.querySelector('#casecreator_case_image').files[0];
		var items = [];

		$('#casecreator_case_items .table-row').each(function(i, e) {
			var id = $(this).data('id');
			var chance = roundedToFixed($(this).find('.casecreator_chance').val(), 5);

			items.push({ id, chance });
		});

		var data = {};

		if(app.paths[3] == 'cases'){
			var battle = $('#casecreator_case_battle').is(':checked') ? 1 : 0;
			var category = $('#casecreator_case_category').val();

			data = { battle, category };
		} else if(app.paths[3] == 'dailycases'){
			var level = parseInt($('#casecreator_case_level').val());

			data = { level };
		}

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'casecreator_create',
				'creator': app.paths[3],
				'name': name,
				'image': image,
				'items': items,
				'data': data,
				'secret': secret
			});
		});
	});

	$(document).on('click', '#casecreator_case_edit', function() {
		var name = $('#casecreator_case_name').val();
		var image = document.querySelector('#casecreator_case_image').files[0];
		var items = [];

		$('#casecreator_case_items .table-row').each(function(i, e) {
			var id = $(this).data('id');
			var chance = roundedToFixed($(this).find('.casecreator_chance').val(), 5);

			items.push({ id, chance });
		});

		var data = {};

		if(app.paths[3] == 'cases'){
			var battle = $('#casecreator_case_battle').is(':checked') ? 1 : 0;
			var category = $('#casecreator_case_category').val();

			data = { battle, category };
		} else if(app.paths[3] == 'dailycases'){
			var level = parseInt($('#casecreator_case_level').val());

			data = { level };
		}

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'casecreator_edit',
				'creator': app.paths[3],
				'id': app.paths[4],
				'name': name,
				'image': image,
				'items': items,
				'data': data,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.casecreator-remove', function() {
		var id = $(this).attr('data-id');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'casecreator_remove',
				'creator': app.paths[3],
				'id': id,
				'secret': secret
			});
		});
	});

	$(document).on('click', '.casecreator_item_remove', function() {
		var id = $(this).attr('data-id');

		$('#casecreator_items .listing-item[data-id="' + id + '"]').removeClass('active').find('.item-selected').addClass('hidden');

		$('#casecreator_case_items .table-row[data-id="' + id + '"]').remove();

		if($('#casecreator_case_items .table-row').length <= 0) $('#casecreator_case_items').html('<div class="in-grid bg-card flex justify-center items-center font-8 p-4 history_message">No items selected</div>');

		casecreator_refreshSelectedItems();
	});

	$(document).on('click', '#casecreator_items .listing-item', function() {
        var dataPos = $(this).attr('data-id');

		if ($(this).hasClass('active')) {
            $(this).removeClass('active').find('.item-selected').addClass('hidden');

			$('#casecreator_case_items .table-row[data-id="' + dataPos + '"]').remove();

			if($('#casecreator_case_items .table-row').length <= 0) $('#casecreator_case_items').html('<div class="in-grid bg-card flex justify-center items-center font-8 p-4 history_message">No items selected</div>');

			casecreator_refreshSelectedItems();
		} else {
			var item = $(this).data('item');

			casecreator_selectItem(item, 0);
		}
	});

	//CATEGORIES
	$('#modal_casecreator_categories').on('show', function() {
		$('#casecreator_categories_list').html(createLoader());

		send_request_socket({
			'type': 'admin',
			'command': 'casecreator_categories_list'
		});
	});

	$(document).on('click', '#casecreator_category_create', function() {
		var name = $('#casecreator_category_name').val();

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'casecreator_categories_create',
				'name': name,
				'secret': secret
			});
		});
	});

	$(document).on('change', '.casecreator-categories-visible', function() {
		var id = $(this).attr('data-id');
		var visible = $(this).is(':checked') ? 1 : 0;

		send_request_socket({
			'type': 'admin',
			'command': 'casecreator_categories_edit',
			'id': id,
			'visible': visible
		});
	});

	$(document).on('click', '.casecreator-categories-remove', function() {
		var id = $(this).attr('data-id');

		confirm_identity(function(confirmed, secret){
			if(!confirmed) return;

			send_request_socket({
				'type': 'admin',
				'command': 'casecreator_categories_remove',
				'id': id,
				'secret': secret
			});
		});
	});
});

/* END CASE CREATOR */

/* GAME BOTS */

$(document).ready(function() {
	$(document).on('click', '.gamebots_confirm', function() {
		var game = $(this).attr('data-game');
		var data = JSON.parse(stringUnescape($(this).attr('data-data')));

		send_request_socket({
			'type': 'gamebots',
			'command': 'confirm',
			'game': game,
			'data': data
		});
	});
});

/* END GAME BOTS */

/* INVENTORY */

function pagination_addInventoryItems(list){
	$('#inventory_list').html('<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No data found</div></div>');

	if(list.length > 0) $('#inventory_list .history_message').remove();

	list.forEach(function(item){
		$('#inventory_list').append(inventory_generateItem(item));
	});
}

function inventory_generateItem(item){
	var classes = '';

	var ITEM = '<div class="listing-item inventory-item flex column ' + classes + '" data-id="' + item.id + '">';
		ITEM += '<div class="listing-slot rounded-0" style="border-bottom: solid 3px ' + item.color + ' !important;">';
			var name = getInfosByItemName(item.name);

			ITEM += '<div class="item-inventory-settings transition-5" style="opacity: 0; display: unset;">';
				ITEM += '<div class="flex column gap-2 items-center justify-center height-full width-full">';
					ITEM += '<button class="button button-primary shadow-2 inventory_sell_item" data-id="' + item.id + '">SELL ITEM</button>';
					ITEM += '<a href="/upgrader/' + item.id + '"><button class="button button-danger shadow-2">TO UPGRADER</button></a>';
				ITEM += '</div>';
			ITEM += '</div>';

			if(name.exterior != null) ITEM += '<div class="item-quality text-left">' + name.exterior + '</div>';

			ITEM += '<div class="item-image-content flex items-center justify-center p-2">';
				ITEM += '<img class="item-image transition-5" src="' + item.image + '">';
			ITEM += '</div>';

			ITEM += '<div class="item-name-content text-left">';
				if(name.brand != null) ITEM += '<div class="item-brand ellipsis">' + name.brand + '</div>';
				if(name.name != null) ITEM += '<div class="item-name ellipsis">' + name.name + '</div>';
			ITEM += '</div>';

			ITEM += '<div class="item-price flex row items-center justify-left gap-1">';
                ITEM += '<div class="coin main"></div>';
                ITEM += '<span>' + getFormatAmountString(item.price) + '</span>';
            ITEM += '</div>';
		ITEM += '</div>';
	ITEM += '</div>';

	return ITEM;
}

$(document).ready(function() {
	$(document).on('mouseover', '.inventory-item:not(.notaccepted)', function() {
		var $DIV = $(this);

		$DIV.find('.item-inventory-settings').css('display', 'unset');

		setTimeout(function(){
			$DIV.find('.item-inventory-settings').css('opacity', 1);
		}, 10);
	});

	$(document).on('mouseleave', '.inventory-item:not(.notaccepted)', function() {
		var $DIV = $(this);

		$DIV.find('.item-inventory-settings').css('opacity', 0);

		setTimeout(function(){
			$DIV.find('.item-inventory-settings').css('display', 'none');
		}, 500);
	});

	$(document).on('click', '.inventory_sell_item', function(){
		var id = $(this).attr('data-id');

		send_request_socket({
			'type': 'inventory',
			'command': 'sell_item',
			'id': id
		});
	});

	$(document).on('click', '#inventory_sell_all', function(){
		send_request_socket({
			'type': 'inventory',
			'command': 'sell_all'
		});
	});

	$(document).on('show', '#modal_user_inventory', function(){
		$('#inventory_list').html(createLoader());

		send_request_socket({
			'type': 'pagination',
			'command': 'inventory_items',
			'page': 1
		});
	});

	$(document).on('click', '#pagination_inventory_items .pagination-item', function() {
		$('#inventory_list').html(createLoader());

		var page = $(this).attr('data-page');

		send_request_socket({
			'type': 'pagination',
			'command': 'inventory_items',
			'page': page
		});
	});
});

/* END INVENTORY */

/* DAILY CASES */

var spinnerWidth_Daily = 0;
var lastSpinner_Daily = 0;
var timeSpinner_Daily = 0;
var viewSpinner_Daily = 0;
var beginTimeSpinner_Daily = 0;
var movingSpinner_Daily = false;
var durationSpinner_Daily = 8;

var partSpinnerWidth_Daily = 150;

function renderSpinner_Daily() {
	var time = new Date().getTime() - beginTimeSpinner_Daily;
	if (time > timeSpinner_Daily) time = timeSpinner_Daily;

	var deg = viewSpinner_Daily * (Math.pow((0.99 + 0.001 * durationSpinner_Daily), time) - 1) / Math.log((0.99 + 0.001 * durationSpinner_Daily));

	rotateSpinner_Daily(deg);

	if (time < timeSpinner_Daily) {
		setTimeout(function () {
			renderSpinner_Daily();
		}, 1);
	} else {
		lastSpinner_Daily = deg;
		movingSpinner_Daily = false;
	}
}

function rotateSpinner_Daily(offset) {
	if (offset > 0) offset = -(offset - spinnerWidth_Daily / 2);

	$('#dailycases_spinner').css('transform', 'translate3d(' + offset + 'px, 0px, 0px)');
}

function initializingSpinner_Daily() {
	spinnerWidth_Daily = $('#dailycases_case').width();

	if (!movingSpinner_Daily) rotateSpinner_Daily(lastSpinner_Daily);
}

function startSpinner_Daily() {
	initializingSpinner_Daily();

	var distance = partSpinnerWidth_Daily * 99;
	distance += Math.floor(Math.random() * partSpinnerWidth_Daily);

	beginTimeSpinner_Daily = new Date().getTime();
	viewSpinner_Daily = 0.01 - distance * Math.log((0.99 + 0.001 * durationSpinner_Daily));
	timeSpinner_Daily = (Math.log(0.01) - Math.log(viewSpinner_Daily)) / Math.log((0.99 + 0.001 * durationSpinner_Daily));
	movingSpinner_Daily = true;

	renderSpinner_Daily();
}

function dailycases_addCase(dailycase, level) {
	$('#dailycases_cases .history_message').remove();

	var DIV = '<div class="case-item flex column gap-1" data-id="' + dailycase.id + '">';
		DIV += '<div class="case-slot rounded-0">';
			DIV += '<div class="case-image-content flex items-center justify-center p-2">';
				DIV += '<img class="case-image transition-5" src="/img/dailycases/' + dailycase.image + '">';
			DIV += '</div>';

			DIV += '<div class="case-name-content text-center ellipsis">' + dailycase.name + '</div>';

			DIV += '<div class="case-action-content">';
				if(dailycase.time > 0){
					var dailycase_time = getFormatSeconds(dailycase.time);

					DIV += '<button type="button" class="case-action dailycases-open button button-primary shadow-2 disabled" data-id="' + dailycase.id + '">' + dailycase_time.hours + ':' + dailycase_time.minutes + ':' + dailycase_time.seconds + '</button>';

					DIV += '<script>';
						DIV += 'var dailycases_timer_' + dailycase.id + ' = ' + dailycase.time + ';';

						DIV += 'if(dailycases_interval_' + dailycase.id + ') clearInterval(dailycases_interval_' + dailycase.id + ');';
						DIV += 'var dailycases_interval_' + dailycase.id + ' = setInterval(function(){';
							DIV += 'dailycases_timer_' + dailycase.id + '--;';

							DIV += 'var dailycase_time = getFormatSeconds(dailycases_timer_' + dailycase.id + ');';

							DIV += '$(".dailycases-open[data-id=\'' + dailycase.id + '\']").text(dailycase_time.hours + ":" + dailycase_time.minutes + ":" + dailycase_time.seconds);';

							DIV += 'if(dailycases_timer_' + dailycase.id + ' <= 0) {';
								DIV += 'clearInterval(dailycases_interval_' + dailycase.id + ');';

								DIV += '$(".dailycases-open[data-id=\'' + dailycase.id + '\']").removeClass("disabled").text("OPEN CASE (LVL. ' + dailycase.level + ')")';
							DIV += '}';
						DIV += '}, 1000);';
					DIV += '</script>';
				} else DIV += '<button type="button" class="case-action dailycases-open button button-primary shadow-2" data-id="' + dailycase.id + '">OPEN CASE (LVL. ' + dailycase.level + ')</button>';
			DIV += '</div>';
		DIV += '</div>';
	DIV += '</div>';

	$('#dailycases_cases').append(DIV);
}

function dailycases_countdownCase(dailycase){
	if(dailycase.time > 0){
		var dailycase_time = getFormatSeconds(dailycase.time);

		var DIV = '<button type="button" class="case-action dailycases-open button button-primary shadow-2 disabled" data-id="' + dailycase.id + '">' + dailycase_time.hours + ':' + dailycase_time.minutes + ':' + dailycase_time.seconds + '</button>';

		DIV += '<script>';
			DIV += 'var dailycases_timer_' + dailycase.id + ' = ' + dailycase.time + ';';

			DIV += 'if(dailycases_interval_' + dailycase.id + ') clearInterval(dailycases_interval_' + dailycase.id + ');';
			DIV += 'var dailycases_interval_' + dailycase.id + ' = setInterval(function(){';
				DIV += 'dailycases_timer_' + dailycase.id + '--;';

				DIV += 'var dailycase_time = getFormatSeconds(dailycases_timer_' + dailycase.id + ');';

				DIV += '$(".dailycases-open[data-id=\'' + dailycase.id + '\']").text(dailycase_time.hours + ":" + dailycase_time.minutes + ":" + dailycase_time.seconds);';

				DIV += 'if(dailycases_timer_' + dailycase.id + ' <= 0) {';
					DIV += 'clearInterval(dailycases_interval_' + dailycase.id + ');';

					DIV += '$(".dailycases-open[data-id=\'' + dailycase.id + '\']").removeClass("disabled").text("OPEN CASE (LVL. ' + dailycase.level + ')")';
				DIV += '}';
			DIV += '}, 1000);';
		DIV += '</script>';
	} else {
		var DIV = '<button type="button" class="case-action dailycases-open button button-primary shadow-2" data-id="' + dailycase.id + '">OPEN CASE (LVL. ' + dailycase.level + ')</button>';
	}

	$('#dailycases_cases .case-item[data-id="' + dailycase.id + '"] .case-action-content').html(DIV);
}

function dailycases_showCase(items, dailycase, level, spinner) {
	$('#dailycases_spinner').css('transform', 'translate3d(0px, 0px, 0px)');

	$('#dailycases_case_name').text(dailycase.name);
	$('#dailycases_case_level').text(dailycase.level);

	$('#dailycases_open').removeClass('disabled');
	if(level < dailycase.level) $('#dailycases_open').addClass('disabled');

	$('#dailycases_open').attr('data-id', dailycase.id)

	$('#dailycases_list').empty();
	items.forEach(function (item) {
		var ITEM = dailycases_generateItem(item);

		$('#dailycases_list').append(ITEM);
	});

	$('#dailycases_field').empty();
	spinner.forEach(function (item) {
		var ITEM = '<div class="reel-item flex justify-center items-center">';
			ITEM += dailycases_generateItem(item);
		ITEM += '</div>';

		$('#dailycases_field').append(ITEM);
	});

	$('#modal_dailycases_case').modal('show');
}

function dailycases_generateItem(item) {
	var name = getInfosByItemName(item.name);

	var ITEM = '<div class="listing-item flex column">';
		ITEM += '<div class="listing-slot rounded-0" style="border-bottom: solid 3px ' + item.color + ' !important;">';
			if(name.exterior != null) ITEM += '<div class="item-quality text-left">' + name.exterior + '</div>';

			ITEM += '<div class="item-chance text-right">' + roundedToFixed(item.chance, 2).toFixed(2) + '%</div>';

			ITEM += '<div class="item-image-content flex items-center justify-center p-2">';
				ITEM += '<img class="item-image transition-5" src="' + item.image + '">';
			ITEM += '</div>';

			ITEM += '<div class="item-name-content text-left">';
				if(name.brand != null) ITEM += '<div class="item-brand ellipsis">' + name.brand + '</div>';
				if(name.name != null) ITEM += '<div class="item-name ellipsis">' + name.name + '</div>';
			ITEM += '</div>';

			ITEM += '<div class="item-price flex row items-center justify-left gap-1">';
                ITEM += '<div class="coin main"></div>';
                ITEM += '<span>' + getFormatAmountString(item.price) + '</span>';
            ITEM += '</div>';

			if (item.tickets !== undefined) ITEM += '<div class="item-tickets text-right">' + item.tickets.min + ' - ' + item.tickets.max + '</div>';
		ITEM += '</div>';
	ITEM += '</div>';

	return ITEM;
}

function dailycases_openCase(items) {
	sounds_play('dailycase_rolling');

	$('#dailycases_spinner').css('transform', 'translate3d(0px, 0px, 0px)');

	$('#dailycases_field').empty();

	items.forEach(function (item) {
		var ITEM = '<div class="reel-item flex justify-center items-center">';
			ITEM += dailycases_generateItem(item);
		ITEM += '</div>';

		$('#dailycases_field').append(ITEM);
	});

	startSpinner_Daily();
}

$(document).ready(function () {
	$('#modal_dailycases_cases').on('show', function() {
		$('#dailycases_cases').html(createLoader());

		send_request_socket({
			'type': 'dailycases',
			'command': 'cases'
		});
	});

	$(document).on('click', '.dailycases-open', function () {
		var id = $(this).attr('data-id');

		send_request_socket({
			'type': 'dailycases',
			'command': 'get',
			'id': id,
		});
	});

	$(document).on('click', '#dailycases_open', function () {
		var id = $(this).attr('data-id');

		send_request_socket({
			'type': 'dailycases',
			'command': 'open',
			'id': id,
		});

		$('#dailycases_open').addClass('disabled');
	});

	$(window).resize(function () {
		initializingSpinner_Daily();
	});
});

/* END DAILY CASES */

/* CRYPTO TRADES */

$(document).ready(function() {
	$(document).on('click', '#deposit_bonuses_apply', function() {
		var code = $('#deposit_bonuses_code').val();

		requestRecaptcha(function(render){
			send_request_socket({
				type: 'account',
				command: 'deposit_bonus',
				code: code,
				recaptcha: render
			});
		});
	});

	$(document).on('input', '.crypto-panel [data-conversion="from"]', function() {
		var currency = $(this).attr('data-currency');

		var value = $('.crypto-panel [data-conversion="from"]').val();
		var amount = getNumberFromString(value);

		$('.crypto-panel [data-conversion="from"]').val(value);

		if(offers_currencyAmounts[currency] === undefined) $('.crypto-panel [data-conversion="to"]').val('0.00000000');
        else $('.crypto-panel [data-conversion="to"]').val((getFormatAmount(amount) / offers_currencyAmounts[currency]).toFixed(8));

        changeInputFieldLabel($('.crypto-panel [data-conversion="to"]').closest('.input_field'));

        if(app.page == 'withdraw'){
            if(offers_currencyFees[currency] === undefined) $('.crypto-panel [data-conversion="estimated"]').val('0.00000000');
            else $('.crypto-panel [data-conversion="estimated"]').val((getFormatAmount(amount) / offers_currencyAmounts[currency] - offers_currencyFees[currency]).toFixed(8));

            changeInputFieldLabel($('.crypto-panel [data-conversion="estimated"]').closest('.input_field'));
        }
	});

	$(document).on('input', '.crypto-panel [data-conversion="to"]', function() {
		var currency = $(this).attr('data-currency');

		var value = $('.crypto-panel [data-conversion="to"]').val();
		var amount = getNumberFromString(value);

		if(offers_currencyAmounts[currency] === undefined) $('.crypto-panel [data-conversion="from"]').val('0.00');
		else $('.crypto-panel [data-conversion="from"]').val(getFormatAmountString(offers_currencyAmounts[currency] * amount));

		$('.crypto-panel [data-conversion="to"]').val(value);
		if(app.page == 'withdraw') $('.crypto-panel [data-conversion="estimated"]').val(amount - offers_currencyFees[currency]);

		var $input_check = $('.crypto-panel [data-conversion="from"]');
		changeInputFieldLabel($input_check.closest('.input_field'));
	});

	$(document).on('input', '.crypto-panel [data-conversion="estimated"]', function() {
		var currency = $(this).attr('data-currency');

		var value = $('.crypto-panel [data-conversion="estimated"]').val();
		var amount = getNumberFromString(value);

		if(offers_currencyAmounts[currency] === undefined || offers_currencyFees[currency] === undefined) $('.crypto-panel [data-conversion="from"]').val('0.00');
		else $('.crypto-panel [data-conversion="from"]').val(getFormatAmountString(offers_currencyAmounts[currency] * (amount + offers_currencyFees[currency])));

		$('.crypto-panel [data-conversion="estimated"]').val(value);
		$('.crypto-panel [data-conversion="to"]').val(amount + offers_currencyFees[currency]);

		var $input_check = $('.crypto-panel [data-conversion="from"]');
		changeInputFieldLabel($input_check.closest('.input_field'));
	});

	$(document).on('click', '#crypto_deposit', function() {
		var currency = $(this).attr('data-currency');
        var value = $('#crypto_deposit_value').val();

		send_request_socket({
            type: 'crypto',
            command: 'deposit',
            currency: currency,
            value: value
        });
	});

	$(document).on('click', '#crypto_deposit_back', function() {
		$('#crypto_deposit_panel').removeClass('active');
	});

	$(document).on('click', '#crypto_withdraw', function() {
		var currency = $(this).attr('data-currency');
		var address = $('#currency_withdraw_address').val();
		var amount = $('#currency_withdraw_amount').val();

		requestRecaptcha(function(render){
			send_request_socket({
				type: 'crypto',
				command: 'withdraw',
				currency: currency,
				amount: amount,
				address: address,
				recaptcha: render
			});
		});
	});
});

/* END CRYPTO TRADES */

/* STEAM & P2P TRADES */

var offers_inventoryIsLoading = false;

var offers_maxSelectItems = 20;
var offers_selectedItems = 0;

var offers_nameGames = {
	'cs2': 'CS2',
	'dota2': 'DOTA 2',
	'h1z1': 'H1Z1',
	'rust': 'RUST',
	'tf2': 'TEAM FORTRESS 2',
}

function offers_addItemInventory(item){
    if(app.paths[0] == 'deposit'){
        $('#list_items').append(paymentSkinDeposit({
            ...item,
            ...{
                price: getFormatAmountString(item.price),
                offset: item.offset.toFixed(2),
                wear: item.wear ? item.wear.toString().slice(0, 6) : null
            }
        }));
    } else if(app.paths[0] == 'withdraw'){
        $('#list_items').append(paymentSkinWithdraw({
            ...item,
            ...{
                price: getFormatAmountString(item.price),
                offset: item.offset.toFixed(2),
                wear: item.wear ? item.wear.toString().slice(0, 6) : null
            }
        }));
    }
}

function offers_addBundleInventory(listing){
	if($('#list_items .listing-item').length <= 0) $('#list_items').empty();

	$('#list_items').append(paymentSkinP2P({ ...listing.items[0], ...{
        id: listing.id,
        price: getFormatAmountString(listing.items[0].price),
        offset: listing.items[0].offset.toFixed(2),
        wear: listing.items[0].wear ? listing.items[0].wear.toString().slice(0, 6) : null,
        time: listing.time
    } }));
}

function offers_editPending(offer){
	if($('#pending-offers .bundle_offer[data-id="' + offer.id + '"][data-method="' + offer.method + '"]').length <= 0) return;

	$('#pending-offers .bundle_offer[data-id="' + offer.id + '"][data-method="' + offer.method + '"]').replaceWith(paymentSkinPending({
        ...offer,
        ...{
            price: getFormatAmountString(offer.items.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0)),
            offset: roundedToFixed(offer.items.reduce((acc, cur) => acc + cur.offset, 0) / offer.items.length, 2).toFixed(2),
            items: offer.items.map(a => ({
                ...a,
                ...{
                    price: getFormatAmountString(a.price),
                    offset: a.offset.toFixed(2),
                    wear: a.wear ? a.wear.toString().slice(0, 6) : null
                }
            }))
        }
    }));

	offers_refreshPendingItems();

	offers_addStatusPending({
        ...offer,
        ...{
            price: getFormatAmountString(offer.items.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0)),
            offset: roundedToFixed(offer.items.reduce((acc, cur) => acc + cur.offset, 0) / offer.items.length, 2).toFixed(2),
            items: offer.items.map(a => ({
                ...a,
                ...{
                    price: getFormatAmountString(a.price),
                    offset: a.offset.toFixed(2),
                    wear: a.wear ? a.wear.toString().slice(0, 6) : null
                }
            }))
        }
    });
}

function offers_addPending(offer, notify){
	$('#pending-offers').append(paymentSkinPending({
        ...offer,
        ...{
            price: getFormatAmountString(offer.items.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0)),
            offset: roundedToFixed(offer.items.reduce((acc, cur) => acc + cur.offset, 0) / offer.items.length, 2).toFixed(2),
            items: offer.items.map(a => ({
                ...a,
                ...{
                    price: getFormatAmountString(a.price),
                    offset: a.offset.toFixed(2),
                    wear: a.wear ? a.wear.toString().slice(0, 6) : null
                }
            }))
        }
    }));

	offers_refreshPendingItems();

	if(notify) offers_addStatusPending({
        ...offer,
        ...{
            price: getFormatAmountString(offer.items.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0)),
            offset: roundedToFixed(offer.items.reduce((acc, cur) => acc + cur.offset, 0) / offer.items.length, 2).toFixed(2),
            items: offer.items.map(a => ({
                ...a,
                ...{
                    price: getFormatAmountString(a.price),
                    offset: a.offset.toFixed(2),
                    wear: a.wear ? a.wear.toString().slice(0, 6) : null
                }
            }))
        }
    });
}

function offers_refreshCartItems() {
    var amount = 0;
    var count = 0;

	var offset = 0;
	if(app.paths[0] == 'deposit' && app.paths[1] == 'p2p') offset = parseInt($('#bundle_offset').val());

    $('#list_items .listing-item.active').each(function(i, e) {
		var price = getFormatAmount($(this).data('price'));

        amount += getFormatAmount(price + roundedToFixed(price * offset / 100, 5));
        count += $(this).data('items').length;
    });

	$('#cart_items_total').countToFloat(amount);
    $('#cart_items_count').text(count);

	offers_selectedItems = count;

    if(count == 0) $('.confirm-offer').addClass('disabled');
	else $('.confirm-offer').removeClass('disabled');
}

function offers_refreshPendingItems() {
    var total = 0;
    var amount = 0;
    var count = 0;

    $('#pending-offers .bundle_offer').each(function(i, e) {
		total++;
		amount += getFormatAmount($(this).data('price'));
		count += $(this).data('items').length;
    });

	if(total <= 0) $('#pending_count').addClass('hidden');
	else $('#pending_count').removeClass('hidden');

	$('#pending_count').text(total);
	$('#padding_items_total').countToFloat(amount);
    $('#padding_items_count').text(count);
}

function offers_addStatusPending(offer){
	$('#modal_offers_pending').modal('hide');

	$('#modal_offers_pending .offers_pending_method').addClass('hidden');
	$('#modal_offers_pending .offers_pending_method[data-method="' + offer.method + '"]').removeClass('hidden');

	$('#modal_offers_pending .offers_pending_method[data-method="' + offer.method + '"] .offers_pending_type').addClass('hidden');
	$('#modal_offers_pending .offers_pending_method[data-method="' + offer.method + '"] .offers_pending_type[data-type="' + offer.type + '"]').removeClass('hidden');

	var $content = $('#modal_offers_pending .offers_pending_method[data-method="' + offer.method + '"] .offers_pending_type[data-type="' + offer.type + '"] .offers_pending_status[data-status="' + offer.status + '"]');

	$('#modal_offers_pending .offers_pending_method[data-method="' + offer.method + '"] .offers_pending_type[data-type="' + offer.type + '"] .offers_pending_status').addClass('hidden');
	$content.removeClass('hidden');

    $content.find('.bundle_items_pending').html(paymentSkinOrder(offer));

	if(offer.method == 'p2p'){
		if(offer.status == 0) {
			var COUNTER = 'Waiting for <span class="counter" id="counter_' + offer.method + '_' + offer.id + '_' + offer.status + '">00d 00h 00m 00s</span>';

			COUNTER += '<script>';
				COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(getFormatSeconds(' + (time() - offer.data.time) + ').days + "d " + getFormatSeconds(' + (time() - offer.data.time) + ').hours + "h " + getFormatSeconds(' + (time() - offer.data.time) + ').minutes + "m " + getFormatSeconds(' + (time() - offer.data.time) + ').seconds + "s");';

				COUNTER += 'var time_' + offer.method + '_' + offer.id + '_' + offer.status + ' = ' + (time() - offer.data.time) + ';';

				COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
				COUNTER += 'var int_' + offer.method + '_' + offer.id + '_' + offer.status + ' = setInterval(function(){';
					COUNTER += 'var time = getFormatSeconds(time_' + offer.method + '_' + offer.id + '_' + offer.status + ');';

					COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(time.days + "d " + time.hours + "h " + time.minutes + "m " + time.seconds + "s");';

					COUNTER += 'time_' + offer.method + '_' + offer.id + '_' + offer.status + ' ++;';
				COUNTER += '}, 1000);';
			COUNTER += '</script>';

			$content.find('.counter_content').html(COUNTER);

			$content.find('#cancel_p2p_listing').attr('data-listing', offer.id);
		}

		if(offer.status == 1 || offer.status == 2 || offer.status == 3) {
			var COUNTER = 'Expire in <span class="counter" id="counter_' + offer.method + '_' + offer.id + '_' + offer.status + '">00:00</span>';

			COUNTER += '<script>';
				COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(getFormatSeconds(' + (offer.data.time - time()) + ').minutes + ":" + getFormatSeconds(' + (offer.data.time - time()) + ').seconds);';

				COUNTER += 'var time_' + offer.method + '_' + offer.id + '_' + offer.status + ' = ' + (offer.data.time - time()) + ';';

				COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
				COUNTER += 'var int_' + offer.method + '_' + offer.id + '_' + offer.status + ' = setInterval(function(){';
					COUNTER += 'if(time_' + offer.method + '_' + offer.id + '_' + offer.status + ' <= 0){';
						COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
						COUNTER += 'return;';
					COUNTER += '}';

					COUNTER += 'var time = getFormatSeconds(time_' + offer.method + '_' + offer.id + '_' + offer.status + ');';

					COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(time.minutes + ":" + time.seconds);';

					COUNTER += 'time_' + offer.method + '_' + offer.id + '_' + offer.status + ' --;';
				COUNTER += '}, 1000);';
			COUNTER += '</script>';

			$content.find('.counter_content').html(COUNTER);
		}

        if(offer.status == 4) {
			var COUNTER = 'Clearing in <span class="counter" id="counter_' + offer.method + '_' + offer.id + '_' + offer.status + '">00d 00h 00m 00s</span>';

			COUNTER += '<script>';
				COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(getFormatSeconds(' + (offer.data.time - time()) + ').days + "d " + getFormatSeconds(' + (offer.data.time - time()) + ').hours + "h " + getFormatSeconds(' + (offer.data.time - time()) + ').minutes + "m " + getFormatSeconds(' + (offer.data.time - time()) + ').seconds + "s");';

				COUNTER += 'var time_' + offer.method + '_' + offer.id + '_' + offer.status + ' = ' + (offer.data.time - time()) + ';';

				COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
				COUNTER += 'var int_' + offer.method + '_' + offer.id + '_' + offer.status + ' = setInterval(function(){';
					COUNTER += 'if(time_' + offer.method + '_' + offer.id + '_' + offer.status + ' <= 0){';
						COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
						COUNTER += 'return;';
					COUNTER += '}';

					COUNTER += 'var time = getFormatSeconds(time_' + offer.method + '_' + offer.id + '_' + offer.status + ');';

					COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(time.days + "d " + time.hours + "h " + time.minutes + "m " + time.seconds + "s");';

					COUNTER += 'time_' + offer.method + '_' + offer.id + '_' + offer.status + ' --;';
				COUNTER += '}, 1000);';
			COUNTER += '</script>';

			$content.find('.counter_content').html(COUNTER);
        }

		if(offer.type == 'deposit'){
			if(offer.status == 1) $content.find('#confirm_p2p_listing').attr('data-listing', offer.id);

			if(offer.status == 1 || offer.status == 2 || offer.status == 3){
				var DIV = createAvatarField(offer.data.user, 'medium', '');
				DIV += '<div>' + offer.data.user.name + '</div>';

				$content.find('.offer_buyer_profile').attr('href', 'http://steamcommunity.com/profiles/' + offer.data.steamid);
				$content.find('.offer_buyer_profile').html(DIV);
			}

			if(offer.status == 2 || offer.status == 3) $content.find('.trade_link_offer').attr('href', offer.data.tradelink);
		}

		if(offer.type == 'withdraw'){
			if(offer.status == 3){
				$content.find('.trade_link_offer').attr('href', offer.data.tradeoffer);
			}
		}
	} else if(offer.method == 'steam'){
		if(offer.status == -1 || offer.status == 0 || offer.status == 1 || offer.status == 2 || offer.status == 3) $content.find('.offer_id').text(offer.data.tradeofferid);
		if(offer.status == 0 || offer.status == 1) $content.find('.offer_code').text(offer.data.code);

		if(offer.type == 'deposit'){
			if(offer.status == 3) {
				$content.find('.offer_coins').text(offer.data.amount);

				if(offer.data.refill) $content.find('.offer_got_coins').addClass('hidden');
				else $content.find('.offer_got_coins').removeClass('hidden');
			}
		}

		if(offer.type == 'withdraw'){
			if(offer.status == -1) $content.find('.offer_coins').text(offer.data.amount);
		}

		if(offer.status == 1) {
			var COUNTER = 'Expire in <span class="counter" id="counter_' + offer.method + '_' + offer.id + '_' + offer.status + '">00:00</span>';

			COUNTER += '<script>';
				COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(getFormatSeconds(' + (offer.data.time - time()) + ').minutes + ":" + getFormatSeconds(' + (offer.data.time - time()) + ').seconds);';

				COUNTER += 'var time_' + offer.method + '_' + offer.id + '_' + offer.status + ' = ' + (offer.data.time - time()) + ';';

				COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
				COUNTER += 'var int_' + offer.method + '_' + offer.id + '_' + offer.status + ' = setInterval(function(){';
					COUNTER += 'if(time_' + offer.method + '_' + offer.id + '_' + offer.status + ' <= 0){';
						COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
						COUNTER += 'return;';
					COUNTER += '}';

					COUNTER += 'var time = getFormatSeconds(time_' + offer.method + '_' + offer.id + '_' + offer.status + ');';

					COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(time.minutes + ":" + time.seconds);';

					COUNTER += 'time_' + offer.method + '_' + offer.id + '_' + offer.status + ' --;';
				COUNTER += '}, 1000);';
			COUNTER += '</script>';

			$content.find('.counter_content').html(COUNTER);

			$content.find('.offer_trade').attr('href', 'https://steamcommunity.com/tradeoffer/' + offer.data.tradeofferid + '/');
		}

		if(offer.status == 2) {
			var COUNTER = 'Clearing in <span class="counter" id="counter_' + offer.method + '_' + offer.id + '_' + offer.status + '">00d 00h 00m 00s</span>';

			COUNTER += '<script>';
				COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(getFormatSeconds(' + (offer.data.time - time()) + ').days + "d " + getFormatSeconds(' + (offer.data.time - time()) + ').hours + "h " + getFormatSeconds(' + (offer.data.time - time()) + ').minutes + "m " + getFormatSeconds(' + (offer.data.time - time()) + ').seconds + "s");';

				COUNTER += 'var time_' + offer.method + '_' + offer.id + '_' + offer.status + ' = ' + (offer.data.time - time()) + ';';

				COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
				COUNTER += 'var int_' + offer.method + '_' + offer.id + '_' + offer.status + ' = setInterval(function(){';
					COUNTER += 'if(time_' + offer.method + '_' + offer.id + '_' + offer.status + ' <= 0){';
						COUNTER += 'clearInterval(int_' + offer.method + '_' + offer.id + '_' + offer.status + ');';
						COUNTER += 'return;';
					COUNTER += '}';

					COUNTER += 'var time = getFormatSeconds(time_' + offer.method + '_' + offer.id + '_' + offer.status + ');';

					COUNTER += '$("#counter_' + offer.method + '_' + offer.id + '_' + offer.status + '").text(time.days + "d " + time.hours + "h " + time.minutes + "m " + time.seconds + "s");';

					COUNTER += 'time_' + offer.method + '_' + offer.id + '_' + offer.status + ' --;';
				COUNTER += '}, 1000);';
			COUNTER += '</script>';

			$content.find('.counter_content').html(COUNTER);
        }
	}

	setTimeout(function(){
        $('#modal_offers_pending').modal('show');
    }, 200);
}

function offers_refreshInventory(){
	if(app.paths[1] == 'p2p'){
		if(app.paths[0] == 'deposit') {
			send_request_socket({
				type: 'p2p',
				command: 'load_inventory',
				game: app.paths[2]
			});

			offers_inventoryIsLoading = true;
		} else if(app.paths[0] == 'withdraw') {
			send_request_socket({
				type: 'p2p',
				command: 'load_shop',
				game: app.paths[2]
			});

			offers_inventoryIsLoading = true;
		}
	} else if(app.paths[1] == 'steam'){
		if(app.paths[0] == 'deposit') {
			send_request_socket({
				type: 'steam',
				command: 'load_inventory',
				game: app.paths[2]
			});

			offers_inventoryIsLoading = true;
		} else if(app.paths[0] == 'withdraw') {
			send_request_socket({
				type: 'steam',
				command: 'load_shop',
				game: app.paths[2]
			});

			offers_inventoryIsLoading = true;
		}
	}

	$('#refresh_inventory').addClass('disabled');

	$('#list_items').html(createLoader());
	$('#cart-items').empty();
}

$(document).ready(function() {
	$(document).on('mouseover', '.bundle_offer', function() {
		var $DIV = $(this);

		$DIV.find('.item-bundle-settings').css('display', 'unset');

		setTimeout(function(){
			$DIV.find('.item-bundle-settings').css('opacity', 1);
		}, 10);
	});

	$(document).on('mouseleave', '.bundle_offer', function() {
		var $DIV = $(this);

		$DIV.find('.item-bundle-settings').css('opacity', 0);

		setTimeout(function(){
			$DIV.find('.item-bundle-settings').css('display', 'none');
		}, 500);
	});

	$(document).on('click', '.bundle_offer .view_more_bundle', function() {
		var items = $(this).closest('.listing-item').data('items');

		$('#modal_view_bundle').modal('show');
		$('#modal_view_bundle .bundle-items').empty();

		items.forEach(function(item){
            $('#modal_view_bundle .bundle-items').append(paymentSkinView(item));
        });
	});

	$('#items_order').on('change', function() {
		var type = $(this).val();
		if (type == 0) {
			tinysort('#list_items .listing-item', {
				data: 'price',
				order: 'desc'
			});
		} else if (type == 1) {
			tinysort('#list_items .listing-item', {
				data: 'price',
				order: 'asc'
			});
		} else if (type == 2) {
			tinysort('#list_items .listing-item', {
				data: 'name',
				order: 'asc'
			});
		} else if (type == 3) {
			tinysort('#list_items .listing-item', {
				data: 'name',
				order: 'desc'
			});
		}

		tinysort('#list_items .listing-item', {
			data: "accepted",
			order: "desc"
		});
	});

	var timeout_items = null;
	$('#items_search').on('input', function() {
		var search = $(this).val().toString().toLowerCase();

		if(timeout_items) clearTimeout(timeout_items);

		timeout_items = setTimeout(function(){
			$('#list_items .history_message').remove();

			$('#list_items > .listing-item').addClass('hidden').filter(function(i, e) {
				var name = $(this).data('name');

				if(app.paths[0] == 'withdraw' && app.paths[1] == 'steam') {
                    if (name.toLowerCase().indexOf(search) >= 0 && $(this).data('bot') == $('.steam-bot.active').data('bot')) return true;
                } else if (name.toLowerCase().indexOf(search) >= 0) return true;
			}).removeClass('hidden');

			if($('#list_items .listing-item:not(.hidden)').length <= 0) {
				if(app.page == 'deposit') $('#list_items').append('<div class="in-grid font-8 history_message">Your Inventory is currently empty.</div>');
				if(app.page == 'withdraw') $('#list_items').append('<div class="in-grid font-8 history_message">The Marketplace is currently empty. Please try to switch the bot inventory.</div>');
			}
		}, 1000);
    });

	$(document).on('click', '#list_items .listing-item:not(.notaccepted):not(.unselectable)', function() {
        var dataPos = $(this).data('id');

		if ($(this).hasClass('active')) {
            $(this).removeClass('active').find('.item-selected').addClass('hidden');

			$('#cart-items .item-selected-content[data-id="' + dataPos + '"]').remove();
        } else {
			if(offers_selectedItems < offers_maxSelectItems){
				var items = $(this).data('items');

                if($(this).hasClass('bundle')){
                    $('#list_items .listing-item.active').removeClass('active').find('.item-selected').addClass('hidden');;
                    $('#cart-items').empty();
				}

                $(this).addClass('active').find('.item-selected').removeClass('hidden');

                $('#cart-items').append(paymentSkinCart(items[0]));
			} else {
				notify('error', 'Error: You can select maximum ' + offers_maxSelectItems + ' item!');

				sounds_play('error');
			}
        }

		offers_refreshCartItems();
    });

	$(document).on('click', '#refresh_inventory', function() {
		offers_refreshInventory();
	});

	$(document).on('click', '#remove_item', function() {
		var id = $(this).data('id');

		$('#list_items .listing-item[data-id="' + id + '"]').removeClass('active').find('.item-selected').addClass('hidden');

		$('#cart-items .item-selected-content[data-id="' + id + '"]').remove();

		offers_refreshCartItems();
	});

	$(document).on('click', '.confirm-offer', function(){
		var confirm = $(this).data('confirm');

		var items = [];
		$('#list_items .listing-item.active').each(function(i, e) {
			items.push($(this).data('id'));
		});

		requestRecaptcha(function(render){
			if(app.paths[1] == 'steam'){
				if(confirm == 'refill' && app.paths[0] != 'deposit') return;

				if(app.page == 'deposit') {
					send_request_socket({
						type: 'steam',
						command: 'deposit',
						items: items,
						game: app.paths[2],
						refill: confirm == 'refill',
						recaptcha: render
					});
				} else if(app.page== 'withdraw') {
					var bot = $('.steam-bot.active').data('bot');

					send_request_socket({
						type: 'steam',
						command: 'withdraw',
						items: items,
						game: app.paths[2],
						bot: bot,
						recaptcha: render
					});
				}
			} else if(app.paths[1] == 'p2p'){
				if(confirm == 'refill') return;

				if(app.page == 'deposit'){
					var offset = $('#bundle_offset').val();

					send_request_socket({
						type: 'p2p',
						command: 'create_listing',
						items: items,
						game: app.paths[2],
						offset: offset,
						recaptcha: render
					});
				}else if(app.page == 'withdraw'){
					send_request_socket({
						type: 'p2p',
						command: 'buy_listing',
						id: items[0],
						recaptcha: render
					});
				}
			}
		});
	});

	$(document).on('click', '.inspect_pending_offer', function(){
		var offer = $(this).closest('.listing-item').data('offer');
        var items = $(this).closest('.listing-item').data('items');

		offers_addStatusPending({
			id: $(this).closest('.listing-item').data('id'),
			type: offer.type,
			method: $(this).closest('.listing-item').data('method'),
            game: offer.game,
			status: offer.status,
            price: getFormatAmountString(items.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0)),
            offset: roundedToFixed(items.reduce((acc, cur) => acc + cur.offset, 0) / items.length, 2).toFixed(2),
			items: items,
            data: offer.data
		});
	});
});

/* END STEAM & P2P TRADES */

/* STEAM TRADES */

$(document).ready(function() {
	$(document).on('click', '.steam-bot', function(){
		var bot = $(this).data('bot');

		$('.steam-bot').removeClass('active');
		$(this).addClass('active');

	    $('#list_items .history_message').remove();

        var search = $('#items_search').val();

        $('#list_items > .listing-item.active').removeClass('active').find('.item-selected').addClass('hidden');
		$('#cart-items').empty();

        offers_refreshCartItems();

		$('#list_items > .listing-item').addClass('hidden').filter(function(i, e) {
			var name = $(this).data('name');

			if (name.toLowerCase().indexOf(search) >= 0 && $(this).data('bot') == bot) return true;
		}).removeClass('hidden');

        if($('#list_items > .listing-item:not(.hidden)').length <= 0) {
            if(app.page == 'deposit') $('#list_items').append('<div class="in-grid font-8 history_message">Your Inventory is currently empty.</div>');
            if(app.page == 'withdraw') $('#list_items').append('<div class="in-grid font-8 history_message">The Marketplace is currently empty. Please try to switch the bot inventory.</div>');
        }
	});
});

/* END STEAM TRADES */

/* P2P TRADES */

$(document).ready(function() {
	$(document).on('click', '#cancel_p2p_listing', function() {
		var listing = $(this).attr('data-listing');

		requestRecaptcha(function(render){
			send_request_socket({
				type: 'p2p',
				command: 'cancel_listing',
				id: listing,
				recaptcha: render
			});
		});
	});

	$(document).on('click', '#confirm_p2p_listing', function() {
		var listing = $(this).data('listing');

		requestRecaptcha(function(render){
			send_request_socket({
				type: 'p2p',
				command: 'confirm_listing',
				id: listing,
				recaptcha: render
			});
		});
	});

	$(document).on('input', '#bundle_offset', function(){
		var offset = $(this).val();

		$('#cart-items .item-selected-content').each(function(i, e) {
			var price = getFormatAmount($(this).data('price'));

			$(this).find('.price').text(getFormatAmountString(price + roundedToFixed(price * offset / 100, 5)));
		});

		offers_refreshCartItems();
	});
});

/* END P2P TRADES */

/* FAQ */

$(document).ready(function() {
	$(document).on('click', '.faq-open', function() {
		if($(this).parent().parent().hasClass('active')){
			$(this).parent().parent().removeClass('active');
		} else {
			$(this).parent().parent().addClass('active');
		}
	});
});

/* END FAQ */

/* FAIR */

$(document).ready(function() {
	$(document).on('click', '.fair-results', function() {
		var fair = JSON.parse($(this).attr('data-fair').toString());

		var game = fair.game;
		var draw = fair.draw;

		$('#fair_server_seed_hashed').text('-');
		$('#fair_server_seed').text('-');
		$('#fair_public_seed').text('-');
		$('#fair_nonce').text('-');
		$('#fair_block').text('-');
		$('#fair_block_link').attr('href', '');

		$('#fair_server_seed_hashed').attr('data-text', '');
		$('#fair_server_seed').attr('data-text', '');
		$('#fair_public_seed').attr('data-text', '');
		$('#fair_nonce').attr('data-text', '');

		if(game.server_seed_hashed !== undefined) $('#fair_server_seed_hashed').text(game.server_seed_hashed);
		if(game.server_seed !== undefined) $('#fair_server_seed').text(game.server_seed);
		if(game.public_seed !== undefined) $('#fair_public_seed').text(game.public_seed);
		if(game.nonce !== undefined) $('#fair_nonce').text(game.nonce);
		if(game.block !== undefined) {
			$('#fair_block').text(game.block);
			$('#fair_block_link').attr('href', 'https://eosflare.io/block/' + game.block);
		}

		$('#fair_server_seed_hashed').attr('data-text', game.server_seed_hashed);
		$('#fair_server_seed').attr('data-text', game.server_seed);
		$('#fair_public_seed').attr('data-text', game.public_seed);
		$('#fair_nonce').attr('data-text', game.nonce);

		if(draw){
			$('#fair_draw').removeClass('hidden');

			$('#fair_draw_public_seed').text('-');
			$('#fair_draw_block').text('-');
			$('#fair_draw_block_link').attr('href', '');

			if(draw.public_seed !== undefined) $('#fair_draw_public_seed').text(draw.public_seed);

			if(draw.block !== undefined) {
				$('#fair_draw_block').text(draw.block);
				$('#fair_draw_block_link').attr('href', 'https://eosflare.io/block/' + draw.block);
			}
		} else {
			$('#fair_draw').addClass('hidden');
		}

		$('#modal_fair_round').modal('show');
	});
});

/* END FAIR */

function isOnMobile(){
	return ($(window).width() <= 768);
}

function getInfosByItemName(name){
	var infos = {
		brand: null,
		name: null,
		exterior: null
	};

	var match = /^\s*(.*?)\s*(?:\|\s*(.*?)\s*(?:\(\s*(.*?)\s*\))?)?$/.exec(name);

	if(match && match[2]) {
		infos.brand = match[1] || null;
		infos.name = match[2] || null;
		infos.exterior = match[3] || null;
	} else infos.brand = name.trim();

	return infos;
}

function createLoader(){
	var DIV = '<div class="flex in-grid justify-center items-center width-full height-full history_message">';
		DIV += '<div class="loader">';
			DIV += '<div class="loader-part loader-part-1">';
				DIV += '<div class="loader-dot loader-dot-1"></div>';
				DIV += '<div class="loader-dot loader-dot-2"></div>';
			DIV += '</div>';

			DIV += '<div class="loader-part loader-part-2">';
				DIV += '<div class="loader-dot loader-dot-1"></div>';
				DIV += '<div class="loader-dot loader-dot-2"></div>';
			DIV += '</div>';
		DIV += '</div>';
	DIV += '</div>';

	return DIV;
}

function createAvatarField(user, type, more, classes){
	var level_class = ['tier-steel', 'tier-bronze', 'tier-silver', 'tier-gold', 'tier-diamond'][Math.floor(user.level / 25)];

	var DIV = '<div class="avatar-field rounded-full ' + classes + ' ' + level_class + ' relative">';
		DIV += '<img class="avatar icon-' + type + ' rounded-full" src="' + user.avatar + '">';
		DIV += '<div class="level sup-' + type + '-left flex justify-center items-center b-d2 rounded-full">' + user.level + '</div>';
		DIV += more;
	DIV += '</div>';

	return DIV;
}

function roundedToFixed(number, decimals){
	if(isNaN(Number(number))) return 0;

	number = Number((Number(number).toFixed(5)));

	var number_string = number.toString();
	var decimals_string = 0;

	if(number_string.split('.')[1] !== undefined) decimals_string = number_string.split('.')[1].length;

	while(decimals_string - decimals > 0) {
		number_string = number_string.slice(0, -1);

		decimals_string --;
	}

	return Number(number_string);
}

function getFormatAmount(amount){
	return roundedToFixed(amount, 2);
}

function getFormatAmountString(amount){
	return getFormatAmount(amount).toFixed(2);
}

function getNumberFromString(amount){
	if(amount.toString().trim().length <= 0) return 0;
	if(isNaN(Number(amount.toString().trim()))) return 0;

	return amount;
}

function stringEscape(string){
	return string.toString().replace(/"/g, '&quot;');
}

function stringUnescape(string){
	return string.toString().replace(/(&quot;)/g, '"');
}

function generateCode(length) {
	var text = '';
	var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

	for(var i = 0; i < length; i++) text += possible.charAt(Math.floor(Math.random() * possible.length));

	return text;
}

function getFormatSeconds(time){
	var days = Math.floor(time / (24 * 60 * 60));
	var hours = Math.floor((time - days * 24 * 60 * 60) / (60 * 60));
	var minutes = Math.floor((time - days * 24 * 60 * 60 - hours * 60 * 60) / 60);
	var seconds = Math.floor(time - days * 24 * 60 * 60 - hours * 60 * 60 - minutes * 60);

	return {
		days: '0'.concat(days.toString()).slice(-2),
		hours: '0'.concat(hours.toString()).slice(-2),
		minutes: '0'.concat(minutes.toString()).slice(-2),
		seconds: '0'.concat(seconds.toString()).slice(-2)
	};
}

function getRandomInt(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function capitalizeText(text){
	return text.charAt(0).toUpperCase() + text.slice(1);
}

function time(){
	return Math.floor(new Date().getTime() / 1000);
}