CREATE TABLE `steam_items` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `itemid` varchar(256) NOT NULL,
    `wear` decimal(32,16) NOT NULL,
    `paintindex` bigint(32) NOT NULL,
    `time` bigint(32) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;