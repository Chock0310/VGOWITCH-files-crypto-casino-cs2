CREATE TABLE `unboxing_bets` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `userid` varchar(36) NOT NULL,
    `name` varchar(256) NOT NULL,
    `avatar` text NOT NULL,
    `xp` bigint(32) NOT NULL,
    `caseid` text NOT NULL,
    `amount` decimal(32,2) NOT NULL,
    `winning` text NOT NULL,
    `roll` bigint(32) NOT NULL,
    `tickets` bigint(32) NOT NULL,
    `server_seedid` bigint(32) NOT NULL,
    `client_seedid` bigint(32) NOT NULL,
    `nonce` bigint(32) NOT NULL,
    `time` bigint(32) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;