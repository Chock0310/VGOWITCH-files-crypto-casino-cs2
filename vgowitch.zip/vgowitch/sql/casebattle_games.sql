CREATE TABLE `casebattle_games` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `canceled` bigint(32) NOT NULL DEFAULT 0,
    `ended` bigint(32) NOT NULL DEFAULT 0,
    `cases` text NOT NULL,
    `amount` decimal(32,2) NOT NULL,
    `mode` bigint(32) NOT NULL,
    `privacy` bigint(32) NOT NULL,
    `free` bigint(32) NOT NULL,
    `crazy` bigint(32) NOT NULL,
    `server_seed` varchar(256) NOT NULL,
    `battleid` varchar(36) NOT NULL,
    `time` bigint(32) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;