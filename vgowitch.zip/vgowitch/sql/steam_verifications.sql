CREATE TABLE `steam_verifications` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `userid` varchar(36) NOT NULL,
    `botsteamid` varchar(17) NOT NULL,
    `tradeofferid` bigint(32) NOT NULL,
    `code` varchar(24) NOT NULL,
    `item` text NOT NULL,
    `time` bigint(32) NOT NULL,
    UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;