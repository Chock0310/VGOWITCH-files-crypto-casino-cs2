CREATE TABLE `p2p_transactions` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `status` bigint(32) NOT NULL DEFAULT 0,
    `userid` varchar(36) NOT NULL,
    `name` varchar(256) NOT NULL,
    `avatar` text NOT NULL,
    `xp` bigint(32) NOT NULL,
    `steamid` varchar(17) NOT NULL,
    `webapi_token` text NOT NULL,
    `tradelink` text NOT NULL,
    `items` text NOT NULL,
    `amount` decimal(32,2) NOT NULL,
    `game` varchar(256) NOT NULL,
    `tradeofferid` varchar(32) DEFAULT NULL,
    `update` bigint(32) NOT NULL,
    `time` bigint(32) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;