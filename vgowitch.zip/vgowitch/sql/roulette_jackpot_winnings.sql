CREATE TABLE `roulette_jackpot_winnings` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `userid` varchar(36) NOT NULL,
    `name` varchar(256) NOT NULL,
    `avatar` text NOT NULL,
    `level` bigint(32) NOT NULL,
    `bets` decimal(32,2) NOT NULL,
    `amount` decimal(32,2) NOT NULL,
    `jackpotid` bigint(32) NOT NULL,
    `time` bigint(32) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;