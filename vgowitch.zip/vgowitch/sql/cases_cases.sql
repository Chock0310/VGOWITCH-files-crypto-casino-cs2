CREATE TABLE `cases_cases` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `removed` bigint(32) NOT NULL DEFAULT 0,
    `game` text NOT NULL,
    `category` bigint(32) NOT NULL,
    `caseid` text NOT NULL,
    `items` text NOT NULL,
    `name` text NOT NULL,
    `image` text NOT NULL,
    `battle` bigint(32) NOT NULL,
    `time` bigint(32) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;