CREATE TABLE `steam_withdraw` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `status` bigint(32) NOT NULL DEFAULT 0,
    `itemid` varchar(256) NOT NULL,
    `name` text NOT NULL,
    `image` text NOT NULL,
    `quality` text DEFAULT NULL,
    `stickers` text NOT NULL,
    `game` text NOT NULL,
    `botsteamid` varchar(17) NOT NULL,
    `time` bigint(32) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;