CREATE TABLE `p2p_buyers` (
    `id` bigint(32) NOT NULL AUTO_INCREMENT,
    `canceled` bigint(32) NOT NULL DEFAULT 0,
    `userid` varchar(36) NOT NULL,
    `name` varchar(256) NOT NULL,
    `avatar` text NOT NULL,
    `xp` bigint(32) NOT NULL,
    `steamid` varchar(17) NOT NULL,
    `webapi_token` text NOT NULL,
    `tradelink` text NOT NULL,
    `offerid` bigint(32) NOT NULL,
    `time` bigint(32) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;