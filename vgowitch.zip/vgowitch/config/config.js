const config = {
	cache: require('../cache.json'),
	settings: require('../settings.json'),

	app: {
		name: process.env.APP_NAME,
		abbreviation: process.env.APP_ABBREVIATION,

		url: process.env.APP_URL,

        keywords: [ 'jackpot', 'coinflip', 'csgo', 'cs', 'go', 'global', 'offensive', 'cs:go', 'vgo', 'csgocoinflip', 'csgocoinflip', 'csgosite', 'vgocoinflip', 'vgocoinflip', 'vgosite', 'site', 'vgokingdom', 'kingdom', 'bet', 'gambling', 'gamble', 'fair', 'best', 'great', 'csgoempire', 'csgoatse', 'csgo500', 'crypto', 'btc', 'eth', 'roulette', 'experience' ],
        autor: 'MrCHICK',
        description: process.env.APP_NAME + ' - The best crypto place to win money!',
        themecolor: '#9370db',

        social: {
            steam_group: process.env.STEAM_GROUP_URL,
            twitter_page: process.env.TWITTER_PAGE_URL
        },

		port: process.env.APP_PORT,
		secure: process.env.APP_SECURE === 'true',

        ssl: {
            certificate: process.env.SSL_CRT_FILE,
            private_key: process.env.SSL_KEY_FILE
        },

		database: {
			database: process.env.DB_DATABASE,
			host: process.env.DB_HOST,
			user: process.env.DB_USERNAME,
			password: process.env.DB_PASSWORD
		},

        google: {
            client: process.env.GOOGLE_CLIENT_ID,
            secret: process.env.GOOGLE_CLIENT_SECRET,
            callback_url: process.env.GOOGLE_CALLBACK_URL
        },

        discord: {
            client: process.env.DISCORD_CLIENT_ID,
            secret: process.env.DISCORD_CLIENT_SECRET,
            callback_url: process.env.DISCORD_CALLBACK_URL
        },

        steam: {
            apikey: process.env.STEAM_API_KEY,
            callback_url: process.env.STEAM_CALLBACK_URL
        },

		mailer: {
			host: process.env.MAIL_HOST,
			port: process.env.MAIL_PORT,
			secure: process.env.MAIL_SECURE === 'true',
			email: process.env.MAIL_EMAIL,
			password: process.env.MAIL_PASSWORD
		},

		recaptcha: {
			private_key: process.env.RECAPTCHA_PRIVATE_KEY,
			public_key: process.env.RECAPTCHA_PUBLIC_KEY
		},

        pages: {
            'roulette': 'Roulette',
            'crash': 'Crash',
            'coinflip': 'Coinflip',
            'jackpot': 'Jackpot',
            'dice': 'Dice',
            'casebattle': 'Case Battle',
            'unboxing': 'Unboxing',
            'upgrader': 'Upgrader',
            'minesweeper': 'Minesweeper',
            'tower': 'Tower',
            'plinko': 'Plinko',
            'casino': 'Casino',
            'account': 'Account',
            'user': 'User',
            'rewards': 'Rewards',
            'deposit': 'Deposit',
            'withdraw': 'Withdraw',
            'tos': 'Terms Of Service',
            'support': 'Support',
            'fair': 'Provably Fair',
            'faq': 'Frequently Asked Questions',
            'maintenance': 'Maintenance',
            'leaderboard': 'Leaderboard',
            'banned': 'Banned',
            'home': 'Home',
            'admin': 'Admin',
            'dashboard': 'Dashboard',
            'affiliates': 'Affiliates',
            'login': 'Sign In',
            'register': 'Create Account',
            'setPassword': 'Set Your Password',
            'setEmail': 'Set Your Email',
            'forgotPassword': 'Forgot Password',
            'resetPassword': 'Reset Your Password',
            'twofa': 'Two-Factory Authentication',
            'authorize': 'Verification Authentication'
        },

		access_secrets: [ 'K22KJz' ],

        permissions: {
            exclude_ban_ip: [ 'owner' ],
            exclude_ban_site: [ 'owner' ],
            exclude_ban_play: [ 'owner' ],
            exclude_ban_trade: [ 'owner' ],
            exclude_mute: [ 'owner' ],
            exclude_chat_pause: [ 'owner', 'admin', 'moderator' ],
            access_maintenance: [ 'owner', 'developer', 'admin', 'moderator', 'helper' ],
            create_bonus: [ 'owner', 'admin' ],
            play_offline: [ 'owner' ],
            play_disabled: [ 'owner' ],
            play_casino_real: [ 'owner' ],
            trade_offline: [ 'owner' ],
            trade_disabled: [ 'owner' ],
            load_inventory: [ 'owner', 'admin' ],
            withdraw: [ 'owner' ],
            repply_support: [ 'owner' ],
            view_user: [ 'owner', 'admin' ],
            refill_shop: [ 'owner' ],
            call_gamebots: [ 'owner' ],
            extended_session: [ 'owner', 'admin', 'moderator' ]
        },

        ranks: {
            0: 'member', 1: 'admin', 2: 'moderator', 3: 'helper', 4: 'veteran', 5: 'pro', 6: 'youtuber', 7: 'streamer', 8: 'developer', 100: 'owner',
            'member': 0, 'admin': 1, 'moderator': 2, 'helper': 3, 'veteran': 4, 'pro': 5, 'youtuber': 6, 'streamer': 7, 'developer': 8, 'owner': 100
        },

		flood: {
			time: 100 * 10e5, // IN NANO SECONDS
			count: 5
		},

		level: {
			start: 500,
			next: 0.235
		},

        tip: {
            level_send: 5,
            level_receive: 5
        },

		rain: {
			start: 1.00,
			cooldown_start: 5 * 60,
			timeout_interval: { min: 10 * 60, max: 30 * 60 }
		},

        intervals: {
            amounts: {
                roulette: { min: 0.01, max: 1000.00 },
                crash: { min: 0.01, max: 1000.00 },
                jackpot: { min: 0.01, max: 1000.00 },
                coinflip: { min: 0.01, max: 1000.00 },
                dice: { min: 0.01, max: 1000.00 },
                upgrader: { min: 0.00, max: 1000.00 },
                minesweeper: { min: 0.01, max: 1000.00 },
                tower: { min: 0.01, max: 1000.00 },
                plinko: { min: 0.01, max: 1000.00 },

                tip_player: { min: 0.01, max: 100.00 },
                tip_rain: { min: 0.01, max: 1000.00 },

                deposit_crypto: { min: 2.00, max: 500.00 },
                withdraw_crypto: { min: 2.00, max: 500.00 },

                deposit_item: { min: 0.01, max: 100000.00 },
                withdraw_item: { min: 0.01, max: 100000.00 },

                deposit_p2p: { min: 0.01, max: 100000.00 },
                deposit_steam: { min: 0.01, max: 100000.00 },
                withdraw_steam: { min: 0.01, max: 100000.00 }
            },

            items: {
                deposit: { min: 1, max: 20 },
                withdraw: { min: 1, max: 20 },
                p2p: { min: 1, max: 20 }
            }
        },

		rewards: {
            amounts: {
                steam: 0.50,
                google: 0.50,
                discord: 0.50,
                facebook: 0.50,

                refferal_code: 1.00,

                daily_start: 0.20,
                daily_level: 0.02
            },

            requirements: {
                code_length: { min: 6, max: 20 },
                bonus_uses: { min: 1, max: 500 },
                bonus_amount: { min: 0.01, max: 10.00 }
            },

            daily: {
                amount: 5.00,
                time: 7 * 24 * 60 * 60
            }
		},

        affiliates: {
            requirements: [0.00, 200.00, 500.00, 750.00, 1000.00, 2000.00, 3500.00, 5000.00, 7500.00, 10000.00],
            commissions: {
                deposit: 1,
                bet: 2
            }
        },

		dailycases:{
			time: 24
		},

		items: {
			prices: {
				games: {
					cs2: 730,
					rust: 252490
				},

				apikey: {
					key: process.env.BITSKINS_APIKEY
				},

				cooldown_load: 24 * 60 * 60
			}
		},

		admin: {
			casecreator_requirements: {
				name_length: { min: 4, max: 20 },
				items_length: { min: 2, max: 50 },

				dailycases: {
					level: { min: 0, max: 100 }
				},

				categories: {
					name_length: { min: 4, max: 20 }
				}
			},

			gamebots_requirements: {
				name_length: { min: 4, max: 20 }
			},

            tracking_links: {
                code_length: 64,
                usage_length: { min: 4, max: 20 }
            },

            deposit_bonuses: {
                code_length: { min: 6, max: 12 },
            }
		},

        support: {
            requirements: {
                subject_length: { min: 6, max: 100 },
                message_length: { min: 10, max: 2000 }
            }
        },

		chat: {
			max_messages: 40,

			cooldown_massage: 1,

			channels: ['en', 'ro', 'fr', 'ru', 'de'],

			support: {
				active: false,
				message: 'If you find bugs contact us as soon as possible to solve them! With all due respect, the ' + process.env.APP_ABBREVIATION + ' team.',
				cooldown: 24 * 60 * 60
			},

			greeting: {
				active: true,
				message: 'Please contact us if you need help. We don\'t resolve issues in the chat. Type /help for chat commands. With all due respect, the ' + process.env.APP_ABBREVIATION + ' team.',
			},

			message_double_xp: 'Weekly Double XP! Get double XP betting on our games until Sunday at 23:59PM GTM.'
		},

        auth: {
            binds: [ 'steam', 'google', 'discord' ],
            expire: {
                token: {
                    authentication: 2 * 60 * 60,
                    recover: 2 * 60 * 60,
                    email_validation: 10 * 60
                },
                code: {
                    twofa: 10 * 60,
                    email_verification: 10 * 60
                },
                sessions: {
                    security: 15 * 60
                }
            },
            session: {
                expire: {
                    normal: 1 * 24 * 60 * 60,
                    extended: 30 * 24 * 60 * 60
                }
            }
        }
	},

	trading: {
		deposit_bonus: 5,

		withdraw_requirements: {
            deposit: {
                amount: 1.00,
                time: -1 // time in seconds or -1 for all-time
            }
        },

		proxies: {
			attempts: 10,

			apikey: {
                key: process.env.WEBSHARE_APIKEY
            }
		},

		steam: {
			time_cancel_trade: 5 * 60,
			time_clear_trade: 7 * 24 * 60 * 60,
			time_remove_pending: 1 * 60,

			cooldown_inventory_success: 10 * 60,
			cooldown_inventory_fault: 1 * 60,

            cooldown_items_deposit: 10 * 24 * 60 * 60,
            cooldown_checking_rollback: 1 * 60,

			withdraw_offset: 10,
			deposit_offset: 0,

			game_verify_webapi_token: 'cs2',

			bots: require('./steambots.js'),

			prices: {
				apikey: {
					key: process.env.BITSKINS_APIKEY
				},

				cooldown_load: 1 * 60 * 60
			},

			games: {
				cs2: { game: { appid: 730, contextid: 2 } },
				dota2: { game: { appid: 570, contextid: 2 } },
				rust: { game: { appid: 252490, contextid: 2 } },
				tf2: { game: { appid: 440, contextid: 2 } }
			},

			blacklist_items: {
				cs2: [],
				dota2: [],
				rust: [],
				tf2: []
			}
		},

		p2p: {
			timer_confirm: 1 * 60,
			timer_send: 10 * 60,
			timer_clear: 7 * 24 * 60 * 60,

			cooldown_tracking: 1,

			listing_validity: {
				enable: true,

				cooldown_checking: 1 * 60
			}
		},

		crypto: {
			nowpayments: {
				api_key: process.env.NOWPAYMENTS_API_KEY,
				public_key: process.env.NOWPAYMENTS_PUBLIC_KEY,

                email: process.env.NOWPAYMENTS_EMAIL,
                password: process.env.NOWPAYMENTS_PASSWORD,

                ipn_secret_key: process.env.NOWPAYMENTS_IPN_SECRET_KEY,
                twofa_secret_key: process.env.NOWPAYMENTS_TWOFA_SECRET_KEY,

                callback_url: process.env.NOWPAYMENTS_CALLBACK_URL
			},

			currencies: {
				cooldown_load: 10
			}
		}
	},

	games: {
		history: {
			big_bets: 100.00
		},

		winning_to_chat: 50000.00,

		eos_future: 10,

		house_edge: {
			roulette: 6.67, // fixed house edge
			crash: 5,
			jackpot: 5, // as commission
			coinflip: 5, // as commission
			dice: 5,
			unboxing: 10, // added to cases prices
			casebattle: 10, // house edge due to cases being used
			upgrader: 10,
			tower: 2.00, // fixed house edge
			minesweeper: 4.00, // fixed house edge
			plinko: 5
		},

		games: {
			roulette: {
				multiplayer: true,
				timer: 20,
				cooldown_rolling: 10,
				total_bets: 3,

                multipliers: {
                    red: 2,
                    black: 2,
                    bait: 7,
                    green: 14,
                },

				jackpot_commission: 1
			},

			crash: {
				multiplayer: true,
				timer: 5,
				max_profit: 5000.00,
				instant_chance: 5
			},

			jackpot: {
				multiplayer: true,
				timer: 30,
				total_bets: 3,
				bets_start: 2,
				users_start: 2,
				colors: [
					'#FF0000','#FF9D00','#FFF700','#1AFF00','#147AFF',
					'#C414FF','#14FFE4','#99FF14','#D55AED','#CC3798',
					'#965821','#A8A142','#A1ED8E','#37DBB5','#C45F41',
					'#F3408B','#05668D','#4CE0B3','#5D2E8C','#2CA58D',
					'#E9D758','#F68F71','#2B4570','#297373','#5B507A',
					'#1B2238','#C1A88D','#7880B5','#6987C9','#6C99B5',
					'#2B013B','#570C43','#8F065A','#F1EEFD','#AB90F0',
					'#23113A','#F9CC72','#791E94','#DE6449','#D8D4F2'
				]
			},

			coinflip: {
				multiplayer: true,
				cancel: false,
				timer_cancel: 1 * 60 * 60,
				timer_wait_start: 10,
				timer_delete: 1 * 60
			},

			dice: {
				multiplayer: false
			},

			unboxing: {
				multiplayer: false,
				cases_length: { min: 1, max: 5 } //move to admin
			},

			casebattle: {
				multiplayer: true,
				interval_cases: { min: 1, max: 20 },
				timer_countdown: 3,
				timer_wait_start: 1,
				timer_delete: 1 * 60,

				cashback: 1
			},

			upgrader: {
				multiplayer: false,
				interval_myitems: { min: 1, max: 15 },
				interval_siteitems: { min: 1, max: 15 }
			},

			minesweeper: {
				multiplayer: false,
				multipliers: {
					24: [24.00],
                    23: [12.25, 295.00],
                    22: [8.20, 99.00, 2200.00],
                    21: [6.18, 49.52, 568.30, 12000.00],
                    20: [4.95, 29.72, 227.20, 2504.30, 52598.30],
                    19: [4.12, 19.80, 113.85, 834.50, 8766.40, 175329.40],
                    18: [3.53, 14.14, 65.05, 357.81, 2504.34, 25047.30, 475893.00],
                    17: [3.09, 10.62, 40.66, 178.40, 939.20, 6261.75, 59486.62, 1070759.25],
                    16: [2.75, 8.24, 27.10, 99.39, 417.45, 2087.25, 13219.25, 118973.25, 2022545.25],
                    15: [2.47, 6.60, 18.97, 59.63, 208.72, 834.89, 3965.77, 23794.64, 202254.52, 3236072.00],
                    14: [2.25, 5.40, 13.80, 37.95, 113.85, 379.50, 1442.10, 6489.45, 36773.55, 294188.40, 4412826.00],
                    13: [2.06, 4.50, 10.35, 25.30, 66.41, 189.75, 600.87, 2163.15, 9193.38, 49031.40, 367735.50, 5148297.00],
                    12: [1.90, 3.80, 7.96, 17.51, 40.86, 102.17, 277.32, 831.98, 2828.73, 11314.93, 56574.69, 396022.84, 48296.99],
                    11: [1.76, 3.26, 6.25, 12.51, 26.27, 58.38, 138.66, 356.56, 1010.26, 3232.83, 12123.14, 56574.69, 367735.50],
                    10: [1.65, 2.82, 5.00, 9.17, 17.51, 35.03, 73.95, 166.39, 404.10, 1077.61, 3232.83, 11314.93, 49031.40, 69031.40, 79031.40],
                    9: [1.54, 2.47, 4.06, 6.88, 12.04, 21.89, 41.59, 83.19, 176.79, 404.10, 1010.26, 2828.73, 9193.38, 10000.00, 15000.00, 18000.00],
                    8: [1.73, 2.34, 3.69, 5.49, 10.35, 18.53, 38.10, 78.26, 157.80, 360.12, 777.77, 1000.00, 1337.00, 1560.00, 3234.00, 4589.00, 8888.88],
                    7: [1.43, 1.87, 2.69, 4.49, 5.35, 7.53, 8.10, 10.26, 14.80, 18.12, 22.52, 24.51, 29.32, 48.46, 71.49, 113.27, 150.78, 300.22],
                    6: [1.23, 1.53, 1.99, 2.49, 4.35, 5.53, 6.10, 7.26, 8.80, 10.12, 12.52, 17.51, 25.32, 38.46, 61.49, 93.27, 130.78, 150.22, 260.00],
                    5: [1.23, 1.53, 1.99, 2.49, 4.35, 5.53, 6.10, 7.26, 8.80, 10.12, 12.52, 17.51, 25.32, 38.46, 61.49, 93.27, 130.78, 150.22, 178.34, 240.00],
                    4: [1.17, 1.41, 1.71, 2.09, 2.35, 3.23, 4.10, 5.26, 6.80, 9.12, 12.52, 17.51, 25.32, 38.46, 61.49, 93.27, 130.78, 150.22, 178.34, 200.00, 220.00],
                    3: [1.12, 1.25, 1.47, 1.72, 1.92, 2.34, 2.75, 3.28, 4.02, 5.07, 6.23, 7.93, 10.35, 13.88, 18.97, 25.43, 38.40, 57.43, 89.47, 127.59, 170.00],
                    2: [1.07, 1.17, 1.26, 1.41, 1.51, 1.73, 1.94, 2.18, 2.46, 2.82, 3.26, 3.80, 4.50, 5.48, 6.66, 8.25, 10.60, 14.14, 19.78, 29.69, 49.49, 98.56, 150.00],
                    1: [1.03, 1.06, 1.12, 1.17, 1.23, 1.30, 1.37, 1.43, 1.53, 1.65, 1.75, 1.90, 2.06, 2.25, 2.45, 2.75, 3.09, 3.53, 4.12, 4.95, 6.12, 8.25, 12.37, 24.00]
				}
			},

			tower: {
				multiplayer: false,
				multipliers: {
					easy: [1.31, 1.74, 2.32, 3.10, 4.13, 5.51, 7.34, 9.79, 13.05],
					medium: [1.47, 2.21, 3.31, 4.96, 7.44, 11.16, 16.74, 25.11, 37.67],
					hard: [1.96, 3.92, 7.84, 15.68, 31.36, 62.72, 125.44, 250.88, 501.76],
					expert: [2.94, 8.82, 26.46, 79.38, 238,14, 714.42, 2143.26, 6429.78, 19289.34],
					master: [3.92, 15.68, 62.72, 250.88, 1003.52, 4014.08, 16056.32, 64225.28, 256901.12]
				},
				tiles: {
					easy: 4,
					medium: 3,
					hard: 2,
					expert: 3,
					master: 4
				}
			},

			plinko: {
				multiplayer: false,
				results: {
					easy: {
						8: [5.6, 2.1, 1.1, 1, 0.5, 1, 1.1, 2.1, 5.6],
						9: [5.6, 2, 1.6, 1, 0.7, 0.7, 1, 1.6, 2, 5.6],
						10: [8.9, 3, 1.4, 1.1, 1, 0.5, 1, 1.1, 1.4, 3, 8.9],
						11: [8.4, 3, 1.9, 1.3, 1, 0.7, 0.7, 1, 1.3, 1.9, 3, 8.4],
						12: [10, 3, 1.6, 1.4, 1.1, 1, 0.5, 1, 1.1, 1.4, 1.6, 3, 10],
						13: [8.1, 4, 3, 1.9, 1.2, 0.9, 0.7, 0.7, 0.9, 1.2, 1.9, 3, 4, 8.1],
						14: [7.1, 4, 1.9, 1.4, 1.3, 1.1, 1, 0.5, 1, 1.1, 1.3, 1.4, 1.9, 4, 7.1],
						15: [15, 8, 3, 2, 1.5, 1.1, 1, 0.7, 0.7, 1, 1.1, 1.5, 2, 3, 8, 15],
						16: [16, 9, 2, 1.4, 1.4, 1.2, 1.1, 1, 0.5, 1, 1.1, 1.2, 1.4, 1.4, 2, 9, 16]
					},
					medium: {
						8: [13, 3, 1.3, 0.7, 0.4, 0.7, 1.3, 3, 13],
						9: [18, 4, 1.7, 0.9, 0.5, 0.5, 0.9, 1.7, 4, 18],
						10: [22, 5, 2, 1.4, 0.6, 0.4, 0.6, 1.4, 2, 5, 22],
						11: [24, 6, 3, 1.8, 0.7, 0.5, 0.5, 0.7, 1.8, 3, 6, 24],
						12: [33, 11, 4, 2, 1.1, 0.6, 0.3, 0.6, 1.1, 2, 4, 11, 33],
						13: [43, 13, 6, 3, 1.3, 0.7, 0.4, 0.4, 0.7, 1.3, 3, 6, 13, 43],
						14: [58, 15, 7, 4, 1.9, 1, 0.5, 0.2, 0.5, 1, 1.9, 4, 7, 15, 58],
						15: [88, 18, 11, 5, 3, 1.3, 0.5, 0.3, 0.3, 0.3, 0.5, 1.3, 3, 5, 11, 18, 88],
						16: [110, 41, 10, 5, 3, 1.5, 1, 0.5, 0.3, 0.5, 1, 1.5, 3, 5, 10, 41, 110]
					},
					hard: {
						8: [29, 4, 1.5, 0.3, 0.2, 0.3, 1.5, 4, 29],
						9: [43, 7, 2, 0.6, 0.2, 0.2, 0.6, 2, 7, 43],
						10: [76, 10, 3, 0.9, 0.3, 0.2, 0.3, 0.9, 3, 10, 76],
						11: [120, 14, 5.2, 1.4, 0.4, 0.2, 0.2, 0.4, 1.4, 5.2, 14, 120],
						12: [170, 24, 8.1, 2, 0.7, 0.2, 0.2, 0.2, 0.7, 2, 8.1, 24, 170],
						13: [260, 37, 11, 4, 1, 0.2, 0.2, 0.2, 0.2, 1, 4, 11, 37, 260],
						14: [420, 56, 17, 5, 1.9, 0.3, 0.2, 0.2, 0.2, 0.3, 1.9, 5, 18, 56, 420],
						15: [620, 83, 27, 8, 3, 0.5, 0.2, 0.2, 0.2, 0.2, 0.5, 3, 8, 27, 83, 620],
						16: [1000, 130, 26, 9, 4, 2, 0.2, 0.2, 0.2, 0.2, 0.2, 2, 4, 9, 26, 130, 1000]
					}
				}
			},

            casino: {
                multiplayer: false,

                drakon: {
                    agent: {
                        code: process.env.DRAKON_AGENT_CODE,
                        token: process.env.DRAKON_AGENT_TOKEN,
                        secret_key: process.env.DRAKON_AGENT_SECRET_KEY,
                        currency: process.env.DRAKON_AGENT_CURRENCY
                    },
                    language: process.env.DRAKON_LANGUAGE
                },

                access_token: {
                    cooldown_load: 10 * 60
                },

                games: {
                    cooldown_load: 1 * 60 * 60
                }
            }
		}
	}
}

module.exports = config;