/*

Steam Bot Example

{
	active: true|false,
	botname: 'Bot Name',
	steamid: 'steamid',
	username: 'username',
	password: 'password',
	identity_secret: 'identity_secret',
	shared_secret: 'shared_secret',
	options: {
		trade: true|false,
		info: true|false,
		webapi_token: true|false
	}
}

*can_trade: steam bot with trade unlocked - bot used for trading
*can_info: steam bot with CS2 game played at least one time - bot used to load CS2 info, like itemswear
*can_webapi_token: steam bot with trade unlocked and with some cs2 skins in inventory (trash skins) - to check the players WebAPI Token, if is a valid one

*/

const steambots = [{
	active: false,
	botname: process.env.STEAMBOT1_NAME,
	steamid: process.env.STEAMBOT1_STEAMID,
	username: process.env.STEAMBOT1_USERNAME,
	password: process.env.STEAMBOT1_PASSWORD,
	identity_secret: process.env.STEAMBOT1_IDENTITY_SECRET,
	shared_secret: process.env.STEAMBOT1_SHARED_SECRET,
	options: {
		trade: true,
		info: true,
		webapi_token: true
	}
}];

module.exports = steambots;