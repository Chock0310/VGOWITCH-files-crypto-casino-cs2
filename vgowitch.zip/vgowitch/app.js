require('dotenv').config();
require('module-alias/register');

global.BASE_DIR = __dirname;

var fs = require('fs');
var http = require('http');
var https = require('https');
var { Server } = require('socket.io');
var sha256 = require('sha256');
var cookie = require('cookie');
var crypto = require('crypto');
var os = require('os');

var config = require('@/config/config.js');

var app = require('@/lib/app.js');

var { pool } = require('@/lib/database.js');
var { initializeSocket, emitSocketToUser, emitSocketToAll } = require('@/lib/socket.js');
var { initializeLogs, loggerWarn, loggerFatal, loggerDebug } = require('@/lib/logger.js');
var { usersRequests, usersOnline, usersFlooding } = require('@/lib/globals.js');

var { makeDate, time } = require('@/utils/formatDate.js');
var { roundedToFixed, getFormatAmount } = require('@/utils/formatAmount.js');
var { haveRankPermission, calculateLevel } = require('@/utils/utils.js');

var chatService = (({ messages, ignoreList, usersChannels, initializeChat, loadChannel, loadCommands, checkMessage }) => ({ messages, ignoreList, usersChannels, initializeChat, loadChannel, loadCommands, checkMessage }))(require('@/services/chatService.js'));

var rewardsService = (({ getDailyCooldown, redeemDailyReward, redeemBindReward, redeemRefferalCode, createRefferalCode, redeemBonusCode, createBonusCode }) => ({ getDailyCooldown, redeemDailyReward, redeemBindReward, redeemRefferalCode, createRefferalCode, redeemBonusCode, createBonusCode }))(require('@/services/rewardsService.js'));
var affiliatesService = (({ collectRewards }) => ({ collectRewards }))(require('@/services/affiliatesService.js'));

var userService = (({ getUserTransactions, getUserDeposits, getUserWithdrawals, getUserRouletteHistory, getUserCrashHistory, getUserJackpotHistory, getUserCoinflipHistory, getUserDiceHistory, getUserUnboxingHistory, getUserCasebattleHistory, getUserUpgraderHistory, getUserTowerHistory, getUserMinesweeperHistory, getUserPlinkoHistory, getUserCasinoHistory, getUserInventory, getAffiliatesReferrals, getItemsInventory, sellItemInventory, sellAllInventory }) => ({ getUserTransactions, getUserDeposits, getUserWithdrawals, getUserRouletteHistory, getUserCrashHistory, getUserJackpotHistory, getUserCoinflipHistory, getUserDiceHistory, getUserUnboxingHistory, getUserCasebattleHistory, getUserUpgraderHistory, getUserTowerHistory, getUserMinesweeperHistory, getUserPlinkoHistory, getUserCasinoHistory, getUserInventory, getAffiliatesReferrals, getItemsInventory, sellItemInventory, sellAllInventory }))(require('@/services/userService.js'));
var accountService = (({ saveEmail, saveTradelink, saveWebapiToken, saveProfileSettings, applyDepositBonus, setExclusionAccount, removeSessionAccount, removeAllSessionsAccount, enableEmailVerification, activateEmailVerification, disableEmailVerification, enableAuthenticatorApp, activateAuthenticatorApp, disableAuthenticatorApp, manageAuthenticatorApp, generateCodesAuthenticatorApp, setTwofaPrimaryMethod, mutePlayer, sendTip, getAccountTransactions, getAccountDeposits, getAccountWithdrawals, getAccountRouletteHistory, getAccountCrashHistory, getAccountJackpotHistory, getAccountCoinflipHistory, getAccountDiceHistory, getAccountUnboxingHistory, getAccountCasebattleHistory, getAccountUpgraderHistory, getAccountTowerHistory, getAccountMinesweeperHistory, getAccountPlinkoHistory, getAccountCasinoHistory, getAccountInventory }) => ({ saveEmail, saveTradelink, saveWebapiToken, saveProfileSettings, applyDepositBonus, setExclusionAccount, removeSessionAccount, removeAllSessionsAccount, enableEmailVerification, activateEmailVerification, disableEmailVerification, enableAuthenticatorApp, activateAuthenticatorApp, disableAuthenticatorApp, manageAuthenticatorApp, generateCodesAuthenticatorApp, setTwofaPrimaryMethod, mutePlayer, sendTip, getAccountTransactions, getAccountDeposits, getAccountWithdrawals, getAccountRouletteHistory, getAccountCrashHistory, getAccountJackpotHistory, getAccountCoinflipHistory, getAccountDiceHistory, getAccountUnboxingHistory, getAccountCasebattleHistory, getAccountUpgraderHistory, getAccountTowerHistory, getAccountMinesweeperHistory, getAccountPlinkoHistory, getAccountCasinoHistory, getAccountInventory }))(require('@/services/accountService.js'));
var itemsService = (({ updating, initializeItems, addCallback }) => ({ updating, initializeItems, addCallback }))(require('@/services/itemsService.js'));
var historyService = (({ usersLive, initializeHistory, getHistory, getUserHistory }) => ({ usersLive, initializeHistory, getHistory, getUserHistory }))(require('@/services/historyService.js'));
var fairService = (({ getCombinedSeed, generateSaltHash, getRoll, regenerateServerSeed, changeClientSeed }) => ({ getCombinedSeed, generateSaltHash, getRoll, regenerateServerSeed, changeClientSeed }))(require('@/services/fairService.js'));
var supportService = (({ createRequest, replyRequest, closeRequest, getSupportRequests }) => ({ createRequest, replyRequest, closeRequest, getSupportRequests }))(require('@/services/supportService.js'));

var dailycasesService = (({ loadCases, getCases, getCase, openCase }) => ({ loadCases, getCases, getCase, openCase }))(require('@/services/dailycasesService.js'));
var rainService = (({ gameProperties, lastGame, totalBets, userBets, initializeGame, rollGame, joinGame, tipGame }) => ({ gameProperties, lastGame, totalBets, userBets, initializeGame, rollGame, joinGame, tipGame }))(require('@/services/rainService.js'));

var adminService = (({ updating, setMaintenance, setSettings, getUsers, removeUserBind, removeUserExclusion, removeUserSessions, banUserIp, unbanUserIp, setUserRank, editUserBalance, setUserRestriction, unsetUserRestriction, setAdminAccess, unsetAdminAccess, createTrackingLink, removeTrackingLink, createDepositBonus, removeDepositBonus, confirmWithdrawListing, cancelWithdrawListing, setManuallyWithdrawAmount,getCryptoWithdrawListings, getSteamWithdrawListings, getTrackingLinks, getDepositBonuses, getItems, createCase, createDailyCase, getCases, removeCase, removeDailyCase, showCase, showDailyCase, editCase, editDailyCase, getCategories, createCategory, editCategory, removeCategory, confirmGameBot, createGameBot, getGameBots, claimSupportRequest, releaseSupportRequest, changeDepartmentSupportRequest, replySupportRequest, closeSupportRequest, getSupportRequests }) => ({ updating, setMaintenance, setSettings, getUsers, removeUserBind, removeUserExclusion, removeUserSessions, banUserIp, unbanUserIp, setUserRank, editUserBalance, setUserRestriction, unsetUserRestriction, setAdminAccess, unsetAdminAccess, createTrackingLink, removeTrackingLink, createDepositBonus, removeDepositBonus, confirmWithdrawListing, cancelWithdrawListing, setManuallyWithdrawAmount,getCryptoWithdrawListings, getSteamWithdrawListings, getTrackingLinks, getDepositBonuses, getItems, createCase, createDailyCase, getCases, removeCase, removeDailyCase, showCase, showDailyCase, editCase, editDailyCase, getCategories, createCategory, editCategory, removeCategory, confirmGameBot, createGameBot, getGameBots, claimSupportRequest, releaseSupportRequest, changeDepartmentSupportRequest, replySupportRequest, closeSupportRequest, getSupportRequests }))(require('@/services/adminService.js'));
var dashboardService = (({ getAllStats, getAllGraphs, getGraph }) => ({ getAllStats, getAllGraphs, getGraph }))(require('@/services/dashboardService.js'));

var rouletteService = (({ lastGames, last100Games, lastRoll, gameSettings, totalBets, gameProperties, jackpotProperties, initializeGame, placeBet, getJackpotHistory, getJackpotWinners }) => ({ lastGames, last100Games, lastRoll, gameSettings, totalBets, gameProperties, jackpotProperties, initializeGame, placeBet, getJackpotHistory, getJackpotWinners }))(require('@/services/games/rouletteService.js'));
var crashService = (({ lastGames, gameSettings, totalBets, userBets, gameProperties, initializeGame, placeBet, cashoutBet }) => ({ lastGames, gameSettings, totalBets, userBets, gameProperties, initializeGame, placeBet, cashoutBet }))(require('@/services/games/crashService.js'));
var jackpotService = (({ lastGames, gameSettings, totalBets, userBets, gameProperties, gameColors, gameAvatars, initializeGame, placeBet }) => ({ lastGames, gameSettings, totalBets, userBets, gameProperties, gameColors, gameAvatars, initializeGame, placeBet }))(require('@/services/games/jackpotService.js'));
var coinflipService = (({ games, secure, loadGames, createGame, joinGame, getWinner }) => ({ games, secure, loadGames, createGame, joinGame, getWinner }))(require('@/services/games/coinflipService.js'));
var diceService = (({ gameCooldown, placeBet }) => ({ gameCooldown, placeBet }))(require('@/services/games/diceService.js'));
var unboxingService = (({ lastWinnings, cases, categories, gameCooldown, loadCases, getCases, getCategories, showSpinner, showCase, placeDemo, placeBet }) => ({ lastWinnings, cases, categories, gameCooldown, loadCases, getCases, getCategories, showSpinner, showCase, placeDemo, placeBet }))(require('@/services/games/unboxingService.js'));
var casebattleService = (({ cases, games, secure, stats, loadCases, loadStats, getWinners, getCases, sendEmoji, showGame, createGame, joinGame, leaveGame, getFinishedGames, getMyGames }) => ({ cases, games, secure, stats, loadCases, loadStats, getWinners, getCases, sendEmoji, showGame, createGame, joinGame, leaveGame, getFinishedGames, getMyGames }))(require('@/services/games/casebattleService.js'));
var upgraderService = (({ placeBet, getChance, getMyItems, getSiteItems }) => ({ placeBet, getChance, getMyItems, getSiteItems }))(require('@/services/games/upgraderService.js'));
var minesweeperService = (({ games, placeBet, cashoutBet, checkBomb, loadGames, generateAmounts }) => ({ games, placeBet, cashoutBet, checkBomb, loadGames, generateAmounts }))(require('@/services/games/minesweeperService.js'));
var towerService = (({ games, placeBet, cashoutBet, checkStage, loadGames, generateAmounts }) => ({ games, placeBet, cashoutBet, checkStage, loadGames, generateAmounts }))(require('@/services/games/towerService.js'));
var plinkoService = (({ gameCooldown, generateAmounts, placeBet }) => ({ gameCooldown, generateAmounts, placeBet }))(require('@/services/games/plinkoService.js'));
var casinoService = (({ initializeCasino, getSlotsGames, getLiveGames, getFavoritesGames, getAllGames, setFavoriteGame, unsetFavoriteGame, getLaunchGameDemo, getLaunchGameReal }) => ({ initializeCasino, getSlotsGames, getLiveGames, getFavoritesGames, getAllGames, setFavoriteGame, unsetFavoriteGame, getLaunchGameDemo, getLaunchGameReal }))(require('@/services/games/casinoService.js'));

var pricesService = (({ updating, initializePrices }) => ({ updating, initializePrices }))(require('@/services/trading/pricesService.js'));
var botsService = (({ initializeBots, addReadyCallbacks, addTradeCallbacks, addOfferCallbacks, addConfirmationCallbacks }) => ({ initializeBots, addReadyCallbacks, addTradeCallbacks, addOfferCallbacks, addConfirmationCallbacks }))(require('@/services/trading/botsService.js'));

var steamService = (({ initializeTrades, loadOffers, offerStateChanged, offerConfirmationAccepted, getBots, getPendings, loadShopItems, placeDeposit, loadUserInventory, placeWithdraw, loadShopInventory }) => ({ initializeTrades, loadOffers, offerStateChanged, offerConfirmationAccepted, getBots, getPendings, loadShopItems, placeDeposit, loadUserInventory, placeWithdraw, loadShopInventory }))(require('@/services/trading/steamService.js'));
var p2pService = (({ getPendings, initializeListings, startTrackingListings, getListings, placeDeposit, cancelDeposit, loadUserInventory, placeWithdraw, confirmWithdraw }) => ({ getPendings, initializeListings, startTrackingListings, getListings, placeDeposit, cancelDeposit, loadUserInventory, placeWithdraw, confirmWithdraw }))(require('@/services/trading/p2pService.js'));
var cryptoService = (({ amounts, fees, updating, initializeCurrencies, placeDeposit, placeWithdraw }) => ({ amounts, fees, updating, initializeCurrencies, placeDeposit, placeWithdraw }))(require('@/services/trading/cryptoService.js'));

process.on('uncaughtException', function (error) {
	loggerFatal(error);
});

var server;

if (config.app.secure) {
    server = https.createServer({
        cert: fs.readFileSync(config.app.ssl.certificate),
        key: fs.readFileSync(config.app.ssl.private_key)
    }, app);
} else {
    server = http.createServer(app);
}

var io = new Server(server, {
    transports: [ 'polling' ],
    cors: {
        origin: config.app.secure ? config.app.url : '*',
        allowedHeaders: config.app.secure ? ['Access-Control-Allow-Origin'] : [],
        credentials: config.app.secure,
        methods: [ 'GET', 'POST' ]
    }
});

server.listen(config.app.port, function(){
    loggerDebug('[SERVER] Server running on port ' + config.app.port);
});

setInterval(function(){
    var heapUsed = process.memoryUsage().heapUsed / 1000000;

    loggerWarn('[SERVER] Memory usage: ' + heapUsed.toFixed(2) + 'MB');
    loggerWarn('[SERVER] CPU load: ' + os.loadavg()[0].toFixed(2) + '%');
}, 1 * 60 * 1000);

initializeLogs();

initializeSocket(io);

chatService.initializeChat();

rainService.initializeGame();

itemsService.addCallback(unboxingService.loadCases);
itemsService.addCallback(casebattleService.loadCases);
itemsService.addCallback(dailycasesService.loadCases);
itemsService.initializeItems();

historyService.initializeHistory();

rouletteService.initializeGame();
crashService.initializeGame();
jackpotService.initializeGame();
coinflipService.loadGames();
casebattleService.loadStats();
minesweeperService.loadGames();
towerService.loadGames();
casinoService.initializeCasino();

pricesService.initializePrices();

botsService.addTradeCallbacks(steamService.initializeTrades);
botsService.addReadyCallbacks(steamService.loadOffers);
botsService.addOfferCallbacks(steamService.offerStateChanged);
botsService.addConfirmationCallbacks(steamService.offerConfirmationAccepted);
botsService.initializeBots();

steamService.loadShopItems();

p2pService.initializeListings();
p2pService.startTrackingListings();

cryptoService.initializeCurrencies();

io.on('connection', function(socket) {
    var user = null;
	var channel = null;
	var paths = [];

    var agent = socket.request.headers['user-agent'];
    var device = crypto.createHash('sha256').update(agent).digest('hex');

    var cookies = cookie.parse(socket.request.headers.cookie || '');
    var { session } = cookies;

	socket.on('join', function(join_data) {
		channel = join_data.channel;
		paths = join_data.paths;

		if(paths.length <= 0) {
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'Your page is now inactive. Please refresh the page!'
			});
		}

		if(!config.app.chat.channels.includes(channel)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'Your page is now inactive. Please refresh the page!'
			});
		}

        pool.query('SELECT users.*, users_sessions.session FROM `users` INNER JOIN `users_sessions` ON users.userid = users_sessions.userid WHERE users_sessions.session = ' + pool.escape(session) + ' AND users_sessions.device = ' + pool.escape(device) + ' AND users_sessions.removed = 0 AND users_sessions.expire > ' + pool.escape(time()), function (err1, row1) {
            if(err1) {
                return emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while fetching user data (1)'
                });
            }

            pool.query('SELECT * FROM `maintenance` WHERE `removed` = 0', function(err2, row2) {
                if(err2) {
                    return emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while fetching user data (2)'
                    });
                }

                if(row1.length > 0){
                    user = {
                        bot: 0,
                        guest: 0,
                        userid: row1[0].userid,
                        name: row1[0]['anonymous'] == 1 ? '[anonymous]' : row1[0].name,
                        avatar: row1[0]['anonymous'] == 1 ? 'http://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg' : row1[0].avatar,
                        balance: roundedToFixed(row1[0].balance, 2),
                        rank: row1[0].rank,
                        xp: row1[0].xp,
                        tradelink: row1[0].tradelink,
                        webapi_token: row1[0].webapi_token,
                        email: row1[0].email,
                        rollover: roundedToFixed(row1[0].rollover, 2),
                        binds: {},
                        settings: {
                            'anonymous': row1[0]['anonymous'],
                            'private': row1[0]['private']
                        },
                        restrictions: {
                            play: 0,
                            trade: 0,
                            site: 0,
                            mute: 0
                        },
                        exclusion: row1[0]['exclusion']
                    };
                } else {
                    user = {
                        bot: 0,
                        guest: 1,
                        userid: socket.id,
                        name: 'Guest',
                        avatar: 'http://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg',
                        balance: 0,
                        rank: 0,
                        xp: 0,
                        tradelink: null,
                        webapi_token: null,
                        email: null,
                        rollover: 0,
                        binds: {},
                        settings: {
                            'anonymous': 0,
                            'private': 0
                        },
                        restrictions: {},
                        exclusion: 0
                    };
                }

                //USERS ONLINE
                if(usersOnline[channel] === undefined) usersOnline[channel] = {};
                if(usersOnline[channel][user.userid] === undefined) usersOnline[channel][user.userid] = {
                    count: 0,
                    guest: user.guest,
                    paths: paths,
                    user: {
                        userid: user.userid,
                        name: user.name,
                        avatar: user.avatar,
                        level: calculateLevel(user.xp).level,
                        rank: user.rank
                    }
                };

                usersOnline[channel][user.userid].count++;

                //USERS REQUESTS
                if(usersRequests[user.userid] === undefined) usersRequests[user.userid] = {};

                var hrtime = process.hrtime();
                var nanotime = hrtime[0] * 1000000000 + hrtime[1];

                //USERS FLOOD
                if(usersFlooding[user.userid] === undefined) usersFlooding[user.userid] = { time: nanotime, count: 0};

                //USER ROOM
                socket.join(user.userid);

                //DEVICE ROOM
                socket.join(device);

                var excludes_pages = [ 'unboxing', 'account' ];

                //PAGE ROOM
                if(excludes_pages.includes(paths[0])) socket.join(paths[0]);
                else {
                    //CASE BATTLE ROOM
                    if(paths[0] == 'casebattle') socket.join(paths[0]);

                    //DEPOSIT/WITHDRAW PATHS ROOM
                    if((paths[0] == 'deposit' || paths[0] == 'withdraw') && (paths[1] == 'steam' || paths[1] == 'p2p') && paths.length == 3) socket.join([ ...paths, ...[ user.userid ] ].join('/'));

                    //PAGE PATHS ROOM
                    socket.join(paths.join('/'));
                }

                if(row1.length > 0) loggerWarn('[SERVER] User with userid ' + user.userid + ' is connected on page /' + paths.join('/'));
                else loggerWarn('[SERVER] Guest with socketid ' + socket.id + ' is connected on page /' + paths.join('/'));

                //CHAT ROOM
                socket.join('chat_channel_' + channel);
                chatService.usersChannels[socket.id] = channel;

                //CASE BATTLE
                var user_casebattleBets = [];

                for(var bet in casebattleService.games){
                    if(!casebattleService.games[bet].privacy){
                        var casebattle_data = {};

                        casebattle_data.game = {};

                        if(casebattleService.games[bet].status == 3) {
                            casebattle_data.countdown = config.games.games.casebattle.timer_countdown;
                        } else if(casebattleService.games[bet].status == 4) {
                            casebattle_data.round = casebattleService.games[bet].round;
                        } else if(casebattleService.games[bet].status == 6) {
                            var winners_positions_all = casebattleService.getWinners(casebattleService.games[bet].players, casebattleService.games[bet].mode, casebattleService.games[bet].crazy);

                            var seed = fairService.getCombinedSeed(casebattleService.games[bet].game.server_seed, casebattleService.games[bet].draw.public_seed, casebattleService.games[bet].id);
                            var salt = fairService.generateSaltHash(seed);

                            var roll = fairService.getRoll(salt, winners_positions_all.length);

                            casebattle_data.winners = winners_positions_all.filter(a => a.position == roll)[0].winners;
                        }

                        user_casebattleBets.push({
                            status: casebattleService.games[bet].status,
                            casebattle: {
                                id: bet,
                                players: casebattleService.games[bet].players,
                                mode: casebattleService.games[bet].mode,
                                cases: casebattleService.games[bet].cases,
                                amount: casebattleService.games[bet].amount,
                                free: casebattleService.games[bet].free,
                                crazy: casebattleService.games[bet].crazy,
                                time: casebattleService.games[bet].time,
                                data: casebattle_data
                            }
                        });
                    }
                }

                //GAMES AMOUNTS
                var games_intervalAmounts = {};

                Object.keys(config.settings.games.games.original).forEach(function(item){
                    if(config.app.intervals.amounts[item] !== undefined) games_intervalAmounts[item] = config.app.intervals.amounts[item];
                });

                games_intervalAmounts['tip_player'] = config.app.intervals.amounts['tip_player'];
                games_intervalAmounts['tip_rain'] = config.app.intervals.amounts['tip_rain'];
                games_intervalAmounts['withdraw_crypto'] = config.app.intervals.amounts['withdraw_crypto'];

                var maintenance = row2.length > 0 && !haveRankPermission('access_maintenance', user.rank);

                var socket_return = {
                    maintenance: maintenance
                };

                if(!maintenance){
                    socket_return['amounts'] = games_intervalAmounts;

                    socket_return['user'] = {
                        userid: user.userid,
                        name: user.name,
                        balances: [
                            { type: 'main', balance: getFormatAmount(user.balance) }
                        ],
                        rank: user.rank,
                        settings: user.settings,
                        level: calculateLevel(user.xp)
                    };

                    socket_return['chat'] = {
                        messages: [ ...(chatService.messages[channel] || []), ...[{
                            type: 'system',
                            message: config.app.chat.greeting.message,
                            time: time()
                        }] ],
                        listignore: (chatService.ignoreList[user.userid] === undefined) ? [] : Object.keys(chatService.ignoreList[user.userid])
                    };

                    socket_return['offers'] = {
                        p2p_pendings: p2pService.getPendings(user.userid),
                        steam_pendings: steamService.getPendings(user.userid)
                    };

                    var game_enabled = false;

                    if(config.settings.games.games.original[paths[0]] !== undefined) {
                        if(config.settings.games.games.original[paths[0]].enable) game_enabled = true;
                    } else if(config.settings.games.games.classic[paths[0]] !== undefined) {
                        if(config.settings.games.games.classic[paths[0]].enable) game_enabled = true;
                    }

                    if(haveRankPermission('play_disabled', user.rank)) game_enabled = true;

                    if(paths[0] == 'admin' && paths[1] == 'casecreator' && ((paths[2] == 'edit' && paths.length > 4) || paths[2] == 'create')) {
                        socket_return['admin'] = {
                            casecreator: {
                                categories: Object.values(unboxingService.categories)
                            }
                        };
                    }

                    if(paths[0] == 'roulette' && game_enabled) {
                        socket_return['roulette'] = {
                            bets: rouletteService.totalBets,
                            totals: Object.keys(config.games.games.roulette.multipliers).reduce((acc, cur) => ({
                                ...acc, [cur]: {
                                    amount: rouletteService.totalBets.filter(a => a.color == cur).reduce((acc, cur) => getFormatAmount(acc + cur.amount), 0),
                                    count: rouletteService.totalBets.filter(a => a.color == cur).length
                                }
                            }), {}),
                            last: rouletteService.lastRoll,
                            history: rouletteService.lastGames,
                            hundred: Object.keys(config.games.games.roulette.multipliers).reduce((acc, cur) => ({
                                ...acc, [cur]: rouletteService.last100Games.filter(a => a.color == cur).length
                            }), {}),
                            info: {
                                id: rouletteService.gameProperties.id,
                                public_seed: rouletteService.gameProperties.public_seed
                            },
                            jackpot: {
                                total: rouletteService.jackpotProperties.amount,
                                greens: rouletteService.jackpotProperties.greens.last
                            }
                        };
                    } else if(paths[0] == 'crash' && game_enabled) {
                        socket_return['crash'] = {
                            history: crashService.lastGames,
                            bets: crashService.totalBets.map(a => ({
                                id: a.id,
                                user: a.user,
                                amount: a.amount,
                                cashedout: crashService.userBets[a.user.userid].cashedout,
                                ended: crashService.gameProperties.status == 'ended',
                                at: crashService.userBets[a.user.userid].cashedout ? roundedToFixed(crashService.userBets[a.user.userid].point / 100, 2) : null,
                                profit: crashService.userBets[a.user.userid].cashedout ? getFormatAmount(crashService.userBets[a.user.userid].amount * crashService.userBets[a.user.userid].point / 100 - crashService.userBets[a.user.userid].amount) : null
                            })),
                            info: {
                                id: crashService.gameProperties.id,
                                public_seed: crashService.gameProperties.public_seed
                            }
                        };
                    } else if(paths[0] == 'jackpot' && game_enabled) {
                        socket_return['jackpot'] = {
                            fair: {
                                server_seed_hashed: sha256(jackpotService.gameProperties.server_seed),
                                nonce: jackpotService.gameProperties.id,
                                server_seed: jackpotService.gameProperties.status == 'rolling' ? jackpotService.gameProperties.server_seed : null,
                                public_seed: jackpotService.gameProperties.status == 'rolling' ? jackpotService.gameProperties.public_seed : null,
                                block: jackpotService.gameProperties.status == 'eos' || jackpotService.gameProperties.status == 'rolling' ? jackpotService.gameProperties.block : null
                            },
                            avatars: jackpotService.gameAvatars,
                            bets: jackpotService.totalBets,
                            total: getFormatAmount(jackpotService.totalBets.reduce((acc, cur) => acc + cur.amount, 0)),
                            chance: jackpotService.userBets[user.userid] !== undefined && jackpotService.userBets[user.userid].total > 0 ? roundedToFixed(jackpotService.userBets[user.userid].amount / getFormatAmount(jackpotService.totalBets.reduce((acc, cur) => acc + cur.amount, 0)) * 100, 2) : 0,
                            history: jackpotService.lastGames
                        };
                    } else if(paths[0] == 'coinflip' && game_enabled) {
                        socket_return['coinflip'] = {
                            bets: Object.keys(coinflipService.games).map(function(bet){
                                var coinflip_data = {};

                                coinflip_data.game = {
                                    server_seed_hashed: sha256(coinflipService.games[bet].game.server_seed),
                                    nonce: bet
                                };

                                if(coinflipService.games[bet].status == 1) {
                                    coinflip_data.time = config.games.games.coinflip.timer_wait_start - time() + coinflipService.games[bet].time
                                } else if(coinflipService.games[bet].status == 2) {
                                    coinflip_data.game.block = coinflipService.games[bet].game.block;
                                } else if(coinflipService.games[bet].status == 3) {
                                    coinflip_data.winner = coinflipService.getWinner(bet);

                                    coinflip_data.game.block = coinflipService.games[bet].game.block;
                                } else if(coinflipService.games[bet].status == 4) {
                                    coinflip_data.winner = coinflipService.getWinner(bet);

                                    coinflip_data.game.server_seed = coinflipService.games[bet].game.server_seed;
                                    coinflip_data.game.public_seed = coinflipService.games[bet].game.public_seed;
                                    coinflip_data.game.block = coinflipService.games[bet].game.block;
                                }

                                return {
                                    status: coinflipService.games[bet].status,
                                    coinflip: {
                                        id: bet,
                                        players: coinflipService.games[bet].players,
                                        amount: coinflipService.games[bet].amount,
                                        data: coinflip_data
                                    }
                                };
                            })
                        };
                    } else if(paths[0] == 'dice' && game_enabled) {
                        socket_return['dice'] = {};
                    } else if(paths[0] == 'unboxing' && game_enabled) {
                        socket_return['unboxing'] = {
                            cases: unboxingService.getCases(),
                            categories: unboxingService.getCategories(),
                            history: unboxingService.lastWinnings
                        };
                    } else if(paths[0] == 'upgrader' && game_enabled) {
                        socket_return['upgrader'] = {};
                    } else if(paths[0] == 'casebattle' && game_enabled) {
                        socket_return['casebattle'] = {
                            bets: user_casebattleBets,
                            stats: casebattleService.stats
                        };
                    } else if(paths[0] == 'minesweeper' && game_enabled) {
                        socket_return['minesweeper'] = {
                            game: {
                                active: minesweeperService.games[user.userid] !== undefined,
                                total: minesweeperService.games[user.userid] !== undefined ? (minesweeperService.games[user.userid]['route'].length == 0 ? minesweeperService.games[user.userid]['amount'] : getFormatAmount(minesweeperService.generateAmounts(minesweeperService.games[user.userid]['amount'], minesweeperService.games[user.userid]['bombs'])[minesweeperService.games[user.userid]['route'].length - 1])) : 0,
                                profit: minesweeperService.games[user.userid] !== undefined ? (minesweeperService.games[user.userid]['route'].length == 0 ? 0 : getFormatAmount(getFormatAmount(minesweeperService.generateAmounts(minesweeperService.games[user.userid]['amount'], minesweeperService.games[user.userid]['bombs'])[minesweeperService.games[user.userid]['route'].length - 1]) - minesweeperService.games[user.userid]['amount'])) : 0,
                                route: minesweeperService.games[user.userid] !== undefined ? minesweeperService.games[user.userid]['route'] : [],
                                amount: minesweeperService.games[user.userid] !== undefined ? minesweeperService.games[user.userid]['amount'] : 0,
                                multipliers: minesweeperService.games[user.userid] !== undefined ? config.games.games.minesweeper.multipliers[minesweeperService.games[user.userid]['bombs']].slice(0, minesweeperService.games[user.userid]['route'].length) : [],

                            }
                        };
                    } else if(paths[0] == 'tower' && game_enabled) {
                        socket_return['tower'] = {
                            game: {
                                active: towerService.games[user.userid] !== undefined,
                                difficulty: towerService.games[user.userid] !== undefined ? towerService.games[user.userid]['difficulty'] : 'medium',
                                total: towerService.games[user.userid] !== undefined ? (towerService.games[user.userid]['route'].length == 0 ? towerService.games[user.userid]['amount'] : getFormatAmount(towerService.generateAmounts(towerService.games[user.userid]['amount'], towerService.games[user.userid]['difficulty'])[towerService.games[user.userid]['route'].length - 1])) : 0,
                                profit: towerService.games[user.userid] !== undefined ? ((towerService.games[user.userid]['route'].length == 0) ? 0 : getFormatAmount(getFormatAmount(towerService.generateAmounts(towerService.games[user.userid]['amount'], towerService.games[user.userid]['difficulty'])[towerService.games[user.userid]['route'].length - 1]) - towerService.games[user.userid]['amount'])) : 0,
                                route: towerService.games[user.userid] !== undefined ? towerService.games[user.userid]['route'] : [],
                                amount: towerService.games[user.userid] !== undefined ? towerService.games[user.userid]['amount'] : 0
                            },
                            multipliers: config.games.games.tower.multipliers
                        };
                    } else if(paths[0] == 'plinko' && game_enabled) {
                        socket_return['plinko'] = {
                            multipliers: plinkoService.generateAmounts()
                        };
                    } else if(paths[0] == 'casino' && game_enabled) {

                    } else if(paths[0] == 'deposit' || paths[0] == 'withdraw') {
                        if(paths[1] == 'crypto') {
                            socket_return['offers']['crypto'] = {
                                amounts: cryptoService.amounts,
                                fees: cryptoService.fees
                            };
                        } else if(paths[0] == 'withdraw' && paths[1] == 'steam') {
                            socket_return['offers']['steam_bots'] = steamService.getBots();
                        }
                    }
                }

                //FIRST DATES
                emitSocketToUser(socket, 'site', 'connected', socket_return);

                if(!maintenance){
                    if(paths[0] == 'roulette') dRoulette(user, socket);
                    else if(paths[0] == 'crash') dCrash(user, socket);
                    else if(paths[0] == 'jackpot') dJackpot(user, socket);

                    dRain(user, socket);

                    rewardsService.getDailyCooldown(user, socket);

                    historyService.getUserHistory(user, socket, join_data.history, paths[0]);

                    //USERS ONLINE
                    emitSocketToAll('site', 'online', {
                        online: config.app.chat.channels.reduce((acc, cur) => ({ ...acc, [cur]: Object.keys(usersOnline[cur] || {}).length }), {})
                    });
                }
            });
        });
	});

	socket.on('request', function(request) {
		if(!user) {
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'Your page is now inactive. Please refresh the page!'
			});
		}

		if(adminService.updating.value){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server settings are updating. Please try again later!'
			});
		}

		var hrtime = process.hrtime();
		var nanotime = hrtime[0] * 1000000000 + hrtime[1];

		if(nanotime - usersFlooding[user.userid].time >= config.app.flood.time) {
            usersFlooding[user.userid].time = nanotime;
            usersFlooding[user.userid].count = 1;
        } else usersFlooding[user.userid].count++;

		if(usersFlooding[user.userid].count >= config.app.flood.count) {
			loggerWarn('[SERVER] User with userid ' + user.userid + ' is disconnected for flooding');

			socket_disconnect(user, socket, channel, device, paths);

            user = null;

            return;
		}

		if(usersRequests[user.userid][[ request.type, request.command ].join('_')] !== undefined){
			loggerWarn(user.name + '(' + user.userid + ') - Duplicated request: ' + JSON.stringify(request));

            return emitSocketToUser(socket, 'message', 'error', {
				message: 'Wait for ending last action!'
			});
		}

		pool.query('SELECT * FROM `maintenance` WHERE `removed` = 0', function(err1, row1) {
			if(err1) {
                return emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while fetching user data (3)'
                });
            }

            pool.query('SELECT users.*, users_sessions.session FROM `users` INNER JOIN `users_sessions` ON users.userid = users_sessions.userid WHERE users_sessions.session = ' + pool.escape(session) + ' AND users_sessions.device = ' + pool.escape(device) + ' AND users_sessions.removed = 0 AND users_sessions.expire > ' + pool.escape(time()), function (err2, row2) {
                if(err2) {
                    return emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while fetching user data (4)'
                    });
                }

				if(row1.length > 0 && !haveRankPermission('access_maintenance', row2.length > 0 ? row2[0].rank : 0)){
					return emitSocketToUser(socket, 'message', 'error', {
						message: 'The server is now in maintenance. Please try again later!'
					});
				}

				if(row2.length <= 0) return userRequest_request(user, socket, request, device, false);

				pool.query('SELECT * FROM `bannedip` WHERE `ip` = ' + pool.escape(socket.client.request.headers['x-forwarded-for'] || socket.request.connection.remoteAddress) + ' AND `removed` = 0', function(err3, row3) {
					if(err3) {
                        return emitSocketToUser(socket, 'message', 'error', {
                            message: 'An error occurred while fetching user data (5)'
                        });
                    }

					if(row3.length > 0 && !haveRankPermission('exclude_ban_ip', row2[0].rank)){
						return emitSocketToUser(socket, 'message', 'error', {
							message: 'Your IP is banned.'
						});
					}

					pool.query('SELECT `restriction`, `expire` FROM `users_restrictions` WHERE `removed` = 0 AND (`expire` = -1 OR `expire` > ' + pool.escape(time()) + ') AND `userid` = '+ pool.escape(row2[0].userid), function(err4, row4){
						if(err4) {
                            return emitSocketToUser(socket, 'message', 'error', {
                                message: 'An error occurred while fetching user data (6)'
                            });
                        }

						user = {
							bot: 0,
							guest: 0,
							userid: row2[0].userid,
							name: row2[0]['anonymous'] == 1 ? '[anonymous]' : row2[0].name,
							avatar: row2[0]['anonymous'] == 1 ? 'http://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg' : row2[0].avatar,
							balance: roundedToFixed(row2[0].balance, 2),
							rank: row2[0].rank,
							xp: row2[0].xp,
							tradelink: row2[0].tradelink,
							webapi_token: row2[0].webapi_token,
							email: row2[0].email,
							rollover: roundedToFixed(row2[0].rollover, 2),
							binds: {},
							settings: {
								'anonymous': row2[0]['anonymous'],
								'private': row2[0]['private']
							},
							restrictions: {
								play: 0,
								trade: 0,
								site: 0,
								mute: 0
							},
							exclusion: row2[0]['exclusion']
						};

						row4.forEach(function(item){
							if(user.restrictions[item.restriction] !== undefined) user.restrictions[item.restriction] = item.expire;
						});

						if((user.restrictions.site >= time() || user.restrictions.site == -1) && !haveRankPermission('exclude_ban_site', user.rank)){
							return emitSocketToUser(socket, 'message', 'error', {
								message: 'You are restricted to use our site. The restriction expires ' + ((user.restrictions.site == -1) ? 'never' : makeDate(new Date(user.restrictions.site * 1000))) + '.'
							});
						}

						pool.query('SELECT `bind`, `bindid` FROM `users_binds` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `removed` = 0', function(err5, row5) {
							if(err5) {
                                return emitSocketToUser(socket, 'message', 'error', {
                                    message: 'An error occurred while fetching user data (7)'
                                });
                            }

                            if(!user) {
                                return emitSocketToUser(socket, 'message', 'error', {
                                    message: 'Your page is now inactive. Please refresh the page!'
                                });
                            }

							row5.forEach(function(bind){
								if(Object.keys(config.settings.server.binds).filter(key => config.settings.server.binds[key] == true).includes(bind.bind)) user.binds[bind.bind] = bind.bindid;
							});

							return userRequest_request(user, socket, request, device, true);
						});
					});
				});
			});
		});
	});

	socket.on('disconnect', function() {
		socket_disconnect(user, socket, channel, device, paths);

        user = null;
	});
});

function socket_disconnect(user, socket, channel, device, paths){
	socket.disconnect();

    if(!user) return;

	//USER ROOM
	socket.leave(user.userid);

    //DEVICE ROOM
    socket.join(device);

	var allowed_page = [ 'unboxing', 'profile', 'admin' ];

	//PAGE ROOM
	if(allowed_page.includes(paths[0])) socket.leave(paths[0]);
	else {
		//CASE BATTLE ROOM
		if(paths[0] == 'casebattle') socket.leave(paths[0]);

		//DEPOSIT/WITHDRAW PATHS ROOM
		if((paths[0] == 'deposit' || paths[0] == 'deposit') && paths.length == 3) socket.leave([ ...paths, ...[ user.userid ] ].join('/'));

		//PAGE PATHS ROOM
		socket.leave(paths.join('/'));
	}

	//HISTORY ROOM
	if(historyService.usersLive[user.userid] !== undefined) {
		socket.leave(historyService.usersLive[user.userid]);

		delete historyService.usersLive[user.userid];
	}

	//CHAT CHANNEL ROOM
	if(chatService.usersChannels[socket.id] !== undefined) {
		socket.leave(chatService.usersChannels[socket.id]);

		delete chatService.usersChannels[socket.id];
	}

	//USERS ONLINE
	if(usersOnline[channel] !== undefined){
		if(usersOnline[channel][user.userid] !== undefined) {
			usersOnline[channel][user.userid].count--;

			if(usersOnline[channel][user.userid].count <= 0) {
				delete usersOnline[channel][user.userid];
				if(Object.keys(usersOnline[channel]).length <= 0) delete usersOnline[channel];

				emitSocketToAll('site', 'online', {
					online: config.app.chat.channels.reduce((acc, cur) => ({ ...acc, [cur]: Object.keys(usersOnline[cur] || {}).length }), {})
				});
			}
		}
	}
}

function userRequest_cooldown(userid, action, value, games, request){
	if(usersRequests[userid][action] !== undefined) {
        clearTimeout(usersRequests[userid][action]);
        delete usersRequests[userid][action];
    }

    if(value){
        if(action == 'dice_bet') diceService.gameCooldown[userid] = true;
		if(action == 'unboxing_open') unboxingService.gameCooldown[userid] = true;
		if(action == 'plinko_bet') plinkoService.gameCooldown[userid] = true;

        usersRequests[userid][action] = setTimeout(function(){
            clearTimeout(usersRequests[userid][action]);
            delete usersRequests[userid][action];

            if(action == 'dice_bet') diceService.gameCooldown[userid] = false;
            if(action == 'unboxing_open') unboxingService.gameCooldown[userid] = false;
            if(action == 'plinko_bet') plinkoService.gameCooldown[userid] = false;

            if(action == 'coinflip_join') {
                if(coinflipService.secure[request.id] !== undefined && coinflipService.secure[request.id][userid] !== undefined) delete coinflipService.secure[request.id][userid];
            } else if(action == 'casebattle_join') {
                if(casebattleService.secure[request.id] !== undefined && casebattleService.secure[request.id][request.position] !== undefined && casebattleService.secure[request.id][request.position][userid] !== undefined) delete casebattleService.secure[request.id][request.position][userid];
            }

            loggerWarn('[SERVER] Old request not finished for Userid: ' + userid + ' | Action: ' + action);
        }, 10 * 1000)
	} else {
        if(games){
            if(action == 'dice_bet') diceService.gameCooldown[userid] = false;
            if(action == 'unboxing_open') unboxingService.gameCooldown[userid] = false;
            if(action == 'plinko_bet') plinkoService.gameCooldown[userid] = false;
        }

		if(action == 'coinflip_join') {
			if(coinflipService.secure[request.id] !== undefined && coinflipService.secure[request.id][userid] !== undefined) delete coinflipService.secure[request.id][userid];
		} else if(action == 'casebattle_join') {
			if(casebattleService.secure[request.id] !== undefined && casebattleService.secure[request.id][request.position] !== undefined && casebattleService.secure[request.id][request.position][userid] !== undefined) delete casebattleService.secure[request.id][request.position][userid];
		}
	}
}

function userRequest_request(user, socket, request, device, logged){
    if(!user) {
        return emitSocketToUser(socket, 'message', 'error', {
            message: 'Your page is now inactive. Please refresh the page!'
        });
    }

	if(request) loggerWarn(user.name + '(' + user.userid + ') - New request: ' + JSON.stringify(request));

	function request_cooldown(value, urgent){
		userRequest_cooldown(user.userid, [ request.type, request.command ].join('_'), value, urgent, request);
	}

	//ACCOUNT REQUESTS
	if(request.type == 'account') {
        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'save_email') return accountService.saveEmail(user, socket, request.email, request.recaptcha, device, request_cooldown);
		if(request.command == 'save_tradelink') return accountService.saveTradelink(user, socket, request.tradelink, request.recaptcha, request_cooldown);
		if(request.command == 'save_webapi_token') return accountService.saveWebapiToken(user, socket, request.webapi_token, request.recaptcha, request_cooldown);

		if(request.command == 'tip') return accountService.sendTip(user, socket, request.userid, request.amount, request.recaptcha, request_cooldown);
		if(request.command == 'mute') return accountService.mutePlayer(user, socket, request.userid, request.time, request.reason, request_cooldown);

		if(request.command == 'deposit_bonus') return accountService.applyDepositBonus(user, socket, request.code, request.recaptcha, request_cooldown);
		if(request.command == 'profile_settings') return accountService.saveProfileSettings(user, socket, request.data, request_cooldown);
		if(request.command == 'exclusion') return accountService.setExclusionAccount(user, socket, request.exclusion, request.recaptcha, request_cooldown);
		if(request.command == 'remove_session') return accountService.removeSessionAccount(user, socket, request.session, device, request_cooldown);
		if(request.command == 'remove_sessions') return accountService.removeAllSessionsAccount(user, socket, device, request_cooldown);

        if(request.command == 'enable_email_verification') return accountService.enableEmailVerification(user, socket, device, request_cooldown);
        if(request.command == 'activate_email_verification') return accountService.activateEmailVerification(user, socket, request.code, device, request_cooldown);
        if(request.command == 'disable_email_verification') return accountService.disableEmailVerification(user, socket, device, request_cooldown);

        if(request.command == 'enable_authenticator_app') return accountService.enableAuthenticatorApp(user, socket, device, request_cooldown);
        if(request.command == 'activate_authenticator_app') return accountService.activateAuthenticatorApp(user, socket, request.token, device, request_cooldown);
        if(request.command == 'disable_authenticator_app') return accountService.disableAuthenticatorApp(user, socket, device, request_cooldown);
        if(request.command == 'manage_authenticator_app') return accountService.manageAuthenticatorApp(user, socket, device, request_cooldown);
        if(request.command == 'generate_codes_authenticator_app') return accountService.generateCodesAuthenticatorApp(user, socket, device, request_cooldown);

        if(request.command == 'twofa_primary_method') return accountService.setTwofaPrimaryMethod(user, socket, request.method, device, request_cooldown);

        /* END REQUESTS FOR USERS */
    }

	//REWARDS REQUESTS
	if(request.type == 'rewards'){
		if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

        if(user.exclusion > time()) {
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'
			});
		}

		if(request.command == 'bind') return rewardsService.redeemBindReward(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'referral_redeem') return rewardsService.redeemRefferalCode(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'referral_create') return rewardsService.createRefferalCode(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'bonus_redeem') return rewardsService.redeemBonusCode(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'bonus_create') return rewardsService.createBonusCode(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'daily_redeem') return rewardsService.redeemDailyReward(user, socket, request.recaptcha, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//AFFILIATES REQUESTS
	if(request.type == 'affiliates') {
        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'collect') return affiliatesService.collectRewards(user, socket, request.recaptcha, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//HISTORY REQUESTS
	if(request.type == 'history') {
        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR GUESTS */

		if(request.command == 'get') return historyService.getHistory(user, socket, request.history, request.game, request_cooldown);

        /* END REQUESTS FOR GUESTS */
	}

	//CHAT REQUESTS
	if(request.type == 'chat') {
        /* REQUESTS FOR GUESTS */

		if(request.command == 'channel') return chatService.loadChannel(user, socket, request.channel, request_cooldown);
		if(request.command == 'commands') return chatService.loadCommands(user, socket, request.message, request_cooldown);

        /* END REQUESTS FOR GUESTS */

        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'message') return chatService.checkMessage(user, socket, request.message, request.channel, request.reply, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//RAIN REQUESTS
	if(request.type == 'rain') {
        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'join') return rainService.joinGame(user, socket, request.recaptcha, request_cooldown);
		if(request.command == 'tip') return rainService.tipGame(user, socket, request.amount, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//FAIR REQUESTS
	if(request.type == 'fair') {
        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'save_clientseed') return fairService.changeClientSeed(user, socket, request.seed, request.recaptcha, request_cooldown);
		if(request.command == 'regenerate_serverseed') return fairService.regenerateServerSeed(user, socket, request.recaptcha, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//SUPPORT REQUESTS
	if(request.type == 'support') {
        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'create') return supportService.createRequest(user, socket, request.subject, request.department, request.message, request_cooldown);
		if(request.command == 'reply') return supportService.replyRequest(user, socket, request.id, request.message, request_cooldown);
		if(request.command == 'close') return supportService.closeRequest(user, socket, request.id, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//DAILY CASES REQUESTS
	if(request.type == 'dailycases') {
		if(itemsService.updating.value){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server items prices are updating. Please try again later!'
			});
		}

        /* REQUESTS FOR GUESTS */

        if(request.command == 'cases') return dailycasesService.getCases(user, socket, request_cooldown);
		if(request.command == 'get') return dailycasesService.getCase(user, socket, request.id, request_cooldown);

        /* END REQUESTS FOR GUESTS */

        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'open') return dailycasesService.openCase(user, socket, request.id, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//INVENTORY REQUESTS
	if(request.type == 'inventory') {
		if(itemsService.updating.value){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server items prices are updating. Please try again later!'
			});
		}

        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'sell_item') return userService.sellItemInventory(user, socket, request.id, request_cooldown);
		if(request.command == 'sell_all') return userService.sellAllInventory(user, socket, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//GAME BOTS REQUESTS
	if(request.type == 'gamebots') {
        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'confirm') return adminService.confirmGameBot(user, socket, request.userid, request.game, request.data, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//DASHBOARD REQUESTS
	if(request.type == 'dashboard') {
        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'graph') return dashboardService.getGraph(user, socket, request.graph, request_cooldown);
		if(request.command == 'graphs') return dashboardService.getAllGraphs(user, socket, request.graphs, request_cooldown);
		if(request.command == 'stats') return dashboardService.getAllStats(user, socket, request.stats, request_cooldown);

        /* END REQUESTS FOR USERS */
	}

	//ADMIN REQUESTS
	if(request.type == 'admin') {
		if(itemsService.updating.value && (request.command == 'casecreator_create' || request.command == 'casecreator_remove' || request.command == 'casecreator_cases' || request.command == 'casecreator_get' || request.command == 'casecreator_edit')){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server items prices are updating. Please try again later!'
			});
		}

        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

		if(request.command == 'maintenance') return adminService.setMaintenance(user, socket, request.status, request.reason, request.secret, request_cooldown);
		if(request.command == 'settings') return adminService.setSettings(user, socket, request.settings, request.status, request_cooldown);
		if(request.command == 'remove_bind') return adminService.removeUserBind(user, socket, request.userid, request.bind, request.secret, request_cooldown);
		if(request.command == 'remove_exclusion') return adminService.removeUserExclusion(user, socket, request.userid, request.secret, request_cooldown);
		if(request.command == 'remove_sessions') return adminService.removeUserSessions(user, socket, request.userid, request.secret, request_cooldown);
		if(request.command == 'ban_ip') return adminService.banUserIp(user, socket, request.userid, request.ip, request.secret, request_cooldown);
		if(request.command == 'unban_ip') return adminService.unbanUserIp(user, socket, request.userid, request.ip, request.secret, request_cooldown);
		if(request.command == 'set_rank') return adminService.setUserRank(user, socket, request.userid, request.rank, request.secret, request_cooldown);
		if(request.command == 'edit_balance') return adminService.editUserBalance(user, socket, request.userid, request.amount, request.secret, request_cooldown);
		if(request.command == 'set_restriction') return adminService.setUserRestriction(user, socket, request.userid, request.restriction, request.time, request.reason, request.secret, request_cooldown);
		if(request.command == 'unset_restriction') return adminService.unsetUserRestriction(user, socket, request.userid, request.restriction, request.secret, request_cooldown);
		if(request.command == 'tracking_links_create') return adminService.createTrackingLink(user, socket, request.expire, request.usage, request.secret, request_cooldown);
		if(request.command == 'tracking_links_remove') return adminService.removeTrackingLink(user, socket, request.id, request.secret, request_cooldown);

		if(request.command == 'deposit_bonuses_create') return adminService.createDepositBonus(user, socket, request.referral, request.code, request.secret, request_cooldown);
		if(request.command == 'deposit_bonuses_remove') return adminService.removeDepositBonus(user, socket, request.id, request.secret, request_cooldown);

		if(request.command == 'payment_confirm') return adminService.confirmWithdrawListing(user, socket, request.method, request.trade, request.secret, request_cooldown);
		if(request.command == 'payment_cancel') return adminService.cancelWithdrawListing(user, socket, request.method, request.trade, request.secret, request_cooldown);
		if(request.command == 'payments_manually_amount') return adminService.setManuallyWithdrawAmount(user, socket, request.amount, request.secret, request_cooldown);

		if(request.command == 'admin_access_set') return adminService.setAdminAccess(user, socket, request.userid, request.secret, request_cooldown);
		if(request.command == 'admin_access_unset') return adminService.unsetAdminAccess(user, socket, request.userid, request.secret, request_cooldown);

		if(request.command == 'casecreator_create') {
			if(request.creator == 'cases') return adminService.createCase(user, socket, request.name, request.image, request.items, request.data, request.secret, request_cooldown);
			if(request.creator == 'dailycases') return adminService.createDailyCase(user, socket, request.name, request.image, request.items, request.data, request.secret, request_cooldown);
		}

		if(request.command == 'casecreator_remove') {
			if(request.creator == 'cases') return adminService.removeCase(user, socket, request.id, request.secret, request_cooldown);
			if(request.creator == 'dailycases') return adminService.removeDailyCase(user, socket, request.id, request.secret, request_cooldown);
		}

		if(request.command == 'casecreator_cases') return adminService.getCases(user, socket, request.creator, request_cooldown);

		if(request.command == 'casecreator_get') {
			if(request.creator == 'cases') return adminService.showCase(user, socket, request.id, request_cooldown);
			if(request.creator == 'dailycases') return adminService.showDailyCase(user, socket, request.id, request_cooldown);
		}

		if(request.command == 'casecreator_edit') {
			if(request.creator == 'cases') return adminService.editCase(user, socket, request.id, request.name, request.image, request.items, request.data, request.secret, request_cooldown);
			if(request.creator == 'dailycases') return adminService.editDailyCase(user, socket, request.id, request.name, request.image, request.items, request.data, request.secret, request_cooldown);
		}

		if(request.command == 'casecreator_categories_list') return adminService.getCategories(user, socket, request_cooldown);
		if(request.command == 'casecreator_categories_create') return adminService.createCategory(user, socket, request.name, request.secret, request_cooldown);
		if(request.command == 'casecreator_categories_edit') return adminService.editCategory(user, socket, request.id, request.visible, request_cooldown);
		if(request.command == 'casecreator_categories_remove') return adminService.removeCategory(user, socket, request.id, request.secret, request_cooldown);

		if(request.command == 'gamebots_create') return adminService.createGameBot(user, socket, request.name, request.secret, request_cooldown);

        if(request.command == 'support_claim') return adminService.claimSupportRequest(user, socket, request.id, request.secret, request_cooldown);
        if(request.command == 'support_release') return adminService.releaseSupportRequest(user, socket, request.id, request.secret, request_cooldown);
        if(request.command == 'support_change_department') return adminService.changeDepartmentSupportRequest(user, socket, request.id, request.department, request.secret, request_cooldown);
        if(request.command == 'support_reply') return adminService.replySupportRequest(user, socket, request.id, request.message, request.secret, request_cooldown);
        if(request.command == 'support_close') return adminService.closeSupportRequest(user, socket, request.id, request.secret, request_cooldown);

        /* END REQUESTS FOR USERS */
    }

	//PAGINATION REQUESTS
	if(request.type == 'pagination') {
		if(itemsService.updating.value && (request.command == 'account_inventory' || request.command == 'user_inventory' || request.command == 'inventory_items' || request.command == 'casecreator_items' || request.command == 'upgrader_myitems' || request.command == 'upgrader_siteitems')){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server items prices are updating. Please try again later!'
			});
		}

        /* REQUESTS FOR GUESTS */

        if(request.command == 'user_inventory') return userService.getUserInventory(user, socket, request.page, request.order, request.game, request.search, request.userid, request_cooldown);

        if(request.command == 'affiliates_referrals') return userService.getAffiliatesReferrals(user, socket, request.page, request_cooldown);

        if(request.command == 'inventory_items') return userService.getItemsInventory(user, socket, request.page, request_cooldown);

        if(request.command == 'upgrader_myitems') return upgraderService.getMyItems(user, socket, request.page, request.order, request.game, request_cooldown);
		if(request.command == 'upgrader_siteitems') return upgraderService.getSiteItems(user, socket, request.page, request.order, request.search, request.items, request.amount, request.multiplier, request_cooldown);

        if(request.command == 'casino_slots_games') return casinoService.getSlotsGames(user, socket, request.page, request.order, request.provider, request.search, request_cooldown);
        if(request.command == 'casino_live_games') return casinoService.getLiveGames(user, socket, request.page, request.order, request.provider, request.search, request_cooldown);
        if(request.command == 'casino_favorites_games') return casinoService.getFavoritesGames(user, socket, request.page, request.order, request.provider, request.search, request_cooldown);
        if(request.command == 'casino_all_games') return casinoService.getAllGames(user, socket, request.page, request.search, request_cooldown);

		/* END REQUESTS FOR GUESTS */

        if(!logged) {
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });
        }

        /* REQUESTS FOR USERS */

        if(request.command == 'admin_users') return adminService.getUsers(user, socket, request.page, request.order, request.search, request_cooldown);
		if(request.command == 'admin_crypto_confirmations') return adminService.getCryptoWithdrawListings(user, socket, request.page, request_cooldown);
		if(request.command == 'admin_steam_confirmations') return adminService.getSteamWithdrawListings(user, socket, request.page, request_cooldown);
		if(request.command == 'admin_tracking_links') return adminService.getTrackingLinks(user, socket, request.page, request.search, request_cooldown);
		if(request.command == 'admin_deposit_bonuses') return adminService.getDepositBonuses(user, socket, request.page, request.search, request_cooldown);
		if(request.command == 'admin_gamebots') return adminService.getGameBots(user, socket, request.page, request.order, request.search, request_cooldown);
        if(request.command == 'admin_support_requests') return adminService.getSupportRequests(user, socket, request.page, request.status, request.department, request.search, request_cooldown);

		if(request.command == 'account_transactions') return accountService.getAccountTransactions(user, socket, request.page, request_cooldown);
		if(request.command == 'account_deposits') return accountService.getAccountDeposits(user, socket, request.page, request_cooldown);
		if(request.command == 'account_withdrawals') return accountService.getAccountWithdrawals(user, socket, request.page, request_cooldown);
        if(request.command == 'account_roulette_history') return accountService.getAccountRouletteHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_crash_history') return accountService.getAccountCrashHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_jackpot_history') return accountService.getAccountJackpotHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_coinflip_history') return accountService.getAccountCoinflipHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_dice_history') return accountService.getAccountDiceHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_unboxing_history') return accountService.getAccountUnboxingHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_casebattle_history') return accountService.getAccountCasebattleHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_upgrader_history') return accountService.getAccountUpgraderHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_tower_history') return accountService.getAccountTowerHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_minesweeper_history') return accountService.getAccountMinesweeperHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_plinko_history') return accountService.getAccountPlinkoHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_casino_history') return accountService.getAccountCasinoHistory(user, socket, request.page, request_cooldown);
        if(request.command == 'account_inventory') return accountService.getAccountInventory(user, socket, request.page, request.order, request.game, request.search, request_cooldown);

        if(request.command == 'user_transactions') return userService.getUserTransactions(user, socket, request.page, request.userid, request_cooldown);
		if(request.command == 'user_deposits') return userService.getUserDeposits(user, socket, request.page, request.userid, request_cooldown);
		if(request.command == 'user_withdrawals') return userService.getUserWithdrawals(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_roulette_history') return userService.getUserRouletteHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_crash_history') return userService.getUserCrashHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_jackpot_history') return userService.getUserJackpotHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_coinflip_history') return userService.getUserCoinflipHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_dice_history') return userService.getUserDiceHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_unboxing_history') return userService.getUserUnboxingHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_casebattle_history') return userService.getUserCasebattleHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_upgrader_history') return userService.getUserUpgraderHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_tower_history') return userService.getUserTowerHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_minesweeper_history') return userService.getUserMinesweeperHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_plinko_history') return userService.getUserPlinkoHistory(user, socket, request.page, request.userid, request_cooldown);
        if(request.command == 'user_casino_history') return userService.getUserCasinoHistory(user, socket, request.page, request.userid, request_cooldown);

		if(request.command == 'casecreator_items') return adminService.getItems(user, socket, request.page, request.order, request.game, request.search, request_cooldown);

        if(request.command == 'support_requests') return supportService.getSupportRequests(user, socket, request.page, request.status, request.search, request_cooldown);

        /* END REQUESTS FOR USERS */
    }

	//ORIGINAL GAMES REQUESTS
	if(config.settings.games.games.original[request.type] !== undefined){
		if(!config.settings.games.games.original[request.type].enable && !haveRankPermission('play_disabled', user.rank)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'This game is offline. Please try again later!'
			});
		}

        /* REQUESTS FOR GUESTS */

        if(request.type == 'roulette') {
			if(request.command == 'jackpot_history') return rouletteService.getJackpotHistory(user, socket, request_cooldown);
			if(request.command == 'jackpot_winners') return rouletteService.getJackpotWinners(user, socket, request.id, request_cooldown);
		}

        if(request.type == 'unboxing') {
			if(request.command == 'show') return unboxingService.showCase(user, socket, request.id, request_cooldown);
			if(request.command == 'spinner') return unboxingService.showSpinner(user, socket, request.id, request.amount, request_cooldown);
		}

        if(request.type == 'casebattle') {
			if(itemsService.updating.value){
				return emitSocketToUser(socket, 'message', 'error', {
					message: 'The server items prices are updating. Please try again later!'
				});
			}

			if(request.command == 'finished') return casebattleService.getFinishedGames(user, socket, request_cooldown);
			if(request.command == 'my') return casebattleService.getMyGames(user, socket, request_cooldown);

			if(request.command == 'cases') return casebattleService.getCases(user, socket, request_cooldown);
			if(request.command == 'show') return casebattleService.showGame(user, socket, request.id, request_cooldown);
		}

        /* END REQUESTS FOR GUESTS */

		if(!logged) {
            emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });

            return emitSocketToUser(socket, 'modal', 'auth');
        }

        /* REQUESTS FOR USERS */

		if(request.type == 'casebattle') {
			if(request.command == 'emoji') return casebattleService.sendEmoji(user, socket, request.id, request.position, request.emoji, request_cooldown);

			if(itemsService.updating.value){
				return emitSocketToUser(socket, 'message', 'error', {
					message: 'The server items prices are updating. Please try again later!'
				});
			}
		}

        if(request.type == 'upgrader') {
			if(itemsService.updating.value){
				return emitSocketToUser(socket, 'message', 'error', {
					message: 'The server items prices are updating. Please try again later!'
				});
			}

			if(request.command == 'chance') return upgraderService.getChance(user, socket, request.myitems, request.siteitems, request.amount, request_cooldown);
		}

        if(!config.settings.games.status && !haveRankPermission('play_offline', user.rank)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server bets is now offline. Please try again later!'
			});
		}

		if((user.restrictions.play >= time() || user.restrictions.play == -1) && !haveRankPermission('exclude_ban_play', user.rank)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'You are restricted to use our games. The restriction expires ' + ((user.restrictions.play == -1) ? 'never' : makeDate(new Date(user.restrictions.play * 1000))) + '.'
			});
		}

		if(user.exclusion > time()) {
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'
			});
		}

        if(request.type == 'roulette') {
			if(request.command == 'bet') return rouletteService.placeBet(user, socket, request.amount, request.color, request_cooldown);
		}

		if(request.type == 'crash') {
			if(request.command == 'bet') return crashService.placeBet(user, socket, request.amount, request.auto, request_cooldown);
			if(request.command == 'cashout') return crashService.cashoutBet(user, socket, request_cooldown);
		}

		if(request.type == 'jackpot') {
			if(request.command == 'bet') return jackpotService.placeBet(user, socket, request.amount, request_cooldown);
		}

		if(request.type == 'coinflip') {
			if(request.command == 'create') return coinflipService.createGame(user, socket, request.amount, request.position, request_cooldown);
			if(request.command == 'join') return coinflipService.joinGame(user, socket, request.id, request_cooldown);
		}

		if(request.type == 'dice') {
			if(request.command == 'bet') return diceService.placeBet(user, socket, request.amount, request.chance, request.mode, request_cooldown);
		}

		if(request.type == 'unboxing') {
			if(itemsService.updating.value){
				return emitSocketToUser(socket, 'message', 'error', {
					message: 'The server items prices are updating. Please try again later!'
				});
			}

			if(request.command == 'demo') return unboxingService.placeDemo(user, socket, request.id, request.amount, request_cooldown);
		    if(request.command == 'open') return unboxingService.placeBet(user, socket, request.id, request.amount, request_cooldown);
		}

		if(request.type == 'casebattle') {
			if(request.command == 'leave') return casebattleService.leaveGame(user, socket, request.id, request.position, request_cooldown);

			if(itemsService.updating.value){
				return emitSocketToUser(socket, 'message', 'error', {
					message: 'The server items prices are updating. Please try again later!'
				});
			}

			if(request.command == 'create') return casebattleService.createGame(user, socket, request.cases, request.mode, request.privacy, request.free, request.crazy, request_cooldown);
			if(request.command == 'join') return casebattleService.joinGame(user, socket, request.id, request.position, request_cooldown);
		}

		if(request.type == 'upgrader') {
			if(itemsService.updating.value){
				return emitSocketToUser(socket, 'message', 'error', {
					message: 'The server items prices are updating. Please try again later!'
				});
			}

			if(request.command == 'bet') return upgraderService.placeBet(user, socket, request.myitems, request.siteitems, request.amount, request.game, request_cooldown);
		}

		if(request.type == 'minesweeper') {
			if(request.command == 'bet') return minesweeperService.placeBet(user, socket, request.amount, request.bombs, request_cooldown);
			if(request.command == 'cashout') return minesweeperService.cashoutBet(user, socket, request_cooldown);
			if(request.command == 'bomb') return minesweeperService.checkBomb(user, socket, request.bomb, request_cooldown);
		}

		if(request.type == 'tower') {
			if(request.command == 'bet') return towerService.placeBet(user, socket, request.amount, request.difficulty, request_cooldown);
			if(request.command == 'cashout') return towerService.cashoutBet(user, socket, request_cooldown);
			if(request.command == 'stage') return towerService.checkStage(user, socket, request.stage, request.button, request_cooldown);
		}

		if(request.type == 'plinko') {
			if(request.command == 'bet') return plinkoService.placeBet(user, socket, request.amount, request.difficulty, request.rows, request_cooldown);
		}

        /* END REQUESTS FOR USERS */
	}

    //CLASSIC GAMES REQUESTS
	if(config.settings.games.games.classic[request.type] !== undefined){
        if(!config.settings.games.games.classic[request.type].enable && !haveRankPermission('play_disabled', user.rank)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'This game is offline. Please try again later!'
			});
		}

        /* REQUESTS FOR GUESTS */

        if(request.type == 'casino') {
			if(request.command == 'launch_demo') return casinoService.getLaunchGameDemo(user, socket, request.id, request_cooldown);
		}

        /* END REQUESTS FOR GUESTS */

		if(!logged) {
            emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });

            return emitSocketToUser(socket, 'modal', 'auth');
        }

        /* REQUESTS FOR USERS */

        if(!config.settings.games.status && !haveRankPermission('play_offline', user.rank)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server bets is now offline. Please try again later!'
			});
		}

		if((user.restrictions.play >= time() || user.restrictions.play == -1) && !haveRankPermission('exclude_ban_play', user.rank)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'You are restricted to use our games. The restriction expires ' + ((user.restrictions.play == -1) ? 'never' : makeDate(new Date(user.restrictions.play * 1000))) + '.'
			});
		}

		if(user.exclusion > time()) {
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'
			});
		}

		if(request.type == 'casino') {
			if(request.command == 'set_favorite') return casinoService.setFavoriteGame(user, socket, request.id, request_cooldown);
			if(request.command == 'unset_favorite') return casinoService.unsetFavoriteGame(user, socket, request.id, request_cooldown);

            if(request.command == 'launch_real') return casinoService.getLaunchGameReal(user, socket, request.id, request_cooldown);
		}

        /* END REQUESTS FOR USERS */
    }

	//STEAM PAYMENTS REQUESTS
    if(request.type == 'steam'){
        var deposit_requests = [ 'load_inventory', 'deposit' ];
        var withdraw_requests = [ 'load_shop', 'withdraw' ];

        if(deposit_requests.includes(request.command) && (config.settings.payments.methods.steam[request.game].enable.deposit === undefined || (!config.settings.payments.methods.steam[request.game].enable.deposit && !haveRankPermission('trade_disabled', user.rank)))){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'This Steam deposit method is offline. Please try again later!'
            });
        }

        if(withdraw_requests.includes(request.command) && (config.settings.payments.methods.steam[request.game].enable.withdraw === undefined || (!config.settings.payments.methods.steam[request.game].enable.withdraw && !haveRankPermission('trade_disabled', user.rank)))){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'This Steam withdraw method is offline. Please try again later!'
            });
        }

        if(pricesService.updating.value){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'The steam items prices are updating. Please try again later!'
            });
        }

        /* REQUESTS FOR GUESTS */

        if(request.command == 'load_shop') return steamService.loadShopInventory(user, socket, 'steam', request.game, config.trading.steam.withdraw_offset, request_cooldown);

        /* END REQUESTS FOR GUESTS */

        if(!logged) {
            emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });

            return emitSocketToUser(socket, 'modal', 'auth');
        }

        /* REQUESTS FOR USERS */

        if(request.command == 'load_inventory') return steamService.loadUserInventory(user, socket, 'steam', request.game, config.trading.steam.deposit_offset, request_cooldown);

        if(!config.settings.payments.status && !haveRankPermission('trade_offline', user.rank)){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'The server trades is now offline. Try again later!'
            });
        }

        if(request.command == 'deposit') return steamService.placeDeposit(user, socket, request.game, request.items, request.refill, request.recaptcha, request_cooldown);
        if(request.command == 'withdraw') return steamService.placeWithdraw(user, socket, request.game, request.items, request.bot, request.recaptcha, request_cooldown);

        /* END REQUESTS FOR USERS */
    }

    //P2P PAYMENTS REQUESTS
    if(request.type == 'p2p'){
        var deposit_requests = [ 'create_listing', 'load_inventory' ];
        var withdraw_requests = [ 'load_shop' ];

        if(deposit_requests.includes(request.command) && (config.settings.payments.methods.p2p[request.game].enable.deposit === undefined || (!config.settings.payments.methods.p2p[request.game].enable.deposit && !haveRankPermission('trade_disabled', user.rank)))){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'This P2P deposit method is offline. Please try again later!'
            });
        }

        if(withdraw_requests.includes(request.command) && (config.settings.payments.methods.p2p[request.game].enable.withdraw === undefined || (!config.settings.payments.methods.p2p[request.game].enable.withdraw && !haveRankPermission('trade_disabled', user.rank)))){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'This P2P withdraw method is offline. Please try again later!'
            });
        }

        if(pricesService.updating.value){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The steam items prices are updating. Please try again later!'
			});
		}

        /* REQUESTS FOR GUESTS */

        if(request.command == 'load_shop') return p2pService.getListings(user, socket, request.game, request_cooldown);

        /* END REQUESTS FOR GUESTS */

        if(!logged) {
            emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });

            return emitSocketToUser(socket, 'modal', 'auth');
        }

        /* REQUESTS FOR USERS */

        if(request.command == 'load_inventory') return p2pService.loadUserInventory(user, socket, 'p2p', request.game, 0, request_cooldown);

        if(!config.settings.payments.status && !haveRankPermission('trade_offline', user.rank)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server trades is now offline. Try again later!'
			});
		}

        if(request.command == 'create_listing') return p2pService.placeDeposit(user, socket, request.items, request.offset, request.game, request.recaptcha, request_cooldown);
        if(request.command == 'cancel_listing') return p2pService.cancelDeposit(user, socket, request.id, request.recaptcha, request_cooldown);
        if(request.command == 'buy_listing') return p2pService.placeWithdraw(user, socket, request.id, request.recaptcha, request_cooldown);
        if(request.command == 'confirm_listing') return p2pService.confirmWithdraw(user, socket, request.id, request.recaptcha, request_cooldown);

        /* END REQUESTS FOR USERS */
    }

    //CRYPTO PAYMENTS REQUESTS
    if(request.type == 'crypto') {
        var deposit_requests = [ 'deposit' ];
        var withdraw_requests = [ 'withdraw' ];

        if(deposit_requests.includes(request.command) && (config.settings.payments.methods.crypto[request.currency].enable.deposit === undefined || (!config.settings.payments.methods.crypto[request.currency].enable.deposit && !haveRankPermission('trade_disabled', user.rank)))){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'This Crypto deposit method is offline. Please try again later!'
            });
        }

        if(withdraw_requests.includes(request.command) && (config.settings.payments.methods.crypto[request.currency].enable.withdraw === undefined || (!config.settings.payments.methods.crypto[request.currency].enable.withdraw && !haveRankPermission('trade_disabled', user.rank)))){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'This Crypto withdraw method is offline. Please try again later!'
            });
        }

        if(!logged) {
            emitSocketToUser(socket, 'message', 'error', {
                message: 'Session expired or you are not logged in. Please refresh the page and try again.'
            });

            return emitSocketToUser(socket, 'modal', 'auth');
        }

        if(!config.settings.payments.status && !haveRankPermission('trade_offline', user.rank)){
			return emitSocketToUser(socket, 'message', 'error', {
				message: 'The server trades is now offline. Try again later!'
			});
		}

        if(cryptoService.updating.value){
            return emitSocketToUser(socket, 'message', 'error', {
                message: 'The crypto currencies prices are updating. Please try again later!'
            });
        }

        /* REQUESTS FOR USERS */

        if(request.command == 'deposit') return cryptoService.placeDeposit(user, socket, request.currency, request.value, request_cooldown);
        if(request.command == 'withdraw') return cryptoService.placeWithdraw(user, socket, request.currency, request.amount, request.address, request.recaptcha, request_cooldown);

        /* END REQUESTS FOR USERS */
    }

	emitSocketToUser(socket, 'message', 'error', {
		message: 'This is a invalid request! Please refresh the page.'
	});
}

function dRain(user, socket){
	if(rainService.gameProperties.status == 'waiting') {
		emitSocketToUser(socket, 'rain', 'waiting', {
			last: rainService.lastGame.value,
			amount: rainService.gameProperties.amount
		});
	} else if(rainService.gameProperties.status == 'started'){
		emitSocketToUser(socket, 'rain', 'started', {
			time: config.app.rain.cooldown_start + rainService.gameProperties.roll - time(),
			cooldown: config.app.rain.cooldown_start,
			amount: rainService.gameProperties.amount,
			joined: rainService.userBets[user.userid] !== undefined && rainService.userBets[user.userid] >= 1
		});
	} else {
		emitSocketToUser(socket, 'rain', 'started', {
			time: 0,
			cooldown: config.app.rain.cooldown_start,
			amount: rainService.gameProperties.amount,
			joined: rainService.userBets[user.userid] !== undefined && rainService.userBets[user.userid] >= 1
		});
	}
}

function dJackpot(user, socket){
	if(jackpotService.gameProperties.status == 'rolling'){
		emitSocketToUser(socket, 'jackpot', 'roll', {
			avatars: jackpotService.gameSettings.avatars_rolling,
			cooldown: new Date().getTime() - jackpotService.gameSettings.start_time
		});

	} else if(jackpotService.gameProperties.status == 'picking'){
		emitSocketToUser(socket, 'jackpot', 'picking');
	}
}

function dRoulette(user, socket){
	if(rouletteService.gameProperties.status == 'rolling' || rouletteService.gameProperties.status == 'jackpot' || rouletteService.gameProperties.status == 'ended'){
		var colors = [];

		if(rouletteService.gameProperties.roll == 0) colors.push('green');
		else if(rouletteService.gameProperties.roll >= 1 && rouletteService.gameProperties.roll <= 7) colors.push('red');
		else if(rouletteService.gameProperties.roll >= 8 && rouletteService.gameProperties.roll <= 14) colors.push('black');

		if(rouletteService.gameProperties.roll == 4 || rouletteService.gameProperties.roll == 11) colors.push('bait');

		emitSocketToUser(socket, 'roulette', 'timer', {
			time: 0,
			cooldown: config.games.games.roulette.cooldown_rolling
		});

		emitSocketToUser(socket, 'roulette', 'roll', {
			roll: {
				id: rouletteService.gameProperties.id,
				roll: rouletteService.gameProperties.roll,
				colors: colors,
				progress: rouletteService.gameProperties.progress
			},
			greens: rouletteService.jackpotProperties.greens.actual,
			cooldown: config.games.games.roulette.cooldown_rolling - rouletteService.gameSettings.timer - 3
		});
	} else {
		if(rouletteService.gameSettings.timer - config.games.games.roulette.cooldown_rolling >= 0){
			emitSocketToUser(socket, 'roulette', 'timer', {
				time: rouletteService.gameSettings.timer - config.games.games.roulette.cooldown_rolling,
				cooldown: config.games.games.roulette.timer
			});
		}
	}
}

function dCrash(user, socket){
	if(crashService.gameProperties.status == 'started'){
		emitSocketToUser(socket, 'crash', 'starting', {
			time: (crashService.gameSettings.start_time > 0) ? Math.floor(config.games.games.crash.timer * 1000 - new Date().getTime() + crashService.gameSettings.start_time) : Math.floor(config.games.games.crash.timer * 1000),
			total: (crashService.userBets[user.userid] !== undefined) ? crashService.userBets[user.userid]['amount'] : 0,
			profit: 0
		});
	} else if(crashService.gameProperties.status == 'counting'){
		emitSocketToUser(socket, 'crash', 'started', {
			difference: new Date().getTime() - crashService.gameSettings.progress_time
		});

		if(crashService.userBets[user.userid] !== undefined){
			if(crashService.userBets[user.userid]['cashedout'] == true){
				var winning = getFormatAmount(crashService.userBets[user.userid]['amount'] * crashService.userBets[user.userid]['point'] / 100);

				emitSocketToUser(socket, 'crash', 'cashed_out', {
					total: winning,
					profit: getFormatAmount(winning - crashService.userBets[user.userid]['amount'])
				});
			}
		}
	} else if(crashService.gameProperties.status == 'ended'){
		var winners = [];
		for(var bet of crashService.totalBets) {
			if(crashService.userBets[bet.user.userid]['cashedout']) {
				winners.push(bet.user);
			}
		}

		if(crashService.userBets[user.userid] !== undefined){
			if(crashService.userBets[user.userid]['cashedout'] == true){
				var winning = getFormatAmount(crashService.userBets[user.userid]['amount'] * crashService.userBets[user.userid]['point'] / 100);

				emitSocketToUser(socket, 'crash', 'cashed_out', {
					total: winning,
					profit: getFormatAmount(winning - crashService.userBets[user.userid]['amount'])
				});
			}
		}

		emitSocketToUser(socket, 'crash', 'crashed', {
			number: crashService.gameProperties.roll,
			time: crashService.gameSettings.end_time,
			loaded: true,
			winners: winners.map(a => a.userid)
		});

		if(crashService.userBets[user.userid] !== undefined){
			if(crashService.userBets[user.userid]['cashedout'] == true){
				var winning = getFormatAmount(crashService.userBets[user.userid]['amount'] * crashService.userBets[user.userid]['point'] / 100);

				emitSocketToUser(socket, 'crash', 'cashed_out', {
					amount: winning,
					loaded: true
				});
			}
		}
	}
}