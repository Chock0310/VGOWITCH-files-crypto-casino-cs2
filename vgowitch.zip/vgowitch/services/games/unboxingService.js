var { pool } = require('@/lib/database.js');
var { emitSocketToUser, emitSocketToRoom } = require('@/lib/socket.js');
var { loggerDebug, loggerTrace, loggerInfo } = require('@/lib/logger.js');

var chatService = (({ writeSystemMessage }) => ({ writeSystemMessage }))(require('@/services/chatService.js'));
var userService = (({ updateBalance, updateLevel, getBalance, registerOriginalBet, finishOriginalBet }) => ({ updateBalance, updateLevel, getBalance, registerOriginalBet, finishOriginalBet }))(require('@/services/userService.js'));
var fairService = (({ getUserSeeds, getCombinedSeed, generateSaltHash, getRoll }) => ({ getUserSeeds, getCombinedSeed, generateSaltHash, getRoll }))(require('@/services/fairService.js'));

var { time } = require('@/utils/formatDate.js');
var { roundedToFixed, getFormatAmount, getFormatAmountString } = require('@/utils/formatAmount.js');
var { calculateLevel, getColorByQuality, getRandomInt, getAmountCommission, countDecimals } = require('@/utils/utils.js');

var itemsService = (({ items }) => ({ items }))(require('@/services/itemsService.js'));

var config = require('@/config/config.js');

var lastWinnings = [];

var cases = {};
var categories = {};

var gameCooldown = {};

var historyLoaded = false;
var categoriesLoaded = false;

/* ----- INTERNAL USAGE ----- */
function loadHistory(){
	if(historyLoaded) return;
	historyLoaded = true;

	loggerDebug('[UNBOXING] Loading History');

	pool.query('SELECT * FROM `unboxing_bets` ORDER BY `id` DESC LIMIT 20', function(err1, row1) {
		if(err1) return;

		if(row1.length <= 0) return;

        row1.reverse();

        row1.forEach(function(history){
            if(cases[history.caseid] !== undefined){
                var winning = JSON.parse(history.winning);

                if(winning.length > 0){
                    pool.query('SELECT `itemid` FROM `users_items` WHERE `id` = ' + pool.escape(winning[0].id), function(err2, row2) {
                        if(err2) return;

                        if(row2.length > 0) {
                            if(itemsService.items[row2[0].itemid] !== undefined){
                                if(cases[history.caseid].items.filter(a => a.id == row2[0].itemid).length > 0){
                                    lastWinnings.push({
                                        user:{
                                            userid: history.userid,
                                            name: history.name,
                                            avatar: history.avatar,
                                            level: calculateLevel(history.xp).level,
                                        },
                                        unboxing: {
                                            id: history.caseid,
                                            name: cases[history.caseid].name,
                                            image: cases[history.caseid].image,
                                            price: cases[history.caseid].price
                                        },
                                        winning: {
                                            name: itemsService.items[row2[0].itemid].name,
                                            image: itemsService.items[row2[0].itemid].image,
                                            price: getFormatAmount(itemsService.items[row2[0].itemid].price),
                                            chance: roundedToFixed(cases[history.caseid].items.filter(a => a.id == row2[0].itemid)[0].chance, 5),
                                            color: getColorByQuality(itemsService.items[row2[0].itemid].quality)
                                        }
                                    });
                                }
                            }
                        }
                    });
                }
            }
        });
	});
}

/* ----- INTERNAL USAGE ----- */
function loadCategories(){
	if(categoriesLoaded) return;
	categoriesLoaded = true;

	loggerDebug('[UNBOXING] Loading Categories');

	pool.query('SELECT * FROM `cases_categories` WHERE `removed` = 0', function(err1, row1) {
		if(err1) {
            loggerInfo('[UNBOXING] Error In Loading Categories');

            categoriesLoaded = false;

            return loadCategories();
        }

		if(row1.length <= 0) return;

		row1.forEach(function(item){
			categories[parseInt(item.id)] = {
				id: parseInt(item.id),
				name: item.name,
				visible: parseInt(item.visible)
			};
		});
	});
}

function loadCases(callback){
	loggerDebug('[UNBOXING] Loading Cases');

	pool.query('SELECT `caseid`, `category`, `name`, `image`, `items`, `game` FROM `cases_cases` WHERE `removed` = 0', function(err1, row1){
		if(err1) return callback(new Error('An error occurred while loading cases (1)'));

		row1.forEach(function(caseitem){
			var caseitems = JSON.parse(caseitem.items);

			var caseprice = 0;

			caseitems.forEach(function(item){
				var item_price = getFormatAmount(itemsService.items[item.id].price);

				caseprice += item_price * item.chance / 100;
			});

			caseprice = getFormatAmount(caseprice + getAmountCommission(caseprice, config.games.house_edge.unboxing));

			var item = {
				game: caseitem.game,
				name: caseitem.name,
				image: caseitem.image,
				price: caseprice,
				category: parseInt(caseitem.category),
				items: caseitems
			}

			cases[caseitem.caseid] = item;
		});

		loadHistory();
		loadCategories();

		callback(null);
	})
}

function getCases(){
	var list_cases = [];

	Object.keys(cases).filter(a => categories[cases[a].category] !== undefined && categories[cases[a].category].visible).forEach(function(id){
		list_cases.push({
			id: id,
			name: cases[id].name,
			image: cases[id].image,
			price: getFormatAmount(cases[id].price),
			category: cases[id].category
		});
	});

	list_cases.sort(function(a, b){ return a.price - b.price });

	return list_cases;
}

function getCategories(){
	return Object.values(categories).filter(a => a.visible).map(a => ({
		id: a.id,
		name: a.name
	}));
}

/* ----- INTERNAL USAGE ----- */
function getItems(items){
	var newitems = [];

	items.forEach(function(item){
		newitems.push({
			id: item.id,
			name: itemsService.items[item.id].name,
			image: itemsService.items[item.id].image,
			price: getFormatAmount(itemsService.items[item.id].price),
			chance: roundedToFixed(item.chance, 5),
			quality: itemsService.items[item.id].quality
		});
	});

	return newitems;
}

/* ----- CLIENT USAGE ----- */
function showSpinner(user, socket, id, amount, cooldown){
	cooldown(true, true);

	if(cases[id] === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	if(categories[cases[id].category] === undefined || categories[cases[id].category].visible == 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(amount))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid amount cases!'
		});

		return cooldown(false, true);
	}

	if(amount < config.games.games.unboxing.cases_length.min || amount > config.games.games.unboxing.cases_length.max){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid amount cases [' + config.games.games.unboxing.cases_length.min + '-' + config.games.games.unboxing.cases_length.max + ']!'
		});

		return cooldown(false, true);
	}

	amount = parseInt(amount);

	var caseitems = getItems(cases[id].items);
	var spinner = [];

	for(var i = 0; i < amount; i++) spinner.push(generateSpinner(caseitems));

	emitSocketToUser(socket, 'unboxing', 'spinner', {
		spinner: spinner
	});

	cooldown(false, false);
}

/* ----- CLIENT USAGE ----- */
function showCase(user, socket, id, cooldown){
	cooldown(true, true);

	if(cases[id] === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	if(categories[cases[id].category] === undefined || categories[cases[id].category].visible == 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	var caseitems = getItems(cases[id].items);

	var tickets = generateTickets(caseitems);
	var newitems = [];

	caseitems.forEach(function(item, index){
		newitems.push({
			name: item.name,
			image: item.image,
			price: getFormatAmount(item.price),
			chance: roundedToFixed(item.chance, 5),
			color: getColorByQuality(item.quality),
			tickets: tickets[index]
		});
	})

	emitSocketToUser(socket, 'unboxing', 'show', {
		items: newitems,
		unboxing: {
			id: id,
			name: cases[id].name,
			price: getFormatAmount(cases[id].price)
		}
	});

	cooldown(false, false);
}

/* ----- CLIENT USAGE ----- */
function placeDemo(user, socket, id, amount, cooldown){
	if(gameCooldown[user.userid]){
		return emitSocketToUser(socket, 'message', 'error', {
			message: 'Wait for ending last unboxing game!'
		});
	}

	cooldown(true, true);

	if(cases[id] === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	if(categories[cases[id].category] === undefined || categories[cases[id].category].visible == 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(amount))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid amount cases!'
		});

		return cooldown(false, true);
	}

	if(amount < config.games.games.unboxing.cases_length.min || amount > config.games.games.unboxing.cases_length.max){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid amount cases [' + config.games.games.unboxing.cases_length.min + '-' + config.games.games.unboxing.cases_length.max + ']!'
		});

		return cooldown(false, true);
	}

	amount = parseInt(amount);

	//SEEDS
	fairService.getUserSeeds(user.userid, function(err1, fair){
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			return cooldown(false, true);
		}

		testCase(user, fair, id, amount, 0, [], function(err2, data){
			if(err2) {
				emitSocketToUser(socket, 'message', 'error', {
                    message: err2.message
                });

				return cooldown(false, true);
			}

			emitSocketToUser(socket, 'unboxing', 'roll', {
				spinner: data.map(a => a.spinner)
			});

			setTimeout(function(){
				emitSocketToUser(socket, 'unboxing', 'finish');
			});

			cooldown(false, false);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function testCase(user, fair, id, amount, index, data, callback){
	if(index >= amount) return callback(null, data);

	var seed = fairService.getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce + index);
	var salt = fairService.generateSaltHash(seed);

	var caseitems = getItems(cases[id].items);

	var tickets = generateTickets(caseitems);
	var total = tickets[tickets.length - 1].max;

	var spinner = generateSpinner(caseitems);

	var roll = fairService.getRoll(salt, total) + 1;

	var winningitem = null;

	for(var i = 0; i < tickets.length; i++){
		if(roll >= tickets[i].min && roll <= tickets[i].max) {
			winningitem = {
				name: caseitems[i].name,
				image: caseitems[i].image,
				price: getFormatAmount(caseitems[i].price),
				chance: roundedToFixed(caseitems[i].chance, 5),
				color: getColorByQuality(caseitems[i].quality)
			};

			break;
		}
	}

	spinner[99] = winningitem;

	pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err1){
		if(err1) return callback(new Error('An error occurred while testing case (1)'));

		data.push({
			winning: winningitem,
			spinner: spinner
		});

		testCase(user, fair, id, amount, index + 1, data, callback);
	});
}

/* ----- CLIENT USAGE ----- */
function placeBet(user, socket, id, amount, cooldown){
	if(gameCooldown[user.userid]){
		return emitSocketToUser(socket, 'message', 'error', {
			message: 'Wait for ending last unboxing game!'
		});
	}

	cooldown(true, true);

	if(cases[id] === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	if(categories[cases[id].category] === undefined || categories[cases[id].category].visible == 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(amount))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid amount cases!'
		});

		return cooldown(false, true);
	}

	if(amount < config.games.games.unboxing.cases_length.min || amount > config.games.games.unboxing.cases_length.max){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid amount cases [' + config.games.games.unboxing.cases_length.min + '-' + config.games.games.unboxing.cases_length.max + ']!'
		});

		return cooldown(false, true);
	}

	amount = parseInt(amount);

	//SEEDS
	fairService.getUserSeeds(user.userid, function(err1, fair){
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			return cooldown(false, true);
		}

		var amount_bet = getFormatAmount(getFormatAmount(cases[id].price) * amount);

        //CHECK BALANCE
        userService.getBalance(user.userid, function(err2, balance){
            if(err2) {
                emitSocketToUser(socket, 'message', 'error', {
                    message: err2.message
                });

                return cooldown(false, true);
            }

            if(balance < amount_bet) {
                emitSocketToRoom(user.userid, 'modal', 'insufficient_balance', {
                    amount: getFormatAmount(amount_bet - balance)
                });

                emitSocketToUser(socket, 'message', 'error', {
                    message: 'You don\'t have enough money'
                });

                return cooldown(false, true);
            }

            //REGISTER BET
            userService.registerOriginalBet(user.userid, amount_bet, [], 'unboxing', function(err3, newbalance){
                if(err3) {
                    emitSocketToUser(socket, 'message', 'error', {
                        message: err3.message
                    });

                    return cooldown(false, true);
                }

                userService.updateBalance(user.userid, 'main', newbalance);

                openCase(user, fair, id, amount, 0, [], 0, function(err4, data, newxp){
                    if(err4) {
                        emitSocketToUser(socket, 'message', 'error', {
                            message: err4.message
                        });

                        return cooldown(false, true);
                    }

                    emitSocketToUser(socket, 'unboxing', 'roll', {
                        spinner: data.map(a => a.spinner)
                    });

                    setTimeout(function(){
                        emitSocketToUser(socket, 'unboxing', 'finish');

                        data.forEach(function(item){
                            var winning = getFormatAmount(item.winning.price);

                            var history = {
                                user:{
                                    userid: user.userid,
                                    name: user.name,
                                    avatar: user.avatar,
                                    level: calculateLevel(user.xp).level
                                },
                                unboxing: {
                                    id: id,
                                    name: cases[id].name,
                                    image: cases[id].image,
                                    price: getFormatAmount(cases[id].price)
                                },
                                winning: item.winning
                            };

                            lastWinnings.push(history);
                            if(lastWinnings.length > 20) lastWinnings.shift();

                            emitSocketToRoom('unboxing', 'unboxing', 'history', {
                                history: history
                            });

                            if(winning >= config.games.winning_to_chat){
                                var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to unboxing with chance ' + roundedToFixed(item.winning.chance, 2).toFixed(2) + '%!';
                                chatService.writeSystemMessage(send_message, 'all', true, null);
                            }

                            loggerTrace('[UNBOXING] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning) + ' with chance ' + roundedToFixed(item.winning.chance, 2).toFixed(2) + '%');
                        });

                        userService.updateLevel(user.userid, newxp);

                        gameCooldown[user.userid] = false;
                    }, 5000);

                    loggerTrace('[UNBOXING] Bet registed. ' + user.name + ' did open a case for $' + getFormatAmountString(amount_bet));

                    cooldown(false, false);
                });
            });
        });
	});
}

/* ----- INTERNAL USAGE ----- */
function openCase(user, fair, id, amount, index, data, xp, callback){
	if(index >= amount) return callback(null, data, xp);

	var seed = fairService.getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce + index);
	var salt = fairService.generateSaltHash(seed);

	var caseitems = getItems(cases[id].items);

	var tickets = generateTickets(caseitems);
	var total = tickets[tickets.length - 1].max;

	var spinner = generateSpinner(caseitems);

	var roll = fairService.getRoll(salt, total) + 1;

	var winningitem = null;
	var itemid = null;

	for(var i = 0; i < tickets.length; i++){
		if(roll >= tickets[i].min && roll <= tickets[i].max) {
			itemid = caseitems[i].id;

			winningitem = {
				name: caseitems[i].name,
				image: caseitems[i].image,
				price: getFormatAmount(caseitems[i].price),
				chance: roundedToFixed(caseitems[i].chance, 5),
				color: getColorByQuality(caseitems[i].quality)
			};

			break;
		}
	}

	spinner[99] = winningitem;

    var caseamount = getFormatAmount(cases[id].price);

	pool.query('INSERT INTO `unboxing_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `caseid` = ' + pool.escape(id) + ', `amount` = ' + pool.escape(caseamount) + ', `winning` = ' + pool.escape('[]') + ', `roll` = ' + roll + ', `tickets` = ' + total + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce + index) + ', `time` = ' + pool.escape(time()), function(err1, row1) {
		if(err1) return callback(new Error('An error occurred while opening case (1)'));

		pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err2){
			if(err2) return callback(new Error('An error occurred while opening case (2)'));

			var amount_bet = getFormatAmount(getFormatAmount(cases[id].price) * amount);
			var winning = getFormatAmount(winningitem.price);

			//FINISH BET
			userService.finishOriginalBet(user.userid, amount_bet, winning, 0, [ itemid ], 'unboxing', {
				active: true,
				visible: true,
				gameid: row1.insertId,
				countdown: 5000
			}, function(err3, newxp, newbalance, items){
				if(err3) return callback(err3);

                var items_winnings = items.slice().map(a => ({
                    id: a.id,
                    price: a.price
                }));

                pool.query('UPDATE `unboxing_bets` SET `winning` = ' + pool.escape(JSON.stringify(items_winnings)) + ' WHERE `id` = ' + pool.escape(row1.insertId), function(err4) {
                    if(err4) return callback(new Error('An error occurred while opening case (3)'));

                    data.push({
                        winning: winningitem,
                        spinner: spinner
                    });

                    xp = newxp;

                    openCase(user, fair, id, amount, index + 1, data, xp, callback);
			    });
			});
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function generateTickets(items){
	var decimals = 0;
	items.forEach(function(item){
		if(countDecimals(item.chance) > decimals) decimals = countDecimals(item.chance);
	});

	var tickets = [];
	var total = 0;

	items.forEach(function(item){
		tickets.push({
			min: total + 1,
			max: total + item.chance * Math.pow(10, decimals)
		});

		total += item.chance * Math.pow(10, decimals);
	});

	return tickets;
}

/* ----- INTERNAL USAGE ----- */
function generateSpinner(items){
	var tickets = generateTickets(items);
	var total = tickets[tickets.length - 1].max;

	var spinner = [];

	for(var i = 0; i < 150; i++){
		var ticket = getRandomInt(1, total);

		for(var j = 0; j < tickets.length; j++){
			if(ticket >= tickets[j].min && ticket <= tickets[j].max) {
				spinner.push({
					name: items[j].name,
					image: items[j].image,
					price: getFormatAmount(items[j].price),
					chance: roundedToFixed(items[j].chance, 5),
					color: getColorByQuality(items[j].quality)
				});
			}
		}
	}

	return spinner;
}

module.exports = {
	lastWinnings, cases, categories, gameCooldown,
	loadCases, getCases, getCategories, showSpinner, showCase, placeDemo, placeBet
};