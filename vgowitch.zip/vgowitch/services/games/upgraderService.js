var { pool } = require('@/lib/database.js');
var { emitSocketToUser, emitSocketToRoom } = require('@/lib/socket.js');
var { loggerTrace } = require('@/lib/logger.js');

var chatService = (({ writeSystemMessage }) => ({ writeSystemMessage }))(require('@/services/chatService.js'));
var userService = (({ updateBalance, updateLevel, getBalance, registerOriginalBet, finishOriginalBet }) => ({ updateBalance, updateLevel, getBalance, registerOriginalBet, finishOriginalBet }))(require('@/services/userService.js'));
var fairService = (({ getUserSeeds, getCombinedSeed, generateSaltHash, getRoll }) => ({ getUserSeeds, getCombinedSeed, generateSaltHash, getRoll }))(require('@/services/fairService.js'));

var { time } = require('@/utils/formatDate.js');
var { roundedToFixed, getFormatAmount, getFormatAmountString, verifyFormatAmount } = require('@/utils/formatAmount.js');
var { getColorByQuality } = require('@/utils/utils.js');

var itemsService = (({ items }) => ({ items }))(require('@/services/itemsService.js'));

var config = require('@/config/config.js');

/* ----- CLIENT USAGE ----- */
function placeBet(user, socket, myitems, siteitems, amount, game, cooldown){
	cooldown(true, true);

	/* CHECK DATA GAME */

	var allowed_games = [ 'under', 'over' ];
	if(!allowed_games.includes(game)) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid type game [over or under]!'
		});

		return cooldown(false, true);
	}

	if(myitems.length < config.games.games.upgrader.interval_myitems.min) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You have to sellect minimum ' + config.games.games.upgrader.interval_myitems.min + ' items from your inventory!'
		});

		return cooldown(false, true);
	}

	if(myitems.length > config.games.games.upgrader.interval_myitems.max) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You have to sellect maximum ' + config.games.games.upgrader.interval_myitems.max + ' items from your inventory!'
		});

		return cooldown(false, true);
	}

	if(siteitems.length < config.games.games.upgrader.interval_siteitems.min) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You have to sellect minimum ' + config.games.games.upgrader.interval_siteitems.min + ' items from site inventory!'
		});

		return cooldown(false, true);
	}

	if(siteitems.length > config.games.games.upgrader.interval_siteitems.max) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You have to sellect maximum ' + config.games.games.upgrader.interval_siteitems.max + ' items from site inventory!'
		});

		return cooldown(false, true);
	}

	/* END CHECK DATA GAME */

	//VERIFY FORMAT AMOUNT
	verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			return cooldown(false, true);
		}

		var myitemsin_query = myitems.map(a => '"' + a + '"').join(',') || 'null';

		pool.query('SELECT `id`, `itemid` FROM `users_items` WHERE `id` IN (' + myitemsin_query + ') AND `status` = 0 AND `userid` = ' + pool.escape(user.userid), function(err2, row2){
			if(err2){
				emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while placing bet (1)'
                });

				return cooldown(false, true);
			}

			if(row2.length != myitems.length){
				emitSocketToUser(socket, 'message', 'error', {
					message: 'Invalid user items in upgrader!'
				});

				return cooldown(false, true);
			}

			var games = row2.map(a => itemsService.items[a.itemid].game).filter((value, index, self) => self.indexOf(value) === index);

			if(games.length != 1){
				emitSocketToUser(socket, 'message', 'error', {
					message: 'Invalid user items in upgrader!'
				});

				return cooldown(false, true);
			}

			var myitems_amount = row2.reduce(function(acc, val) { return getFormatAmount(acc + itemsService.items[val.itemid].price) }, 0);

			var siteitemsin_query = siteitems.map(a => '"' + a + '"').join(',') || 'null';

			var table = {
				'cs2': 'items_list',
				'rust': 'items_list_rust'
			}[games[0]];

			pool.query('SELECT `itemid` FROM `' + table + '` WHERE `itemid` IN (' + siteitemsin_query + ')', function(err3, row3){
				if(err3){
					emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while placing bet (2)'
                    });

					return cooldown(false, true);
				}

				if(row3.length != siteitems.length){
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Invalid site items in upgrader!'
					});

					return cooldown(false, true);
				}

				var siteitems_amount = row3.reduce(function(acc, val) { return getFormatAmount(acc + itemsService.items[val.itemid].price) }, 0);

				var multiplier = roundedToFixed(siteitems_amount / getFormatAmount(myitems_amount + amount), 2);
				var chance = roundedToFixed((100 - config.games.house_edge.upgrader) / multiplier, 2);

				if(chance > 80){
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Upgrade above 80% is not possible'
					});

					return cooldown(false, true);
				}

				if(chance < 1){
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Upgrade below 1% is not possible'
					});

					return cooldown(false, true);
				}

				//SEEDS
				fairService.getUserSeeds(user.userid, function(err4, fair){
					if(err4) {
						emitSocketToUser(socket, 'message', 'error', {
							message: err4.message
						});

						return cooldown(false, true);
					}

                    if(amount < config.app.intervals.amounts['upgrader'].min || amount > config.app.intervals.amounts['upgrader'].max) {
                        emitSocketToUser(socket, 'message', 'error', {
                            message: 'Invalid bet amount [' + getFormatAmountString(config.app.intervals.amounts['upgrader'].min) + '-' + getFormatAmountString(config.app.intervals.amounts['upgrader'].max) + ']'
                        });

                        return cooldown(false, true);
                    }

                    //CHECK BALANCE
                    userService.getBalance(user.userid, function(err5, balance){
                        if(err5) {
                            emitSocketToUser(socket, 'message', 'error', {
                                message: err5.message
                            });

                            return cooldown(false, true);
                        }

                        if(balance < amount) {
                            emitSocketToRoom(user.userid, 'modal', 'insufficient_balance', {
                                amount: getFormatAmount(amount - balance)
                            });

                            emitSocketToUser(socket, 'message', 'error', {
                                message: 'You don\'t have enough money'
                            });

                            return cooldown(false, true);
                        }

                        //REGISTER BET
                        userService.registerOriginalBet(user.userid, amount, myitems, 'upgrader', function(err6, newbalance1){
                            if(err6) {
                                emitSocketToUser(socket, 'message', 'error', {
                                    message: err6.message
                                });

                                return cooldown(false, true);
                            }

                            userService.updateBalance(user.userid, 'main', newbalance1);

                            var seed = fairService.getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce);
                            var salt = fairService.generateSaltHash(seed);

                            var roll = (fairService.getRoll(salt, 10000) / 100) % 100;
                            var win = false;

                            if(game == 'under' && roll < chance) win = true;
                            if(game == 'over' && roll >= roundedToFixed(100 - chance, 2)) win = true;

                            var winning = [];
                            if(win) winning = siteitems.slice();

                            var amount_bet = getFormatAmount(myitems_amount + amount);

                            var amount_winning = 0;
                            if(win) amount_winning = siteitems_amount;

                            var items_bet = row2.map(a => ({
                                id: a.id,
                                price: itemsService.items[a.itemid].price
                            }));

                            pool.query('INSERT INTO `upgrader_bets` SET `userid` = ' + pool.escape(user.userid) + ', `avatar` = ' + pool.escape(user.avatar) + ', `name` = ' + pool.escape(user.name) + ', `xp` = ' + parseInt(user.xp) + ', `items` = ' + pool.escape(JSON.stringify(items_bet)) + ', `amount` = ' + amount + ', `game` = ' + pool.escape(game) + ', `chance` = ' + chance + ', `multiplier` = ' + multiplier + ', `roll` = ' + roll + ', `winning` = ' + pool.escape('[]') + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce) + ', `time` = ' + pool.escape(time()), function(err7, row7) {
                                if(err7) {
                                    emitSocketToUser(socket, 'message', 'error', {
                                        message: 'An error occurred while placing bet (3)'
                                    });

                                    return cooldown(false, true);
                                }

                                pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err8){
                                    if(err8) {
                                        emitSocketToUser(socket, 'message', 'error', {
                                            message: 'An error occurred while placing bet (4)'
                                        });

                                        return cooldown(false, true);
                                    }

                                    //FINISH BET
                                    userService.finishOriginalBet(user.userid, amount_bet, amount_winning, 0, winning, 'upgrader', {
                                        active: true,
                                        visible: true,
                                        gameid: row7.insertId,
                                        countdown: 6000
                                    }, function(err9, newxp, newbalance2, items){
                                        if(err9) {
                                            emitSocketToUser(socket, 'message', 'error', {
                                                message: err9.message
                                            });

                                            return cooldown(false, true);
                                        }

                                        var items_winnings = items.slice().map(a => ({
                                            id: a.id,
                                            price: a.price
                                        }));

                                        pool.query('UPDATE `upgrader_bets` SET `winning` = ' + pool.escape(JSON.stringify(items_winnings)) + ' WHERE `id` = ' + pool.escape(row7.insertId), function(err10) {
                                            if(err10) {
                                                emitSocketToUser(socket, 'message', 'error', {
                                                    message: 'An error occurred while placing bet (5)'
                                                });

                                                return cooldown(false, true);
                                            }

                                            emitSocketToUser(socket, 'upgrader', 'roll', {
                                                roll: roll
                                            });

                                            setTimeout(function(){
                                                emitSocketToUser(socket, 'upgrader', 'finish', {
                                                    win: win,
                                                    items: items.slice().map(a => a.id),
                                                });

                                                if(win){
                                                    if(amount_winning >= config.games.winning_to_chat){
                                                        var send_message = user.name + ' won ' + getFormatAmountString(amount_winning) + ' to upgrader!';
                                                        chatService.writeSystemMessage(send_message, 'all', true, null);
                                                    }

                                                    loggerTrace('[UPGRADER] Win registed. ' + user.name + ' did win $' + getFormatAmountString(amount_winning) + ' with chance ' + roundedToFixed(chance, 2).toFixed(2) + '%');
                                                }

                                                userService.updateLevel(user.userid, newxp);
                                            }, 6000);

                                            loggerTrace('[UPGRADER] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount_bet));

                                            cooldown(false, false);
                                        });
                                    });
                                });
                            });
                        });
                    });
				});
			});
		});
	});
}

/* ----- CLIENT USAGE ----- */
function getChance(user, socket, myitems, siteitems, amount, cooldown){
	cooldown(true, true);

	//VERIFY FORMAT AMOUNT
	verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			return cooldown(false, true);
		}

		if(myitems.length <= 0 || siteitems.length <= 0){
			emitSocketToUser(socket, 'upgrader', 'chance', {
				chance: 0
			});

			return cooldown(false, false);
		}

		var myitemsin_query = myitems.map(a => '"' + a + '"').join(',') || 'null';

		pool.query('SELECT `itemid` FROM `users_items` WHERE `id` IN (' + myitemsin_query + ') AND `status` = 0 AND `userid` = ' + pool.escape(user.userid), function(err2, row2){
			if(err2){
				emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while getting chance (1)'
                });

				return cooldown(false, true);
			}

			if(row2.length != myitems.length){
				emitSocketToUser(socket, 'message', 'error', {
					message: 'Invalid user items in upgrader!'
				});

				return cooldown(false, true);
			}

			var games = row2.map(a => itemsService.items[a.itemid].game).filter((value, index, self) => self.indexOf(value) === index);

			if(games.length != 1){
				emitSocketToUser(socket, 'message', 'error', {
					message: 'Invalid user items in upgrader!'
				});

				return cooldown(false, true);
			}

			var myitems_amount = row2.reduce(function(acc, val) { return getFormatAmount(acc + itemsService.items[val.itemid].price) }, 0);

			var siteitemsin_query = siteitems.map(a => '"' + a + '"').join(',') || 'null';

			var table = {
				'cs2': 'items_list',
				'rust': 'items_list_rust'
			}[games[0]];

			pool.query('SELECT `itemid` FROM `' + table + '` WHERE `itemid` IN (' + siteitemsin_query + ')', function(err3, row3){
				if(err3){
					emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while getting chance (2)'
                    });

					return cooldown(false, true);
				}

				if(row3.length != siteitems.length){
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Invalid site items in upgrader!'
					});

					return cooldown(false, true);
				}

				var siteitems_amount = row3.reduce(function(acc, val) { return getFormatAmount(acc + itemsService.items[val.itemid].price) }, 0);

                var chance = roundedToFixed((100 - config.games.house_edge.upgrader) * getFormatAmount(myitems_amount + amount) / siteitems_amount, 2);

				if(chance > 80){
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Upgrade above 80% is not possible'
					});
				}

				if(chance < 1){
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Upgrade below 1% is not possible'
					});
				}

				emitSocketToUser(socket, 'upgrader', 'chance', {
					chance: chance
				});

				cooldown(false, false);
			});
		});
	});
}

/* ----- CLIENT USAGE ----- */
function getMyItems(user, socket, page, order, game, cooldown){
	cooldown(true, true);

	var order_allowed = [ 0, 1, 2, 3, 4 ];
	if(!order_allowed.includes(order)){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid order!'
		});

		return cooldown(false, true);
	}

	var game_allowed = [ 'cs2', 'rust' ];
	if(!game_allowed.includes(game)){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid game!'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(page))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid page!'
		});

		return cooldown(false, true);
	}

	page = parseInt(page);

	pool.query('SELECT `id`, `itemid`, `time` FROM `users_items` WHERE `status` = 0 AND `userid` = ' + pool.escape(user.userid), function(err1, row1){
		if(err1){
			emitSocketToUser(socket, 'message', 'error', {
                message: 'An error occurred while getting my items (1)'
            });

			return cooldown(false, true);
		}

		var listitems = row1.filter(a => itemsService.items[a.itemid].game == game).map(a => ({
			id: a.id,
			itemid: a.itemid,
			name: itemsService.items[a.itemid].name,
			price: getFormatAmount(itemsService.items[a.itemid].price),
			time: parseInt(a.time)
		}));

		var pages = Math.ceil(listitems.length / 100);

		if(pages <= 0){
			emitSocketToUser(socket, 'pagination', 'upgrader_myitems', {
				list: [],
				pages: 1,
				page: 1
			});

			return cooldown(false, false);
		}

		if(page <= 0 || page > pages) {
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid page!'
			});

			return cooldown(false, true);
		}

		if(order == 0) listitems.sort((a, b) => b.time - a.time );
		else if(order == 1) listitems.sort((a, b) => a.name.localeCompare(b.name));
		else if(order == 2) listitems.sort((a, b) => b.name.localeCompare(a.name));
		else if(order == 3) listitems.sort((a, b) => a.price - b.price );
		else if(order == 4) listitems.sort((a, b) => b.price - a.price );

		var result = listitems.slice((page - 1) * 100, page * 100);

		var list = result.map(a => ({
			id: a.id,
			name: itemsService.items[a.itemid].name,
			image: itemsService.items[a.itemid].image,
			price: getFormatAmount(itemsService.items[a.itemid].price),
			color: getColorByQuality(itemsService.items[a.itemid].quality)
		}));

		emitSocketToUser(socket, 'pagination', 'upgrader_myitems', {
			list: list,
			pages: pages,
			page: page
		});

		cooldown(false, false);
	});
}

/* ----- CLIENT USAGE ----- */
function getSiteItems(user, socket, page, order, search, items, amount, multiplier, cooldown){
	cooldown(true, true);

	//VERIFY FORMAT AMOUNT
	verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			return cooldown(false, true);
		}

		var multiplier_allowed = [ 0, 1, 2, 3 ];
		if(!multiplier_allowed.includes(multiplier)){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid multiplier!'
			});

			return cooldown(false, true);
		}

		var order_allowed = [ 0, 1, 2, 3 ];
		if(!order_allowed.includes(order)){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid order!'
			});

			return cooldown(false, true);
		}

		if(isNaN(Number(page))){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid page!'
			});

			return cooldown(false, true);
		}

		page = parseInt(page);
		search = search.trim();

		if(items.length <= 0){
			emitSocketToUser(socket, 'pagination', 'upgrader_siteitems', {
				list: [],
				pages: 1,
				page: 1
			});

			return cooldown(false, false);
		}

		var itemsin_query = items.map(a => '"' + a + '"').join(',') || 'null';

		pool.query('SELECT `itemid` FROM `users_items` WHERE `id` IN (' + itemsin_query + ') AND `status` = 0 AND `userid` = ' + pool.escape(user.userid), function(err2, row2){
			if(err2){
				emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while getting site items (1)'
                });

				return cooldown(false, true);
			}

			if(row2.length != items.length){
				emitSocketToUser(socket, 'message', 'error', {
					message: 'Invalid user items in upgrader!'
				});

				return cooldown(false, true);
			}

			if(row2.length <= 0){
				emitSocketToUser(socket, 'pagination', 'upgrader_siteitems', {
					list: [],
					pages: 1,
					page: 1
				});

				return cooldown(false, false);
			}

			var games = row2.map(a => itemsService.items[a.itemid].game).filter((value, index, self) => self.indexOf(value) === index);

			if(games.length != 1){
				emitSocketToUser(socket, 'message', 'error', {
					message: 'Invalid user items in upgrader!'
				});

				return cooldown(false, true);
			}

			var items_amount = row2.reduce(function(acc, val) { return getFormatAmount(acc + itemsService.items[val.itemid].price) }, 0);

			var total_amount = getFormatAmount(items_amount + amount);
			var multiplier_amount = getFormatAmount(total_amount * [1.50, 2.00, 5.00, 10.00][multiplier]);

			var items_prices = Object.values(itemsService.items).filter(a => a.price >= multiplier_amount).map(a => a.id);
			var items_query = items_prices.map(a => '"' + a + '"').join(',') || 'null';

			var table = {
				'cs2': 'items_list',
				'rust': 'items_list_rust'
			}[games[0]];

			pool.query('SELECT COUNT(*) AS `count` FROM `' + table + '` WHERE `name` LIKE ' + pool.escape('%' + search + '%') + ' AND `itemid` IN (' + items_query + ')', function(err3, row3){
				if(err3){
					emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while getting site items (2)'
                    });

					return cooldown(false, true);
				}

				var pages = Math.ceil(row3[0].count / 100);

				if(pages <= 0){
					emitSocketToUser(socket, 'pagination', 'upgrader_siteitems', {
						list: [],
						pages: 1,
						page: 1
					});

					return cooldown(false, false);
				}

				if(page <= 0 || page > pages) {
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Invalid page!'
					});

					return cooldown(false, true);
				}

				var order_query = {
					0: 'ORDER BY `name` ASC',
					1: 'ORDER BY `name` DESC',
					2: 'ORDER BY `price` ASC',
					3: 'ORDER BY `price` DESC'
				}[order];

				pool.query('SELECT `itemid` FROM `' + table + '` WHERE `name` LIKE ' + pool.escape('%' + search + '%') + ' AND `itemid` IN (' + items_query + ') ' + order_query + ' LIMIT 100 OFFSET ' + pool.escape(page * 100 - 100), function(err4, row4){
					if(err4){
						emitSocketToUser(socket, 'message', 'error', {
                            message: 'An error occurred while getting site items (3)'
                        });

						return cooldown(false, true);
					}

					var list = row4.map(a => ({
						id: a.itemid,
						name: itemsService.items[a.itemid].name,
						image: itemsService.items[a.itemid].image,
						price: getFormatAmount(itemsService.items[a.itemid].price),
						color: getColorByQuality(itemsService.items[a.itemid].quality)
					}));

					emitSocketToUser(socket, 'pagination', 'upgrader_siteitems', {
						list: list,
						pages: pages,
						page: page
					});

					cooldown(false, false);
				});
			});
		});
	});
}

module.exports = {
	placeBet, getChance, getMyItems, getSiteItems
};