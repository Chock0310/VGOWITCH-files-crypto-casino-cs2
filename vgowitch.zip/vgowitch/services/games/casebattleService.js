var sha256 = require('sha256');

var { pool } = require('@/lib/database.js');
var { emitSocketToUser, emitSocketToRoom } = require('@/lib/socket.js');
var { loggerDebug, loggerTrace, loggerInfo } = require('@/lib/logger.js');
var { uuid } = require('@/lib/uuid.js');

var chatService = (({ writeSystemMessage }) => ({ writeSystemMessage }))(require('@/services/chatService.js'));
var userService = (({ updateBalance, updateLevel, getBalance, registerOriginalBet, finishOriginalBet, refundOriginalBet, editBalance, sellAllInventoryItem }) => ({ updateBalance, updateLevel, getBalance, registerOriginalBet, finishOriginalBet, refundOriginalBet, editBalance, sellAllInventoryItem }))(require('@/services/userService.js'));
var fairService = (({ generateEosSeed, generateServerSeed, getCombinedSeed, generateSaltHash, getRoll, getRollCaseBattle }) => ({ generateEosSeed, generateServerSeed, getCombinedSeed, generateSaltHash, getRoll, getRollCaseBattle }))(require('@/services/fairService.js'));

var { time } = require('@/utils/formatDate.js');
var { roundedToFixed, getFormatAmount, getFormatAmountString } = require('@/utils/formatAmount.js');
var { calculateLevel, getColorByQuality, getAmountCommission, getRandomInt, countDecimals } = require('@/utils/utils.js');

var itemsService = (({ items }) => ({ items }))(require('@/services/itemsService.js'));

var config = require('@/config/config.js');

var cases = {};
var games = {};
var secure = {};

var stats = {
	active: 0,
	total: 0
};

var gamesLoaded = false;

function loadStats(){
	loggerDebug('[CASE BATTLE] Loading Stats');

	pool.query('SELECT COUNT(*) AS `count` FROM `casebattle_games` WHERE `canceled` = 0', function(err1, row1) {
		if(err1) {
            loggerInfo('[CASE BATTLE] Error In Loading Stats');

            return loadStats();
        }

		pool.query('SELECT COUNT(*) AS `count` FROM `casebattle_games` WHERE `ended` = 0 AND `canceled` = 0', function(err2, row2) {
			if(err2) {
                loggerInfo('[CASE BATTLE] Error In Loading Stats');

                return loadStats();
            }

			stats.active = parseInt(row2[0].count);
			stats.total = parseInt(row1[0].count);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function loadGames(){
	if(gamesLoaded) return;
	gamesLoaded = true;

	loggerDebug('[CASE BATTLE] Loading Games');

	pool.query('SELECT * FROM `casebattle_games` WHERE `ended` = 0 AND `canceled` = 0', function(err1, row1) {
		if(err1) return;

		if(row1.length <= 0) return;

		row1.reverse();

		row1.forEach(function(casebattle){
            var amount = getFormatAmount(casebattle.amount);

			var listcases = [];
			JSON.parse(casebattle.cases).forEach(function(item){
				listcases.push({
					id: item.id,
					name: cases[item.id].name,
					image: cases[item.id].image,
					price: getFormatAmount(cases[item.id].price)
				});
			});

			var mode = parseInt(casebattle.mode);
			var privacy = parseInt(casebattle.privacy);
			var free = parseInt(casebattle.free);
			var crazy = parseInt(casebattle.crazy);

			games[casebattle.battleid] = {
				id: casebattle.id,
				battleid: casebattle.battleid,
				status: 0,
				players: [],
				mode: mode,
				privacy: privacy,
				free: free,
				crazy: crazy,
				cases: listcases,
				amount: amount,
				round: 0,
				game: {
					server_seed: casebattle.server_seed,
					public_seed: null,
					block: null
				},
				draw: {
					public_seed: null,
					block: null
				},
				time: parseInt(casebattle.time)
			}

			var total_players = [ 2, 3, 4, 4 ][mode];

			secure[casebattle.battleid] = {};
			for(var i = 0; i < total_players; i++) secure[casebattle.battleid][i] = {};

			pool.query('SELECT * FROM `casebattle_bets` WHERE `gameid` = ' + pool.escape(casebattle.id) + ' AND `canceled` = 0', function(err2, row2) {
				if(err2) return;

				if(row2.length >= total_players) {
					games[casebattle.battleid].status = 1;
					games[casebattle.battleid].time = time();
				}

				row2.forEach(function(bet){
					games[casebattle.battleid]['players'].push({
						user: {
							userid: bet.userid,
							name: bet.name,
							avatar: bet.avatar,
							level: calculateLevel(bet.xp).level
						},
						id: parseInt(bet.id),
						position: parseInt(bet.position),
						creator: parseInt(bet.creator),
						bot: parseInt(bet.bot),
						items: [],
						total: 0
					});
				});

				if(games[casebattle.battleid].status) continueGame(casebattle.battleid);
			});
		});
	});
}

function loadCases(callback){
	loggerDebug('[CASE BATTLE] Loading Cases');

	pool.query('SELECT `caseid`, `name`, `image`, `items`, `game` FROM `cases_cases` WHERE `removed` = 0 AND `battle` = 1', function(err1, row1){
		if(err1) return callback(new Error('An error occurred while loading cases (1)'));

		row1.forEach(function(caseitem){
			var caseitems = JSON.parse(caseitem.items);

			var caseprice = 0;

			caseitems.forEach(function(item){
				var item_price = getFormatAmount(itemsService.items[item.id].price);

				caseprice += item_price * item.chance / 100;
			});

			caseprice = getFormatAmount(caseprice + getAmountCommission(caseprice, config.games.house_edge.unboxing));

			var item = {
				game: caseitem.game,
				name: caseitem.name,
				image: caseitem.image,
				price: caseprice,
				category: 0,
				items: caseitems
			}

			cases[caseitem.caseid] = item;
		});

		loadGames();

		callback(null);
	})
}

function getItems(items){
	var newitems = [];

	items.forEach(function(item){
		newitems.push({
			id: item.id,
			name: itemsService.items[item.id].name,
			image: itemsService.items[item.id].image,
			price: roundedToFixed(itemsService.items[item.id].price, 2),
			chance: roundedToFixed(item.chance, 5),
			quality: itemsService.items[item.id].quality
		});
	});

	return newitems;
}

/* ----- CLIENT USAGE ----- */
function getCases(user, socket, cooldown){
	cooldown(true, true);

	var listcases = Object.keys(cases).map(a => ({
		id: a,
		game: cases[a].game,
		name: cases[a].name,
		image: cases[a].image,
		price: getFormatAmount(cases[a].price)
	}));

	listcases.sort(function(a, b){ return a.price - b.price });

	emitSocketToUser(socket, 'casebattle', 'cases', {
		cases: listcases
	});

	cooldown(false, false);
}

/* ----- CLIENT USAGE ----- */
function sendEmoji(user, socket, id, position, emoji, cooldown) {
	cooldown(true, true);

	/* CHECK DATA GAME */

	if(isNaN(Number(position))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid position!'
		});

		return cooldown(false, true);
	}

	position = parseInt(position);

	if(isNaN(Number(emoji))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid emoji!'
		});

		return cooldown(false, true);
	}

	emoji = parseInt(emoji);

	var allowed_mode = [0, 1, 2, 3, 4];
	if(!allowed_mode.includes(emoji)) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid emoji!'
		});

		return cooldown(false, true);
	}

	/* END CHECK DATA GAME */

	pool.query('SELECT * FROM `casebattle_games` WHERE `battleid` = ' + pool.escape(id) + ' AND `canceled` = 0', function(err1, row1) {
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
                message: 'An error occurred while sending emoji (1)'
            });

			return cooldown(false, true);
		}

		if(row1.length <= 0) {
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid battle id!'
			});

			return cooldown(false, true);
		}

		pool.query('SELECT * FROM `casebattle_bets` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `gameid` = ' + pool.escape(row1[0].id) + ' AND `position` = ' + position + ' AND `canceled` = 0', function(err2, row2){
			if(err2) {
				emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while sending emoji (2)'
                });

				return cooldown(false, true);
			}

			if(row2.length <= 0) {
				emitSocketToUser(socket, 'message', 'error', {
					message: 'Invalid battle id!'
				});

				return cooldown(false, true);
			}

			emitSocketToRoom('casebattle/' + id, 'casebattle', 'emoji', {
				position: position,
				emoji: emoji,
				casebattle: {
					id: id
				}
			});

			cooldown(false, false);
		});
	});
}

/* ----- CLIENT USAGE ----- */
function showGame(user, socket, id, cooldown){
	cooldown(true, true);

	pool.query('SELECT * FROM `casebattle_games` WHERE `battleid` = ' + pool.escape(id) + ' AND `canceled` = 0', function(err1, row1) {
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
                message: 'An error occurred while showing game (1)'
            });

			return cooldown(false, true);
		}

		if(row1.length <= 0) {
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid battle id!'
			});

			return cooldown(false, true);
		}

		if(games[id] !== undefined && parseInt(row1[0].ended) == 0) {
			var casebattle_data = {
				privacy: games[id].privacy,
				free: games[id].free,
				crazy: games[id].crazy,
				round: games[id].round
			};

			casebattle_data.game = {
				server_seed_hashed: sha256(games[id].game.server_seed),
				nonce: games[id].id
			};

			casebattle_data.draw = null;

			if(games[id].status == 2){
				casebattle_data.game.block = games[id].game.block;
			} else if(games[id].status == 3) {
				casebattle_data.countdown = config.games.games.casebattle.timer_countdown

				casebattle_data.game.block = games[id].game.block;
			} else if(games[id].status == 4 || games[id].status == 5){
				casebattle_data.round = games[id].round;
				casebattle_data.positions = getWinners(games[id].players, games[id].mode, games[id].crazy).reduce((acc, obj) => { return [ ...acc, ...obj.winners ] }, []);

				casebattle_data.game.block = games[id].game.block;
			} else if(games[id].status == 6) {
				var winners_positions_all = getWinners(games[id].players, games[id].mode, games[id].crazy);

				var seed = fairService.getCombinedSeed(games[id].game.server_seed, games[id].draw.public_seed, games[id].id);
				var salt = fairService.generateSaltHash(seed);

				var roll = fairService.getRoll(salt, winners_positions_all.length);

				casebattle_data.winners = winners_positions_all.filter(a => a.position == roll)[0].winners;

				casebattle_data.game.server_seed = games[id].game.server_seed;
				casebattle_data.game.public_seed = games[id].game.public_seed;
				casebattle_data.game.block = games[id].game.block;
			}

			if(games[id].draw){
				if(games[id].status == 5){
					casebattle_data.draw = {
						block: games[id].draw.block
					};
				} else if(games[id].status == 6){
					casebattle_data.draw = games[id].draw;
				}
			}

			emitSocketToUser(socket, 'casebattle', 'show', {
				status: games[id].status,
				casebattle: {
					id: id,
					players: games[id].players,
					mode: games[id].mode,
					cases: games[id].cases,
					amount: games[id].amount,
					data: casebattle_data
				}
			});

			cooldown(false, false);
		} else {
            var amount = getFormatAmount(row1[0].amount);

			var listcases = [];
			JSON.parse(row1[0].cases).forEach(function(item){
				listcases.push({
                    id: item.id,
                    name: cases[item.id].name,
                    image: cases[item.id].image,
                    price: getFormatAmount(cases[item.id].price)
                });
			});

			var mode = parseInt(row1[0].mode);

			pool.query('SELECT * FROM `casebattle_bets` WHERE `gameid` = ' + pool.escape(row1[0].id) + ' AND `canceled` = 0', function(err2, row2) {
				if(err2) {
					emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while showing game (2)'
                    });

					return cooldown(false, true);
				}

				var players = [];

				row2.forEach(function(bet){
					players.push({
						user: {
							userid: bet.userid,
							name: bet.name,
							avatar: bet.avatar,
							level: calculateLevel(bet.xp).level
						},
						position: parseInt(bet.position),
						creator: parseInt(bet.creator),
						bot: parseInt(bet.bot),
						items: [],
						total: 0
					});
				});

				pool.query('SELECT * FROM `casebattle_items` WHERE `gameid` = ' + pool.escape(row1[0].id), function(err3, row3) {
					if(err3) {
						emitSocketToUser(socket, 'message', 'error', {
                            message: 'An error occurred while showing game (3)'
                        });

						return cooldown(false, true);
					}

					if(row3.length > 0){
						JSON.parse(row3[0].items).forEach(function(item){
							players[players.slice().findIndex(a => a.position == item.position)].items.push({
								name: itemsService.items[item.itemid].name,
								image: itemsService.items[item.itemid].image,
								price: getFormatAmount(item.price),
								color: getColorByQuality(itemsService.items[item.itemid].quality)
							});

							players[players.slice().findIndex(a => a.position == item.position)].total = getFormatAmount(players[players.slice().findIndex(a => a.position == item.position)].total + getFormatAmount(item.price));
						});
					}

					pool.query('SELECT `position` FROM `casebattle_winnings` WHERE `gameid` = ' + pool.escape(row1[0].id), function(err4, row4) {
						if(err4) {
							emitSocketToUser(socket, 'message', 'error', {
                                message: 'An error occurred while showing game (4)'
                            });

							return cooldown(false, true);
						}

						pool.query('SELECT * FROM `casebattle_rolls` WHERE `gameid` = ' + pool.escape(row1[0].id), function(err5, row5) {
							if(err5) {
								emitSocketToUser(socket, 'message', 'error', {
                                    message: 'An error occurred while showing game (5)'
                                });

								return cooldown(false, true);
							}

							pool.query('SELECT * FROM `casebattle_draws` WHERE `gameid` = ' + pool.escape(row1[0].id), function(err6, row6) {
								if(err6) {
									emitSocketToUser(socket, 'message', 'error', {
                                        message: 'An error occurred while showing game (6)'
                                    });

									return cooldown(false, true);
								}

								var draw = null;
								if(row6.length > 0){
									draw = {
										public_seed: row6[0].public_seed,
										block: row6[0].blockid
									}
								}

								emitSocketToUser(socket, 'casebattle', 'show', {
									status: 6,
									casebattle: {
										id: id,
										players: players,
										mode: mode,
										cases: listcases,
										amount: amount,
										data: {
											game: {
												server_seed_hashed: sha256(row1[0].server_seed),
												server_seed: row1[0].server_seed,
												public_seed: row5[0].public_seed,
												block: row5[0].blockid,
												nonce: row1[0].id
											},
											draw: draw,
											round: listcases.length - 1,
											privacy: parseInt(row1[0].privacy),
											free: parseInt(row1[0].free),
											crazy: parseInt(row1[0].crazy),
											winners: row4.slice().map(a => parseInt(a.position))
										}
									}
								});

								cooldown(false, false);
							});
						});
					});
				});
			});
		}
	});
}

/* ----- CLIENT USAGE ----- */
function createGame(user, socket, listcases, mode, privacy, free, crazy, cooldown) {
	cooldown(true, true);

	/* CHECK DATA GAME */

	if(!Array.isArray(listcases)) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid cases!'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(mode))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid mode!'
		});

		return cooldown(false, true);
	}

	mode = parseInt(mode);

	var allowed_mode = [0, 1, 2, 3];
	if(!allowed_mode.includes(mode)) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid mode [1v1, 1v1v1, 1v1v1v1 or 2v2]!'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(privacy))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid privacy!'
		});

		return cooldown(false, true);
	}

	privacy = parseInt(privacy);

	var allowed_privacy = [0, 1];
	if(!allowed_privacy.includes(privacy)) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid privacy [public or private]!'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(free))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid free!'
		});

		return cooldown(false, true);
	}

	free = parseInt(free);

	var allowed_privacy = [0, 1];
	if(!allowed_privacy.includes(free)) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid free!'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(crazy))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid crazy!'
		});

		return cooldown(false, true);
	}

	crazy = parseInt(crazy);

	var allowed_privacy = [0, 1];
	if(!allowed_privacy.includes(crazy)) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid crazy!'
		});

		return cooldown(false, true);
	}

	/* END CHECK DATA GAME */

	if(listcases.length < config.games.games.casebattle.interval_cases.min) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You have to sellect minimum ' + config.games.games.casebattle.interval_cases.min + ' cases!'
		});

		return cooldown(false, true);
	}

	if(listcases.length > config.games.games.casebattle.interval_cases.max) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You have to sellect maximum ' + config.games.games.casebattle.interval_cases.max + ' cases!'
		});

		return cooldown(false, true);
	}

	var amount = 0;
	var available = true;

	for(var i = 0; i < listcases.length; i++){
		if(!Object.keys(cases).includes(listcases[i])) {
			available = false;
			break;
		}

		amount += getFormatAmount(cases[listcases[i]].price);
	}

	if(!available) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid cases in your battle!'
		});

		return cooldown(false, true);
	}

	var total_players = [ 2, 3, 4, 4 ][mode];

	var casebattle_amount = getFormatAmount(amount);

	amount = getFormatAmount(amount);
	if(free) amount = getFormatAmount(amount * total_players);

    //CHECK BALANCE
    userService.getBalance(user.userid, function(err1, balance){
        if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			return cooldown(false, true);
		}

        if(balance < amount) {
            emitSocketToRoom(user.userid, 'modal', 'insufficient_balance', {
                amount: getFormatAmount(amount - balance)
            });

            emitSocketToUser(socket, 'message', 'error', {
				message: 'You don\'t have enough money'
			});

			return cooldown(false, true);
        }

        //REGISTER BET
        userService.registerOriginalBet(user.userid, amount, [], 'casebattle', function(err2, newbalance){
            if(err2) {
                emitSocketToUser(socket, 'message', 'error', {
                    message: err2.message
                });

                return cooldown(false, true);
            }

            var server_seed = fairService.generateServerSeed();

            var battleid = uuid.uuidv4();

            var cases_bet = listcases.map(a => ({
                id: a,
                price: cases[a].price
            }));

            pool.query('INSERT INTO `casebattle_games` SET `cases` = ' + pool.escape(JSON.stringify(cases_bet)) + ', `amount` = ' + casebattle_amount + ', `mode` = ' + mode + ', `privacy` = ' + privacy + ', `free` = ' + free + ', `crazy` = ' + crazy + ', `server_seed` = ' + pool.escape(server_seed) + ', `battleid` = ' + pool.escape(battleid) + ', `time` = ' + pool.escape(time()), function(err3, row3){
                if(err3) {
                    emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while creating game (1)'
                    });

                    return cooldown(false, true);
                }

                pool.query('INSERT INTO `casebattle_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `bot` = ' + parseInt(user.bot) + ', `gameid` = ' + row3.insertId + ', `position` = 0, `creator` = 1, `time` = ' + pool.escape(time()), function(err4, row4){
                    if(err4) {
                        emitSocketToUser(socket, 'message', 'error', {
                            message: 'An error occurred while creating game (2)'
                        });

                        return cooldown(false, true);
                    }

                    var list = [];
                    listcases.forEach(function(item){
                        list.push({
                            id: item,
                            name: cases[item].name,
                            image: cases[item].image,
                            price: getFormatAmount(cases[item].price)
                        });
                    });

                    games[battleid] = {
                        id: row3.insertId,
                        battleid: battleid,
                        status: 0,
                        players: [],
                        mode: mode,
                        privacy: privacy,
                        free: free,
                        crazy: crazy,
                        cases: list,
                        amount: casebattle_amount,
                        round: 0,
                        game: {
                            server_seed: server_seed,
                            public_seed: null,
                            block: null
                        },
                        draw: {
                            public_seed: null,
                            block: null
                        },
                        time: time()
                    }

                    secure[battleid] = [];
                    for(var i = 0; i < total_players; i++) secure[battleid][i] = {};

                    games[battleid]['players'].push({
                        user: {
                            userid: user.userid,
                            name: user.name,
                            avatar: user.avatar,
                            level: calculateLevel(user.xp).level
                        },
                        id: row4.insertId,
                        position: 0,
                        creator: 1,
                        bot: user.bot,
                        items: [],
                        total: 0
                    });

                    emitSocketToUser(socket, 'casebattle', 'bet_confirmed');

                    emitSocketToUser(socket, 'casebattle', 'redirect', {
                        action: 'join',
                        id: battleid
                    });

                    if(!privacy){
                        emitSocketToRoom('casebattle/list/active', 'casebattle', 'add', {
                            casebattle: {
                                id: battleid,
                                players: games[battleid]['players'],
                                mode: mode,
                                cases: list,
                                amount: casebattle_amount,
                                free: free,
                                time: games[battleid]['time'],
                                data: {}
                            }
                        });
                    }

                    stats.active++;
                    stats.total++;

                    emitSocketToRoom('casebattle', 'casebattle', 'stats', {
                        stats: stats
                    });

                    userService.updateBalance(user.userid, 'main', newbalance);

                    loggerTrace('[CASE BATTLE] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));

                    cooldown(false, false);
                });
            });
        });
    });
}

/* ----- CLIENT USAGE ----- */
function joinGame(user, socket, id, position, cooldown) {
	cooldown(true, true);

	/* CHECK DATA GAME */

	if(isNaN(Number(position))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid position!'
		});

		return cooldown(false, true);
	}

	position = parseInt(position);

	/* END CHECK DATA GAME */

	if(games[id] === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case battle id!'
		});

		return cooldown(false, true);
	}

	if(games[id].status != 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'This case battle are already ended!'
		});

		return cooldown(false, true);
	}

	var total_players = [ 2, 3, 4, 4 ][games[id].mode];

	if(position < 0 || position >= total_players) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'That position is invalid!'
		});

		return cooldown(false, true);
	}

	if(games[id].players.filter(a => a.position == position).length > 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'That position is already taked!'
		});

		return cooldown(false, true);
	}

	if(games[id].players.filter(a => a.user.userid == user.userid).length > 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You already joined in this case battle!'
		});

		return cooldown(false, true);
	}

	if(Object.keys(secure[id][position]).length > 0){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Another user are trying to join in this game. Please try again later!'
		});

		return cooldown(false, true);
	}

    var amount = getFormatAmount(games[id]['amount']);

    //CHECK BALANCE
    userService.getBalance(user.userid, function(err1, balance){
        if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			return cooldown(false, true);
		}

        if(balance < amount) {
            emitSocketToRoom(user.userid, 'modal', 'insufficient_balance', {
                amount: getFormatAmount(amount - balance)
            });

            emitSocketToUser(socket, 'message', 'error', {
				message: 'You don\'t have enough money'
			});

			return cooldown(false, true);
        }

        secure[id][position][user.userid] = true;

        confirmJoinGame(user, id, position, function(err2, newbalance){
            if(err2){
                emitSocketToUser(socket, 'message', 'error', {
                    message: err2.message
                });

                return cooldown(false, true);
            }

            emitSocketToUser(socket, 'casebattle', 'bet_confirmed');

            for(var i = 0; i < total_players; i++){
                if(games[id]['players'].filter(a => a.position == i).length <= 0){
                    emitSocketToUser(socket, 'casebattle', 'update', {
                        stage: 'position',
                        status: games[id].status,
                        position: i,
                        casebattle: {
                            id: id,
                            players: games[id]['players'],
                            mode: games[id]['mode'],
                            cases: games[id]['cases'],
                            amount: games[id]['amount'],
                            data: {}
                        }
                    });
                }
            }

            userService.updateBalance(user.userid, 'main', newbalance);

            cooldown(false, false);
        });
    });
}

function confirmJoinGame(user, id, position, callback){
	var amount = getFormatAmount(games[id]['amount']);

	if(games[id]['free']) amount = 0;

	var total_players = [ 2, 3, 4, 4 ][games[id].mode];

	//REGISTER BET
	userService.registerOriginalBet(user.userid, amount, [], 'casebattle', function(err1, newbalance){
		if(err1) return callback(err1);

		pool.query('SELECT * FROM `casebattle_bets` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `gameid` = ' + pool.escape(games[id].id) + ' AND `canceled` = 1 AND `creator` = 1', function(err2, row2){
			if(err2) return callback(new Error('An error occurred while confirming join game (1)'));

			var creator = row2.length > 0 ? 1 : 0;

			pool.query('INSERT INTO `casebattle_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `bot` = ' + parseInt(user.bot) + ', `gameid` = ' + pool.escape(games[id].id) + ', `position` = ' + position + ', `creator` = ' + creator + ', `time` = ' + pool.escape(time()), function(err3, row3){
				if(err3) return callback(new Error('An error occurred while confirming join game (2)'));

				games[id]['players'].push({
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					id: row3.insertId,
					position: position,
					bot: user.bot,
					creator: creator,
					items: [],
					total: 0
				});

				if(games[id]['players'].length >= total_players) games[id].status = 1;

				if(!games[id].privacy){
					emitSocketToRoom('casebattle/list/active', 'casebattle', 'edit', {
						status: games[id].status,
						casebattle: {
							id: id,
							players: games[id]['players'],
							mode: games[id]['mode'],
							cases: games[id]['cases'],
							amount: games[id]['amount'],
							free: games[id]['free'],
							time: games[id]['time'],
							data: {}
						}
					});
				}

				emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
					stage: 'position',
					status: games[id].status,
					position: position,
					casebattle: {
						id: id,
						players: games[id]['players'],
						mode: games[id]['mode'],
						cases: games[id]['cases'],
						amount: games[id]['amount'],
						data: {}
					}
				});

				if(games[id].status == 1) continueGame(id);

				loggerTrace('[CASE BATTLE] Join registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));

				callback(null, newbalance);
			});
		});
	});
}

/* ----- CLIENT USAGE ----- */
function leaveGame(user, socket, id, position, cooldown){
	cooldown(true, true);

	/* CHECK DATA GAME */

	if(isNaN(Number(position))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid position!'
		});

		return cooldown(false, true);
	}

	position = parseInt(position);

	/* END CHECK DATA GAME */

	if(games[id] === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case battle id!'
		});

		return cooldown(false, true);
	}

	if(games[id].status != 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'This case battle are already ended!'
		});

		return cooldown(false, true);
	}

	var total_players = [ 2, 3, 4, 4 ][games[id].mode];

	if(position < 0 || position >= total_players) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'That position is invalid!'
		});

		return cooldown(false, true);
	}

	if(games[id].players.filter(a => a.position == position).length <= 0) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'That position is not taked!'
		});

		return cooldown(false, true);
	}

	if(games[id].players.find(a => a.position == position).user.userid != user.userid) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'That potition is not yours!'
		});

		return cooldown(false, true);
	}

	var remove_position = games[id]['players'].findIndex(a => a.position == position);

	if(games[id]['players'][remove_position]['creator'] && games[id]['players'].length > 1 && games[id]['free']) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'The creator can\'t leave a free case battle once others players already joined!'
		});

		return cooldown(false, true);
	}

	var amount = getFormatAmount(games[id]['amount']);

	if(games[id]['free']) {
		if(games[id]['players'][remove_position]['creator']) amount = getFormatAmount(amount * total_players);
		else amount = 0;
	}

	//REGISTER BET
	userService.refundOriginalBet(user.userid, amount, 'casebattle', function(err1, newbalance){
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			return cooldown(false, true);
		}

		pool.query('UPDATE `casebattle_bets` SET `canceled` = 1 WHERE `gameid` = ' + pool.escape(games[id].id) + ' AND `position` = ' + position, function(err2){
			if(err2) {
				emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while leaving game (1)'
                });

				return cooldown(false, true);
			}

			pool.query('SELECT COUNT(*) AS `count` FROM `casebattle_bets` WHERE `gameid` = ' + pool.escape(games[id].id) + ' AND `canceled` = 0', function(err3, row3){
				if(err3) {
					emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while leaving game (2)'
                    });

					return cooldown(false, true);
				}

				if(row3[0].count <= 0){
					pool.query('UPDATE `casebattle_games` SET `canceled` = 1 WHERE `id` = ' + pool.escape(games[id].id), function(err4){
						if(err4) {
							emitSocketToUser(socket, 'message', 'error', {
                                message: 'An error occurred while leaving game (3)'
                            });

							return cooldown(false, true);
						}

						emitSocketToRoom('casebattle/' + id, 'casebattle', 'redirect', {
							action: 'leave'
						});

						if(!games[id].privacy){
							emitSocketToRoom('casebattle/list/active', 'casebattle', 'remove', {
								casebattle: {
									id: id
								}
							});
						}

						stats.active--;

						emitSocketToRoom('casebattle', 'casebattle', 'stats', {
							stats: stats
						});

						delete games[id];

						userService.updateBalance(user.userid, 'main', newbalance);

						loggerTrace('[CASE BATTLE] Leave Registed. Bet #' + id + ' was canceled');

						cooldown(false, false);
					});
				} else {
					games[id]['players'].splice(remove_position, 1);

					if(!games[id].privacy){
						emitSocketToRoom('casebattle/list/active', 'casebattle', 'edit', {
							status: games[id].status,
							casebattle: {
								id: id,
								players: games[id]['players'],
								mode: games[id]['mode'],
								cases: games[id]['cases'],
								amount: games[id]['amount'],
								free: games[id]['free'],
								time: games[id]['time'],
								data: {}
							}
						});
					}

					for(var i = 0; i < total_players; i++){
						if(games[id]['players'].filter(a => a.position == i).length <= 0){
							emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
								stage: 'position',
								status: games[id].status,
								position: i,
								casebattle: {
									id: id,
									players: games[id]['players'],
									mode: games[id]['mode'],
									cases: games[id]['cases'],
									amount: games[id]['amount'],
									data: {}
								}
							});
						}
					}

					userService.updateBalance(user.userid, 'main', newbalance);

					loggerTrace('[CASE BATTLE] Leave Registed. Bet #' + id + ' was updated');

					cooldown(false, false);
				}
			});
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function continueGame(id){
	delete secure[id];

	var total_players = [ 2, 3, 4, 4 ][games[id].mode];

	emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
		stage: 'refresh',
		status: games[id]['status'],
		casebattle: {
			id: id,
			players: games[id]['players'],
			mode: games[id]['mode'],
			cases: games[id]['cases'],
			amount: games[id]['amount'],
			data: {
				game: {
					server_seed_hashed: sha256(games[id].game.server_seed),
					nonce: games[id].id
				},
				draw: null
			}
		}
	});

	setTimeout(function(){
		fairService.generateEosSeed(function(data){
			games[id].status = 2;

			games[id].game.block = data.block;

			emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
				stage: 'refresh',
				status: games[id]['status'],
				casebattle: {
					id: id,
					players: games[id]['players'],
					mode: games[id]['mode'],
					cases: games[id]['cases'],
					amount: games[id]['amount'],
					data: {
						game: {
							server_seed_hashed: sha256(games[id].game.server_seed),
							block: games[id].game.block,
							nonce: games[id].id
						},
						draw: null
					}
				}
			});

			if(!games[id].privacy){
				emitSocketToRoom('casebattle/list/active', 'casebattle', 'edit', {
					status: games[id].status,
					casebattle: {
						id: id,
						players: games[id]['players'],
						mode: games[id]['mode'],
						cases: games[id]['cases'],
						amount: games[id]['amount'],
						free: games[id]['free'],
						time: games[id]['time'],
						data: {}
					}
				});
			}
		}, function(data){
			pool.query('UPDATE `casebattle_rolls` SET `removed` = 1 WHERE `gameid` = ' + pool.escape(games[id].id), function(err1) {
				if(err1) return;

				var seed = fairService.getCombinedSeed(games[id].game.server_seed, data.hash, games[id].id);
				var salt = fairService.generateSaltHash(seed);

				var roll = fairService.getRollCaseBattle(salt, games[id]['cases'].length, total_players);

				pool.query('INSERT INTO `casebattle_rolls` SET `gameid` = ' + pool.escape(games[id].id) + ', `blockid` = ' + pool.escape(data.block) + ', `public_seed` = ' + pool.escape(data.hash) + ', `roll` = ' + pool.escape(JSON.stringify(roll)) + ', `time` = ' + pool.escape(time()), function(err2) {
					if(err2) return;

					games[id].status = 3;

					emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
						stage: 'refresh',
						status: games[id]['status'],
						casebattle: {
							id: id,
							players: games[id]['players'],
							mode: games[id]['mode'],
							cases: games[id]['cases'],
							amount: games[id]['amount'],
							data: {
								game: {
									server_seed_hashed: sha256(games[id].game.server_seed),
									block: games[id].game.block,
									nonce: games[id].id
								},
								draw: null,
								countdown: config.games.games.casebattle.timer_countdown
							}
						}
					});

					setTimeout(function(){
						games[id].status = 4;

						games[id].game.public_seed = data.hash;
						games[id].game.block = data.block;

						var round = 0;
						var items = [];
						var winnings = [];

						roundRoll();

						function roundRoll(){
							games[id]['round'] = round;

							var caseitems = getItems(cases[games[id]['cases'][round].id].items);

							var tickets = generateTickets(caseitems);
							var total = tickets[tickets.length - 1].max;

							if(!games[id].privacy){
								emitSocketToRoom('casebattle/list/active', 'casebattle', 'edit', {
									status: games[id].status,
									casebattle: {
										id: id,
										players: games[id]['players'],
										mode: games[id]['mode'],
										cases: games[id]['cases'],
										amount: games[id]['amount'],
										free: games[id]['free'],
										time: games[id]['time'],
										data: {
											round: games[id]['round']
										}
									}
								});
							}

							var round_winnings = {};

							for(var i = 0; i < total_players; i++){
								var spinner = generateSpinner(caseitems);

								var roll_position = Math.floor(roll[round][i] * total) + 1;

								var winning_item = null;

								for(var j = 0; j < tickets.length; j++){
									if(roll_position >= tickets[j].min && roll_position <= tickets[j].max) {
										winning_item = {
											id: caseitems[j].id,
											name: caseitems[j].name,
											image: caseitems[j].image,
											price: getFormatAmount(caseitems[j].price),
											color: getColorByQuality(caseitems[j].quality)
										};

										break;
									}
								}

								spinner[99] = { image: winning_item.image };

								emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
									stage: 'position',
									status: games[id].status,
									position: i,
									casebattle: {
										id: id,
										players: games[id]['players'],
										mode: games[id]['mode'],
										cases: games[id]['cases'],
										amount: games[id]['amount'],
										data: {
											spinner: spinner,
											positions: getWinners(games[id]['players'], games[id]['mode'], games[id]['crazy']).reduce((acc, obj) => { return [ ...acc, ...obj.winners ] }, [])
										}
									}
								});

								round_winnings[i] = winning_item;
							}

							emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
								stage: 'roll',
								casebattle: {
									id: id
								}
							});

							emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
								stage: 'round',
								round: round,
								casebattle: {
									id: id
								}
							});

							setTimeout(function(){
								for(var i = 0; i < total_players; i++){
									var winning = getFormatAmount(round_winnings[i].price);

									games[id]['players'][games[id]['players'].slice().findIndex(a => a.position == i)].items.push(round_winnings[i]);
									games[id]['players'][games[id]['players'].slice().findIndex(a => a.position == i)].total = getFormatAmount(games[id]['players'][games[id]['players'].slice().findIndex(a => a.position == i)].total + winning);

                                    winnings.push(round_winnings[i].id);

									items.push({
										'caseid': games[id]['cases'][round].id,
										'itemid': round_winnings[i].id,
                                        'price': round_winnings[i].price,
										'position': i
									});
								}

								emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
									stage: 'items',
									players: games[id]['players'].slice().map(a => ({ position: a.position, item: a.items.slice(-1)[0], total: a.total })),
									positions: getWinners(games[id]['players'], games[id]['mode'], games[id]['crazy']).reduce((acc, obj) => { return [ ...acc, ...obj.winners ] }, []),
									casebattle: {
										id: id,
										mode: games[id]['mode']
									}
								});

								round++;

								setTimeout(function(){
									if(round >= games[id]['cases'].length) return roundFinish();

									roundRoll();
								}, 1000);
							}, 6000);
						}

						function roundFinish(){
							var winners_positions_all = getWinners(games[id]['players'], games[id]['mode'], games[id]['crazy']);

							if(winners_positions_all.length == 1) return drawFinish(0);

							fairService.generateEosSeed(function(data){
								games[id].status = 5;

								games[id].draw.block = data.block;

								emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
									stage: 'refresh',
									status: games[id]['status'],
									casebattle: {
										id: id,
										players: games[id]['players'],
										mode: games[id]['mode'],
										cases: games[id]['cases'],
										amount: games[id]['amount'],
										data: {
											game: {
												server_seed_hashed: sha256(games[id].game.server_seed),
												block: games[id].game.block,
												nonce: games[id].id
											},
											draw: {
												block: games[id].draw.block
											},
											winners: winners_positions_all.slice().reduce((acc, obj) => { return [ ...acc, ...obj.winners ] }, [])
										}
									}
								});
							}, function(data){
								pool.query('UPDATE `casebattle_draws` SET `removed` = 1 WHERE `gameid` = ' + pool.escape(games[id].id), function(err3) {
									if(err3) return;

									var seed = fairService.getCombinedSeed(games[id].game.server_seed, data.hash, games[id].id);
									var salt = fairService.generateSaltHash(seed);

									var roll = fairService.getRoll(salt, winners_positions_all.length);

									pool.query('INSERT INTO `casebattle_draws` SET `gameid` = ' + pool.escape(games[id].id) + ', `blockid` = ' + pool.escape(data.block) + ', `public_seed` = ' + pool.escape(data.hash) + ', `roll` = ' + pool.escape(JSON.stringify(roll)) + ', `time` = ' + pool.escape(time()), function(err4) {
										if(err4) return;

										games[id].draw.public_seed = data.hash;
										games[id].draw.block = data.block;

										drawFinish(roll);
									});
								});
							});

							function drawFinish(roll){
								var winners_positions = winners_positions_all.filter(a => a.position == roll)[0].winners;

								var winners = games[id]['players'].slice().filter(a => winners_positions.includes(a.position));
								var opponents = games[id]['players'].slice().filter(a => !winners_positions.includes(a.position));

								pool.query('UPDATE `casebattle_games` SET `ended` = 1 WHERE `id` = ' + pool.escape(games[id].id), function(err3){
									if(err3) return;

									var amount = games[id].amount;
									var winning = 0;

									games[id]['players'].forEach(function(item){
										winning = getFormatAmount(winning + item.total);
									});

									//FINISH BET
									start(0, function(err4){
										if(err4) return;

										finish(0, function(){
											pool.query('INSERT INTO `casebattle_items` SET `gameid` = ' + pool.escape(games[id].id) + ', `items` = ' + pool.escape(JSON.stringify(items)) + ', `time` = ' + pool.escape(time()), function(err5){
												if(err5) return;

												games[id].status = 6;

												emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
													stage: 'refresh',
													status: games[id]['status'],
													casebattle: {
														id: id,
														players: games[id]['players'],
														mode: games[id]['mode'],
														cases: games[id]['cases'],
														amount: games[id]['amount'],
														data: {
															game: {
																server_seed_hashed: sha256(games[id].game.server_seed),
																server_seed: games[id].game.server_seed,
																public_seed: games[id].game.public_seed,
																block: games[id].game.block,
																nonce: games[id].id
															},
															draw: games[id].draw,
															winners: winners.slice().map(a => a.position)
														}
													}
												});

												emitSocketToRoom('casebattle/' + id, 'casebattle', 'update', {
													stage: 'finish',
													casebattle: {
														id: id
													}
												});

												if(!games[id].privacy){
													emitSocketToRoom('casebattle/list/active', 'casebattle', 'edit', {
														status: games[id].status,
														casebattle: {
															id: id,
															players: games[id]['players'],
															mode: games[id]['mode'],
															cases: games[id]['cases'],
															amount: games[id]['amount'],
															free: games[id]['free'],
															time: games[id]['time'],
															data: {
																winners: winners.slice().map(a => a.position)
															}
														}
													});
												}

												setTimeout(function(){
													if(!games[id].privacy){
														emitSocketToRoom('casebattle/list/active', 'casebattle', 'remove', {
															casebattle: {
																id: id
															}
														});
													}

													stats.active--;

													emitSocketToRoom('casebattle', 'casebattle', 'stats', {
														stats: stats
													});

													delete games[id];
												}, config.games.games.casebattle.timer_delete * 1000);
											});
										});
									});

									function start(index, callback){
										if(index >= winners.length) return callback();

										var winnings_items = winnings;
										var winnings_amount = winning;
										var winnings_amount_add = 0;

										if(games[id]['mode'] == 3){
											winnings_items = [];

											winnings_amount = [
												getFormatAmount(winning / 2),
												getFormatAmount(winning - getFormatAmount(winning / 2))
											][winners[index].position % 2];

											winnings_amount_add = winnings_amount;
										}

										//FINISH BET
										userService.finishOriginalBet(winners[index].user.userid, amount, winnings_amount, winnings_amount_add, winnings_items, 'casebattle', {
											active: winners[index].bot == 0,
											visible: true,
											gameid: winners[index].id,
											countdown: 0
										}, function(err4, newxp, newbalance, items){
											if(err4) return;

                                            var items_winnings = items.slice().map(a => ({
                                                id: a.id,
                                                price: a.price
                                            }));

											pool.query('INSERT INTO `casebattle_winnings` SET `gameid` = ' + pool.escape(games[id].id) + ', `items` = ' + pool.escape(JSON.stringify(items_winnings)) + ', `amount` = ' + winnings_amount_add + ', `position` = ' + pool.escape(winners[index].position) + ', `time` = ' + pool.escape(time()), function(err5){
												if(err5) return;

                                                if(winnings_amount >= config.games.winning_to_chat){
                                                    var send_message = winners[index].user.name + ' won ' + getFormatAmountString(winnings_amount) + ' to case battle!';
                                                    chatService.writeSystemMessage(send_message, 'all', true, null);
                                                }

                                                emitSocketToRoom(winners[index].user.userid, 'message', 'success', {
                                                    message: 'The game of ' + getFormatAmountString(winnings_amount) + ' on case battle ended as win!'
                                                });

                                                loggerTrace('[CASE BATTLE] Win registed. ' + winners[index].user.name + ' did win $' + getFormatAmountString(winnings_amount));

												if(!winners[index].bot) {
                                                    userService.updateLevel(winners[index].user.userid, newxp);
                                                    userService.updateBalance(winners[index].user.userid, 'main', newbalance);

													return start(index + 1, callback);
												}

												userService.sellAllInventoryItem({ userid: winners[index].user.userid }, 0, items, [], function(err6, items_success){
													if(err6) return;

													var amount_sold = items_success.reduce(function(acc, val) { return getFormatAmount(acc + itemsService.items[val.itemid].price) }, 0);

													userService.editBalance(winners[index].user.userid, amount_sold, 'sell_items', function(err7){
														if(err7) return;

														start(index + 1, callback);
													});
												});
											});
										});
									}

									function finish(index, callback){
										if(index >= opponents.length) return callback();

										//FINISH BET
										userService.finishOriginalBet(opponents[index].user.userid, amount, 0, 0, [], 'casebattle', {
											active: opponents[index].bot == 0,
											visible: false,
											gameid: opponents[index].id,
											countdown: 0
										}, function(err4, newxp){
											if(err4) return;

											var cashback = getFormatAmount(getAmountCommission(amount, config.games.games.casebattle.cashback));

											userService.editBalance(opponents[index].user.userid, cashback, 'casebattle_cashback', function(err5, newbalance){
												if(err5) return;

                                                emitSocketToRoom(opponents[index].user.userid, 'message', 'error', {
                                                    message: 'The game of ' + getFormatAmountString(winning) + ' on case battle ended as lose!'
                                                });

                                                userService.updateLevel(opponents[index].user.userid, newxp);
												userService.updateBalance(opponents[index].user.userid, 'main', newbalance);

												return finish(index + 1, callback);
											});
										});
									}
								});
							}
						}
					}, config.games.games.casebattle.timer_countdown * 1000 + 1000);
				});
			});
		});
	}, config.games.games.casebattle.timer_wait_start * 1000 + 1000);
}

/* ----- INTERNAL USAGE ----- */
function generateTickets(items){
	var decimals = 0;
	items.forEach(function(item){
		if(countDecimals(item.chance) > decimals) decimals = countDecimals(item.chance);
	});

	var tickets = [];
	var total = 0;

	items.forEach(function(item){
		tickets.push({
			min: total + 1,
			max: total + item.chance * Math.pow(10, decimals)
		});

		total += item.chance * Math.pow(10, decimals);
	});

	return tickets;
}

/* ----- INTERNAL USAGE ----- */
function generateSpinner(items){
	var tickets = generateTickets(items);
	var total = tickets[tickets.length - 1].max;

	var spinner = [];

	for(var i = 0; i < 150; i++){
		var ticket = getRandomInt(1, total);

		for(var j = 0; j < tickets.length; j++){
			if(ticket >= tickets[j].min && ticket <= tickets[j].max) {
				spinner.push({
					image: items[j].image
				});
			}
		}
	}

	return spinner;
}

/* ----- CLIENT USAGE ----- */
function getFinishedGames(user, socket, cooldown){
	cooldown(true, true);

	pool.query('SELECT * FROM `casebattle_games` WHERE `ended` = 1 ORDER BY `id` DESC LIMIT 20', function(err1, row1) {
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
                message: 'An error occurred while getting finished games (1)'
            });

			return cooldown(false, true);
		}

		getGames(row1, 0, [], function(err2, battles){
			if(err2) {
				emitSocketToUser(socket, 'message', 'error', {
                    message: err2.message
                });

				return cooldown(false, true);
			}

			emitSocketToUser(socket, 'casebattle', 'list', {
				battles: battles
			});

			cooldown(false, false);
		});
	});
}

/* ----- CLIENT USAGE ----- */
function getMyGames(user, socket, cooldown){
	cooldown(true, true);

	pool.query('SELECT casebattle_games.* FROM `casebattle_games` INNER JOIN `casebattle_bets` ON casebattle_games.id = casebattle_bets.gameid WHERE casebattle_games.ended = 1 AND casebattle_bets.userid = ' + pool.escape(user.userid) + ' AND casebattle_bets.canceled = 0 ORDER BY casebattle_games.id DESC LIMIT 20', function(err1, row1) {
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
                message: 'An error occurred while getting my games (1)'
            });

			return cooldown(false, true);
		}

		getGames(row1, 0, [], function(err2, battles){
			if(err2) {
				emitSocketToUser(socket, 'message', 'error', {
                    message: err2.message
                });

				return cooldown(false, true);
			}

			var myactive = Object.values(games).filter(a => a.status != 5 && a.players.filter(b => b.user.userid == user.userid).length > 0);

			var myactive_battles = [];

			myactive.forEach(function(item){
				myactive_battles.push({
					status: item.status,
					casebattle: {
						id: item.battleid,
						players: item.players,
						mode: item.mode,
						cases: item.cases,
						amount: item.amount,
						free: item.free,
						crazy: item.crazy,
						time: parseInt(item.time),
						data: {}
					}
				})
			});

			emitSocketToUser(socket, 'casebattle', 'list', {
				battles: [ ...battles, ...myactive_battles]
			});

			cooldown(false, false);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function getGames(list, index, battles, callback){
	if(index >= list.length) return callback(null, battles);

    if(JSON.parse(list[index].cases).some(a => cases[a.id] === undefined)) return getGames(list, index + 1, battles, callback);

	var amount = getFormatAmount(list[index].amount);

	var listcases = [];
	JSON.parse(list[index].cases).forEach(function(item){
		listcases.push({
            id: item.id,
            name: cases[item.id].name,
            image: cases[item.id].image,
            price: getFormatAmount(cases[item.id].price)
        });
	});

	var mode = parseInt(list[index].mode);
	var privacy = parseInt(list[index].privacy);
	var free = parseInt(list[index].free);
	var crazy = parseInt(list[index].crazy);

	pool.query('SELECT * FROM `casebattle_bets` WHERE `gameid` = ' + pool.escape(list[index].id) + ' AND `canceled` = 0', function(err1, row1) {
		if(err1) return callback(new Error('An error occurred while getting games (1)'));

		var players = [];

		row1.forEach(function(bet){
			players.push({
				user: {
					userid: bet.userid,
					name: bet.name,
					avatar: bet.avatar,
					level: calculateLevel(bet.xp).level
				},
				position: parseInt(bet.position),
				creator: parseInt(bet.creator),
				bot: parseInt(bet.bot),
				items: [],
				total: 0
			});
		});

		pool.query('SELECT `position` FROM `casebattle_winnings` WHERE `gameid` = ' + pool.escape(list[index].id), function(err2, row2) {
			if(err2) return callback(new Error('An error occurred while getting games (2)'));

			battles.push({
				status: 6,
				casebattle: {
					id: list[index].battleid,
					players: players,
					mode: mode,
					cases: listcases,
					amount: amount,
					free: free,
					crazy: crazy,
					time: parseInt(list[index].time),
					data: {
						winners: row2.slice().map(a => parseInt(a.position))
					}
				}
			});

			getGames(list, index + 1, battles, callback);
		});
	});
}

function getWinners(players, mode, crazy){
	if(mode == 3){
		var total_team = [
			{ position: 0, total: 0 },
			{ position: 1, total: 0 }
		];

		players.forEach(function(item){
			total_team[total_team.slice().findIndex(a => a.position == Math.floor(item.position / 2))].total = getFormatAmount(total_team[total_team.slice().findIndex(a => a.position == Math.floor(item.position / 2))].total + item.total);
		});

		if(crazy){
			var min_total_team = getFormatAmount(total_team.slice().sort(function(a, b){ return getFormatAmount(a.total - b.total) })[0].total);
			return total_team.slice().filter(a => a.total <= min_total_team).sort(function(a, b){ return a.position - b.position }).map((a, i) => ({ position: i, winners: [ [0, 1], [2, 3] ][a.position] }));
		}

		var max_total_team = getFormatAmount(total_team.slice().sort(function(a, b){ return getFormatAmount(b.total - a.total) })[0].total);
		return total_team.slice().filter(a => a.total >= max_total_team).sort(function(a, b){ return a.position - b.position }).map((a, i) => ({ position: i, winners: [ [0, 1], [2, 3] ][a.position] }));
	}

	if(crazy){
		var min_total = getFormatAmount(players.slice().sort(function(a, b){ return getFormatAmount(a.total - b.total) })[0].total);
		return players.slice().filter(a => a.total <= min_total).sort(function(a, b){ return a.position - b.position }).map((a, i) => ({ position: i, winners: [ a.position ] }));
	}

	var max_total = getFormatAmount(players.slice().sort(function(a, b){ return getFormatAmount(b.total - a.total) })[0].total);
	return players.slice().filter(a => a.total >= max_total).sort(function(a, b){ return a.position - b.position }).map((a, i) => ({ position: i, winners: [ a.position ] }));
}

module.exports = {
	cases, games, secure, stats,
	loadCases, loadStats, confirmJoinGame, getWinners,
	getCases, sendEmoji, showGame, createGame, joinGame, leaveGame, getFinishedGames, getMyGames
};