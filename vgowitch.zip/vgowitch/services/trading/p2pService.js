var request = require('request');

var { pool } = require('@/lib/database.js');
var { emitSocketToUser, emitSocketToRoom } = require('@/lib/socket.js');
var { loggerInfo, loggerDebug, loggerError } = require('@/lib/logger.js');

var userService = (({ updateBalance, getBalance, editBalance, registerAffiliates, registerDepositBonus }) => ({ updateBalance, getBalance, editBalance, registerAffiliates, registerDepositBonus }))(require('@/services/userService.js'));

var inventoryService = (({ p2pItems, verifyWebapiToken, checkDepositByGames, loadUserInventory, getAssetids }) => ({ p2pItems, verifyWebapiToken, checkDepositByGames, loadUserInventory, getAssetids }))(require('@/services/trading/inventoryService.js'));

var { makeDate, getSteamTime, time } = require('@/utils/formatDate.js');
var { getFormatAmount, getFormatAmountString } = require('@/utils/formatAmount.js');
var { haveRankPermission, verifyRecaptcha, calculateLevel, isJsonString } = require('@/utils/utils.js');

var config = require('@/config/config.js');

var listings = {};
var checking = false;
var tracking = false;

function getPendings(userid){
	var pendings = [];

	//DEPOSIT
	Object.keys(listings).filter(a => listings[a].seller.user.userid == userid).forEach(function(key){
		var data = {};

		if(listings[key].status == 0) data.time = listings[key].create;
		if(listings[key].status == 1) data.time = listings[key].time + config.trading.p2p.timer_confirm;

		if(listings[key].status == 1 || listings[key].status == 2 || listings[key].status == 3) {
			data.user = listings[key].buyer.user;
			data.steamid = listings[key].buyer.steamid;
		}

		if(listings[key].status == 2 || listings[key].status == 3) {
			data.time = listings[key].time + config.trading.p2p.timer_send;
			data.tradelink = listings[key].tradelink;
		}

		if(listings[key].status == 4) data.time = getSteamTime(listings[key].update + config.trading.p2p.timer_clear);

		pendings.push({
			id: listings[key].id,
			type: 'deposit',
			method: 'p2p',
			game: listings[key].game,
			status: listings[key].status,
			items: listings[key].items,
			data: data
		});
	});

	//WITHDRAW
	Object.keys(listings).filter(a => listings[a].buyer.user !== undefined && listings[a].buyer.user.userid == userid).forEach(function(key){
		var data = {};

		if(listings[key].status == 1) data.time = listings[key].time + config.trading.p2p.timer_confirm;
		if(listings[key].status == 2 || listings[key].status == 3) data.time = listings[key].time + config.trading.p2p.timer_send;
		if(listings[key].status == 3) data.tradeoffer = 'https://steamcommunity.com/tradeoffer/' + listings[key].tradeofferid;
        if(listings[key].status == 4) data.time = getSteamTime(listings[key].update + config.trading.p2p.timer_clear);

		pendings.push({
			id: listings[key].id,
			type: 'withdraw',
			method: 'p2p',
			status: listings[key].status,
			items: listings[key].items,
			data: data
		});
	});

	return pendings;
}

/* ----- INTERNAL USAGE ----- */
function generatePendingItem(item){
    if(item.accepted === undefined) item.accepted = true;
    if(item.inspect === undefined) item.inspect = null;

    item.offset = 0;

    item.tradelocked = null;

	return item;
}

function initializeListings(){
	loggerDebug('[P2P] Loading Listings');

	pool.query('SELECT * FROM `p2p_transactions` WHERE `status` IN (0, 1, 2, 3, 4)', function(err1, row1) {
		if(err1) return;

		row1.forEach(function(item){
			var items = JSON.parse(item.items);
			var amount = getFormatAmount(item.amount);

			items.forEach(function(item){
				if(inventoryService.p2pItems[item.id] === undefined) inventoryService.p2pItems[item.id] = true;
			});

			listings[item.id] = {
				id: item.id,
				status: item.status,
				seller: {
					user: {
						userid: item.userid,
						name: item.name,
						avatar: item.avatar,
						level: calculateLevel(item.xp).level
					},
					steamid: item.steamid,
					webapi_token: item.webapi_token,
					tradelink: item.tradelink
				},
				buyer: {},
				game: item.game,
				items: items,
				amount: amount,
				create: parseInt(item.time),
				update: parseInt(item.update),
				tradeofferid: item.tradeofferid || null,
				time: null,
				timeout: null
			};

			if(item.status == 1 || item.status == 2 || item.status == 3) listings[item.id].time = time();
			if(item.status == 0) {
				loggerInfo('[P2P] Offer Listed. Offer #' + item.id + ' waiting for buyer user');
			} else if(item.status == 1) {
				loggerInfo('[P2P] Offer Bought. Offer #' + item.id + ' waiting for seller user confirmation');

				listings[item.id].timeout = setTimeout(function(){
					cancelConfirmation(item.id);
				}, config.trading.p2p.timer_confirm * 1000);
			} else if(item.status == 2) {
				loggerInfo('[P2P] Tracking Started. Offer #' + item.id + ' has been confirmed by seller user');

				listings[item.id].timeout = setTimeout(function(){
					cancelBuyer(item.id);
				}, config.trading.p2p.timer_send * 1000);
			} else if(item.status == 3) {
				loggerInfo('[P2P] Trade Found. Offer #' + item.id + ' has been sent and waiting for acceptance');
			} else if(item.status == 4) {
				loggerInfo('[P2P] Trade Accepted. Offer #' + item.id + ' waiting for clearing the protection period');
			}

			if(item.status != 0) {
				pool.query('SELECT * FROM `p2p_buyers` WHERE `offerid` = ' + pool.escape(item.id) + ' AND `canceled` = 0', function(err2, row2) {
					if(err2) return;

					if(row2.length > 0){
						listings[item.id].buyer = {
							user: {
								userid: row2[0].userid,
								name: row2[0].name,
								avatar: row2[0].avatar,
								level: calculateLevel(row2[0].xp).level
							},
							steamid: row2[0].steamid,
							webapi_token: row2[0].webapi_token,
							tradelink: row2[0].tradelink
						};
					}
				});
			}
		});

		if(config.trading.p2p.listing_validity.enable) startCheckingListings();
	});
}

/* ----- INTERNAL USAGE ----- */
async function startCheckingListings(){
	if(checking) return;
	checking = true;

	var props = Object.keys(listings);

	for(var i = 0; i < props.length; i++) {
		await checkListing(props[i]).catch(function(err1){
            loggerError(err1);
		});
	}

	checking = false;

	setTimeout(function(){
		startCheckingListings();
	}, config.trading.p2p.listing_validity.cooldown_checking * 1000);
}

/* ----- INTERNAL USAGE ----- */
function checkListing(listing){
	return new Promise(function(resolve, reject) {
		if(listings[listing].status != 0) return resolve();

		loggerDebug('[P2P] Checking Listing #' + listing);

		inventoryService.getAssetids(listings[listing].seller.steamid, config.trading.steam.games[listings[listing].game].game.appid, config.trading.steam.games[listings[listing].game].game.contextid, function(err1, assetsids){
			if(err1) return reject(err1);

			var active = listings[listing].items.length == listings[listing].items.slice().filter(a => assetsids.includes(a.id)).length;

			if(active){
				loggerInfo('[P2P] Listing Checked Successfully. Listing #' + listing + ' Still Active');

				return resolve();
			}

			pool.query('UPDATE `p2p_transactions` SET `status` = -1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(listing) + ' AND `status` = 0', function(err2, row2) {
				if(err2) return reject(new Error('An error occurred while checking listing (1)'));

				if(row2.affectedRows <= 0) return reject(new Error('An error occurred while checking listing (2)'));

				listings[listing].status = -1;
				listings[listing].update = time();

				//REMOVE ITEMS FROM WITHDRAW
				emitSocketToRoom('withdraw/p2p/' + listings[listing].game, 'offers', 'remove_items', {
					offer: {
						items: [{
							id: listings[listing].id
						}],
						all: false
					}
				});

				var items = listings[listing].items.filter(a => assetsids.includes(a.id));

				//ADD ITEMS TO DEPOSIT
				emitSocketToRoom('deposit/p2p/' + listings[listing].game + '/' + listings[listing].seller.user.userid, 'offers', 'add_items', {
					offer: {
						items: items.map(a => generatePendingItem(a)),
						more: true
					}
				});

				//EDIT PENDING FROM SELLER
				emitSocketToRoom(listings[listing].seller.user.userid, 'offers', 'edit_pending', {
					offer: {
						id: listings[listing].id,
						type: 'deposit',
						method: 'p2p',
                        game: listings[listing].game,
						status: listings[listing].status,
						items: listings[listing].items,
						data: {}
					}
				});

				//REMOVE ITEMS BLACKLIST
				items.forEach(function(item){
					delete inventoryService.p2pItems[item.id];
				});

				setTimeout(function(){
					if(listings[listing] !== undefined){
						//REMOVE PENDING FROM SELLER
						emitSocketToRoom(listings[listing].seller.user.userid, 'offers', 'remove_pending', {
							offer: {
								id: listings[listing].id,
								method: 'p2p'
							}
						});

						//REMOVE LISTING
						delete listings[listing];
					}
				}, config.trading.steam.time_remove_pending * 1000);

				loggerInfo('[P2P] Listing Canceled. Listing #' + listing + ' has been canceled by server. Invalid items');

				resolve();
			});
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function cancelConfirmation(id){
	pool.query('UPDATE `p2p_transactions` SET `status` = 0, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(id) + ' AND `status` = 1', function(err1, row1) {
		if(err1) return;

		if(row1.affectedRows > 0){
			pool.query('UPDATE `p2p_buyers` SET `canceled` = 1 WHERE `offerid` = ' + pool.escape(id) + ' AND `canceled` = 0', function(err2, row2) {
				if(err2) return;

				if(row2.affectedRows > 0){
					var amount = getFormatAmount(listings[id].amount);

					//EDIT BALANCE
					userService.editBalance(listings[id].buyer.user.userid, amount, 'p2p_withdraw_refund', function(err3, newbalance){
						if(err3) return;

						userService.updateBalance(listings[id].buyer.user.userid, 'main', newbalance);

                        emitSocketToRoom(listings[id].seller.user.userid, 'message', 'success', {
                            message: 'The P2P deposit #' + id + ' was successfully canceled. Reason: Seller did not confirm the bought.'
                        });

                        emitSocketToRoom(listings[id].buyer.user.userid, 'message', 'success', {
                            message: 'The P2P withdraw #' + id + ' was successfully canceled. Reason: Seller did not confirm the bought.'
                        });

                        if(listings[id] !== undefined) {
                            if(listings[id].timeout != null) clearTimeout(listings[id].timeout);

                            listings[id].status = 0;
				            listings[id].update = time();
                            listings[id].time = null;
                            listings[id].timeout = null;

                            //ADD ITEMS TO WITHDRAW
                            emitSocketToRoom('withdraw/p2p/' + listings[id].game, 'offers', 'add_items', {
                                offer: {
                                    items: [{
                                        id: listings[id].id,
                                        items: listings[id].items,
                                        amount: listings[id].amount,
                                        time: listings[id].create,
                                        game: listings[id].game
                                    }],
                                    more: true
                                }
                            });

                            //REMOVE ITEMS FROM DEPOSIT
                            emitSocketToRoom('deposit/p2p/' + listings[id].game + '/' + listings[id].seller.user.userid, 'offers', 'remove_items', {
                                offer: {
                                    items: listings[id].items,
                                    all: false
                                }
                            });

                            //EDIT PENDING FROM SELLER
                            emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'edit_pending', {
                                offer: {
                                    id: listings[id].id,
                                    type: 'deposit',
                                    method: 'p2p',
                                    game: listings[id].game,
                                    status: listings[id].status,
                                    items: listings[id].items,
                                    data: {
                                        time: listings[id].create
                                    }
                                }
                            });

                            //EDIT PENDING FROM	BUYER
                            emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'edit_pending', {
                                offer: {
                                    id: listings[id].id,
                                    type: 'withdraw',
                                    method: 'p2p',
                                    game: listings[id].game,
                                    status: listings[id].status,
                                    items: listings[id].items,
                                    data: {}
                                }
                            });

                            loggerInfo('[P2P] Offer Confirmation Canceled. Offer #' + id + ' confirmation has been canceled by unconfirmed offer by seller');
                        }
					});
				}
			})
		}
	});
}

/* ----- INTERNAL USAGE ----- */
function cancelBuyer(id){
	pool.query('UPDATE `p2p_transactions` SET `status` = -1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(id) + ' AND (`status` = 2 OR `status` = 3)', function(err1, row1) {
		if(err1) return;

		if(row1.affectedRows > 0){
			pool.query('UPDATE `p2p_buyers` SET `canceled` = 1 WHERE `offerid` = ' + pool.escape(id) + ' AND `canceled` = 0', function(err2, row2) {
				if(err2) return;

				if(row2.affectedRows > 0){
					var amount = getFormatAmount(listings[id].amount);

					//EDIT BALANCE
					userService.editBalance(listings[id].buyer.user.userid, amount, 'p2p_withdraw_refund', function(err3, newbalance){
						if(err3) return;

						userService.updateBalance(listings[id].buyer.user.userid, 'main', newbalance);

                        emitSocketToRoom(listings[id].seller.user.userid, 'message', 'success', {
                            message: 'The P2P deposit #' + id + ' was successfully canceled. Reason: Seller did not sent the items.'
                        });

                        emitSocketToRoom(listings[id].buyer.user.userid, 'message', 'success', {
                            message: 'The P2P withdraw #' + id + ' was successfully canceled. Reason: Seller did not sent the items.'
                        });

                        if(listings[id] !== undefined) {
                            if(listings[id].timeout != null) clearTimeout(listings[id].timeout);

                            listings[id].status = -1;
				            listings[id].update = time();
                            listings[id].time = null;
                            listings[id].timeout = null;

                            //REMOVE ITEMS FROM WITHDRAW
                            emitSocketToRoom('withdraw/p2p/' + listings[id].game, 'offers', 'remove_items', {
                                offer: {
                                    items: [{
                                        id: listings[id].id
                                    }],
                                    all: false
                                }
                            });

                            //ADD ITEMS TO DEPOSIT
                            emitSocketToRoom('deposit/p2p/' + listings[id].game + '/' + listings[id].seller.user.userid, 'offers', 'add_items', {
                                offer: {
                                    items: listings[id].items.map(a => generatePendingItem(a)),
                                    more: true
                                }
                            });

                            //EDIT PENDING FROM SELLER
                            emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'edit_pending', {
                                offer: {
                                    id: listings[id].id,
                                    type: 'deposit',
                                    method: 'p2p',
                                    game: listings[id].game,
                                    status: listings[id].status,
                                    items: listings[id].items,
                                    data: {}
                                }
                            });

                            //EDIT PENDING FROM BUYER
                            emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'edit_pending', {
                                offer: {
                                    id: listings[id].id,
                                    type: 'withdraw',
                                    method: 'p2p',
                                    game: listings[id].game,
                                    status: listings[id].status,
                                    items: listings[id].items,
                                    data: {}
                                }
                            });

                            //REMOVE ITEMS BLACKLIST
                            listings[id].items.forEach(function(item){
                                delete inventoryService.p2pItems[item.id];
                            });

                            setTimeout(function(){
                                if(listings[id] !== undefined){
                                    //REMOVE PENDING FROM SELLER
                                    emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'remove_pending', {
                                        offer: {
                                            id: listings[id].id,
                                            method: 'p2p'
                                        }
                                    });

                                    //REMOVE PENDING FROM BUYER
                                    emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'remove_pending', {
                                        offer: {
                                            id: listings[id].id,
                                            method: 'p2p'
                                        }
                                    });

                                    //REMOVE LISTING
                                    delete listings[id];
                                }
                            }, config.trading.steam.time_remove_pending * 1000);

                            loggerInfo('[P2P] Offer Canceled. Offer #' + id + ' has been canceled by unsent trade');
                        }
					});
				}
			})
		}
	});
}

async function startTrackingListings(){
	if(tracking) return;
	tracking = true;

	var props = Object.keys(listings);

	for(var i = 0; i < props.length; i++) {
		await trackListing(props[i]).catch(function(err1){
			loggerError(err1);
		});
	}

	tracking = false;

	setTimeout(function(){
		startTrackingListings();
	}, config.trading.p2p.cooldown_tracking * 1000);
}

/* ----- INTERNAL USAGE ----- */
function trackListing(listing){
	return new Promise(function(resolve, reject) {
		if(listings[listing] === undefined) return resolve();
		if(listings[listing].status != 2 && listings[listing].status != 3) return resolve();

		loggerDebug('[P2P] Tracking Listing #' + listing);

		trackOffer(listings[listing].seller.webapi_token, listings[listing].buyer.tradelink, 'sent', function(err1, success1){
			if(err1) return reject(err1);

			if(success1) return resolve();

			trackOffer(listings[listing].buyer.webapi_token, listings[listing].seller.tradelink, 'received', function(err2, success2){
				if(err2) return reject(err2);

				return resolve();
			});
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function trackOffer(id, webapi_token, tradelink, type, callback){
	if(type == 'sent') var options = 'https://api.steampowered.com/IEconService/GetTradeOffers/v1?access_token=' + webapi_token + '&get_sent_offers=1&active_only=0';
	else if(type == 'received') var options = 'https://api.steampowered.com/IEconService/GetTradeOffers/v1?access_token=' + webapi_token + '&get_received_offers=1&active_only=0';

	request(options, function(err1, response1, body1) {
		if(err1) {
            loggerError(err1);

            return callback(new Error('An error occurred while tracking offer (1)'));
        }

		if(!response1 || response1.statusCode != 200) return callback(new Error('An error occurred while tracking offer (2)'));
		if(!isJsonString(body1)) return callback(new Error('An error occurred while tracking offer (3)'));

		var body = JSON.parse(body1);

		if(type == 'sent') var user_offers = body.response.trade_offers_sent;
		else if(type == 'received') var user_offers = body.response.trade_offers_received;

		if(user_offers !== undefined){
			var partenerid = tradelink.split('partner=')[1].split('&token=')[0];

			var offers = user_offers.filter(a => a.time_created >= listings[id].create).sort(function(a, b){ return b.time_created - a.time_created }).filter(a => a.accountid_other == partenerid);

            iterate(0);

            function iterate(index){
                if(index >= offers) return callback(null, false);

                var trade_found = false;

				if(type == 'sent'){
                    trade_found = listings[id].items.every(a => offers[index].items_to_give.map(a => a.assetid.toString()).includes(a.id.toString()))
                } else if(type == 'received'){
                    trade_found = listings[id].items.every(a => offers[index].items_to_receive.map(a => a.assetid.toString()).includes(a.id.toString()))
                }

				if(!trade_found) return iterate(index + 1);

                if(offers[index].trade_offer_state == 2 && listings[id].status == 2) {
                    pool.query('UPDATE `p2p_transactions` SET `status` = 3, `tradeofferid` = ' + pool.escape(offers[index].tradeofferid) + ', `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(id) + ' AND `status` = 2', function(err2, row2) {
                        if(err2) return callback(new Error('An error occurred while tracking offer (4)'));

                        if(row2.affectedRows <= 0) return callback(new Error('An error occurred while tracking offer (5)'));

                        /**/

                        if(listings[id].timeout != null) clearTimeout(listings[id].timeout);

                        listings[id].status = 3;
				        listings[id].update = time();
                        listings[id].tradeofferid = offers[index].tradeofferid;

                        //EDIT PENDING FROM SELLER
                        emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'edit_pending', {
                            offer: {
                                id: listings[id].id,
                                type: 'deposit',
                                method: 'p2p',
                                game: listings[id].game,
                                status: listings[id].status,
                                items: listings[id].items,
                                data: {
                                    time: listings[id].time + config.trading.p2p.timer_send,
                                    user: listings[id].buyer.user,
                                    steamid: listings[id].buyer.steamid,
                                    tradelink: listings[id].buyer.tradelink
                                }
                            }
                        });

                        //EDIT PENDING FROM BUYER
                        emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'edit_pending', {
                            offer: {
                                id: listings[id].id,
                                type: 'withdraw',
                                method: 'p2p',
                                game: listings[id].game,
                                status: listings[id].status,
                                items: listings[id].items,
                                data: {
                                    time: listings[id].time + config.trading.p2p.timer_send,
                                    tradeoffer: 'https://steamcommunity.com/tradeoffer/' + listings[id].tradeofferid
                                }
                            }
                        });

                        /**/

                        loggerInfo('[P2P] Listing Tracked Successfully. Listing #' + id + ' found Trade #' + offers[index].tradeofferid + '. Status: Pending');

                        callback(null, true);
                    });
                } else if(offers[index].trade_offer_state == 3 && (listings[id].status == 2 || listings[id].status == 3)) {
                    if(listings[id].game != 'cs2'){
                        listings[id].status = 4;

                        return callback(null, true);
                    }

                    pool.query('UPDATE `p2p_transactions` SET `status` = 4, `tradeofferid` = ' + pool.escape(offers[index].tradeofferid) + ', `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(id) + ' AND (`status` = 2 OR `status` = 3)', function(err2, row2) {
                        if(err2) return callback(new Error('An error occurred while tracking offer (6)'));

                        /**/

                        if(listings[id].timeout != null) clearTimeout(listings[id].timeout);

                        listings[id].status = 4;
				        listings[id].update = time();
                        listings[id].tradeofferid = offers[index].tradeofferid;

                        //EDIT PENDING FROM SELLER
                        emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'edit_pending', {
                            offer: {
                                id: listings[id].id,
                                type: 'deposit',
                                method: 'p2p',
                                game: listings[id].game,
                                status: listings[id].status,
                                items: listings[id].items,
                                data: {
                                    time: getSteamTime(listings[id].update + config.trading.p2p.timer_clear)
                                }
                            }
                        });

                        //EDIT PENDING FROM BUYER
                        emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'edit_pending', {
                            offer: {
                                id: listings[id].id,
                                type: 'withdraw',
                                method: 'p2p',
                                game: listings[id].game,
                                status: listings[id].status,
                                items: listings[id].items,
                                data: {
                                    time: getSteamTime(listings[id].update + config.trading.p2p.timer_clear)
                                }
                            }
                        });

                        //REMOVE ITEMS BLACKLIST
                        listings[id].items.forEach(function(item){
                            delete inventoryService.p2pItems[item.id];
                        });

                        var days = Math.floor((getSteamTime(offers[index].update + config.trading.steam.time_clear_trade) - time()) / (24 * 60 * 60));
                        var hours = Math.floor((getSteamTime(offers[index].update + config.trading.steam.time_clear_trade) - time()) % (24 * 60 * 60) / (60 * 60));


                        loggerInfo('[P2P] Listing Tracked Successfully. Listing #' + id + ' found trade #' + offers[index].tradeofferid + '. Status: Clearing. | Clearing in ' + days + ' days and ' + hours + ' hours');

                        callback(null, true);
                    });
                } else if(offers[index].trade_offer_state == 3 && (listings[id].status == 2 || listings[id].status == 3 || listings[id].status == 4)) {
                    if(getSteamTime(listings[id].update + config.trading.p2p.timer_clear) > time() && listings[id].game == 'cs2') return callback(null, true);

                    var amount = getFormatAmount(listings[id].amount);

                    pool.query('UPDATE `p2p_transactions` SET `status` = 5, `tradeofferid` = ' + pool.escape(offers[index].tradeofferid) + ', `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(id) + ' AND (`status` = 2 OR `status` = 3 OR `status` = 4)', function(err2, row2) {
                        if(err2) return callback(new Error('An error occurred while tracking offer (7)'));

                        if(row2.affectedRows <= 0) return callback(new Error('An error occurred while tracking offer (8)'));

                        //EDIT BALANCE
                        userService.editBalance(listings[id].seller.user.userid, amount, 'p2p_deposit', function(err3, newbalance1){
                            if(err3) return callback(err3);

                            pool.query('UPDATE `users` SET `rollover` = `rollover` + ' + amount + ' WHERE `userid` = ' + pool.escape(listings[id].seller.user.userid), function(err4) {
                                if(err4) return callback(new Error('An error occurred while tracking offer (9)'));

                                //REGISTER AFFILIATES
                                userService.registerAffiliates(listings[id].seller.user.userid, amount, 'deposit', function(err5){
                                    if(err5) return callback(err5);

                                    //REGISTER DEPOSIT BONUS
                                    userService.registerDepositBonus(listings[id].seller.user.userid, amount, function(err6, newbalance2){
                                        if(err6) return callback(err6);

                                        if(newbalance2) userService.updateBalance(listings[id].seller.user.userid, 'main', newbalance2);
                                        else userService.updateBalance(listings[id].seller.user.userid, 'main', newbalance1);

                                        pool.query('INSERT INTO `users_trades` SET `type` = ' + pool.escape("deposit") + ', `method` = ' + pool.escape("p2p") + ', `game` = ' + pool.escape(listings[id].game) + ', `userid` = ' + pool.escape(listings[id].seller.user.userid) + ', `amount` = ' + amount + ', `value` = ' + amount + ', `tradeid` = ' + pool.escape(listings[id].id) + ', `time` = ' + pool.escape(time()), function(err7){
                                            if(err7) return callback(new Error('An error occurred while tracking offer (10)'));

                                            pool.query('INSERT INTO `users_trades` SET `type` = ' + pool.escape("withdraw") + ', `method` = ' + pool.escape("p2p") + ', `game` = ' + pool.escape(listings[id].game) + ', `userid` = ' + pool.escape(listings[id].buyer.user.userid) + ', `amount` = ' + amount + ', `value` = ' + amount + ', `tradeid` = ' + pool.escape(listings[id].id) + ', `time` = ' + pool.escape(time()), function(err8){
                                                if(err8) return callback(new Error('An error occurred while tracking offer (11)'));

                                                /**/

                                                if(listings[id].timeout != null) clearTimeout(listings[id].timeout);

                                                listings[id].status = 5;
                                                listings[id].update = time();
                                                listings[id].tradeofferid = offers[index].tradeofferid;

                                                //EDIT PENDING FROM SELLER
                                                emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'edit_pending', {
                                                    offer: {
                                                        id: listings[id].id,
                                                        type: 'deposit',
                                                        method: 'p2p',
                                                        game: listings[id].game,
                                                        status: listings[id].status,
                                                        items: listings[id].items,
                                                        data: {}
                                                    }
                                                });

                                                //EDIT PENDING FROM BUYER
                                                emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'edit_pending', {
                                                    offer: {
                                                        id: listings[id].id,
                                                        type: 'withdraw',
                                                        method: 'p2p',
                                                        game: listings[id].game,
                                                        status: listings[id].status,
                                                        items: listings[id].items,
                                                        data: {}
                                                    }
                                                });

                                                //REMOVE ITEMS BLACKLIST
                                                listings[id].items.forEach(function(item){
                                                    delete inventoryService.p2pItems[item.id];
                                                });

                                                setTimeout(function(){
                                                    if(listings[id] !== undefined){
                                                        //REMOVE PENDING FROM SELLER
                                                        emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'remove_pending', {
                                                            offer: {
                                                                id: listings[id].id,
                                                                method: 'p2p'
                                                            }
                                                        });

                                                        //REMOVE PENDING FROM BUYER
                                                        emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'remove_pending', {
                                                            offer: {
                                                                id: listings[id].id,
                                                                method: 'p2p'
                                                            }
                                                        });

                                                        //REMOVE LISTING
                                                        delete listings[id];
                                                    }
                                                }, config.trading.steam.time_remove_pending * 1000);

                                                loggerInfo('[P2P] Listing Tracked Successfully. Listing #' + id + ' found trade #' + offers[index].tradeofferid + '. Status: Confirmed');

                                                callback(null, true);
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                } else if(offers[index].trade_offer_state != 2 && offers[index].trade_offer_state != 9) {
                    loggerInfo('[P2P] Listing Tracked Successfully. Listing #' + id + ' found trade #' + offers[index].tradeofferid + '. Status: Declined');

                    cancelBuyer(id);

                    callback(null, true);
                }
            }
		}
	});
}

/* ----- CLIENT USAGE ----- */
function getListings(user, socket, game, cooldown){
	cooldown(true, true);

	if(config.trading.steam.games[game] === undefined){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid deposit game!'
		});

		return cooldown(false, true);
	}

	var listingslist = [];

	Object.keys(listings).filter(a => listings[a].game == game).forEach(function(key){
		var accepted = true;

		if(listings[key].status != 0) accepted = false;

		if(accepted){
			listingslist.push({
				id: listings[key].id,
				items: listings[key].items,
				amount: listings[key].amount,
				time: listings[key].create,
				game: listings[key].game
			});
		}
	});

	if(listingslist.length == 0){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'The Marketplace is currently empty.'
		});

		return cooldown(false, true);
	}

	emitSocketToUser(socket, 'offers', 'add_items', {
		offer: {
			items: listingslist,
			more: false
		}
	});

	cooldown(false, false);
}

/* ----- CLIENT USAGE ----- */
function placeDeposit(user, socket, itemsid, offset, game, recaptcha, cooldown){
	cooldown(true, true);

	if((user.restrictions.trade >= time() || user.restrictions.trade == -1) && !haveRankPermission('exclude_ban_trade', user.rank)){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You are restricted to use our trade. The restriction expires ' + ((user.restrictions.trade == -1) ? 'never' : makeDate(new Date(user.restrictions.trade * 1000))) + '.'
		});

		return cooldown(false, true);
	}

	if(user.exclusion > time()){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'
		});

		return cooldown(false, true);
	}

	if(isNaN(Number(offset))){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid offset!'
		});

		return cooldown(false, true);
	}

	offset = parseInt(offset);

	if(offset < -10 || offset > 10){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid offset [-10 - 10]!'
		});

		return cooldown(false, true);
	}

	if(itemsid.length < config.app.intervals.items.p2p.min || itemsid.length > config.app.intervals.items.p2p.max) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid items amount [' + config.app.intervals.items.p2p.min + '-' + config.app.intervals.items.p2p.max + ']!'
		});

		return cooldown(false, true);
	}

	verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid recaptcha!'
			});

			return cooldown(false, true);
		}

		if(config.trading.steam.games[game] === undefined){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid deposit game!'
			});

			return cooldown(false, true);
		}

		if(user.binds.steam === undefined) {
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Please bind your Steam Account!'
			});

			emitSocketToUser(socket, 'modal', 'bind_steam');

			return cooldown(false, true);
		}

		if(!user.tradelink){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Firstly, you must set your valid Steam Trade Link from settings.'
			});

			emitSocketToUser(socket, 'modal', 'steam_tradelink');

			return cooldown(false, true);
		}

		inventoryService.verifyWebapiToken(user, user.webapi_token, function(err1){
			if(err1){
				emitSocketToUser(socket, 'message', 'error', {
					message: 'Firstly, you must set your valid Steam WebAPI Token from settings.'
				});

				emitSocketToUser(socket, 'modal', 'steam_webapi_token');

				return cooldown(false, true);
			}

			inventoryService.checkDepositByGames(user.binds.steam, game, 0, itemsid, offset, [], function(err2, response){
				if(err2) {
					emitSocketToUser(socket, 'message', 'error', {
						message: err2.message
					});

					return cooldown(false, true);
				}

                var amount = response.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0);

				if(response.length != itemsid.length){
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Invalids items in your offer. Please refresh your inventory!'
					});

					return cooldown(false, true);
				}

				if(amount < config.app.intervals.amounts.deposit_p2p.min || amount > config.app.intervals.amounts.deposit_p2p.max) {
					emitSocketToUser(socket, 'message', 'error', {
						message: 'Invalid deposit amount [' + getFormatAmountString(config.app.intervals.amounts.deposit_p2p.min) + '-' + getFormatAmountString(config.app.intervals.amounts.deposit_p2p.max) + ']!'
					});

					return cooldown(false, true);
				}

				/**/

                iterate(0, function(err3){
                    if(err3) {
                        emitSocketToUser(socket, 'message', 'error', {
                            message: err3.message
                        });

                        return cooldown(false, true);
                    }

                    emitSocketToUser(socket, 'message', 'success', {
                        message: 'The P2P deposit was successfully listed.'
                    });

                    cooldown(false, false);
                });

                function iterate(itemid, callback){
                    if(itemid >= response.length) return callback(null);

                    pool.query('INSERT INTO `p2p_transactions` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + pool.escape(user.xp) + ', `steamid` = ' + pool.escape(user.binds.steam) + ', `webapi_token` = ' + pool.escape(user.webapi_token) + ', `tradelink` = ' + pool.escape(user.tradelink) + ', `items` = ' + pool.escape(JSON.stringify([ response[itemid] ])) + ', `amount` = ' + response[itemid].price + ', `game` = ' + pool.escape(game) + ', `update` = ' + pool.escape(time()) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
                        if(err3) return callback(new Error('An error occurred while placing deposit (1)'));

                        if(row3.affectedRows <= 0) return callback(new Error('An error occurred while placing deposit (2)'));

                        if(inventoryService.p2pItems[response[itemid].id] === undefined) inventoryService.p2pItems[response[itemid].id] = true;

                        listings[row3.insertId] = {
                            id: row3.insertId,
                            status: 0,
                            seller: {
                                user: {
                                    userid: user.userid,
                                    name: user.name,
                                    avatar: user.avatar,
                                    level: calculateLevel(user.xp).level
                                },
                                steamid: user.binds.steam,
                                webapi_token: user.webapi_token,
                                tradelink: user.tradelink
                            },
                            buyer: {},
                            game: game,
                            items: [ response[itemid] ],
                            amount: response[itemid].price,
                            create: time(),
                            update: time(),
                            tradeofferid: null,
                            time: null,
                            timeout: null
                        };

                        //ADD ITEMS TO WITHDRAW
                        emitSocketToRoom('withdraw/p2p/' + listings[row3.insertId].game, 'offers', 'add_items', {
                            offer: {
                                items: [{
                                    id: listings[row3.insertId].id,
                                    items: listings[row3.insertId].items,
                                    amount: listings[row3.insertId].amount,
                                    time: listings[row3.insertId].create,
                                    game: listings[row3.insertId].game
                                }],
                                more: true
                            }
                        });

                        //REMOVE ITEMS FROM DEPOSIT
                        emitSocketToRoom('deposit/p2p/' + listings[row3.insertId].game + '/' + listings[row3.insertId].seller.user.userid, 'offers', 'remove_items', {
                            offer: {
                                items: listings[row3.insertId].items,
                                all: false
                            }
                        });

                        //EDIT PENDING FROM SELLER
                        emitSocketToRoom(listings[row3.insertId].seller.user.userid, 'offers', 'add_pending', {
                            offer: {
                                id: listings[row3.insertId].id,
                                type: 'deposit',
                                method: 'p2p',
                                game: listings[row3.insertId].game,
                                status: listings[row3.insertId].status,
                                items: listings[row3.insertId].items,
                                data: {
                                    time: listings[row3.insertId].create
                                }
                            }
                        });

                        loggerInfo('[P2P] Offer Listed. Offer #' + row3.insertId + ' waiting for buyer user');

                        iterate(itemid + 1, callback);
                    });
                }

				/**/

			});
		});
	});
}

/* ----- CLIENT USAGE ----- */
function cancelDeposit(user, socket, id, recaptcha, cooldown){
	cooldown(true, true);

	verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid recaptcha!'
			});

			return cooldown(false, true);
		}

		/**/

		pool.query('SELECT * FROM `p2p_transactions` WHERE `id` = ' + pool.escape(id) + ' AND `status` = 0', function(err1, row1) {
			if(err1) {
				emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while canceling deposit (1)'
                });

				return cooldown(false, true);
			}

			if(row1.length <= 0) {
				emitSocketToUser(socket, 'message', 'error', {
					message: 'This P2P deposit can\'t be canceled.'
				});

				return cooldown(false, true);
			}

			if(listings[id] === undefined) {
				emitSocketToUser(socket, 'message', 'error', {
					message: 'This P2P deposit can\'t be canceled.'
				});

				return cooldown(false, true);
			}

			if(listings[id].status != 0) {
				emitSocketToUser(socket, 'message', 'error', {
					message: 'This P2P deposit can\'t be canceled.'
				});

				return cooldown(false, true);
			}

			pool.query('UPDATE `p2p_transactions` SET `status` = -1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(id) + ' AND `status` = 0', function(err2, row2) {
				if(err2) {
					emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while canceling deposit (2)'
                    });

					return cooldown(false, true);
				}

				if(row2.affectedRows <= 0) {
					emitSocketToUser(socket, 'message', 'error', {
						message: 'This P2P deposit can\'t be canceled.'
					});

					return cooldown(false, true);
				}

				listings[id].status = -1;
				listings[id].update = time();

				emitSocketToUser(socket, 'message', 'success', {
					message: 'The P2P deposit #' + id + ' was successfully canceled.'
				});

				//REMOVE ITEMS FROM WITHDRAW
				emitSocketToRoom('withdraw/p2p/' + listings[id].game, 'offers', 'remove_items', {
					offer: {
						items: [{
							id: listings[id].id
						}],
						all: false
					}
				});

				//ADD ITEMS TO DEPOSIT
				emitSocketToRoom('deposit/p2p/' + listings[id].game + '/' + listings[id].seller.user.userid, 'offers', 'add_items', {
					offer: {
						items: listings[id].items.map(a => generatePendingItem(a)),
						more: true
					}
				});

				//EDIT PENDING FROM SELLER
				emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'edit_pending', {
					offer: {
						id: listings[id].id,
						type: 'deposit',
						method: 'p2p',
                        game: listings[id].game,
						status: listings[id].status,
						items: listings[id].items,
						data: {}
					}
				});

				//REMOVE ITEMS BLACKLIST
				listings[id].items.forEach(function(item){
					delete inventoryService.p2pItems[item.id];
				});

				setTimeout(function(){
					if(listings[id] !== undefined){
						//REMOVE PENDING FROM SELLER
						emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'remove_pending', {
							offer: {
								id: listings[id].id,
								method: 'p2p'
							}
						});

						//REMOVE LISTING
						delete listings[id];
					}
				}, config.trading.steam.time_remove_pending * 1000);

				loggerInfo('[P2P] Offer Canceled. Offer #' + id + ' has been canceled by seller user');

				cooldown(false, false);
			});
		});

		/**/

	});
}

/* ----- CLIENT USAGE ----- */
function placeWithdraw(user, socket, id, recaptcha, cooldown){
	cooldown(true, true);

	if((user.restrictions.trade >= time() || user.restrictions.trade == -1) && !haveRankPermission('exclude_ban_trade', user.rank)){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You are restricted to use our trade. The restriction expires ' + ((user.restrictions.trade == -1) ? 'never' : makeDate(new Date(user.restrictions.trade * 1000))) + '.'
		});

		return cooldown(false, true);
	}

	verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid recaptcha!'
			});

			return cooldown(false, true);
		}

        if(user.binds.steam === undefined) {
            emitSocketToUser(socket, 'message', 'error', {
                message: 'Please bind your Steam Account!'
            });

            emitSocketToUser(socket, 'modal', 'bind_steam');

            return cooldown(false, true);
        }

        if(!user.tradelink){
            emitSocketToUser(socket, 'message', 'error', {
                message: 'Firstly, you must set your valid Steam Trade Link from settings.'
            });

            emitSocketToUser(socket, 'modal', 'steam_tradelink');

            return cooldown(false, true);
        }

        inventoryService.verifyWebapiToken(user, user.webapi_token, function(err1){
            if(err1){
                emitSocketToUser(socket, 'message', 'error', {
                    message: 'Firstly, you must set your valid Steam WebAPI Token from settings.'
                });

                emitSocketToUser(socket, 'modal', 'steam_webapi_token');

                return cooldown(false, true);
            }

            /**/

            pool.query('SELECT * FROM `p2p_transactions` WHERE `id` = ' + pool.escape(id) + ' AND `status` = 0', function(err2, row2) {
                if(err2) {
                    emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while placing withdraw (1)'
                    });

                    return cooldown(false, true);
                }

                if(row2.length <= 0) {
                    emitSocketToUser(socket, 'message', 'error', {
                        message: 'This P2P deposit can\'t be bought.'
                    });

                    return cooldown(false, true);
                }

                if(listings[id] === undefined) {
                    emitSocketToUser(socket, 'message', 'error', {
                        message: 'This P2P deposit can\'t be bought.'
                    });

                    return cooldown(false, true);
                }

                if(listings[id].status != 0) {
                    emitSocketToUser(socket, 'message', 'error', {
                        message: 'This P2P deposit can\'t be bought.'
                    });

                    return cooldown(false, true);
                }

                if(row2[0].userid == user.userid){
                    emitSocketToUser(socket, 'message', 'error', {
                        message: 'You can\'t buy your P2P offer.'
                    });

                    return cooldown(false, true);
                }

                pool.query('SELECT SUM(`amount`) AS `amount` FROM `users_trades` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `type` = ' + pool.escape('deposit') + ' AND `time` > ' + pool.escape(config.trading.withdraw_requirements.deposit.time == -1 ? 0 : time() - config.trading.withdraw_requirements.deposit.time), function(err3, row3) {
                    if(err3) {
                        emitSocketToUser(socket, 'message', 'error', {
                            message: 'An error occurred while placing withdraw (2)'
                        });

                        return cooldown(false, true);
                    }

                    if(getFormatAmount(row3[0].amount) < config.trading.withdraw_requirements.deposit.amount && !haveRankPermission('withdraw', user.rank)) {
                        if(config.trading.withdraw_requirements.deposit.time == -1) {
                            emitSocketToUser(socket, 'message', 'error', {
                                message: 'You need to deposit minimum ' + getFormatAmountString(config.trading.withdraw_requirements.deposit.amount) + ' coins to unlock withdraw!'
                            });
                        } else {
                            emitSocketToUser(socket, 'message', 'error', {
                                message: 'You need to deposit minimum ' + getFormatAmountString(config.trading.withdraw_requirements.deposit.amount) + ' coins in the last ' + Math.floor(config.trading.withdraw_requirements.deposit.time / (24 * 60 * 60)) + ' days to unlock withdraw!'
                            });
                        }

                        return cooldown(false, true);
                    }

                    //CHECK BALANCE
                    userService.getBalance(user.userid, function(err4, balance){
                        if(err4) {
                            emitSocketToUser(socket, 'message', 'error', {
                                message: err4.message
                            });

                            return cooldown(false, true);
                        }

                        if(balance < listings[id].amount) {
                            emitSocketToUser(socket, 'message', 'error', {
                                message: 'You don\'t have enough money!'
                            });

                            emitSocketToUser(socket, 'modal', 'insufficient_balance', {
                                amount: getFormatAmount(listings[id].amount - balance)
                            });

                            return cooldown(false, true);
                        }

                        if(user.rollover > 0 && !haveRankPermission('withdraw', user.rank)) {
                            emitSocketToUser(socket, 'message', 'error', {
                                message: 'You have to play ' + getFormatAmountString(user.rollover) + ' coins to withdraw!'
                            });

                            emitSocketToRoom(user.userid, 'modal', 'withdraw_rollover', {
                                amount: getFormatAmount(user.rollover)
                            });

                            return cooldown(false, true);
                        }

                        var amount = getFormatAmount(listings[id].amount);

                        //EDIT BALANCE
                        userService.editBalance(user.userid, -amount, 'p2p_withdraw', function(err5, newbalance){
                            if(err5) {
                                emitSocketToUser(socket, 'message', 'error', {
                                    message: err5.message
                                });

                                return cooldown(false, true);
                            }

                            userService.updateBalance(user.userid, 'main', newbalance);

                            pool.query('INSERT INTO `p2p_buyers` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + pool.escape(user.xp) + ', `steamid` = ' + pool.escape(user.binds.steam) + ', `webapi_token` = ' + pool.escape(user.webapi_token) + ', `tradelink` = ' + pool.escape(user.tradelink) + ', `offerid` = ' + pool.escape(id) + ', `time` = ' + pool.escape(time()), function(err6, row6) {
                                if(err6) {
                                    emitSocketToUser(socket, 'message', 'error', {
                                        message: 'An error occurred while placing withdraw (3)'
                                    });

                                    return cooldown(false, true);
                                }

                                if(row6.affectedRows <= 0) {
                                    emitSocketToUser(socket, 'message', 'error', {
                                        message: 'An error occurred while placing withdraw (4)'
                                    });

                                    return cooldown(false, true);
                                }

                                pool.query('UPDATE `p2p_transactions` SET `status` = 1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(id) + ' AND `status` = 0', function(err7, row7) {
                                    if(err7) {
                                        emitSocketToUser(socket, 'message', 'error', {
                                            message: 'An error occurred while placing withdraw (5)'
                                        });

                                        return cooldown(false, true);
                                    }

                                    if(row7.affectedRows <= 0) {
                                        emitSocketToUser(socket, 'message', 'error', {
                                            message: 'An error occurred while placing withdraw (6)'
                                        });

                                        return cooldown(false, true);
                                    }

                                    if(listings[id].timeout != null) clearTimeout(listings[id].timeout);

                                    listings[id].status = 1;
				                    listings[id].update = time();
                                    listings[id].buyer = {
                                        user: {
                                            userid: user.userid,
                                            name: user.name,
                                            avatar: user.avatar,
                                            level: calculateLevel(user.xp).level
                                        },
                                        steamid: user.binds.steam,
                                        webapi_token: user.webapi_token,
                                        tradelink: user.tradelink
                                    };
                                    listings[id].time = time();
                                    listings[id].timeout = setTimeout(function(){
                                        cancelConfirmation(id);
                                    }, config.trading.p2p.timer_confirm * 1000);

                                    emitSocketToUser(socket, 'message', 'success', {
                                        message: 'The P2P deposit #' + id + ' was successfully bought.'
                                    });

                                    //REMOVE ITEMS FROM WITHDRAW
                                    emitSocketToRoom('withdraw/p2p/' + listings[id].game, 'offers', 'remove_items', {
                                        offer: {
                                            items: [{
                                                id: listings[id].id
                                            }],
                                            all: false
                                        }
                                    });

                                    //EDIT PENDING FROM SELLER
                                    emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'edit_pending', {
                                        offer: {
                                            id: listings[id].id,
                                            type: 'deposit',
                                            method: 'p2p',
                                            game: listings[id].game,
                                            status: listings[id].status,
                                            items: listings[id].items,
                                            data: {
                                                time: listings[id].time + config.trading.p2p.timer_confirm,
                                                user: listings[id].buyer.user,
                                                steamid: listings[id].buyer.steamid,
                                                id: listings[id].id
                                            }
                                        }
                                    });

                                    //ADD PENDING TO BUYER
                                    emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'add_pending', {
                                        offer: {
                                            id: listings[id].id,
                                            type: 'withdraw',
                                            method: 'p2p',
                                            game: listings[id].game,
                                            status: listings[id].status,
                                            items: listings[id].items,
                                            data: {
                                                time: listings[id].time + config.trading.p2p.timer_confirm
                                            }
                                        }
                                    });

                                    loggerInfo('[P2P] Offer Bought. Offer #' + id + ' waiting for seller user confirmation');

                                    cooldown(false, false);
                                });
                            });
                        });
                    });
                });

                /**/

            });
        });
	});
}

/* ----- CLIENT USAGE ----- */
function confirmWithdraw(user, socket, id, recaptcha, cooldown){
	cooldown(true, true);

	verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid recaptcha!'
			});

			return cooldown(false, true);
		}

		/**/

		pool.query('SELECT * FROM `p2p_transactions` WHERE `id` = ' + pool.escape(id) + ' AND `status` = 1', function(err1, row1) {
			if(err1) {
				emitSocketToUser(socket, 'message', 'error', {
                    message: 'An error occurred while confirming withdraw (1)'
                });

				return cooldown(false, true);
			}

			if(row1.length <= 0) {
				emitSocketToUser(socket, 'message', 'error', {
					message: 'This P2P deposit can\'t be confirmed.'
				});

				return cooldown(false, true);
			}

			if(listings[id] === undefined) {
				emitSocketToUser(socket, 'message', 'error', {
					message: 'This P2P deposit can\'t be confirmed.'
				});

				return cooldown(false, true);
			}

			if(listings[id].status != 1) {
				emitSocketToUser(socket, 'message', 'error', {
					message: 'This P2P deposit can\'t be confirmed.'
				});

				return cooldown(false, true);
			}

			if(row1[0].userid != user.userid){
				emitSocketToUser(socket, 'message', 'error', {
					message: 'You can\'t confirm this P2P offer.'
				});

				return cooldown(false, true);
			}

			pool.query('UPDATE `p2p_transactions` SET `status` = 2, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(id) + ' AND `status` = 1', function(err2, row2) {
				if(err2) {
					emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while confirming withdraw (2)'
                    });

					return cooldown(false, true);
				}

				if(row2.affectedRows <= 0) {
					emitSocketToUser(socket, 'message', 'error', {
						message: 'An error occurred while confirming withdraw (3)'
					});

					return cooldown(false, true);
				}

				if(listings[id].timeout != null) clearTimeout(listings[id].timeout);

				listings[id].status = 2;
				listings[id].update = time();
				listings[id].time = time();
				listings[id].timeout = setTimeout(function(){
					cancelBuyer(id);
				}, config.trading.p2p.timer_send * 1000);

				emitSocketToUser(socket, 'message', 'success', {
					message: 'The P2P deposit #' + id + ' was successfully confirmed.'
				});

				//EDIT PENDING FROM SELLER
				emitSocketToRoom(listings[id].seller.user.userid, 'offers', 'edit_pending', {
					offer: {
						id: listings[id].id,
						type: 'deposit',
						method: 'p2p',
                        game: listings[id].game,
						status: listings[id].status,
						items: listings[id].items,
						data: {
							time: listings[id].time + config.trading.p2p.timer_send,
							user: listings[id].buyer.user,
							steamid: listings[id].buyer.steamid,
							tradelink: listings[id].buyer.tradelink
						}
					}
				});

				//EDIT PENDING FROM BUYER
				emitSocketToRoom(listings[id].buyer.user.userid, 'offers', 'edit_pending', {
					offer: {
						id: listings[id].id,
						type: 'withdraw',
						method: 'p2p',
                        game: listings[id].game,
						status: listings[id].status,
						items: listings[id].items,
						data: {
							time: listings[id].time + config.trading.p2p.timer_send
						}
					}
				});

				loggerInfo('[P2P] Tracking Started. Offer #' + id + ' has been confirmed by seller user');

				cooldown(false, false);
			});
		});

		/**/

	});
}

module.exports = {
	getPendings, initializeListings, startTrackingListings,
	getListings, placeDeposit, cancelDeposit, loadUserInventory: inventoryService.loadUserInventory,
	placeWithdraw, confirmWithdraw
}