var fs = require('fs');
var request = require('request');

var { loggerInfo, loggerDebug, loggerError } = require('@/lib/logger.js');

var { roundedToFixed } = require('@/utils/formatAmount.js');
var { isJsonString } = require('@/utils/utils.js');

var config = require('@/config/config.js');

var updating = {
	value: true
};

function initializePrices(){
	loggerDebug('[PRICES] Loading Prices');

	updating.value = true;

	loadPrices(0, [ 730, 570, 252490, 440 ], function(err1){
        if(err1) {
            loggerInfo('[PRICES] Error In Loading Prices');

            return initializePrices();
        }

		updating.value = false;

		setTimeout(function(){
			initializePrices();
		}, config.trading.steam.prices.cooldown_load * 1000);
	});
}

/* ----- INTERNAL USAGE ----- */
function loadPrices(gameid, games, callback){
	if(gameid >= games.length) return callback(null);

	loggerDebug('[PRICES] Prices For #' + games[gameid] + ' Are Loading');

	var options = {
		headers: {
			'content-type': 'application/json',
			'x-apikey': config.trading.steam.prices.apikey.key,
		},
		uri: 'https://api.bitskins.com/market/skin/' + games[gameid],
		qs: {}
	}

	request(options, function(err1, response1, body1) {
		if(err1) {
			loggerError(err1);

            return callback(new Error('An error occurred while loading prices (1)'));
		}

        if(!response1 || response1.statusCode != 200) return loadPrices(gameid + 1, games, callback);
		if(!isJsonString(body1)) return loadPrices(gameid + 1, games, callback);

		var body = JSON.parse(body1);

		var prices = {};

		body.forEach(function(item){
			prices[item.name] = item.suggested_price == null ? 0 : roundedToFixed(item.suggested_price / 1000, 2);
		});

		fs.writeFile('./services/trading/prices/prices_' + games[gameid] + '.json', JSON.stringify(prices), function(err1) {
            if(err1) {
                loggerError(err1);

                return callback(new Error('An error occurred while loading prices (2)'));
            }

            loggerInfo('[PRICES] Prices For #' + games[gameid] + ' Loaded Successfully');

            loadPrices(gameid + 1, games, callback);
        });
	});
}

function getPrice(name, game){
	var price = -1;

	if (name && game) {
		var prices = require('@/services/trading/prices/prices_' + game + '.json');

		if(prices[name] !== undefined){
			var list_price = prices[name];

			if(list_price != null && list_price > 0) price = roundedToFixed(list_price, 2);
		}
	}

	return price;
}

module.exports = {
	updating,
	initializePrices, getPrice
};