var fs = require('fs');
var request = require('request');

var { loggerError } = require('@/lib/logger.js');
var { isJsonString, setObjectProperty } = require('@/utils/utils.js');

var config = require('@/config/config.js');

function requestProxy(options, attempts, callback) {
    request({
        url: 'https://proxy.webshare.io/api/v2/proxy/list/?mode=direct&page=1&page_size=100',
        headers: {
            'Authorization': 'Token ' + config.trading.proxies.apikey.key,
        }
    }, function(err1, response1, body1) {
        if(err1) {
            loggerError(err1);

            return callback(new Error('An error occurred while requesting proxy (1)'));
        }

        if(!response1 || response1.statusCode != 200) return callback(new Error('An error occurred while requesting proxy (2)'));
		if(!isJsonString(body1)) return callback(new Error('An error occurred while requesting proxy (3)'));

        var body = JSON.parse(body1);
        var list = body.results.filter(a => a.valid);

        if(list.length <= 0) return callback(new Error('No active proxies!'));

        var local = list.slice().reduce((acc, cur) => ({ ...acc, [cur.proxy_address + ':' + cur.port]: {
            requests: 0,
            failures: 0
        } }), {});

        var proxies = { ...local, ...Object.fromEntries(Object.entries(config.cache.proxies).filter(([key]) => local[key] !== undefined)) };

        var items = list.sort((a, b) => proxies[a.proxy_address + ':' + a.port].requests - proxies[b.proxy_address + ':' + b.port].requests);
        var item = items[0];

        var proxy = 'http://' + item.username + ':' + item.password + '@' + item.proxy_address + ':' + item.port;

        request({
            headers: options.headers,
            url: options.url,
            qs: options.params,
            proxy: proxy
        }, function(err2, response2, body2) {
            if(err2) {
                loggerError(err2);

                return callback(new Error('An error occurred while requesting proxy (4)'));
            }

            var cache = { ...config.cache, ...{ proxies } };

            var path = 'proxies..' + item.proxy_address + ':' + item.port;
            var value = cache.proxies[item.proxy_address + ':' + item.port];

            value.requests++;
            if(response2.statusCode != 200) value.failures++;

            setObjectProperty(cache, path, value);

            fs.writeFile('./cache.json', JSON.stringify(cache, null, 4), function(err2) {
                if(err2) {
                    loggerError(err2);

                    return callback(new Error('An error occurred while requesting proxy (5)'));
                }

                config.cache = require('@/cache.json');

                if(response2.statusCode != 200 && attempts < config.trading.proxies.attempts - 1) return requestProxy(options, attempts + 1, callback);

                callback(null, response2, body2);
            });
        });
    });
}

module.exports = {
	requestProxy
};