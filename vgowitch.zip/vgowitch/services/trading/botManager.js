var TradeOfferManager = require('steam-tradeoffer-manager');
var SteamTotp = require('steam-totp');
var SteamCommunity = require('steamcommunity');
var protos = require('@/services/trading/protos');
var EventEmitter = require('events').EventEmitter;

var SteamUser = require('steam-user');

class Bot extends EventEmitter {
	constructor(options){
		super();

		this._bot_props = {
			username: options.username,
			password: options.password,
			identity_secret: options.identity_secret,
			shared_secret: options.shared_secret,
		};

		this.active = options.active;
		this.name = options.botname;
		this.steamid = options.steamid;
		this.options = {
			trade: false,
			info: false,
			webapi_token: false
		}

		for(var i in (options.options || {})) {
			this.options[i] = options.options[i];
		}

		this.connected = false;

		this.queueRequestInspect = [];

		this.user = new SteamUser({
			autoRelogin: true
		});

		this.community = new SteamCommunity();
		this.manager = new TradeOfferManager({
			steam: this.user,
			community: this.community,
			domain: 'localhost',
			language: 'en',
			useAccessToken: true
		});

		this.cookies = null;
		this.accessToken = null;

		this.gameCoordinator = {
			connected: false,
			appid: null,
			interval: null
		};

		//CONNECT
		if(this.active) this.connect();

		//EVENTS
		this.user.on('receivedFromGC', (appid, type, buffer) => {
			switch(type){
				case 4004:
				case 9187:
					if(!this.gameCoordinator.connected){
						this.emit('message', '[BOT] ' + this.name + ' - Counter Strike Global Offensive Are Ready');

						this.gameCoordinator.connected = true;
						this.gameCoordinator.appid = appid;

						if(this.gameCoordinator.interval) clearInterval(this.gameCoordinator.interval);
					}

					break;

				case 9157:
					var itemDataResponse = protos.CMsgGCCStrike15_v2_Client2GCEconPreviewDataBlockResponse.decode(buffer);

					var buf = Buffer.alloc(4);
					buf.writeUInt32LE(Number(itemDataResponse.iteminfo.paintwear), 0);

					var wear = buf.readFloatLE(0);
					var paintindex = itemDataResponse.iteminfo.paintindex;

					this.confirmInspect({ wear, paintindex });

					break;
			}
		});

		this.user.on('loggedOn', (response) => {
			if(response.eresult !== SteamUser.EResult.OK) {
				return this.emit('message', '[BOT] ' + this.name + ' - User Logging In Failed');
			}

			this.emit('message', '[BOT] ' + this.name + ' - User Logged In Successfully');

			if(this.options.info && this.active){
				this.user.setPersona(SteamUser.EPersonaState.Busy)
				this.user.gamesPlayed([ 730 ]);
			}
		});

		this.user.on('disconnected', (eresult, msg) => {
			if(msg) this.emit('message', '[BOT] ' + this.name + ' - User Disconnected with EResult ' + SteamUser.EResult[eresult] + '. Message: ' + msg);

			if(!this.user.options.autoRelogin) this.connect();
		});

		this.user.on('error', (err1) => {
			if(err1) this.emit('message', '[BOT] ' + this.name + ' - User Error. Error: ' + err1.message);
		});

		this.user.on('webSession', (sessionid, cookies) => {
			this.emit('message', '[BOT] ' + this.name + ' - Session Cookies Have Been Set');

			this.cookies = cookies;
            this.accessToken = cookies.find(a => a.includes('steamLoginSecure')).split('%7C%7C')[1];

			if((this.options.trade || this.options.webapi_token) && this.active){
				this.manager.setCookies(cookies, (err1) => {
					if(err1) return this.emit('error', err1);
				});
			}

			this.community.setCookies(cookies);
			this.community.startConfirmationChecker(10000, this._bot_props.identity_secret);

			setTimeout(() => {
				this.connected = true;

				this.emit('ready', this.steamid);
			}, 1000);
		});

		this.user.on('appLaunched', (appid) => {
			if(!this.gameCoordinator.connected){
				this.user.sendToGC(appid, 4006, {}, Buffer.alloc(0));

				this.gameCoordinator.interval = setInterval(() => {
					this.user.sendToGC(appid, 4006, {}, Buffer.alloc(0));
				}, 2500);
			}
		});

		this.community.on('confKeyNeeded', (deepDataAndEvents, updateFunc) => {
			this.emit('message', '[BOT] ' + this.name + ' - Need Confirmation Key');

			var now = this.time();

			updateFunc(null, now, SteamTotp.getConfirmationKey(this._bot_props.identity_secret, now, deepDataAndEvents));
		});

		this.community.on('sessionExpired', (err1) => {
			this.emit('message', '[BOT] ' + this.name + ' - Session Expired. Session Are Setting. Error: ' + err1.message);
			this.connected = false;

			this.community.stopConfirmationChecker();

			if(this.user.steamID != null) this.user.webLogOn();
			else this.connect();
		});

		this.manager.on('sentOfferChanged', (offer) => {
			if(!this.options.trade && !this.options.webapi_token) return;

			this.emit('sentOfferChanged', {
				bot: this.steamid,
				offer: offer
			});
		});

		this.manager.on('newOffer', (offer) => {
			if(!this.options.trade && !this.options.webapi_token) return;

			this.emit('newOffer', {
				bot: this.steamid,
				offer: offer
			});
		});

		this.community.on('confirmationAccepted', (offer) => {
			if(!this.options.trade) return;

			this.emit('confirmationAccepted', {
				bot: this.steamid,
				offer: offer
			});
		});
	}

	connect() {
		this.user.logOn({
			accountName: this._bot_props.username,
			password: this._bot_props.password,
			twoFactorCode: SteamTotp.generateAuthCode(this._bot_props.shared_secret)
		});
	}

	addQueueRequestInspect(request) {
		var firstRequest = false;
		if(this.queueRequestInspect.length <= 0) firstRequest = true;

		this.queueRequestInspect.push(request);

		if(firstRequest) this.requestInspect(this.queueRequestInspect[0].inspect);
	}

	requestInspect(inspect){
		if(!this.gameCoordinator.connected) return this.confirmInspect(null);

		var payload = new protos.CMsgGCCStrike15_v2_Client2GCEconPreviewDataBlockRequest({
			param_s: inspect.s.toString(),
			param_a: inspect.a.toString(),
			param_d: inspect.d.toString(),
			param_m: '0',
		});

		this.user.sendToGC(this.gameCoordinator.appid, 9156, {}, payload.toBuffer());

		setTimeout(() => {
			if(this.queueRequestInspect.length > 0 && inspect.a == this.queueRequestInspect[0].inspect.a) {
                this.confirmInspect(null)
            }
		}, 5000);
	}

	confirmInspect(data){
		this.queueRequestInspect[0].callback(this.queueRequestInspect[0].inspect.a, data);

		this.queueRequestInspect.shift();

		if(this.queueRequestInspect.length > 0){
			setTimeout(() => {
				this.requestInspect(this.queueRequestInspect[0].inspect);
			}, 500);
		}
	}

	time(){
		return Math.floor(Date.now() / 1000);
	}
};

module.exports = Bot;