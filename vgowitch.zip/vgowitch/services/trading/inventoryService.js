var request = require('request');

var { pool } = require('@/lib/database.js');
var { emitSocketToUser } = require('@/lib/socket.js');
var { loggerError } = require('@/lib/logger.js');

var pricesService = (({ getPrice }) => ({ getPrice }))(require('@/services/trading/pricesService.js'));
var proxiesService = (({ requestProxy }) => ({ requestProxy }))(require('@/services/trading/proxiesService.js'));

var botsService = (({ sendOffer, declineOffer, haveActiveBotByType, getActiveBotByType, haveActiveBotBySteamid, getBotBySteamid, requestItemsInspect }) => ({ sendOffer, declineOffer, haveActiveBotByType, getActiveBotByType, haveActiveBotBySteamid, getBotBySteamid, requestItemsInspect }))(require('@/services/trading/botsService.js'));

var { getSteamTime, time } = require('@/utils/formatDate.js');
var { getFormatAmount } = require('@/utils/formatAmount.js');
var { haveRankPermission, getAmountCommission, isJsonString, generateHexCode, getRandomInt, getSlug } = require('@/utils/utils.js');

var config = require('@/config/config.js');

var userInventory = {};
var p2pItems = {};

var itemExteriors = [ 'Battle-Scarred', 'Well-Worn', 'Field-Tested', 'Minimal Wear', 'Factory New' ];

function verifyWebapiToken(user, webapi_token, callback){
	pool.query('SELECT * FROM `steam_verifications` WHERE `userid` = ' + pool.escape(user.userid) + ' ORDER BY `id` DESC LIMIT 1', function(err1, row1) {
		if(err1) return callback(new Error('We can\'t verify your Steam WebAPI Token (1). Please try again later.'));

		if(row1.length > 0){
			confirmWebapiToken(webapi_token, row1[0].tradeofferid, callback);
		} else {
			if(!botsService.haveActiveBotByType('webapi_token')) return callback(new Error('We can\'t verify your Steam WebAPI Token (2). Please try again later.'));

			var bot = botsService.getActiveBotByType('webapi_token');

			getInventory(bot.steamid, config.trading.steam.games[config.trading.steam.game_verify_webapi_token].game.appid, config.trading.steam.games[config.trading.steam.game_verify_webapi_token].game.contextid, function(err2, inventory){
				if(err2) return callback(err2);

				var filtered_items = inventory.filter(a => a.marketable == true).filter(a => a.tradable == true);

				if(filtered_items.length <= 0) return callback(new Error('We can\'t verify your Steam WebAPI Token (3). Please try again later.'));

				var item = filtered_items[getRandomInt(0, filtered_items.length - 1)].assetid;

				var code = generateHexCode(24);

				botsService.sendOffer(user.binds.steam, config.trading.steam.game_verify_webapi_token, user.tradelink, code, [ item ], [], bot.steamid, function(err3, offer){
					if(err3) return callback(err3);

                    botsService.declineOffer(offer.id, bot.steamid, function(err4){
                        if(err4) return callback(err4);

                        pool.query('INSERT INTO `steam_verifications` SET `userid` = ' + pool.escape(user.userid) + ', `botsteamid` = ' + pool.escape(bot.steamid) + ', `tradeofferid` = ' + pool.escape(offer.id) + ', `code` = ' + pool.escape(code) + ', `item` = ' + pool.escape(JSON.stringify({item})) + ', `time` = ' + pool.escape(time()), function(err5) {
                            if(err5) return callback(new Error('We can\'t verify your Steam WebAPI Token (4). Please try again later.'));

							confirmWebapiToken(webapi_token, offer.id, callback);
						});
					});
				});
			});
		}
	});
}

/* ----- INTERNAL USAGE ----- */
function confirmWebapiToken(webapi_token, offerid, callback){
	var options = 'https://api.steampowered.com/IEconService/GetTradeOffer/v1?access_token=' + webapi_token + '&tradeofferid=' + offerid;

	request(options, function(err1, response1, body1) {
		if(err1) {
            loggerError(err1);

            return callback(new Error('An error occurred while confirming webapi token (1)'));
        }

		if(!response1 || response1.statusCode != 200) return callback(new Error('An error occurred while confirming webapi token (2)'));
		if(!isJsonString(body1)) return callback(new Error('An error occurred while confirming webapi token (3)'));

		var body = JSON.parse(body1);

		if(body.response.offer === undefined) return callback(new Error('An error occurred while confirming webapi token (4)'));

		callback(null);
	});
}

function checkDepositByGames(steamid, game, gameid, itemsid, offset, response, callback){
	if(gameid >= Object.keys(config.trading.steam.games).length) return callback(null, response);

	if(game != Object.keys(config.trading.steam.games)[gameid]) return checkDepositByGames(steamid, game, gameid + 1, itemsid, offset, response, callback);

	getInventory(steamid, config.trading.steam.games[Object.keys(config.trading.steam.games)[gameid]].game.appid, config.trading.steam.games[Object.keys(config.trading.steam.games)[gameid]].game.contextid, function(err1, inventory){
		if(err1) return callback(err1);

		checkDepositByItems(Object.keys(config.trading.steam.games)[gameid], inventory, 0, itemsid, offset, [], function(err2, response_items){
			if(err2) return callback(err2);

			return checkDepositByGames(steamid, game, gameid + 1, itemsid, offset, [ ...response, ...response_items ], callback);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function checkDepositByItems(game, inventory, itemid, itemsid, offset, response, callback){
	if(inventory === undefined) return callback(null, response);

	if(inventory[itemid] === undefined) return callback(null, response);

	if(itemsid.filter(a => a == inventory[itemid].assetid).length <= 0) return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);

	/* -- ACCEPTING --*/

	var accepted = true;

	if(!inventory[itemid].marketable || !inventory[itemid].tradable) accepted = false;
	if(response.filter(a => a.id == itemid).length > 0) accepted = false;
	if(p2pItems[inventory[itemid].assetid] !== undefined) if(p2pItems[inventory[itemid].assetid] == true) accepted = false;
	if(config.trading.steam.blacklist_items[game].filter(a => inventory[itemid].name.toLowerCase().indexOf(a.toLowerCase()) >= 0).length > 0) accepted = false;

	if(!accepted) return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);

    if(!inventory[itemid].inspect || !itemExteriors.includes(parseItemName(inventory[itemid].name).exterior)){
        var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
        if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

        if(price == null || price <= 0 || price < config.app.intervals.amounts.deposit_item.min || price > config.app.intervals.amounts.deposit_item.max) return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);

        response.push({
            id: inventory[itemid].assetid,
            hashname: inventory[itemid].name,
            fullname: inventory[itemid].name,
            ...parseItemName(inventory[itemid].name),
            image: inventory[itemid].image,
            price: price,
            offset: offset,
            quality: inventory[itemid].quality,
            stickers: inventory[itemid].stickers,
            wear: null,
            paintindex: null,
            phase: null
        });

		return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);
    }

    pool.query('SELECT `wear`, `paintindex` FROM `steam_items` WHERE `itemid` = ' + pool.escape(inventory[itemid].assetid), function(err1, row1) {
        if(err1) {
            var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
            if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

            if(price == null || price <= 0 || price < config.app.intervals.amounts.deposit_item.min || price > config.app.intervals.amounts.deposit_item.max) return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);

            response.push({
                id: inventory[itemid].assetid,
                hashname: inventory[itemid].name,
                fullname: inventory[itemid].name,
                ...parseItemName(inventory[itemid].name),
                image: inventory[itemid].image,
                price: price,
                offset: offset,
                quality: inventory[itemid].quality,
                stickers: inventory[itemid].stickers,
                wear: null,
                paintindex: null,
                phase: null
            });

            return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);
        }

        if(row1.length <= 0){
            var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
            if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

            if(price == null || price <= 0 || price < config.app.intervals.amounts.deposit_item.min || price > config.app.intervals.amounts.deposit_item.max) return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);

            response.push({
                id: inventory[itemid].assetid,
                hashname: inventory[itemid].name,
                fullname: inventory[itemid].name,
                ...parseItemName(inventory[itemid].name),
                image: inventory[itemid].image,
                price: price,
                offset: offset,
                quality: inventory[itemid].quality,
                stickers: inventory[itemid].stickers,
                wear: null,
                paintindex: null,
                phase: null
            });

            return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);
        }

        var phase = getPhaseItem(inventory[itemid].name, row1[0].wear, row1[0].paintindex);
        var name = getNameItem(inventory[itemid].name, phase);

        var price = getFormatAmount(pricesService.getPrice(name, config.trading.steam.games[game].game.appid));
        if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

        if(price == null || price <= 0 || price < config.app.intervals.amounts.deposit_item.min || price > config.app.intervals.amounts.deposit_item.max) return checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);

        response.push({
            id: inventory[itemid].assetid,
            hashname: inventory[itemid].name,
            fullname: name,
            ...parseItemName(name),
            image: inventory[itemid].image,
            price: price,
            offset: offset,
            quality: inventory[itemid].quality,
            stickers: inventory[itemid].stickers,
            wear: row1[0].wear,
            paintindex: row1[0].paintindex,
            phase: phase
        });

        checkDepositByItems(game, inventory, itemid + 1, itemsid, offset, response, callback);
    });
}

/* ----- CLIENT USAGE ----- */
function loadUserInventory(user, socket, method, game, offset, cooldown){
	cooldown(true, true);

	if(config.trading.steam.games[game] === undefined){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid deposit game!'
		});

		return cooldown(false, true);
	}

	if(user.binds.steam === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Please bind your Steam Account!'
		});

		emitSocketToUser(socket, 'modal', 'bind_steam');

		return cooldown(false, true);
	}

	if(!user.tradelink){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Firstly, you must set your valid Steam Trade Link from settings.'
		});

		emitSocketToUser(socket, 'modal', 'steam_tradelink');

		return cooldown(false, true);
	}

	if(method != 'p2p') return confirmUserInventory(user, socket, method, game, offset, cooldown);

	verifyWebapiToken(user, user.webapi_token, function(err1){
		if(err1){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Firstly, you must set your valid Steam WebAPI Token from settings.'
			});

			emitSocketToUser(socket, 'modal', 'steam_webapi_token');

			return cooldown(false, true);
		}

		confirmUserInventory(user, socket, method, game, offset, function(){
			return cooldown(false, false);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function confirmUserInventory(user, socket, method, game, offset, callback){
	if(userInventory[user.userid] !== undefined){
		if(userInventory[user.userid][method + '_' + game] !== undefined){
			if(userInventory[user.userid][method + '_' + game].time - time() > 0){
				if(userInventory[user.userid][method + '_' + game].error){
					emitSocketToUser(socket, 'message', 'error', {
						message: userInventory[user.userid][method + '_' + game].error
					});
				} else {
					if(userInventory[user.userid][method + '_' + game].items.length > 0){
						emitSocketToUser(socket, 'offers', 'add_items', {
							offer: {
								items: userInventory[user.userid][method + '_' + game].items,
								more: false
							}
						});
					} else {
						emitSocketToUser(socket, 'message', 'error', {
							message: 'Your Inventory is currently empty.'
						});
					}
				}

				return callback();
			}
		}
	} else {
		userInventory[user.userid] = {};
	}

	checkUserInventoryByGames(user.userid, user.binds.steam, user.webapi_token, game, 0, offset, [], function(err1, response){
		if(err1){
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			userInventory[user.userid][method + '_' + game] = {
				time: time() + config.trading.steam.cooldown_inventory_fault * (haveRankPermission('load_inventory', user.rank) ? 0 : 1),
				items: [],
				error: err1.message
			}

			return callback();
		}

		if(response.length > 0){
			emitSocketToUser(socket, 'offers', 'add_items', {
				offer: {
					items: response,
					more: false
				}
			});
		} else {
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Your inventory is set to private or is empty.'
			});
		}

		userInventory[user.userid][method + '_' + game] = {
			time: time() + config.trading.steam.cooldown_inventory_success * (haveRankPermission('load_inventory', user.rank) ? 0 : 1),
			items: response,
			error: null
		}

		callback();
	});
}

/* ----- INTERNAL USAGE ----- */
function checkUserInventoryByGames(userid, steamid, webapi_token, game, gameid, offset, response, callback){
	if(gameid >= Object.keys(config.trading.steam.games).length) return callback(null, response);

	if(game != Object.keys(config.trading.steam.games)[gameid]) return checkUserInventoryByGames(userid, steamid, webapi_token, game, gameid + 1, offset, response, callback);

	getInventory(steamid, config.trading.steam.games[Object.keys(config.trading.steam.games)[gameid]].game.appid, config.trading.steam.games[Object.keys(config.trading.steam.games)[gameid]].game.contextid, function(err1, inventory){
		if(err1) return callback(err1);

        getHistoryInventory(steamid, webapi_token, config.trading.steam.games[Object.keys(config.trading.steam.games)[gameid]].game.appid, function(err2, history_inventory){
            if(err2) return callback(err2);

            checkUserInventoryByItems(userid, steamid, Object.keys(config.trading.steam.games)[gameid], [
                ...inventory,
                ...history_inventory.filter(a => !inventory.some(b => b.assetid == a.assetid))
            ], 0, offset, [], [], function(err3, response_items){
                if(err3) return callback(err3);

                return checkUserInventoryByGames(userid, steamid, webapi_token, game, gameid + 1, offset, [ ...response, ...response_items ], callback);
            });
        });
	});
}

/* ----- INTERNAL USAGE ----- */
function checkUserInventoryByItems(userid, steamid, game, inventory, itemid, offset, response, inspect, callback){
	if(inventory[itemid] === undefined) {
		if(inspect.length <= 0) return callback(null, response);

        botsService.requestItemsInspect(userid, inspect.map(a => a.inspect), function(err1, data){
            if(err1) {
                loggerError(err1);

                return callback(null, [ ...response, ...inspect.map(a => a.item) ]);
            }

            iterate(0);

            function iterate(index){
                if(index >= Object.entries(data).length) return callback(null, [ ...response, ...inspect.map(a => ({
                    ...a.item,
                    ...data[a.item.id] !== undefined ? {
                        wear: data[a.item.id].wear,
                        paintindex: data[a.item.id].paintindex
                    } : {}
                })) ]);

                pool.query('INSERT INTO `steam_items` SET `itemid` = ' + pool.escape(Object.entries(data)[index][0]) + ', `wear` = ' + parseFloat(Object.entries(data)[index][1].wear) + ', `paintindex` = ' + parseInt(Object.entries(data)[index][1].paintindex) + ', `time` = ' + pool.escape(time()), function(err2){
                    if(err2) return callback(null, [ ...response, ...inspect.map(a => a.item) ]);

                    iterate(index + 1);
                });
            }
        });
	} else {
		/* -- ACCEPTING --*/

		var accepted = true;
		var view = true;

		if(!inventory[itemid].tradelocked && (!inventory[itemid].marketable || !inventory[itemid].tradable)) accepted = false;
		if(response.filter(a => a.id == itemid).length > 0) accepted = false;
		if(p2pItems[inventory[itemid].assetid] !== undefined) if(p2pItems[inventory[itemid].assetid] == true) accepted = false;
		if(config.trading.steam.blacklist_items[game].filter(a => inventory[itemid].name.toLowerCase().indexOf(a.toLowerCase()) >= 0).length > 0) accepted = false;

		if(!inventory[itemid].marketable) view = false;
		if(response.filter(a => a.id == itemid).length > 0) view = false;

		if(!view) return checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback);

        if(!inventory[itemid].inspect || !itemExteriors.includes(parseItemName(inventory[itemid].name).exterior)){
            var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
            if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

            if(price == null || price <= 0 || price < config.app.intervals.amounts.deposit_item.min || price > config.app.intervals.amounts.deposit_item.max) accepted = false;
		    if(price == null || price <= 0) view = false;

            if(!view) return checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback);

            response.push({
                id: inventory[itemid].assetid,
                hashname: inventory[itemid].name,
                fullname: inventory[itemid].name,
                ...parseItemName(inventory[itemid].name),
                image: inventory[itemid].image,
                price: price,
                offset: offset,
                quality: inventory[itemid].quality,
                stickers: inventory[itemid].stickers,
                wear: null,
                paintindex: null,
                phase: null,
                accepted: accepted,
                tradelocked: inventory[itemid].tradelocked
            });

            return checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback);
        }

        pool.query('SELECT `wear`, `paintindex` FROM `steam_items` WHERE `itemid` = ' + pool.escape(inventory[itemid].assetid), function(err1, row1) {
            if(err1) {
                var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
                if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

                if(price == null || price <= 0 || price < config.app.intervals.amounts.deposit_item.min || price > config.app.intervals.amounts.deposit_item.max) accepted = false;
                if(price == null || price <= 0) view = false;

                if(!view) return checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback);

                response.push({
                    id: inventory[itemid].assetid,
                    hashname: inventory[itemid].name,
                    fullname: inventory[itemid].name,
                    ...parseItemName(inventory[itemid].name),
                    image: inventory[itemid].image,
                    price: price,
                    offset: offset,
                    quality: inventory[itemid].quality,
                    stickers: inventory[itemid].stickers,
                    wear: null,
                    paintindex: null,
                    phase: null,
                    accepted: accepted,
                    tradelocked: inventory[itemid].tradelocked
                });

                return checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback);
            }

            if(row1.length <= 0){
                var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
                if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

                if(price == null || price <= 0 || price < config.app.intervals.amounts.deposit_item.min || price > config.app.intervals.amounts.deposit_item.max) accepted = false;
                if(price == null || price <= 0) view = false;

                if(!view) return checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback);

                inspect.push({
                    item: {
                        id: inventory[itemid].assetid,
                        hashname: inventory[itemid].name,
                        fullname: inventory[itemid].name,
                        ...parseItemName(inventory[itemid].name),
                        image: inventory[itemid].image,
                        price: price,
                        offset: offset,
                        quality: inventory[itemid].quality,
                        stickers: inventory[itemid].stickers,
                        wear: null,
                        paintindex: null,
                        phase: null,
                        accepted: accepted,
                        tradelocked: inventory[itemid].tradelocked
                    },
                    inspect: {
                        s: steamid,
                        a: inventory[itemid].assetid,
                        d: inventory[itemid].inspect.split('A' + inventory[itemid].assetid + 'D')[1]
                    }
                });

                return checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback)
            }

            var phase = getPhaseItem(inventory[itemid].name, row1[0].wear, row1[0].paintindex);
            var name = getNameItem(inventory[itemid].name, phase);

            var price = getFormatAmount(pricesService.getPrice(name, config.trading.steam.games[game].game.appid));
            if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

            if(price == null || price <= 0 || price < config.app.intervals.amounts.deposit_item.min || price > config.app.intervals.amounts.deposit_item.max) accepted = false;
            if(price == null || price <= 0) view = false;

            if(!view) return checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback);

            response.push({
                id: inventory[itemid].assetid,
                hashname: inventory[itemid].name,
                fullname: name,
                ...parseItemName(name),
                image: inventory[itemid].image,
                price: price,
                offset: offset,
                quality: inventory[itemid].quality,
                stickers: inventory[itemid].stickers,
                wear: row1[0].wear,
                paintindex: row1[0].paintindex,
                phase: phase,
                accepted: accepted,
                tradelocked: inventory[itemid].tradelocked
            });

            checkUserInventoryByItems(userid, steamid, game, inventory, itemid + 1, offset, response, inspect, callback);
        });
	}
}

function getInventory(steamid, appid, contextid, callback){
	var headers = {};

    if(botsService.haveActiveBotBySteamid(steamid)){
        headers['Cookie'] = botsService.getBotBySteamid(steamid).cookies.join('; ') + ';';
    }

	var options = {
		headers: headers,
		url: 'https://steamcommunity.com/inventory/' + steamid + '/' + appid + '/' + contextid,
		params: {
			'l': 'english',
			'count': 1000
		}
	}

	proxiesService.requestProxy(options, 0, function(err1, response1, body1) {
		if(err1) return callback(err1);

        if(!response1 || response1.statusCode != 200) return callback(null, []);
		if(!isJsonString(body1)) return callback(null, []);

		var body = JSON.parse(body1);

		if(!body.assets || !body.descriptions) return callback(null, []);

		var descriptions = body.descriptions.slice().reduce((obj, a) => ({ ...obj, [a.classid + '_' + a.instanceid]: a }), {});

		var data = body.assets.slice().map(a => ({ ...descriptions[a.classid + '_' + a.instanceid], ['assetid']: a.assetid }));

		var items = [];

		data.forEach(function(item){
			var inspect = getInspectItem(item.actions, steamid, item.assetid);
            var quality = getSlug(getQualityItem(item.type));
            var stickers = getStickersItem(item.descriptions);
            var charms = getCharmsItem(item.descriptions);
            var tradelocked = getTradelockedItem(item.owner_descriptions);

			if(!tradelocked && item.marketable && !item.tradable) tradelocked = getSteamTime(time() + config.trading.steam.cooldown_items_deposit);

			items.push({
				assetid: item.assetid,
				classid: item.classid,
				instanceid: item.instanceid,
                name: item.market_name || item.market_hash_name || item.name,
				image: 'https://steamcommunity-a.akamaihd.net/economy/image/' + (item.icon_url_large || item.icon_url),
				quality: quality,
				stickers: stickers,
				charms: charms,
				inspect: inspect,
				tradable: item.tradable,
				marketable: item.marketable,
				tradelocked: tradelocked
			});
		});

		callback(null, items);
	});
}

/* ----- INTERNAL USAGE ----- */
function getHistoryInventory(steamid, webapi_token, appid, callback){
    var options = 'https://api.steampowered.com/IEconService/GetTradeHistory/v1/?access_token=' + webapi_token + '&get_descriptions=true&max_trades=100';

	request(options, function(err1, response1, body1) {
		if(err1) return callback(err1);

        if(!response1 || response1.statusCode != 200) return callback(null, []);
		if(!isJsonString(body1)) return callback(null, []);

		var body = JSON.parse(body1);

		if(!body.response) return callback(null, []);
		if(!body.response.trades || !body.response.descriptions) return callback(null, []);

		var descriptions = body.response.descriptions.slice().reduce((obj, a) => ({ ...obj, [a.classid + '_' + a.instanceid]: a }), {});

        var trades = body.response.trades.filter(a => a.status == 3 && getSteamTime(parseInt(a.time_mod || a.time_init) + config.trading.steam.cooldown_items_deposit) >= time());
        var assets_received = trades.slice().filter(a => a.assets_received !== undefined).map(a => a.assets_received.filter(b => b.appid == appid).map(b => ({ ...b, ...{ time: parseInt(a.time_mod || a.time_init) } }))).reduce((acc, cur) => ([ ...acc, ...cur ]), []);
        var assets_given = trades.slice().filter(a => a.assets_given !== undefined).map(a => a.assets_given.filter(b => b.appid == appid)).reduce((acc, cur) => ([ ...acc, ...cur ]), []);

        var data = assets_received.filter(a => !assets_given.some(b => b.assetid == a.new_assetid)).slice().map(a => ({ ...descriptions[a.classid + '_' + a.instanceid], ...{
            assetid: a.new_assetid,
            time: a.time
        } }));

		var items = [];

		data.forEach(function(item){
			var inspect = getInspectItem(item.actions, steamid, item.assetid);
            var quality = getSlug(getQualityItem(item.type));
            var stickers = getStickersItem(item.descriptions);
            var charms = getCharmsItem(item.descriptions);
            var tradelocked = getSteamTime(item.time + config.trading.steam.cooldown_items_deposit);

			items.push({
				assetid: item.assetid,
				classid: item.classid,
				instanceid: item.instanceid,
				name: item.market_name || item.market_hash_name || item.name,
				image: 'https://steamcommunity-a.akamaihd.net/economy/image/' + (item.icon_url_large || item.icon_url),
				quality: quality,
				stickers: stickers,
				charms: charms,
				inspect: inspect,
				tradable: false,
				marketable: item.marketable,
				tradelocked: tradelocked
			});
		});

		callback(null, items);
	});
}

function getAssetids(steamid, appid, contextid, callback){
	var headers = {};

	if(botsService.haveActiveBotBySteamid(steamid)){
        headers['Cookie'] = botsService.getBotBySteamid(steamid).cookies.join('; ') + ';';
    }

	var options = {
		headers: headers,
		url: 'https://steamcommunity.com/inventory/' + steamid + '/' + appid + '/' + contextid,
		params: {
			'l': 'english',
			'count': 1000
		}
	}

	proxiesService.requestProxy(options, 0, function(err1, response1, body1) {
		if(err1) return callback(err1);

        if(!response1 || response1.statusCode != 200) return callback(null, []);
		if(!isJsonString(body1)) return callback(null, []);

		var body = JSON.parse(body1);

		if(!body.assets || !body.descriptions) return callback(null, []);

		callback(null, body.assets.map(a => a.assetid));
	});
}

/* ----- INTERNAL USAGE ----- */
function getInspectItem(actions, steamid, assetid){
    if(actions && actions[0]) {
        var action = actions[0];

        return action.link.replace(/%owner_steamid%/g, steamid).replace(/%assetid%/g, assetid);
    }

    return null;
}

/* ----- INTERNAL USAGE ----- */
function getQualityItem(type){
    var qualities = [
        'Consumer Grade',
        'Mil-Spec Grade',
        'Industrial Grade',
        'Restricted',
        'Classified',
        'Covert',
        'Base Grade',
        'Extraordinary',
        'High Grade',
        'Remarkable',
        'Exotic',
        'Contraband',
        'Distinguished',
        'Exceptional',
        'Superior',
        'Master'
    ];

    for(var i = 0; i < qualities.length; i++) {
        var regex = new RegExp(qualities[i], 'i');

        if(regex.test(type)) return qualities[i];
    }

    return null;
}

/* ----- INTERNAL USAGE ----- */
function getStickersItem(descriptions){
    if(Array.isArray(descriptions)) {
        for(var i = 0; i < descriptions.length; i++){
            if(descriptions[i].value) {
                var stickerMatch = descriptions[i].value.match(/<center>(.*?)<\/center>/);

                if(stickerMatch && stickerMatch[1]) {
                    var content = stickerMatch[1];

                    var imageMatches = [ ...content.matchAll(/<img[^>]+src="([^"]+)"[^>]+title="([^"]+)"[^>]*>/g) ];

                    return imageMatches.filter(a => /\bSticker|Patch\b/i.test(a[2])).map(a => ({
                        image: a[1],
                        name: a[2].replace(/^(Sticker|Patch):\s*/, '')
                    }));
                }
            }
        }
    }

    return [];
}

/* ----- INTERNAL USAGE ----- */
function getCharmsItem(descriptions){
    if(Array.isArray(descriptions)) {
        for(var i = 0; i < descriptions.length; i++){
            if(descriptions[i].value) {
                var charmMatch = descriptions[i].value.match(/<center>(.*?)<\/center>/);

                if(charmMatch && charmMatch[1]) {
                    var content = charmMatch[1];

                    var imageMatches = [ ...content.matchAll(/<img[^>]+src="([^"]+)"[^>]+title="([^"]+)"[^>]*>/g) ];

                    return imageMatches.filter(a => /\bCharm\b/i.test(a[2])).map(a => ({
                        image: a[1],
                        name: a[2].replace(/^(Charm):\s*/, '')
                    }));
                }
            }
        }
    }

    return [];
}

/* ----- INTERNAL USAGE ----- */
function getTradelockedItem(owner_descriptions){
    if(Array.isArray(owner_descriptions)) {
        for(var i = 0; i < owner_descriptions.length; i++){
            if(owner_descriptions[i].value) {
                var match = owner_descriptions[i].value.match(/Tradable After (.+)/i);

                if(match && match[1]) {
                    var date = new Date(match[1]);

                    if(!isNaN(date.getTime())) return Math.floor(date.getTime() / 1000);
                }
            }
        }
    }

    return null;
}

/* ----- INTERNAL USAGE ----- */
function isGammaDopplerItem(name){
    return /\bGamma\s+Doppler\b/i.test(name);
}

/* ----- INTERNAL USAGE ----- */
function isDopplerItem(name){
    return /\bDoppler\b/i.test(name);
}

function getPhaseItem(name, wear, painindex){
    if(isGammaDopplerItem(name)){
        if(painindex == 569 && wear <= 0.08) return 'Emerald';
        if(painindex == 568 || painindex == 569) return 'Phase 1';
        if(painindex == 570 || painindex == 571) return 'Phase 2';
        if(painindex == 572 || painindex == 573) return 'Phase 3';
        if(painindex == 574 || painindex == 575) return 'Phase 4';
    } else if(isDopplerItem(name)){
        if(painindex == 418) return 'Phase 1';
        if(painindex == 419) return 'Phase 2';
        if(painindex == 420) return 'Phase 3';
        if(painindex == 421) return 'Phase 4';
        if(painindex == 415) return 'Ruby';
        if(painindex == 416) return 'Sapphire';
        if(painindex == 417) return 'Black Pearl';
    }

    return null;
}

function getNameItem(name, phase){
    if(phase == null) return name;

    return name.replace(/\b(Gamma\s+)?Doppler\b/i, match => match + ' ' + phase);
}

function parseItemName(name){
	var infos = {
		title: null,
		subtitle: null,
		exterior: null
	};

	var match = /^\s*(.*?)\s*(?:\|\s*(.*?)\s*(?:\((Battle-Scarred|Well Worn|Field-Tested|Minimal Wear|Factory New)\))?)?$/.exec(name);

	if(match && match[2]) {
		infos.title = match[1] || null;
		infos.subtitle = match[2] || null;
		infos.exterior = match[3] || null;
	} else infos.title = name.trim();

	return infos;
}

module.exports = {
    p2pItems,
	verifyWebapiToken, checkDepositByGames, loadUserInventory, getInventory, getAssetids,
    getPhaseItem, getNameItem, parseItemName
};