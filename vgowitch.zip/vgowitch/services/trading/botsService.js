var { loggerDebug, loggerError } = require('@/lib/logger.js');

var BotManager = require('@/services/trading/botManager.js');

var { getRandomInt } = require('@/utils/utils.js');

var config = require('@/config/config.js');

var bots = [];
var usersInspect = {};

var tradeReady = {};
var tradeCallbacks = [];

var readyCallbacks = [];
var offerCallbacks = [];
var confirmationCallbacks = [];

function initializeBots(){
	config.trading.steam.bots.forEach(function(options){
		var bot = new BotManager(options);

		bot.on('error', botError);
		bot.on('message', botMessage);
		bot.on('ready', botReady);

		bot.on('sentOfferChanged', botOfferStateChanged);
		bot.on('newOffer', botNewOffer);
		bot.on('confirmationAccepted', botConfirmationAccepted);

		bots.push(bot);

        if(options.options.trade) tradeReady[options.steamid] = false;
	});
}

function addTradeCallbacks(callback){
    tradeCallbacks.push(callback);
}

function addReadyCallbacks(callback){
    readyCallbacks.push(callback);
}

function addOfferCallbacks(callback){
    offerCallbacks.push(callback);
}

function addConfirmationCallbacks(callback){
    confirmationCallbacks.push(callback);
}

function sendOffer(steamid, game, tradelink, message, itemssend, itemsreceive, botsteamid, callback){
	var bot = getBotBySteamid(botsteamid);

	if(bot == undefined) return callback(new Error('An error occurred while sending offer (1)'));

	var create = bot.manager.createOffer(steamid, tradelink.split('token=')[1]);

	itemsreceive.forEach(function(item){
		create.addTheirItem({
			'appid': config.trading.steam.games[game].game.appid,
			'contextid': config.trading.steam.games[game].game.contextid,
			'assetid': item
		});
	});

	itemssend.forEach(function(item){
		create.addMyItem({
			'appid': config.trading.steam.games[game].game.appid,
			'contextid': config.trading.steam.games[game].game.contextid,
			'assetid': item
		});
	});

	create.setMessage(message);

	create.send(function(err1, status) {
		if(err1){
			loggerError(err1);

			return callback(new Error('An error occurred while sending offer (2)'));
		}

		callback(null, create);
	});
}

function declineOffer(offerid, botsteamid, callback){
	var bot = getBotBySteamid(botsteamid);

	if(bot == undefined) return callback(new Error('An error occurred while declining offer (1)'));

	bot.manager.getOffer(offerid, function(err1, offer){
		if(err1){
			loggerError(err1);

			return callback(new Error('An error occurred while declining offer (2)'));
		}

		if(offer.state != 2 && offer.state != 9) return callback(new Error('An error occurred while declining offer (3)'));

        offer.decline(function(err2) {
            if(err2){
                loggerError(err2);

                return callback(new Error('An error occurred while declining offer (4)'));
            }

            callback(null);
        });
	});
}

function acceptOffer(offerid, botsteamid, callback){
	var bot = getBotBySteamid(botsteamid);

	if(bot == undefined) return callback(new Error('An error occurred while accepting offer (1)'));

	bot.manager.getOffer(offerid, function(err1, offer){
		if(err1){
			loggerError(err1);

			return callback(new Error('An error occurred while accepting offer (2)'));
		}

		if(offer.state != 2) return callback(new Error('An error occurred while accepting offer (3)'));

        offer.accept(function(err2) {
            if(err2){
                loggerError(err2);

                return callback(new Error('An error occurred while accepting offer (4)'));
            }

            callback(null);
        });
	});
}

/* ----- INTERNAL USAGE ----- */
function botError(error){
	loggerError(error);
}

/* ----- INTERNAL USAGE ----- */
function botMessage(message){
	loggerDebug(message);
}

/* ----- INTERNAL USAGE ----- */
function botReady(botsteamid){
    readyCallbacks.forEach(function(callback){
        callback(botsteamid);
    });

   if(tradeReady[botsteamid] !== undefined) tradeReady[botsteamid] = true;

   if(Object.values(tradeReady).every(a => a)) {
        tradeCallbacks.forEach(function(callback){
            callback();
        });
   }
}

/* ----- INTERNAL USAGE ----- */
function botOfferStateChanged(response){
	var bot = getBotBySteamid(response.bot);

	if(bot == undefined) return;

	bot.manager.getOffer(response.offer.id, function(err1, offer){
		if(err1) return loggerError(err1);

        offerCallbacks.forEach(function(callback){
            callback(offer.id, offer.state, response.bot);
        });
	});
}

/* ----- INTERNAL USAGE ----- */
function botNewOffer(response){
	//declineOffer(response.offer.id, response.bot);
}

/* ----- INTERNAL USAGE ----- */
function botConfirmationAccepted(response){
	var bot = getBotBySteamid(response.bot);

	if(bot == undefined) return;

    bot.manager.getOffer(response.offer.offerID, function(err1, offer){
		if(err1) return loggerError(err1);

        confirmationCallbacks.forEach(function(callback){
            callback(offer.id, response.bot);
        });
    });
}

function haveActiveBot(){
	return bots.some(a => a.active && a.connected);
}

function getActiveBot(){
	var filter = bots.filter(a => a.active && a.connected);

	return filter[getRandomInt(0, filter.length - 1)];
}

function haveActiveBotByType(type){
	return bots.some(a => a.active && a.connected && a.options[type]);
}

function getActiveBotByType(type){
	var filter = bots.filter(a => a.active && a.connected && a.options[type]);

	return filter[getRandomInt(0, filter.length - 1)];
}

function getActiveBotsByType(type){
	return bots.filter(a => a.active && a.connected && a.options[type]);
}

function haveActiveBotByIndex(index){
	if(bots[index] === undefined) return false;
    if(!bots[index].active || !bots[index].connected) return false;

    return true;
}

function haveActiveBotBySteamid(steamid){
	return bots.some(a => a.active && a.connected && a.steamid == steamid);
}

function haveBotByIndex(index){
	return bots[index] !== undefined;
}

function getBotByIndex(index){
	return bots[index];
}

function getIndexBySteamid(steamid){
	return bots.findIndex(a => a.steamid == steamid);
}

function getBotBySteamid(steamid){
	return bots.find(a => a.steamid == steamid);
}

function requestItemsInspect(userid, items, callback){
	if(!haveActiveBotByType('info')) return callback(null, {});

	if(usersInspect[userid] === undefined) {
        usersInspect[userid] = {
            items: items.reduce((acc, cur) => ({ ...acc, [cur.a]: {
                inspected: false
            } }), {}),

            response: {},

            callback: callback,

            next: function(id, data){
                if(data) this.response[id] = data;

                this.items[id].inspected = true;

                if(Object.values(this.items).every(a => a.inspected)){
                    this.callback(null, this.response);

				    delete usersInspect[userid];
                }
            }
        }
    } else {
        usersInspect[userid].callback = callback;
    }

    items.forEach(function(item){
        var bot = getActiveBotsByType('info').sort((a, b) => a.queueRequestInspect.length - b.queueRequestInspect.length )[0];

        bot.addQueueRequestInspect({
			inspect: item,

			callback: function(id, data){
				if(usersInspect[userid] !== undefined) usersInspect[userid].next(id, data);
			}
		})
    });
}

module.exports = {
    bots,
    initializeBots, addReadyCallbacks, addTradeCallbacks, addOfferCallbacks, addConfirmationCallbacks, sendOffer, declineOffer, acceptOffer,
    haveActiveBot, getActiveBot, haveActiveBotByType, getActiveBotByType, getActiveBotsByType, haveActiveBotByIndex, haveActiveBotBySteamid, haveBotByIndex, getBotByIndex, getIndexBySteamid, getBotBySteamid, requestItemsInspect
};