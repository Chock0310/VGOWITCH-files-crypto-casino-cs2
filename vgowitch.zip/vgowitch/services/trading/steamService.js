var request = require('request');

var { pool } = require('@/lib/database.js');
var { emitSocketToUser, emitSocketToRoom } = require('@/lib/socket.js');
var { loggerInfo, loggerDebug, loggerError } = require('@/lib/logger.js');

var userService = (({ updateBalance, getBalance, editBalance, registerAffiliates, registerDepositBonus }) => ({ updateBalance, getBalance, editBalance, registerAffiliates, registerDepositBonus }))(require('@/services/userService.js'));

var pricesService = (({ getPrice }) => ({ getPrice }))(require('@/services/trading/pricesService.js'));
var botsService = (({ bots, sendOffer, declineOffer, haveActiveBotByType, getActiveBotByType, getActiveBotsByType, haveActiveBotByIndex, haveActiveBotBySteamid, getBotByIndex, getIndexBySteamid, getBotBySteamid }) => ({ bots, sendOffer, declineOffer, haveActiveBotByType, getActiveBotByType, getActiveBotsByType, haveActiveBotByIndex, haveActiveBotBySteamid, getBotByIndex, getIndexBySteamid, getBotBySteamid }))(require('@/services/trading/botsService.js'));
var inventoryService = (({ checkDepositByGames, loadUserInventory, getInventory, getPhaseItem, getNameItem, parseItemName }) => ({ checkDepositByGames, loadUserInventory, getInventory, getPhaseItem, getNameItem, parseItemName }))(require('@/services/trading/inventoryService.js'));

var { makeDate, getSteamTime, time } = require('@/utils/formatDate.js');
var { getFormatAmount, getFormatAmountString } = require('@/utils/formatAmount.js');
var { haveRankPermission, verifyRecaptcha, calculateLevel, getAmountCommission, generateHexCode, isJsonString } = require('@/utils/utils.js');

var config = require('@/config/config.js');

var offers = {};

var shopInventory = {};
var shopItems = {};

var itemExteriors = [ 'Battle-Scarred', 'Well-Worn', 'Field-Tested', 'Minimal Wear', 'Factory New' ];

var initialized = false;
var checking = false;

function initializeTrades(){
    if(initialized) return;
	initialized = true;

    startCheckingTrades();
}

/* ----- INTERNAL USAGE ----- */
async function startCheckingTrades(){
	if(checking) return;
	checking = true;

	var props = Object.keys(offers).filter(a => offers[a].status == 2);

	for(var i = 0; i < props.length; i++) {
		await trackTrade(props[i]).catch(function(err1){
			loggerError(err1);
		});
	}

	checking = false;

	setTimeout(function(){
		startCheckingTrades();
	}, config.trading.steam.cooldown_checking_rollback * 1000);
}

/* ----- INTERNAL USAGE ----- */
function trackTrade(id){
	return new Promise(function(resolve, reject) {
        if(!botsService.haveActiveBotBySteamid(offers[id].botsteamid)) return resolve();

		var bot = botsService.getBotBySteamid(offers[id].botsteamid);

        request('https://api.steampowered.com/IEconService/GetTradeOffer/v1/?access_token=' + bot.accessToken + '&tradeofferid=' + offers[id].tradeofferid, function(err1, response1, body1) {
            if(err1) return reject(err1);

            if(!response1 || response1.statusCode != 200) return reject(new Error('An error occurred while tracking trade (1)'));
            if(!isJsonString(body1)) return reject(new Error('An error occurred while tracking trade (2)'));

            var tradeid = JSON.parse(body1).response.offer.tradeid;

            request('https://api.steampowered.com/IEconService/GetTradeStatus/v1/?access_token=' + bot.accessToken + '&tradeid=' + tradeid, function(err2, response2, body2) {
                if(err2) return reject(err2);

                if(!response2 || response2.statusCode != 200) return reject(new Error('An error occurred while tracking trade (3)'));
                if(!isJsonString(body2)) return reject(new Error('An error occurred while tracking trade (4)'));

                var body = JSON.parse(body2);

                if(body.response.trades === undefined) return resolve();
                if(body.response.trades[0] === undefined) return resolve();

                var offer = body.response.trades[0];
                var state = offer.status;

                if(state == 12) offerStateChanged(id, state, offers[id].botsteamid);
                else {
                    var days = Math.floor((getSteamTime(offers[id].update + config.trading.steam.time_clear_trade) - time()) / (24 * 60 * 60));
                    var hours = Math.floor((getSteamTime(offers[id].update + config.trading.steam.time_clear_trade) - time()) % (24 * 60 * 60) / (60 * 60));

                    loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Still Active | Clearing In ' + days + ' days and ' + hours + ' hours');
                }

                resolve();
            });
        });
	});
}

function getBots(){
	return botsService.bots.filter(a => a.connected && a.options.trade).map((a, index) => ({ index, active: a.active }));
}

function getPendings(userid){
	var pendings = [];

	Object.keys(offers).filter(a => offers[a].user.userid == userid).forEach(function(key){
		var data = {
			tradeofferid: offers[key].tradeofferid
		};

		if(offers[key].status == 0 || offers[key].status == 1) data.code = offers[key].code;
		if(offers[key].status == 1) data.time = offers[key].time + config.trading.steam.time_cancel_trade;
		if(offers[key].status == 2) data.time = getSteamTime(offers[key].update + config.trading.steam.time_clear_trade);

		pendings.push({
			id: offers[key].id,
			type: offers[key].type,
			method: 'steam',
			game: offers[key].game,
			status: offers[key].status,
			items: offers[key].items,
			data: data
		});
	});

	return pendings;
}

function loadOffers(botsteamid){
	var bot = botsService.getBotBySteamid(botsteamid);

    if(!bot.options.trade) return;

	loggerDebug('[BOT] ' + bot.name + ' - Steam Offers Are Loading');

	pool.query('SELECT * FROM `steam_transactions` WHERE (`status` = 0 OR `status` = 1 OR `status` = 2) AND `botsteamid` = ' + pool.escape(botsteamid), function(err1, row1){
		if(err1) return;

		loggerInfo('[BOT] ' + bot.name + ' - ' + row1.length + ' Offers Loaded');

		row1.forEach(function(transaction){
			bot.manager.getOffer(transaction.tradeofferid, function(err2, offer){
				if(err2) return loggerError(err2);

                if(offers[offer.id] === undefined){
                    offers[offer.id] = {
                        id: transaction.id,
                        status: transaction.status,
                        type: transaction.type,
                        botsteamid: transaction.botsteamid,
                        refill: transaction.refill == 1,
                        user: {
                            userid: transaction.userid,
                            name: transaction.name,
                            avatar: transaction.avatar,
                            level: calculateLevel(transaction.xp).level
                        },
                        game: transaction.game,
                        items: JSON.parse(transaction.items),
                        amount: getFormatAmount(transaction.amount),
                        create: parseInt(transaction.time),
                        update: parseInt(transaction.update),
                        tradeofferid: transaction.tradeofferid,
                        code: transaction.code,
                        time: null,
                        timeout: null
                    };

                    if(transaction.status == 1){
                        offers[offer.id].time = time();
                        offers[offer.id].timeout = setTimeout(function(){
                            botsService.declineOffer(offer.id, bot.steamid, function(err3){
                                if(err3) return;
                            });
                        }, config.trading.steam.time_cancel_trade * 1000);
                    } else if(transaction.status == 2){
                        if(getSteamTime(offers[offer.id].update + config.trading.steam.time_clear_trade) <= time()) return offerStateChanged(offer.id, offer.state, transaction.botsteamid);

                        offers[offer.id].timeout = setTimeout(function(){
                            offerStateChanged(offer.id, offer.state, transaction.botsteamid);
                        }, (getSteamTime(offers[offer.id].update + config.trading.steam.time_clear_trade) - time()) * 1000);
                    }

                    if(transaction.status != 2) offerStateChanged(offer.id, offer.state, transaction.botsteamid);
                }
			});
		});
	});
}

function offerStateChanged(id, state, botsteamid){
	if(offers[id] === undefined) return;

    var bot = botsService.getBotBySteamid(botsteamid);

    if(!bot.options.trade) return;

    if(offers[id].refill) loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' (REFILL) | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Changed');
    else loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Changed');

    var amount = getFormatAmount(offers[id].amount);

    if(offers[id].status == 0){
        if(state == 2){
            if(offers[id].type == 'withdraw'){
                pool.query('UPDATE `steam_transactions` SET `status` = 1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err1) {
                    if(err1) return;

                    offers[id].status = 1;
                    offers[id].update = time();
                    offers[id].time = time();

                    offers[id].timeout = setTimeout(function(){
                        botsService.declineOffer(offers[id].tradeofferid, bot.steamid, function(err2){
                            if(err2) return;
                        });
                    }, config.trading.steam.time_cancel_trade * 1000)

                    //EDIT PENDING FROM BUYER
                    emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                        offer: {
                            id: offers[id].id,
                            type: offers[id].type,
                            method: 'steam',
                            game: offers[id].game,
                            status: offers[id].status,
                            items: offers[id].items,
                            data: {
                                tradeofferid: offers[id].tradeofferid,
                                code: offers[id].code,
                                time: offers[id].time + config.trading.steam.time_cancel_trade
                            }
                        }
                    });

                    loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Confirmed');
                });
            }
        } else if(state != 9){
            offers[id].status = 1;

            offerStateChanged(id, state, botsteamid);
        }
    } else if(offers[id].status == 1){
        if(state == 3){
            if(offers[id].game != 'cs2'){
                offers[id].status = 2;

                return offerStateChanged(id, state, botsteamid);
            }

            if(offers[id].type == 'deposit'){
                pool.query('UPDATE `steam_transactions` SET `status` = 2, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err1) {
                    if(err1) return;

                    if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                    offers[id].status = 2;
                    offers[id].update = time();

                    offers[id].timeout = setTimeout(function(){
                        offerStateChanged(id, state, botsteamid);
                    }, (getSteamTime(offers[id].update + config.trading.steam.time_clear_trade) - time()) * 1000)

                    //EDIT PENDING FROM SELLER
                    emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                        offer: {
                            id: offers[id].id,
                            type: offers[id].type,
                            method: 'steam',
                            game: offers[id].game,
                            status: offers[id].status,
                            items: offers[id].items,
                            data: {
                                tradeofferid: offers[id].tradeofferid,
                                time: getSteamTime(offers[id].update + config.trading.steam.time_clear_trade)
                            }
                        }
                    });

                    loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Accepted');
                });
            } else if(offers[id].type == 'withdraw'){
                pool.query('UPDATE `steam_transactions` SET `status` = 2, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err1) {
                    if(err1) return;

                    if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                    offers[id].status = 2;
                    offers[id].update = time();

                    offers[id].timeout = setTimeout(function(){
                        offerStateChanged(id, state, botsteamid);
                    }, (getSteamTime(offers[id].update + config.trading.steam.time_clear_trade) - time()) * 1000)

                    //EDIT PENDING FROM BUYER
                    emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                        offer: {
                            id: offers[id].id,
                            type: offers[id].type,
                            method: 'steam',
                            game: offers[id].game,
                            status: offers[id].status,
                            items: offers[id].items,
                            data: {
                                tradeofferid: offers[id].tradeofferid,
                                time: getSteamTime(offers[id].update + config.trading.steam.time_clear_trade)
                            }
                        }
                    });

                    loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Accepted');
                });
            }
        } else if(state != 2 && state != 9){
            if(offers[id].type == 'deposit'){
                pool.query('UPDATE `steam_transactions` SET `status` = -1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err1) {
                    if(err1) return;

                    if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                    offers[id].status = -1;
                    offers[id].update = time();

                    //EDIT PENDING FROM SELLER
                    emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                        offer: {
                            id: offers[id].id,
                            type: offers[id].type,
                            method: 'steam',
                            game: offers[id].game,
                            status: offers[id].status,
                            items: offers[id].items,
                            data: {
                                tradeofferid: offers[id].tradeofferid
                            }
                        }
                    });

                    //ADD ITEMS TO DEPOSIT
                    emitSocketToRoom('deposit/steam/' + offers[id].game + '/' + offers[id].user.userid, 'offers', 'add_items', {
                        offer: {
                            items: offers[id].items.map(a => generatePendingItem(a, { type: 'deposit', tradelocked: false, offset: false })),
                            more: true
                        }
                    });

                    setTimeout(function(){
                        if(offers[id] !== undefined){
                            //REMOVE PENDING FROM SELLER
                            emitSocketToRoom(offers[id].user.userid, 'offers', 'remove_pending', {
                                offer: {
                                    id: offers[id].id,
                                    method: 'steam'
                                }
                            });

                            delete offers[id];
                        }
                    }, config.trading.steam.time_remove_pending * 1000);

                    if(offers[id].refill) loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' (REFILL) | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Declined');
                    else loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Declined');
                });
            } else if(offers[id].type == 'withdraw'){
                pool.query('UPDATE `steam_transactions` SET `status` = -1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err1) {
                    if(err1) return;

                    //EDIT BALANCE
                    userService.editBalance(offers[id].user.userid, amount, 'steam_withdraw_refund', function(err2, newbalance){
                        if(err2) return;

                        userService.updateBalance(offers[id].user.userid, 'main', newbalance);

                        if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                        offers[id].status = -1;
                        offers[id].update = time();

                        //EDIT PENDING FROM BUYER
                        emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                            offer: {
                                id: offers[id].id,
                                type: offers[id].type,
                                method: 'steam',
                                game: offers[id].game,
                                status: offers[id].status,
                                items: offers[id].items,
                                data: {
                                    tradeofferid: offers[id].tradeofferid,
                                    amount: amount
                                }
                            }
                        });

                        //ADD ITEMS TO WITHDRAW
                        emitSocketToRoom('withdraw/steam/' + offers[id].game, 'offers', 'add_items', {
                            offer: {
                                items: offers[id].items.map(a => generatePendingItem(a, { type: 'withdraw', tradelocked: false, offset: true, bot: botsService.getIndexBySteamid(botsteamid) })),
                                more: true
                            }
                        });

                        //EDIT ITEMS
                        restoreWithdrawItems(offers[id].items, 0, function(err4){
                            if(err4) return;

                            setTimeout(function(){
                                if(offers[id] !== undefined){
                                    //REMOVE PENDING FROM BUYER
                                    emitSocketToRoom(offers[id].user.userid, 'offers', 'remove_pending', {
                                        offer: {
                                            id: offers[id].id,
                                            method: 'steam'
                                        }
                                    });

                                    delete offers[id];
                                }
                            }, config.trading.steam.time_remove_pending * 1000);

                            loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Declined');
                        });
                    });
                });
            }
        }
    } else if(offers[id].status == 2){
        if(state == 3){
            if(getSteamTime(offers[id].update + config.trading.steam.time_clear_trade) <= time() || offers[id].game != 'cs2'){
                if(offers[id].type == 'deposit'){
                    bot.manager.getOffer(id, function(err1, offer){
                        if(err1) return loggerError(err1);

                        offer.getExchangeDetails(function(err2, status, date, received, given) {
                            if(err2) return loggerError(err2);

                            var items = offers[id].items.map(function(a) {
                                var item = received.find(b => b.assetid == a.id);

                                return {
                                    ...a,
                                    ...{
                                        id: item.new_assetid,
                                        image: 'https://steamcommunity-a.akamaihd.net/economy/image/' + (item.icon_url_large || item.icon_url),
                                    }
                                };
                            });

                            pool.query('UPDATE `steam_transactions` SET `status` = 3, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err3) {
                                if(err3) return;

                                // recursive
                                items.forEach(function(item){
                                    if(item.wear != null && item.paintindex != null){
                                        pool.query('INSERT INTO `steam_items` SET `itemid` = ' + pool.escape(item.id) + ', `wear` = ' + pool.escape(item.wear) + ', `paintindex` = ' + pool.escape(item.paintindex) + ', `time` = ' + pool.escape(time()), function(err4) {
                                            if(err4) return;
                                        });
                                    }
                                });

                                if(offers[id].refill) {
                                    //EDIT BALANCE
                                    userService.editBalance(offers[id].user.userid, 0, 'steam_refill', function(err5){
                                        if(err5) return;

                                        if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                                        offers[id].status = 3;
                                        offers[id].update = time();

                                        //EDIT PENDING FROM SELLER
                                        emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                                            offer: {
                                                id: offers[id].id,
                                                type: offers[id].type,
                                                method: 'steam',
                                                game: offers[id].game,
                                                status: offers[id].status,
                                                items: offers[id].items,
                                                data: {
                                                    tradeofferid: offers[id].tradeofferid,
                                                    amount: amount,
                                                    refill: offers[id].refill
                                                }
                                            }
                                        });

                                        //ADD ITEMS TO WITHDRAW
                                        emitSocketToRoom('withdraw/steam/' + offers[id].game, 'offers', 'add_items', {
                                            offer: {
                                                items: items.map(a => generatePendingItem(a, { type: 'withdraw', tradelocked: true, offset: true, bot: botsService.getIndexBySteamid(botsteamid) })),
                                                more: true
                                            }
                                        });

                                        //ADD ITEMS
                                        addWithdrawItems(items, 0, offers[id].game, botsteamid, function(err7){
                                            if(err7) return;

                                            setTimeout(function(){
                                                if(offers[id] !== undefined){
                                                    //REMOVE PENDING FROM SELLER
                                                    emitSocketToRoom(offers[id].user.userid, 'offers', 'remove_pending', {
                                                        offer: {
                                                            id: offers[id].id,
                                                            method: 'steam'
                                                        }
                                                    });

                                                    delete offers[id];
                                                }
                                            }, config.trading.steam.time_remove_pending * 1000);

                                            loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' (REFILL) | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Accepted');
                                        });
                                    });
                                } else {
                                    pool.query('INSERT INTO `users_trades` SET `type` = ' + pool.escape(offers[id].type) + ', `method` = ' + pool.escape("steam") + ', `game` = ' + pool.escape(offers[id].game) + ', `userid` = ' + pool.escape(offers[id].user.userid) + ', `amount` = ' + amount + ', `value` = ' + amount + ', `tradeid` = ' + pool.escape(offers[id].id) + ', `time` = ' + pool.escape(time()), function(err4){
                                        if(err4) return;

                                        //EDIT BALANCE
                                        userService.editBalance(offers[id].user.userid, amount, 'steam_deposit', function(err5, newbalance1){
                                            if(err5) return;

                                            pool.query('UPDATE `users` SET `rollover` = `rollover` + ' + amount + ' WHERE `userid` = ' + pool.escape(offers[id].user.userid), function(err6) {
                                                if(err6) return;

                                                //REGISTER AFFILIATES
                                                userService.registerAffiliates(offers[id].user.userid, amount, 'deposit', function(err7){
                                                    if(err7) return;

                                                    //REGISTER DEPOSIT BONUS
                                                    userService.registerDepositBonus(offers[id].user.userid, amount, function(err8, newbalance2){
                                                        if(err8) return;

                                                        if(newbalance2) userService.updateBalance(offers[id].user.userid, 'main', newbalance2);
                                                        else userService.updateBalance(offers[id].user.userid, 'main', newbalance1);

                                                        if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                                                        offers[id].status = 3;

                                                        //EDIT PENDING FROM SELLER
                                                        emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                                                            offer: {
                                                                id: offers[id].id,
                                                                type: offers[id].type,
                                                                method: 'steam',
                                                                game: offers[id].game,
                                                                status: offers[id].status,
                                                                items: offers[id].items,
                                                                data: {
                                                                    tradeofferid: offers[id].tradeofferid,
                                                                    amount: amount,
                                                                    refill: offers[id].refill
                                                                }
                                                            }
                                                        });

                                                        //ADD ITEMS TO WITHDRAW
                                                        emitSocketToRoom('withdraw/steam/' + offers[id].game, 'offers', 'add_items', {
                                                            offer: {
                                                                items: items.map(a => generatePendingItem(a, { type: 'withdraw', tradelocked: true, offset: true, bot: botsService.getIndexBySteamid(botsteamid) })),
                                                                more: true
                                                            }
                                                        });

                                                        //ADD ITEMS
                                                        addWithdrawItems(items, 0, offers[id].game, botsteamid, function(err9){
                                                            if(err9) return;

                                                            setTimeout(function(){
                                                                if(offers[id] !== undefined){
                                                                    //REMOVE PENDING FROM SELLER
                                                                    emitSocketToRoom(offers[id].user.userid, 'offers', 'remove_pending', {
                                                                        offer: {
                                                                            id: offers[id].id,
                                                                            method: 'steam'
                                                                        }
                                                                    });

                                                                    delete offers[id];
                                                                }
                                                            }, config.trading.steam.time_remove_pending * 1000);

                                                            loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Accepted');
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                }
                            });
                        });
                    });
                } else if(offers[id].type == 'withdraw'){
                    pool.query('UPDATE `steam_transactions` SET `status` = 3, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err1) {
                        if(err1) return;

                        pool.query('INSERT INTO `users_trades` SET `type` = ' + pool.escape(offers[id].type) + ', `method` = ' + pool.escape("steam") + ', `game` = ' + pool.escape(offers[id].game) + ', `userid` = ' + pool.escape(offers[id].user.userid) + ', `amount` = ' + amount + ', `value` = ' + amount + ', `tradeid` = ' + pool.escape(offers[id].id) + ', `time` = ' + pool.escape(time()), function(err2){
                            if(err2) return;

                            if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                            offers[id].status = 3;
                            offers[id].update = time();

                            //EDIT PENDING FROM BUYER
                            emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                                offer: {
                                    id: offers[id].id,
                                    type: offers[id].type,
                                    method: 'steam',
                                    game: offers[id].game,
                                    status: offers[id].status,
                                    items: offers[id].items,
                                    data: {
                                        tradeofferid: offers[id].tradeofferid
                                    }
                                }
                            });

                            //ADD ITEMS TO DEPOSIT
                            emitSocketToRoom('deposit/steam/' + offers[id].game + '/' + offers[id].user.userid, 'offers', 'add_items', {
                                offer: {
                                    items: offers[id].items.map(a => generatePendingItem(a, { type: 'deposit', tradelocked: false, offset: false })),
                                    more: true
                                }
                            });

                            //EDIT ITEMS
                            clearanceWithdrawItems(offers[id].items, 0, function(err4){
                                if(err4) return;

                                setTimeout(function(){
                                    if(offers[id] !== undefined){
                                        //REMOVE PENDING FROM BUYER
                                        emitSocketToRoom(offers[id].user.userid, 'offers', 'remove_pending', {
                                            offer: {
                                                id: offers[id].id,
                                                method: 'steam'
                                            }
                                        });

                                        delete offers[id];
                                    }
                                }, config.trading.steam.time_remove_pending * 1000);

                                loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Accepted');
                            });
                        });
                    });
                }
            }
        } else if(state == 12){
            if(offers[id].type == 'deposit'){
                pool.query('UPDATE `steam_transactions` SET `status` = -1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err1) {
                    if(err1) return;

                    if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                    offers[id].status = -1;
                    offers[id].update = time();

                    //EDIT PENDING FROM SELLER
                    emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                        offer: {
                            id: offers[id].id,
                            type: offers[id].type,
                            method: 'steam',
                            game: offers[id].game,
                            status: offers[id].status,
                            items: offers[id].items,
                            data: {
                                tradeofferid: offers[id].tradeofferid
                            }
                        }
                    });

                    //ADD ITEMS TO DEPOSIT
                    emitSocketToRoom('deposit/steam/' + offers[id].game + '/' + offers[id].user.userid, 'offers', 'add_items', {
                        offer: {
                            items: offers[id].items.map(a => generatePendingItem(a, { type: 'deposit', tradelocked: true, offset: false })),
                            more: true
                        }
                    });

                    setTimeout(function(){
                        if(offers[id] !== undefined){
                            //REMOVE PENDING FROM SELLER
                            emitSocketToRoom(offers[id].user.userid, 'offers', 'remove_pending', {
                                offer: {
                                    id: offers[id].id,
                                    method: 'steam'
                                }
                            });

                            delete offers[id];
                        }
                    }, config.trading.steam.time_remove_pending * 1000);

                    loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Rolled Back');
                });
            } else if(offers[id].type == 'withdraw'){
                pool.query('UPDATE `steam_transactions` SET `status` = -1, `update` = ' + pool.escape(time()) + ' WHERE `id` = ' + pool.escape(offers[id].id), function(err1) {
                    if(err1) return;

                    //EDIT BALANCE
                    userService.editBalance(offers[id].user.userid, amount, 'steam_withdraw_refund', function(err2, newbalance){
                        if(err2) return;

                        userService.updateBalance(offers[id].user.userid, 'main', newbalance);

                        if(offers[id].timeout != null) clearTimeout(offers[id].timeout);

                        offers[id].status = -1;
                        offers[id].update = time();

                        //EDIT PENDING FROM BUYER
                        emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                            offer: {
                                id: offers[id].id,
                                type: offers[id].type,
                                method: 'steam',
                                game: offers[id].game,
                                status: offers[id].status,
                                items: offers[id].items,
                                data: {
                                    tradeofferid: offers[id].tradeofferid,
                                    amount: amount
                                }
                            }
                        });

                        //ADD ITEMS TO WITHDRAW
                        emitSocketToRoom('withdraw/steam/' + offers[id].game, 'offers', 'add_items', {
                            offer: {
                                items: offers[id].items.map(a => generatePendingItem(a, { type: 'withdraw', tradelocked: true, offset: true, bot: botsService.getIndexBySteamid(botsteamid) })),
                                more: true
                            }
                        });

                        //add new items with new assetid, not restore
                        //EDIT ITEMS
                        restoreWithdrawItems(offers[id].items, 0, function(err4){
                            if(err4) return;

                            setTimeout(function(){
                                if(offers[id] !== undefined){
                                    //REMOVE PENDING FROM BUYER
                                    emitSocketToRoom(offers[id].user.userid, 'offers', 'remove_pending', {
                                        offer: {
                                            id: offers[id].id,
                                            method: 'steam'
                                        }
                                    });

                                    delete offers[id];
                                }
                            }, config.trading.steam.time_remove_pending * 1000);

                            loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Declined');
                        });
                    });
                });
            }
        }
    }
}

function offerConfirmationAccepted(id, botsteamid){
	if(offers[id] === undefined) return;

    var bot = botsService.getBotBySteamid(botsteamid);

    if(!bot.options.trade) return;

	if(offers[id].type == 'withdraw'){
        pool.query('UPDATE `steam_transactions` SET `status` = 1, `update` = ' + pool.escape(time()) + ' WHERE `tradeofferid` = ' + pool.escape(id), function(err1) {
            if(err1) return;

            offers[id].status = 1;
            offers[id].update = time();
            offers[id].time = time();

            offers[id].timeout = setTimeout(function(){
                botsService.declineOffer(offers[id].tradeofferid, bot.steamid, function(err2){
                    if(err2) return;
                });
            }, config.trading.steam.time_cancel_trade * 1000)

            //EDIT PENDING FROM BUYER
            emitSocketToRoom(offers[id].user.userid, 'offers', 'edit_pending', {
                offer: {
                    id: offers[id].id,
                    type: offers[id].type,
                    method: 'steam',
                    game: offers[id].game,
                    status: offers[id].status,
                    items: offers[id].items,
                    data: {
                        tradeofferid: offers[id].tradeofferid,
                        code: offers[id].code,
                        time: offers[id].time + config.trading.steam.time_cancel_trade
                    }
                }
            });

            loggerInfo('[BOT] ' + bot.name + ' - ' + offers[id].type.toUpperCase() + ' | ' + offers[id].user.userid + ' | Offer #' + id + ' Was Confirmed');
        });
    }
}

/* ----- INTERNAL USAGE ----- */
function addWithdrawItems(items, itemid, game, botsteamid, callback){
    if(itemid >= items.length) return callback(null);

    pool.query('INSERT INTO `steam_withdraw` SET `itemid` = ' + pool.escape(items[itemid].id) + ', `game` = ' + pool.escape(game) + ', `name` = ' + pool.escape(items[itemid].hashname) + ', `image` = ' + pool.escape(items[itemid].image) + ', `quality` = ' + pool.escape(items[itemid].quality) + ', `stickers` = ' + pool.escape(JSON.stringify(items[itemid].stickers || [])) + ', `botsteamid` = ' + pool.escape(botsteamid) + ', `time` = ' + pool.escape(time()), function(err1, row1) {
        if(err1) return callback(new Error('An error occurred while adding withdraw items (1)'));

        if(row1.affectedRows > 0) shopItems[items[itemid].id] = {
            status: 0,
            id: items[itemid].id,
            name: items[itemid].hashname,
            image: items[itemid].image,
            quality: items[itemid].quality,
            stickers: items[itemid].stickers,
            tradelocked: getSteamTime(time() + config.trading.steam.cooldown_items_deposit),
            game: items[itemid].game,
            botsteamid: botsteamid
        };

        addWithdrawItems(items, itemid + 1, game, botsteamid, callback);
    });
}

/* ----- INTERNAL USAGE ----- */
function reserveWithdrawItems(items, itemid, callback){
    if(itemid >= items.length) return callback(null);

    pool.query('UPDATE `steam_withdraw` SET `status` = 1 WHERE `itemid` = ' + pool.escape(items[itemid].id) + ' AND `status` = 0', function(err1, row1) {
        if(err1) return callback(new Error('An error occurred while reserveing withdraw items (1)'));

        if(row1.affectedRows > 0) if(shopItems[items[itemid].id] !== undefined) shopItems[items[itemid].id].status = 1;

        reserveWithdrawItems(items, itemid + 1, callback);
    });
}

/* ----- INTERNAL USAGE ----- */
function restoreWithdrawItems(items, itemid, callback){
    if(itemid >= items.length) return callback(null);

    pool.query('UPDATE `steam_withdraw` SET `status` = 0 WHERE `itemid` = ' + pool.escape(items[itemid].id) + ' AND `status` = 1', function(err1, row1) {
        if(err1) return callback(new Error('An error occurred while restoring withdraw items (1)'));

        if(row1.affectedRows > 0) if(shopItems[items[itemid].id] !== undefined) shopItems[items[itemid].id].status = 0;

        restoreWithdrawItems(items, itemid + 1, callback);
    });
}

/* ----- INTERNAL USAGE ----- */
function clearanceWithdrawItems(items, itemid, callback){
    if(itemid >= items.length) return callback(null);

    pool.query('UPDATE `steam_withdraw` SET `status` = 2 WHERE `itemid` = ' + pool.escape(items[itemid].id) + ' AND `status` = 1', function(err1, row1) {
        if(err1) return callback(new Error('An error occurred while clearancing withdraw items (1)'));

        if(row1.affectedRows > 0) if(shopItems[items[itemid].id] !== undefined) delete shopItems[items[itemid].id];

        clearanceWithdrawItems(items, itemid + 1, callback);
    });
}

/* ----- INTERNAL USAGE ----- */
function generatePendingItem(item, data){
    if(item.accepted === undefined) item.accepted = true;
    if(item.inspect === undefined) item.inspect = null;

    if(!data.offset) item.offset = 0;

    if(item.bot === undefined) if(data.type == 'withdraw') item.bot = data.bot;

    if(data.tradelocked && item.game == 'cs2') item.tradelocked = config.trading.steam.cooldown_items_deposit;
    else item.tradelocked = null;

	return item;
}

/* ----- CLIENT USAGE ----- */
function placeDeposit(user, socket, game, items, refill, recaptcha, cooldown){
	cooldown(true, true);

	if(refill && !haveRankPermission('refill_shop', user.rank)) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You don\'t have permission to use that!'
		});

		return cooldown(false, true);
	}

	verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid recaptcha!'
			});

			return cooldown(false, true);
		}

		emitSocketToUser(socket, 'message', 'info', {
			message: 'Preparing deposit request. Please wait...'
		});

		confirmDeposit(user, game, items, refill, function(err1, offer){
			if(err1){
				emitSocketToUser(socket, 'message', 'error', {
					message: err1.message
				});

				return cooldown(false, true);
			}

			//REMOVE ITEMS FROM DEPOSIT
			emitSocketToRoom('deposit/steam/' + game + '/' + offers[offer.id].user.userid, 'offers', 'remove_items', {
				offer: {
					items: offers[offer.id].items,
					all: false
				}
			});

			//ADD PENDING TO SELLER
			emitSocketToRoom(offers[offer.id].user.userid, 'offers', 'add_pending', {
				offer: {
					id: offers[offer.id].id,
					type: offers[offer.id].type,
					method: 'steam',
                    game: offers[offer.id].game,
					status: offers[offer.id].status,
					items: offers[offer.id].items,
					data: {
						tradeofferid: offers[offer.id].tradeofferid,
						code: offers[offer.id].code,
						time: offers[offer.id].time + config.trading.steam.time_cancel_trade
					}
				}
			});

			cooldown(false, false);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function confirmDeposit(user, game, itemsid, refill, callback){
	if((user.restrictions.trade >= time() || user.restrictions.trade == -1) && !haveRankPermission('exclude_ban_trade', user.rank)) return callback(new Error('You are restricted to use our trade. The restriction expires ' + ((user.restrictions.trade == -1) ? 'never' : makeDate(new Date(user.restrictions.trade * 1000))) + '.'));

	if(user.exclusion > time()) return callback(new Error('Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'));

	if(config.trading.steam.games[game] === undefined) return callback(new Error('Invalid deposit game!'));

	if(user.binds.steam === undefined) return callback(new Error('Please bind your Steam Account!'));

	if(!user.tradelink) return callback(new Error('Firstly, you must set your valid Steam Trade Link from settings.'));

	if(itemsid.length < config.app.intervals.items.deposit.min || itemsid.length > config.app.intervals.items.deposit.max) return callback(new Error('Invalid items amount [' + config.app.intervals.items.deposit.min + '-' + config.app.intervals.items.deposit.max + ']!'));

	inventoryService.checkDepositByGames(user.binds.steam, game, 0, itemsid, config.trading.steam.deposit_offset, [], function(err1, response){
		if(err1) return callback(err1);

        var amount = response.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0);

		if(response.length != itemsid.length) return callback(new Error('Invalids items in your offer. Please refresh your inventory!'));

		if(amount < config.app.intervals.amounts.deposit_steam.min || amount > config.app.intervals.amounts.deposit_steam.max) return callback(new Error('Invalid deposit amount [' + getFormatAmountString(config.app.intervals.amounts.deposit_steam.min) + '-' + getFormatAmountString(config.app.intervals.amounts.deposit_steam.max) + ']!'));

		var code = generateHexCode(24);

		if(!botsService.haveActiveBotByType('trade')) return callback(new Error('There are no active bots. Please try again later.'));

		var bot = botsService.getActiveBotByType('trade');

		botsService.sendOffer(user.binds.steam, game, user.tradelink, code, [], itemsid, bot.steamid, function(err2, offer){
			if(err2) return callback(err2);

			if(refill) loggerInfo('[BOT] ' + bot.name + ' - DEPOSIT (REFILL) | ' + user.userid + ' | Offer #' + offer.id + ' Was Sent');
			else loggerInfo('[BOT] ' + bot.name + ' - DEPOSIT | ' + user.userid + ' | Offer #' + offer.id + ' Was Sent');

			pool.query('INSERT INTO `steam_transactions` SET `status` = 1, `refill` = ' + (refill ? 1 : 0) + ', `type` = ' + pool.escape('deposit') + ', `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + pool.escape(user.xp) + ', `steamid` = ' + pool.escape(user.binds.steam) + ', `items` = ' + pool.escape(JSON.stringify(response)) + ', `amount` = ' + amount + ', `code` = ' + pool.escape(code) + ', `game` = ' + pool.escape(game) + ', `tradeofferid` = ' + pool.escape(offer.id) + ', `botsteamid` = ' + pool.escape(bot.steamid) + ', `update` = ' + pool.escape(time()) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
				if(err3) return callback(new Error('An error occurred while confirming deposit (1)'));

				offers[offer.id] = {
					id: row3.insertId,
					status: 1,
					type: 'deposit',
                    botsteamid: bot.steamid,
					refill: refill,
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					game: game,
					items: response,
					amount: amount,
					create: time(),
					update: time(),
					tradeofferid: offer.id,
					code: code,
					time: time(),
					timeout: setTimeout(function(){
						botsService.declineOffer(offer.id, bot.steamid, function(err4){
							if(err4) return;
						});
					}, config.trading.steam.time_cancel_trade * 1000)
				};

				loggerInfo('[STEAM] Deposit order #' + row3.insertId + ' has been prepared');

				callback(null, offer);
			});
		});
	});
}

function loadShopItems(){
	pool.query('SELECT * FROM `steam_withdraw` WHERE `status` != 2', function(err1, items) {
		if(err1) return;

		items.forEach(function(item){
			if(shopItems[item.itemid] === undefined) shopItems[item.itemid] = {
                status: parseInt(item.status),
                id: item.itemid,
                name: item.name,
                image: item.image,
                quality: item.quality,
                stickers: JSON.parse(item.stickers),
                tradelocked: getSteamTime(item.time + config.trading.steam.cooldown_items_deposit),
                game: item.game,
                botsteamid: item.botsteamid
            };
		});

		loggerInfo('[BOT] Items withdraw loaded!');
	});
}

/* ----- CLIENT USAGE ----- */
function placeWithdraw(user, socket, game, items, botid, recaptcha, cooldown){
	cooldown(true, true);

	verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			emitSocketToUser(socket, 'message', 'error', {
				message: 'Invalid recaptcha!'
			});

			return cooldown(false, true);
		}

		if(config.settings.payments.manually.enable.steam) {
			emitSocketToUser(socket, 'message', 'info', {
				message: 'Preparing withdraw request. Please wait...'
			});

			return confirmWithdraw(user, game, items, botid, function(err1, listingid){
				if(err1){
					emitSocketToUser(socket, 'message', 'error', {
						message: err1.message
					});

					return cooldown(false, true);
				}

				emitSocketToUser(socket, 'message', 'info', {
					message: 'Your steam withdraw order was listed. Admin confirmations required!'
				});

				cooldown(false, false);
			});
		}

		emitSocketToUser(socket, 'message', 'info', {
			message: 'Preparing withdraw request. Please wait...'
		});

		confirmWithdraw(user, game, items, botid, function(err1, offerid){
			if(err1){
				emitSocketToUser(socket, 'message', 'error', {
					message: err1.message
				});

				return cooldown(false, true);
			}

			cooldown(false, false);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function confirmWithdraw(user, game, itemsid, botid, callback){
	if((user.restrictions.trade >= time() || user.restrictions.trade == -1) && !haveRankPermission('exclude_ban_trade', user.rank)) return callback(new Error('You are restricted to use our trade. The restriction expires ' + ((user.restrictions.trade == -1) ? 'never' : makeDate(new Date(user.restrictions.trade * 1000))) + '.'));

	if(config.trading.steam.games[game] === undefined) return callback(new Error('Invalid withdraw game!'));

	if(user.binds.steam === undefined) return callback(new Error('Please bind your Steam Account!'));

	if(!user.tradelink) return callback(new Error('Firstly, you must set your valid Steam Trade Link from settings.'));

	if(itemsid.length < config.app.intervals.items.withdraw.min || itemsid.length > config.app.intervals.items.withdraw.max) return callback(new Error('Invalid items amount [' + config.app.intervals.items.withdraw.min + '-' + config.app.intervals.items.withdraw.max + ']!'));

	checkWithdrawByGames(game, 0, itemsid, config.trading.steam.withdraw_offset, [], function(err1, response){
		if(err1) return callback(err1);

        var amount = response.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0);

		if(response.length != itemsid.length) return callback(new Error('Invalids items in your offer. Please refresh your inventory!'));

		if((amount < config.app.intervals.amounts.withdraw_steam.min || amount > config.app.intervals.amounts.withdraw_steam.max) && !haveRankPermission('withdraw', user.rank)) return callback(new Error('Invalid withdraw amount [' + getFormatAmountString(config.app.intervals.amounts.withdraw_steam.min) + '-' + getFormatAmountString(config.app.intervals.amounts.withdraw_steam.max) + ']!'));

        pool.query('SELECT SUM(`amount`) AS `amount` FROM `users_trades` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `type` = ' + pool.escape('deposit') + ' AND `time` > ' + pool.escape(config.trading.withdraw_requirements.deposit.time == -1 ? 0 : time() - config.trading.withdraw_requirements.deposit.time), function(err2, row2) {
            if(err2) return callback(new Error('An error occurred while confirming withdraw (1)'));

            if(getFormatAmount(row2[0].amount) < config.trading.withdraw_requirements.deposit.amount && !haveRankPermission('withdraw', user.rank)) {
                if(config.trading.withdraw_requirements.deposit.time == -1) return callback(new Error('You need to deposit minimum ' + getFormatAmountString(config.trading.withdraw_requirements.deposit.amount) + ' coins to unlock withdraw!'));
                else return callback(new Error('You need to deposit minimum ' + getFormatAmountString(config.trading.withdraw_requirements.deposit.amount) + ' coins in the last ' + Math.floor(config.trading.withdraw_requirements.deposit.time / (24 * 60 * 60)) + ' days to unlock withdraw!'));
            }

            //CHECK BALANCE
            userService.getBalance(user.userid, function(err3, balance){
                if(err3) return callback(err3);

                if(balance < amount) {
                    emitSocketToRoom(user.userid, 'modal', 'insufficient_balance', {
                        amount: getFormatAmount(amount - balance)
                    });

                    return callback(new Error('You don\'t have enough money!'));
                }

                if(user.rollover > 0 && !haveRankPermission('withdraw', user.rank)) {
                    emitSocketToRoom(user.userid, 'modal', 'withdraw_rollover', {
                        amount: getFormatAmount(user.rollover)
                    });

                    return callback(new Error('You have to play ' + getFormatAmountString(user.rollover) + ' coins to withdraw!'));
                }

                if(!botsService.haveActiveBotByIndex(botid)) return callback(new Error('This bot is not active anymore. Please try again later.'));

                if(config.settings.payments.manually.enable.steam && amount >= getFormatAmount(config.settings.payments.manually.amount)) {
                    return continueWithdrawManually(user, game, botid, response, function(err4, listingid){
                        if(err4) return callback(err4);

                        callback(null, listingid);
                    });
                }

                continueWithdrawAutomatically(user, game, itemsid, botid, response, function(err4, offerid){
                    if(err4) return callback(err4);

                    callback(null, offerid);
                });
            });
        });
	});
}

/* ----- INTERNAL USAGE ----- */
function continueWithdrawManually(user, game, botid, response, callback){
	var bot = botsService.getBotByIndex(botid);

	//EDIT ITEMS
    reserveWithdrawItems(response, 0, function(err1){
        if(err1) return callback(err1);

        var amount = response.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0);

        //EDIT BALANCE
        userService.editBalance(user.userid, -amount, 'steam_withdraw', function(err2, newbalance){
            if(err2) return callback(err2);

            userService.updateBalance(user.userid, 'main', newbalance);

            pool.query('INSERT INTO `steam_listings` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(user.userid) + ', `steamid` = ' + pool.escape(user.binds.steam) + ', `tradelink` = ' + pool.escape(user.tradelink) + ', `items` = ' + pool.escape(JSON.stringify(response)) + ', `amount` = ' + amount + ', `game` = ' + pool.escape(game) + ', `botsteamid` = ' + pool.escape(bot.steamid) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
                if(err3) return callback(new Error('An error occurred while continuing withdraw manually (1)'));

                //REMOVE ITEMS FROM WITHDRAW
                emitSocketToRoom('withdraw/steam/' + game, 'offers', 'remove_items', {
                    offer: {
                        items: response,
                        all: false
                    }
                });

                loggerInfo('[STEAM] Withdraw listing #' + row3.insertId + ' has been listed. Admin confirmations required');

                callback(null, row3.insertId);
            });
        });
    });
}

/* ----- INTERNAL USAGE ----- */
function continueWithdrawAutomatically(user, game, itemsid, botid, response, callback){
	var bot = botsService.getBotByIndex(botid);

	var code = generateHexCode(24);

	botsService.sendOffer(user.binds.steam, game, user.tradelink, code, itemsid, [], bot.steamid, function(err1, offer){
		if(err1) return callback(err1);

		loggerInfo('[BOT] ' + bot.name + ' - WITHDRAW | ' + user.userid + ' | Offer #' + offer.id + ' Was Sent');

        //EDIT ITEMS
        reserveWithdrawItems(response, 0, function(err2){
            if(err2) return callback(err2);

            var amount = response.reduce((acc, cur) => getFormatAmount(acc + cur.price), 0);

            //EDIT BALANCE
            userService.editBalance(user.userid, -amount, 'steam_withdraw', function(err3, newbalance){
                if(err3) return callback(err3);

                userService.updateBalance(user.userid, 'main', newbalance);

                pool.query('INSERT INTO `steam_transactions` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + pool.escape(user.xp) + ', `steamid` = ' + pool.escape(user.binds.steam) + ', `items` = ' + pool.escape(JSON.stringify(response)) + ', `amount` = ' + amount + ', `code` = ' + pool.escape(code) + ', `game` = ' + pool.escape(game) + ', `tradeofferid` = ' + pool.escape(offer.id) + ', `botsteamid` = ' + pool.escape(bot.steamid) + ', `update` = ' + pool.escape(time()) + ', `time` = ' + pool.escape(time()), function(err4, row4) {
                    if(err4) return callback(new Error('An error occurred while continuing withdraw automatically (1)'));

                    offers[offer.id] = {
                        id: row4.insertId,
                        status: 0,
                        type: 'withdraw',
                        botsteamid: bot.steamid,
                        refill: false,
                        user: {
                            userid: user.userid,
                            name: user.name,
                            avatar: user.avatar,
                            level: calculateLevel(user.xp).level
                        },
                        game: game,
                        items: response,
                        amount: amount,
                        create: time(),
						update: time(),
                        tradeofferid: offer.id,
                        code: code,
                        time: null,
                        timeout: null
                    };

                    //REMOVE ITEMS FROM WITHDRAW
                    emitSocketToRoom('withdraw/steam/' + game, 'offers', 'remove_items', {
                        offer: {
                            items: offers[offer.id].items,
                            all: false
                        }
                    });

                    //ADD PENDING TO BUYER
                    emitSocketToRoom(offers[offer.id].user.userid, 'offers', 'add_pending', {
                        offer: {
                            id: offers[offer.id].id,
                            type: offers[offer.id].type,
                            method: 'steam',
                            game: offers[offer.id].game,
                            status: offers[offer.id].status,
                            items: offers[offer.id].items,
                            data: {
                                tradeofferid: offers[offer.id].tradeofferid,
                                code: offers[offer.id].code
                            }
                        }
                    });

                    loggerInfo('[STEAM] Withdraw order #' + row4.insertId + ' has been prepared');

                    callback(null, offer.id);
                });
            });
        });
	});
}

function confirmWithdrawListing(user, id, callback){
	pool.query('SELECT * FROM `steam_listings` WHERE `id` = ' + pool.escape(id), function(err1, row1) {
		if(err1) return callback(new Error('An error occurred while confirming withdraw listing (1)'));

		if(row1.length <= 0) return callback(new Error('Unknown steam withdraw listing!'));
		if(parseInt(row1[0].confirmed)) return callback(new Error('Steam withdraw listing already confirmed!'));
		if(parseInt(row1[0].canceled)) return callback(new Error('Steam withdraw listing is canceled!'));

		pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(row1[0].userid), function(err2, row2) {
			if(err2) return callback(new Error('An error occurred while confirming withdraw listing (2)'));

			if(row2.length <= 0) return callback(new Error('Unknown user listing!'));

			var game = row1[0].game;
			var botsteamid = row1[0].botsteamid;
			var steamid = row1[0].steamid;
			var tradelink = row1[0].tradelink;

			var items = JSON.parse(row1[0].items);
			var amount = getFormatAmount(row1[0].amount);

			if(config.trading.steam.games[game] === undefined) return callback(new Error('Invalid withdraw game!'));

			var code = generateHexCode(24);

			if(!botsService.haveActiveBotBySteamid(botsteamid)) return callback(new Error('There are no active bots. Please try again later.'));

			var bot = botsService.getBotBySteamid(botsteamid);

			botsService.sendOffer(steamid, game, tradelink, code, items.map(a => a.id), [], bot.steamid, function(err3, offer){
				if(err3) return callback(err3);

				loggerInfo('[BOT] ' + bot.name + ' - WITHDRAW | ' + row2[0].userid + ' | Offer #' + offer.id + ' Was Sent');

				pool.query('INSERT INTO `steam_transactions` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(row2[0].userid) + ', `name` = ' + pool.escape(row2[0].name) + ', `avatar` = ' + pool.escape(row2[0].avatar) + ', `xp` = ' + pool.escape(row2[0].xp) + ', `steamid` = ' + pool.escape(steamid) + ', `items` = ' + pool.escape(JSON.stringify(items)) + ', `amount` = ' + amount + ', `code` = ' + pool.escape(code) + ', `game` = ' + pool.escape(game) + ', `tradeofferid` = ' + pool.escape(offer.id) + ', `botsteamid` = ' + pool.escape(bot.steamid) + ', `update` = ' + pool.escape(time()) + ', `time` = ' + pool.escape(time()), function(err4, row4) {
					if(err4) return callback(new Error('An error occurred while confirming withdraw listing (3)'));

					offers[offer.id] = {
						id: row4.insertId,
						status: 0,
						type: 'withdraw',
                        botsteamid: botsteamid,
						refill: false,
						user: {
							userid: row2[0].userid,
							name: row2[0].name,
							avatar: row2[0].avatar,
							level: calculateLevel(row2[0].xp).level
						},
						game: game,
						items: items,
						amount: amount,
						create: time(),
						update: time(),
						tradeofferid: offer.id,
						code: code,
						time: null,
						timeout: null
					};

					//REMOVE ITEMS FROM WITHDRAW
					emitSocketToRoom('withdraw/steam/' + game, 'offers', 'remove_items', {
						offer: {
							items: offers[offer.id].items,
							all: false
						}
					});

					//ADD PENDING TO BUYER
					emitSocketToRoom(offers[offer.id].user.userid, 'offers', 'add_pending', {
						offer: {
							id: offers[offer.id].id,
							type: offers[offer.id].type,
							method: 'steam',
                            game: offers[offer.id].game,
							status: offers[offer.id].status,
							items: offers[offer.id].items,
							data: {
								tradeofferid: offers[offer.id].tradeofferid,
								code: offers[offer.id].code
							}
						}
					});

					loggerInfo('[STEAM] Withdraw order #' + row4.insertId + ' has been prepared');

					pool.query('UPDATE `steam_listings` SET `confirmed` = 1 WHERE `id` = ' + pool.escape(row1[0].id) + ' AND `confirmed` = 0 AND `canceled` = 0', function(err5) {
						if(err5) return callback(new Error('An error occurred while confirming withdraw listing (4)'));

						pool.query('INSERT INTO `steam_confirmations` SET `userid` = ' + pool.escape(user.userid) + ', `listingid` = ' + pool.escape(row1[0].id) + ', `transactionid` = ' + pool.escape(row4.insertId) + ', `time` = ' + pool.escape(time()), function(err6) {
							if(err6) return callback(new Error('An error occurred while confirming withdraw listing (5)'));

							callback(null, row4.insertId);
						});
					});
				});
			});
		});
	});
}

function cancelWithdrawListing(user, id, callback){
	pool.query('SELECT * FROM `steam_listings` WHERE `id` = ' + pool.escape(id), function(err1, row1) {
		if(err1) return callback(new Error('An error occurred while canceling withdraw listing (1)'));

		if(row1.length <= 0) return callback(new Error('Unknown steam withdraw listing!'));
		if(parseInt(row1[0].confirmed)) return callback(new Error('Steam withdraw listing id confirmed!'));
		if(parseInt(row1[0].canceled)) return callback(new Error('Steam withdraw listing already canceled!'));

		var items = JSON.parse(row1[0].items);
		var amount = getFormatAmount(row1[0].amount);

		var game = row1[0].game;

		//EDIT BALANCE
		userService.editBalance(row1[0].userid, amount, 'steam_withdraw_refund', function(err2, newbalance){
			if(err2) return callback(err2);

			userService.updateBalance(row1[0].userid, 'main', newbalance);

			pool.query('UPDATE `steam_listings` SET `canceled` = 1 WHERE `id` = ' + pool.escape(row1[0].id) + ' AND `confirmed` = 0 AND `canceled` = 0', function(err3) {
                if(err3) return callback(new Error('An error occurred while canceling withdraw listing (2)'));

                emitSocketToRoom(row1[0].userid, 'message', 'info', {
                    message: 'Your steam withdraw order was canceled!'
                });

                //ADD ITEMS TO WITHDRAW
                emitSocketToRoom('withdraw/steam/' + game, 'offers', 'add_items', {
                    offer: {
                        items: items.map(a => generatePendingItem(a, { type: 'withdraw', tradelocked: false, offset: true, bot: botsService.getIndexBySteamid(row1[0].botsteamid) })),
                        more: true
                    }
                });

                //EDIT ITEMS
                restoreWithdrawItems(items, 0, function(err5){
                    if(err5) return callback(err5);

                    loggerInfo('[STEAM] Withdraw listing #' + row1[0].id + ' has been canceled');

                    callback(null);
                });
			});
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function checkWithdrawByGames(game, gameid, itemsid, offset, response, callback) {
	if(gameid >= Object.keys(config.trading.steam.games).length) return callback(null, response);

	if(game != Object.keys(config.trading.steam.games)[gameid]) return checkWithdrawByGames(game, gameid + 1, itemsid, offset, response, callback);

	checkWithdrawByBots(Object.keys(config.trading.steam.games)[gameid], 0, itemsid, offset, [], function(err1, response_items){
		if(err1) return callback(err1);

		return checkWithdrawByGames(game, gameid + 1, itemsid, offset, [ ...response, ...response_items ], callback);
	});
}

/* ----- INTERNAL USAGE ----- */
function checkWithdrawByBots(game, botid, itemsid, offset, response, callback) {
	if(botid >= botsService.getActiveBotsByType('trade').length) return callback(null, response);

    var bot = botsService.getActiveBotsByType('trade')[botid];

	inventoryService.getInventory(bot.steamid, config.trading.steam.games[game].game.appid, config.trading.steam.games[game].game.contextid, function(err1, inventory){
		if(err1) return callback(err1);

		checkWithdrawByItems(game, botid, inventory, 0, itemsid, offset, [], function(err2, response_items){
			if(err2) return callback(err2);

			return checkWithdrawByBots(game, botid + 1, itemsid, offset, [ ...response, ...response_items ], callback);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function checkWithdrawByItems(game, botid, inventory, itemid, itemsid, offset, response, callback){
	if(inventory[itemid] === undefined) return callback(null, response);

	if(itemsid.filter(a => a == inventory[itemid].assetid).length <= 0) return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);

	/* -- ACCEPTING --*/

	var accepted = true;

	if(!inventory[itemid].marketable || !inventory[itemid].tradable) accepted = false;
	if(response.filter(a => a.id == itemid).length > 0) accepted = false;
	if(shopItems[inventory[itemid].assetid] === undefined || shopItems[inventory[itemid].assetid].status == 1) accepted = false;
	if(config.trading.steam.blacklist_items[game].filter(a => inventory[itemid].name.toLowerCase().indexOf(a.toLowerCase()) >= 0).length > 0) accepted = false;

	if(!accepted) return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);

    if(!inventory[itemid].inspect || !itemExteriors.includes(inventoryService.parseItemName(inventory[itemid].name).exterior)){
        var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
	    if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

        if(price == null || price <= 0 || price < config.app.intervals.amounts.withdraw_item.min || price > config.app.intervals.amounts.withdraw_item.max) return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);

	    response.push({
            id: inventory[itemid].assetid,
            hashname: inventory[itemid].name,
            fullname: inventory[itemid].name,
            ...inventoryService.parseItemName(inventory[itemid].name),
            image: inventory[itemid].image,
            price: price,
            offset: offset,
            quality: inventory[itemid].quality,
            stickers: inventory[itemid].stickers,
            wear: null,
            paintindex: null,
            phase: null
        });

		return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);
    }

    pool.query('SELECT `wear`, `paintindex` FROM `steam_items` WHERE `itemid` = ' + pool.escape(inventory[itemid].assetid), function(err1, row1) {
        if(err1) {
            var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
            if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

            if(price == null || price <= 0 || price < config.app.intervals.amounts.withdraw_item.min || price > config.app.intervals.amounts.withdraw_item.max) return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);

            response.push({
                id: inventory[itemid].assetid,
                hashname: inventory[itemid].name,
                fullname: inventory[itemid].name,
                ...inventoryService.parseItemName(inventory[itemid].name),
                image: inventory[itemid].image,
                price: price,
                offset: offset,
                quality: inventory[itemid].quality,
                stickers: inventory[itemid].stickers,
                wear: null,
                paintindex: null,
                phase: null
            });

            return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);
        }

        if(row1.length <= 0){
            var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
            if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

            if(price == null || price <= 0 || price < config.app.intervals.amounts.withdraw_item.min || price > config.app.intervals.amounts.withdraw_item.max) return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);

            response.push({
                id: inventory[itemid].assetid,
                hashname: inventory[itemid].name,
                fullname: inventory[itemid].name,
                ...inventoryService.parseItemName(inventory[itemid].name),
                image: inventory[itemid].image,
                price: price,
                offset: offset,
                quality: inventory[itemid].quality,
                stickers: inventory[itemid].stickers,
                wear: null,
                paintindex: null,
                phase: null
            });

            return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);
        }

        var phase = inventoryService.getPhaseItem(inventory[itemid].name, row1[0].wear, row1[0].paintindex);
        var name = inventoryService.getNameItem(inventory[itemid].name, phase);

        var price = getFormatAmount(pricesService.getPrice(name, config.trading.steam.games[game].game.appid));
	    if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

        if(price == null || price <= 0 || price < config.app.intervals.amounts.withdraw_item.min || price > config.app.intervals.amounts.withdraw_item.max) return checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);

	    response.push({
            id: inventory[itemid].assetid,
            hashname: inventory[itemid].name,
            fullname: name,
            ...inventoryService.parseItemName(name),
            image: inventory[itemid].image,
            price: price,
            offset: offset,
            quality: inventory[itemid].quality,
            stickers: inventory[itemid].stickers,
            wear: row1[0].wear,
            paintindex: row1[0].paintindex,
            phase: phase
        });

        checkWithdrawByItems(game, botid, inventory, itemid + 1, itemsid, offset, response, callback);
    });
}

/* ----- CLIENT USAGE ----- */
function loadShopInventory(user, socket, method, game, offset, cooldown){
	cooldown(true, true);

	if(config.trading.steam.games[game] === undefined){
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid withdraw game!'
		});

		return cooldown(false, true);
	}

	if(shopInventory[user.userid] !== undefined){
		if(shopInventory[user.userid][method + '_' + game] !== undefined){
			if(shopInventory[user.userid][method + '_' + game].time - time() > 0){
				if(shopInventory[user.userid][method + '_' + game].error){
					emitSocketToUser(socket, 'message', 'error', {
						message: shopInventory[user.userid][method + '_' + game].error
					});
				} else {
					if(shopInventory[user.userid][method + '_' + game].items.length > 0){
						emitSocketToUser(socket, 'offers', 'add_items', {
							offer: {
								items: shopInventory[user.userid][method + '_' + game].items,
								more: false
							}
						});
					} else {
						emitSocketToUser(socket, 'message', 'error', {
							message: 'The Marketplace is currently empty.'
						});
					}
				}

				return cooldown(false, false);
			}
		}
	} else {
		shopInventory[user.userid] = {};
	}

	checkShopInventoryByGames(game, 0, offset, [], function(err1, response){
		if(err1){
			emitSocketToUser(socket, 'message', 'error', {
				message: err1.message
			});

			shopInventory[user.userid][method + '_' + game] = {
				time: time() + config.trading.steam.cooldown_inventory_fault * (haveRankPermission('load_inventory', user.rank) ? 0 : 1),
				items: [],
				error: err1.message
			};

			return cooldown(false, false);
		}

		if(response.length > 0){
			emitSocketToUser(socket, 'offers', 'add_items', {
				offer: {
					items: response,
					more: false
				}
			});
		} else {
			emitSocketToUser(socket, 'message', 'error', {
				message: 'The marketplace inventory is set to private or is empty.'
			});
		}

		shopInventory[user.userid][method + '_' + game] = {
			time: time() + config.trading.steam.cooldown_inventory_success * (haveRankPermission('load_inventory', user.rank) ? 0 : 1),
			items: response,
			error: null
		};

		cooldown(false, false);
	});
}

/* ----- INTERNAL USAGE ----- */
function checkShopInventoryByGames(game, gameid, offset, response, callback) {
	if(gameid >= Object.keys(config.trading.steam.games).length) return callback(null, response);

	if(game != Object.keys(config.trading.steam.games)[gameid]) return checkShopInventoryByGames(game, gameid + 1, offset, response, callback);

	checkShopInventoryByBots(Object.keys(config.trading.steam.games)[gameid], 0, offset, [], function(err1, response_items){
		if(err1) return callback(err1);

		return checkShopInventoryByGames(game, gameid + 1, offset, [ ...response, ...response_items], callback)
	});
}

/* ----- INTERNAL USAGE ----- */
function checkShopInventoryByBots(game, botid, offset, response, callback) {
    if(botid >= botsService.getActiveBotsByType('trade').length) return callback(null, response);

    var bot = botsService.getActiveBotsByType('trade')[botid];

	inventoryService.getInventory(bot.steamid, config.trading.steam.games[game].game.appid, config.trading.steam.games[game].game.contextid, function(err1, inventory){
		if(err1) return callback(err1);

		checkShopInventoryByItems(game, botid, [ ...inventory.filter(a => !Object.values(shopItems).some(b => b.id == a.assetid) || a.marketable),
            ...Object.values(shopItems).filter(a => a.botsteamid == bot.steamid && a.game == game && !inventory.some(b => b.assetid == a.id && b.marketable)).map(a => ({
                assetid: a.id,
				name: a.name,
				image: a.image,
				quality: a.quality,
				stickers: a.stickers,
				charms: [],
				inspect: null,
				tradable: false,
				marketable: true,
				tradelocked: a.tradelocked
            }))
        ], 0, offset, [], function(err2, response_items){
			if(err2) return callback(err2);

			return checkShopInventoryByBots(game, botid + 1, offset, [ ...response, ...response_items ], callback);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function checkShopInventoryByItems(game, bot, inventory, itemid, offset, response, callback){
	if(inventory[itemid] === undefined) return callback(null, response);

	/* -- ACCEPTING --*/

	var accepted = true;
	var view = true;

	if(!inventory[itemid].tradelocked && (!inventory[itemid].marketable || !inventory[itemid].tradable)) accepted = false;
	if(response.filter(a => a.id == itemid).length > 0) accepted = false;
	if(shopItems[inventory[itemid].assetid] === undefined || shopItems[inventory[itemid].assetid].status == 1) accepted = false;
	if(config.trading.steam.blacklist_items[game].filter(a => inventory[itemid].name.toLowerCase().indexOf(a.toLowerCase()) >= 0).length > 0) accepted = false;

	if(!inventory[itemid].marketable) view = false;
	if(response.filter(a => a.id == itemid).length > 0) view = false;
	if(shopItems[inventory[itemid].assetid] === undefined || shopItems[inventory[itemid].assetid].status == 1) view = false;

	if(!view) return checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);

    if(!inventory[itemid].inspect || !itemExteriors.includes(inventoryService.parseItemName(inventory[itemid].name).exterior)){
        var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
        if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

        if(price == null || price <= 0 || price < config.app.intervals.amounts.withdraw_item.min || price > config.app.intervals.amounts.withdraw_item.max) accepted = false;
	    if(price == null || price <= 0) view = false;

        if(!view) return checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);

        response.push({
            id: inventory[itemid].assetid,
            hashname: inventory[itemid].name,
            fullname: inventory[itemid].name,
            ...inventoryService.parseItemName(inventory[itemid].name),
            image: inventory[itemid].image,
            price: price,
            offset: offset,
            quality: inventory[itemid].quality,
            stickers: inventory[itemid].stickers,
            wear: null,
            paintindex: null,
            phase: null,
			accepted: accepted,
			tradelocked: inventory[itemid].tradelocked,
			bot: bot
        });

		return checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);
    }

    pool.query('SELECT `wear`, `paintindex` FROM `steam_items` WHERE `itemid` = ' + pool.escape(inventory[itemid].assetid), function(err1, row1) {
        if(err1) {
            var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
            if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

            if(price == null || price <= 0 || price < config.app.intervals.amounts.withdraw_item.min || price > config.app.intervals.amounts.withdraw_item.max) accepted = false;
            if(price == null || price <= 0) view = false;

            if(!view) return checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);

            response.push({
                id: inventory[itemid].assetid,
                hashname: inventory[itemid].name,
                fullname: inventory[itemid].name,
                ...inventoryService.parseItemName(inventory[itemid].name),
                image: inventory[itemid].image,
                price: price,
                offset: offset,
                quality: inventory[itemid].quality,
                stickers: inventory[itemid].stickers,
                wear: null,
                paintindex: null,
                phase: null,
                accepted: accepted,
                tradelocked: inventory[itemid].tradelocked,
                bot: bot
            });

            return checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);
        }

        if(row1.length <= 0){
            var price = getFormatAmount(pricesService.getPrice(inventory[itemid].name, config.trading.steam.games[game].game.appid));
            if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

            if(price == null || price <= 0 || price < config.app.intervals.amounts.withdraw_item.min || price > config.app.intervals.amounts.withdraw_item.max) accepted = false;
            if(price == null || price <= 0) view = false;

            if(!view) return checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);

            response.push({
                id: inventory[itemid].assetid,
                hashname: inventory[itemid].name,
                fullname: inventory[itemid].name,
                ...inventoryService.parseItemName(inventory[itemid].name),
                image: inventory[itemid].image,
                price: price,
                offset: offset,
                quality: inventory[itemid].quality,
                stickers: inventory[itemid].stickers,
                wear: null,
                paintindex: null,
                phase: null,
                accepted: accepted,
                tradelocked: inventory[itemid].tradelocked,
                bot: bot
            });

            return checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);
        }

        var phase = inventoryService.getPhaseItem(inventory[itemid].name, row1[0].wear, row1[0].paintindex);
        var name = inventoryService.getNameItem(inventory[itemid].name, phase);

        var price = getFormatAmount(pricesService.getPrice(name, config.trading.steam.games[game].game.appid));
        if(price > 0) price = getFormatAmount(price + getAmountCommission(price, offset));

        if(price == null || price <= 0 || price < config.app.intervals.amounts.withdraw_item.min || price > config.app.intervals.amounts.withdraw_item.max) accepted = false;
	    if(price == null || price <= 0) view = false;

        if(!view) return checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);

        response.push({
            id: inventory[itemid].assetid,
            hashname: inventory[itemid].name,
            fullname: name,
            ...inventoryService.parseItemName(name),
            image: inventory[itemid].image,
            price: price,
            offset: offset,
            quality: inventory[itemid].quality,
            stickers: inventory[itemid].stickers,
            wear: row1[0].wear,
            paintindex: row1[0].paintindex,
            phase: phase,
			accepted: accepted,
			tradelocked: inventory[itemid].tradelocked,
			bot: bot
        });

        checkShopInventoryByItems(game, bot, inventory, itemid + 1, offset, response, callback);
    });
}

module.exports = {
	initializeTrades, loadOffers, offerStateChanged, offerConfirmationAccepted,
	getBots, getPendings, loadShopItems, confirmWithdrawListing, cancelWithdrawListing,
	placeDeposit, loadUserInventory: inventoryService.loadUserInventory,
	placeWithdraw, loadShopInventory
};