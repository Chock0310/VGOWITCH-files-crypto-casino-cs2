var request = require('request');
var crypto = require('crypto');

var { pool } = require('@/lib/database.js');
var { loggerInfo, loggerDebug, loggerError } = require('@/lib/logger.js');

var { roundedToFixed } = require('@/utils/formatAmount.js');
var { time } = require('@/utils/formatDate.js');
var { isJsonString } = require('@/utils/utils.js');

var config = require('@/config/config.js');

var items = {};
var updating = {
	value: true
};

var callbacks = [];

function initializeItems(){
	loggerDebug('[ITEMS SYSTEM] Loading Items');

	updating.value = true;

	loadItems(0, function(err1){
		if(err1) {
            loggerInfo('[ITEMS SYSTEM] Error In Loading Items');

            return initializeItems();
        }

		updating.value = false;

		loadItemsCallbacks(0, function(err2){
			if(err2) {
                loggerInfo('[ITEMS SYSTEM] Error In Loading Items');

                return initializeItems();
            }

			initializePrices();
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function initializePrices(){
	loggerDebug('[ITEMS SYSTEM] Loading Prices');

	loadPrices(0, [], function(err1, updated){
		if(err1) {
            loggerInfo('[ITEMS SYSTEM] Error In Loading Prices');

            return initializePrices();
        }

		updating.value = true;

		updated.forEach(function(item){
			items[item.itemid].price = item.price;
		});

		updating.value = false;

        loadItemsCallbacks(0, function(err2){
			if(err2) {
                loggerInfo('[ITEMS SYSTEM] Error In Loading Items');

                return initializeItems();
            }

			setTimeout(function(){
                initializePrices();
            }, config.app.items.prices.cooldown_load * 1000);
		});
	});
}

function addCallback(callback){
	callbacks.push(callback);
}

/* ----- INTERNAL USAGE ----- */
function loadItems(gameid, callback){
	if(gameid >= Object.keys(config.app.items.prices.games).length) return callback(null);

	loggerInfo('[ITEMS SYSTEM] Loading ' + Object.keys(config.app.items.prices.games)[gameid].toUpperCase() + ' Items');

	var table = {
		'cs2': 'items_list',
		'rust': 'items_list_rust'
	}[Object.keys(config.app.items.prices.games)[gameid]];

	pool.query('SELECT `itemid`, `name`, `image`, `price`, `quality`, `update` FROM `' + table + '`', function(err1, row1) {
		if(err1) return callback(new Error('An error occurred while loading items (1)'));

		row1.forEach(function(item){
			items[item.itemid] = {
				id: item.itemid,
				game: Object.keys(config.app.items.prices.games)[gameid],
				name: item.name,
				image: item.image,
				price: roundedToFixed(item.price, 2),
				quality: item.quality,
				update: parseInt(item.update)
			};
		});

		loadItems(gameid + 1, callback);
	});
}

/* ----- INTERNAL USAGE ----- */
function loadItemsCallbacks(index, callback){
	if(index >= callbacks.length) return callback(null);

	callbacks[index](function(err1){
		if(err1) return callback(err1);

		loadItemsCallbacks(index + 1, callback);
	});
}

/* ----- INTERNAL USAGE ----- */
function loadPrices(gameid, list, callback){
	if(gameid >= Object.keys(config.app.items.prices.games).length) return callback(null, list);

	var options = {
		headers: {
			'content-type': 'application/json',
			'x-apikey': config.app.items.prices.apikey.key,
		},
		uri: 'https://api.bitskins.com/market/skin/' + config.app.items.prices.games[Object.keys(config.app.items.prices.games)[gameid]],
		qs: {}
	}

	request(options, function(err1, response1, body1) {
		if(err1) {
            loggerError(err1);

            return callback(new Error('An error occurred while loading prices (1)'));
        }

        if(!response1 || response1.statusCode != 200) return callback(new Error('An error occurred while loading prices (2)'));
		if(!isJsonString(body1)) return callback(new Error('An error occurred while loading prices (3)'));

		var body = JSON.parse(body1);

		var prices = [];

		body.forEach(function(item){
			var itemid = crypto.createHash('md5').update(item.name).digest().toString('hex');

			if(items[itemid] !== undefined && item.suggested_price != null){
				prices.push({
					name: item.name,
					price: roundedToFixed(item.suggested_price / 1000, 2)
				});
			}
		});

		updatePrices(Object.keys(config.app.items.prices.games)[gameid], 0, prices, [], function(err2, updated){
			if(err2) return callback(err2);

			loggerInfo('[ITEMS SYSTEM] Loaded ' + updated.length + ' ' + Object.keys(config.app.items.prices.games)[gameid].toUpperCase() + ' Prices Successfully');

			list.push(...updated);

			loadPrices(gameid + 1, list, callback);
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function updatePrices(game, index, prices, updated, callback){
	if(index >= prices.length) return callback(null, updated);

	if(prices[index].price <= 0) return updatePrices(game, index + 1, prices, updated, callback);

	var itemid = crypto.createHash('md5').update(prices[index].name).digest().toString('hex');

	var table = {
		'cs2': 'items_list',
		'rust': 'items_list_rust'
	}[game];

	pool.query('UPDATE `' + table + '` SET `price` = ' + prices[index].price + ', `update` = ' + pool.escape(time()) + ' WHERE `itemid` = ' + pool.escape(itemid), function(err1, row1){
		if(err1) return callback(new Error('An error occurred while updating prices (1)'));

		if(row1.affectedRows > 0) {
			updated.push({
				itemid: itemid,
				price: prices[index].price
			});
		}

		updatePrices(game, index + 1, prices, updated, callback);
	});
}

function addItem(userid, itemid, reward, callback){
	if(items[itemid] === undefined) return callback(new Error('Unknown itemid!'));

	pool.query('INSERT INTO `users_items` SET `userid` = ' + pool.escape(userid) + ', `itemid` = ' + pool.escape(itemid) + ', `reward` = ' + pool.escape(reward ? 1 : 0) + ', `time` = ' + pool.escape(time()), function(err1, row1){
		if(err1) return callback(new Error('An error occurred while adding item (1)'));

		if(row1.affectedRows <= 0) return callback(new Error('An error occurred while adding item (2)'));

		callback(null, {
			id: row1.insertId,
			itemid: itemid,
			price: items[itemid].price
		});
	});
}

module.exports = {
	items, updating,
	initializeItems, addCallback, addItem
};