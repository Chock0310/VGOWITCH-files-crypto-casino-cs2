var { pool } = require('@/lib/database.js');
var { emitSocketToUser } = require('@/lib/socket.js');
var { loggerDebug, loggerTrace, loggerInfo } = require('@/lib/logger.js');

var userService = (({ editBalance, addItems }) => ({ editBalance, addItems }))(require('@/services/userService.js'));
var fairService = (({ getUserSeeds, getCombinedSeed, generateSaltHash, getRoll }) => ({ getUserSeeds, getCombinedSeed, generateSaltHash, getRoll }))(require('@/services/fairService.js'));

var { time } = require('@/utils/formatDate.js');
var { roundedToFixed, getFormatAmount, getFormatAmountString } = require('@/utils/formatAmount.js');
var { calculateLevel, getColorByQuality, getRandomInt, countDecimals } = require('@/utils/utils.js');

var itemsService = (({ items }) => ({ items }))(require('@/services/itemsService.js'));

var config = require('@/config/config.js');

var cases = {};

function loadCases(callback){
	loggerDebug('[ITEMS SYSTEM] Loading Daily Cases');

	pool.query('SELECT * FROM `cases_dailycases` WHERE `removed` = 0', function(err1, row1){
		if(err1) {
            loggerInfo('[CHAT] Error In Loading Daily Cases');

            return loadCases(callback);
        }

		row1.forEach(function(caseitem){
			var caseitems = JSON.parse(caseitem.items);
			var caselevel = parseInt(caseitem.level);

			var item = {
				name: caseitem.name,
				image: caseitem.image,
				items: caseitems,
				level: caselevel
			}

			cases[caseitem.caseid] = item;
		});

		callback(null);
	})
}

/* ----- CLIENT USAGE ----- */
function getCases(user, socket, cooldown){
	cooldown(true, true);

	getCasesCase(user, 0, [], function(err1, listcases){
		if(err1) return cooldown(false, true);

		listcases.sort(function(a, b){ return a.level - b.level });

		emitSocketToUser(socket, 'dailycases', 'cases', {
			cases: listcases,
			level: calculateLevel(user.xp).level
		});

		cooldown(false, false);
	});
}

/* ----- INTERNAL USAGE ----- */
function getCasesCase(user, caseid, list, callback){
	if(caseid >= Object.keys(cases).length) return callback(null, list);

	pool.query('SELECT * FROM `dailycases_bets` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `caseid` = ' + pool.escape(Object.keys(cases)[caseid]) + ' AND `time` > ' + pool.escape(time() - config.app.dailycases.time * 60 * 60), function(err1, row1) {
		if(err1) return callback(new Error('An error occurred while getting cases case (1)'));

		var time_cooldown = row1.length > 0 ? (parseInt(row1[0].time) - time() + config.app.dailycases.time * 60 * 60) : -1;

		list.push({
			id: Object.keys(cases)[caseid],
			name: cases[Object.keys(cases)[caseid]].name,
			image: cases[Object.keys(cases)[caseid]].image,
			level: cases[Object.keys(cases)[caseid]].level,
			time: time_cooldown
		});

		getCasesCase(user, caseid + 1, list, callback);
	});
}

/* ----- INTERNAL USAGE ----- */
function getItems(items){
	var newitems = [];

	items.forEach(function(item){
		newitems.push({
			id: item.id,
			name: itemsService.items[item.id].name,
			image: itemsService.items[item.id].image,
			price: getFormatAmount(itemsService.items[item.id].price),
			chance: roundedToFixed(item.chance, 5),
			quality: itemsService.items[item.id].quality
		});
	});

	return newitems;
}

/* ----- INTERNAL USAGE ----- */
function getCase(user, socket, id, cooldown){
	cooldown(true, true);

	if(cases[id] === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	var caseitems = getItems(cases[id].items);

	var tickets = generateTickets(caseitems);
	var newitems = [];

	caseitems.forEach(function(item, index){
		newitems.push({
			name: item.name,
			image: item.image,
			price: getFormatAmount(item.price),
			chance: roundedToFixed(item.chance, 5),
			color: getColorByQuality(item.quality),
			tickets: tickets[index]
		});
	})

	emitSocketToUser(socket, 'dailycases', 'show', {
		items: newitems,
		dailycase: {
			id: id,
			name: cases[id].name,
			image: cases[id].image,
			level: cases[id].level
		},
		level: calculateLevel(user.xp).level,
		spinner: generateSpinner(caseitems)
	});

	cooldown(false, false);
}

/* ----- CLIENT USAGE ----- */
function openCase(user, socket, id, cooldown){
	cooldown(true, true);

	if(cases[id] === undefined) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'Invalid case id!'
		});

		return cooldown(false, true);
	}

	if(calculateLevel(user.xp).level < cases[id].level) {
		emitSocketToUser(socket, 'message', 'error', {
			message: 'You need to level up to open this case!'
		});

		return cooldown(false, true);
	}

	pool.query('SELECT * FROM `dailycases_bets` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `caseid` = ' + pool.escape(id) + ' AND `time` > ' + pool.escape(time() - config.app.dailycases.time * 60 * 60), function(err1, row1) {
		if(err1) {
			emitSocketToUser(socket, 'message', 'error', {
                message: 'An error occurred while opening case (1)'
            });

			return cooldown(false, true);
		}

		if(row1.length > 0) {
			emitSocketToUser(socket, 'message', 'error', {
				message: 'You already opened this daily case in the last ' + config.app.dailycases.time + ' hours!'
			});

			return cooldown(false, true);
		}

		//SEEDS
		fairService.getUserSeeds(user.userid, function(err2, fair){
			if(err2) {
				emitSocketToUser(socket, 'message', 'error', {
					message: err2.message
				});

				return cooldown(false, true);
			}

			var seed = fairService.getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce);
			var salt = fairService.generateSaltHash(seed);

			var caseitems = getItems(cases[id].items);

			var tickets = generateTickets(caseitems);
			var total = tickets[tickets.length - 1].max;

			var spinner = generateSpinner(caseitems);

			var roll = fairService.getRoll(salt, total) + 1;

			var winningitem = null;
			var itemid = null;

			for(var i = 0; i < tickets.length; i++){
				if(roll >= tickets[i].min && roll <= tickets[i].max) {
					itemid = caseitems[i].id;

					winningitem = {
						name: caseitems[i].name,
						image: caseitems[i].image,
						price: getFormatAmount(caseitems[i].price),
						chance: roundedToFixed(caseitems[i].chance, 5),
						color: getColorByQuality(caseitems[i].quality)
					};

					break;
				}
			}

			spinner[99] = winningitem;

			var winning = getFormatAmount(winningitem.price);

			pool.query('INSERT INTO `dailycases_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `caseid` = ' + pool.escape(id) + ', `winning` = ' + pool.escape('[]') + ', `roll` = ' + roll + ', `tickets` = ' + total + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
				if(err3) {
					emitSocketToUser(socket, 'message', 'error', {
                        message: 'An error occurred while opening case (2)'
                    });

					return cooldown(false, true);
				}

				pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err4){
					if(err4) {
						emitSocketToUser(socket, 'message', 'error', {
                            message: 'An error occurred while opening case (3)'
                        });

						return cooldown(false, true);
					}

					//EDIT BALANCE
					userService.editBalance(user.userid, 0, 'dailycase_win', function(err5){
						if(err5) {
							emitSocketToUser(socket, 'message', 'error', {
                                message: err5.message
                            });

							return cooldown(false, true);
						}

						userService.addItems(user.userid, [ itemid ], 'dailycase_win', function(err6, items){
							if(err6) {
								emitSocketToUser(socket, 'message', 'error', {
                                    message: err6.message
                                });

								return cooldown(false, true);
							}

                            var items_winnings = items.slice().map(a => ({
                                id: a.id,
                                itemid: a.itemid,
                                price: a.price
                            }));

                            pool.query('UPDATE `dailycases_bets` SET `winning` = ' + pool.escape(JSON.stringify(items_winnings)) + ' WHERE `id` = ' + pool.escape(row3.insertId), function(err7) {
                                if(err7) {
                                    emitSocketToUser(socket, 'message', 'error', {
                                        message: 'An error occurred while opening case (4)'
                                    });

                                    return cooldown(false, true);
                                }

                                emitSocketToUser(socket, 'dailycases', 'countdown', {
                                    dailycase: {
                                        id: id,
                                        level: cases[id].level,
                                        time: config.app.dailycases.time * 60 * 60
                                    }
                                });

                                emitSocketToUser(socket, 'dailycases', 'roll', {
                                    items: spinner
                                });

                                setTimeout(function(){
                                    emitSocketToUser(socket, 'dailycases', 'finish');

                                    loggerTrace('[DAILY CASE] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning) + ' with chance ' + roundedToFixed(winningitem.chance, 2).toFixed(2) + '%');
                                }, 5000);

                                loggerTrace('[DAILY CASE] Bet registed. ' + user.name + ' did open a daily case level' + cases[id].level);

                                cooldown(false, false);
						    });
						});
					});
				});
			});
		});
	});
}

/* ----- INTERNAL USAGE ----- */
function generateTickets(items){
	var decimals = 0;
	items.forEach(function(item){
		if(countDecimals(item.chance) > decimals) decimals = countDecimals(item.chance);
	});

	var tickets = [];
	var total = 0;

	items.forEach(function(item){
		tickets.push({
			min: total + 1,
			max: total + item.chance * Math.pow(10, decimals)
		});

		total += item.chance * Math.pow(10, decimals);
	});

	return tickets;
}

/* ----- INTERNAL USAGE ----- */
function generateSpinner(items){
	var tickets = generateTickets(items);
	var total = tickets[tickets.length - 1].max;

	var spinner = [];

	for(var i = 0; i < 150; i++){
		var ticket = getRandomInt(1, total);

		for(var j = 0; j < tickets.length; j++){
			if(ticket >= tickets[j].min && ticket <= tickets[j].max) {
				spinner.push({
					name: items[j].name,
					image: items[j].image,
					price: getFormatAmount(items[j].price),
					chance: roundedToFixed(items[j].chance, 5),
					color: getColorByQuality(items[j].quality)
				});
			}
		}
	}

	return spinner;
}

module.exports = {
	cases,
	loadCases,
	getCases, getCase, openCase
}