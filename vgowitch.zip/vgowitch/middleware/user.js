var crypto = require('crypto');

var { pool } = require('@/lib/database.js');

var { time } = require('@/utils/formatDate.js');

var user = async (req, res, next) => {
    res.locals.user = null;

    var { session } = req.cookies;

    if (!session) return next();

    var agent = req.headers['user-agent'];
    var device = crypto.createHash('sha256').update(agent).digest('hex');

    pool.query('SELECT users.*, users_sessions.session FROM `users` INNER JOIN `users_sessions` ON users.userid = users_sessions.userid WHERE users_sessions.session = ' + pool.escape(session) + ' AND users_sessions.device = ' + pool.escape(device) + ' AND users_sessions.removed = 0 AND users_sessions.expire > ' + pool.escape(time()), function (err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while processing user middleware (1)' });

        if(row1.length <= 0) return next();

        res.locals.user = row1[0];

        next();
    });
};

module.exports = user;