var gulp = require('gulp');
var concat = require('gulp-concat');
var terser = require('gulp-terser');
var cleanCss = require('gulp-clean-css');

gulp.task('pack-js', function () {
    return gulp.src(['assets/js/**/*.js'])
        .pipe(concat('components.js'))
        .pipe(terser())
        .pipe(gulp.dest('public/js'));
});

gulp.task('pack-css', function () {
    return gulp.src(['assets/css/**/*.css'])
        .pipe(concat('globals.css'))
        .pipe(cleanCss())
        .pipe(gulp.dest('public/css'));
});

gulp.task('pack', gulp.series('pack-js', 'pack-css'));

gulp.task('watch', function () {
    gulp.watch('assets/js/**/*.js', gulp.series('pack-js'));
    gulp.watch('assets/css/**/*.css', gulp.series('pack-css'));
});

gulp.task('default', gulp.series('pack', 'watch'));