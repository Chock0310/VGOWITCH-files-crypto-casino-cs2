var crypto = require('crypto');

var { pool } = require('@/lib/database.js');

var { calculateLevel, getUserDevice } = require('@/utils/utils.js');
var { roundedToFixed, getFormatAmount, getFormatAmountString } = require('@/utils/formatAmount.js');
var { makeDate, time } = require('@/utils/formatDate.js');

var config = require('@/config/config.js');

exports.accountUnset = async (req, res, next) => {
    res.redirect('/account/inventory');
};

exports.accountInventory = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/inventory');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (4)' });

                    res.render('accountInventory', {
                        page: 'account',
                        name: config.app.pages['account'],
                        response: {
                            account: {
                                user: {
                                    userid: res.locals.user.userid,
                                    name: res.locals.user.name,
                                    avatar: res.locals.user.avatar,
                                    rank: config.app.ranks[res.locals.user.rank],
                                    level: {
                                        ...level,
                                        ...{
                                            tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                            progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                        }
                                    },
                                    created: makeDate(new Date(res.locals.user.time_create * 1000))
                                },
                                stats: {
                                    deposited: getFormatAmountString(row1[0].deposited),
                                    withdrawn: getFormatAmountString(row2[0].withdrawn),
                                    wagered: getFormatAmountString(row3[0].wagered),
                                    profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                }
                            }
                        }
                    });
                });
            });
        });
    });
};

exports.accountSettings = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/settings');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (4)' });

                    //BINDS
                    pool.query('SELECT `bind` FROM `users_binds` WHERE `removed` = 0 AND `userid` = ' + pool.escape(res.locals.user.userid), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account settings page (5)' });

                        res.render('accountSettings', {
                            page: 'account',
                            name: config.app.pages['account'],
                            response: {
                                account: {
                                    user: {
                                        userid: res.locals.user.userid,
                                        name: res.locals.user.name,
                                        avatar: res.locals.user.avatar,
                                        rank: config.app.ranks[res.locals.user.rank],
                                        level: {
                                            ...level,
                                            ...{
                                                tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                            }
                                        },
                                        created: makeDate(new Date(res.locals.user.time_create * 1000))
                                    },
                                    stats: {
                                        deposited: getFormatAmountString(row1[0].deposited),
                                        withdrawn: getFormatAmountString(row2[0].withdrawn),
                                        wagered: getFormatAmountString(row3[0].wagered),
                                        profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                    },
                                    settings: {
                                        webapi_token: res.locals.user.webapi_token,
                                        tradelink: res.locals.user.tradelink,

                                        binds: {
                                            value: {
                                                ...Object.keys(config.settings.server.binds).reduce((acc, cur) => ({ ...acc, [cur]: false }), {}),
                                                ...row5.reduce((acc, cur) => ({ ...acc, [cur.bind]: true }), {})
                                            },
                                            enable: config.settings.server.binds
                                        }
                                    }
                                }
                            }
                        });
                    });
                });
            });
        });
    });
};

exports.accountDeposits = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/deposits');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account deposits page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account deposits page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account deposits page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account deposits page (4)' });

                    //DEPOSIT TRANSACTIONS
                    pool.query('SELECT COUNT(*) AS `count` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit" AND `refill` = 0 UNION ALL SELECT COUNT(*) AS `count` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit" UNION ALL SELECT COUNT(*) AS `count` FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_transactions.userid = ' + pool.escape(res.locals.user.userid), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account deposits page (5)' });

                        pool.query('SELECT `tradeofferid` AS `id`, `status`, `amount`, IF(status = 3, amount, 0) AS `paid`, "steam" AS `method`, `game`, `time` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit" AND `refill` = 0 UNION ALL SELECT `transactionid` AS `id`, `status`, `amount`, `paid` * `exchange` AS `paid`, "crypto" AS `method`, `currency` AS `game`, `time` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit" UNION ALL SELECT p2p_transactions.tradeofferid AS `id`, p2p_transactions.status, p2p_transactions.amount, IF(p2p_transactions.status = 5, p2p_transactions.amount, 0) AS `paid`, "p2p" AS `method`, p2p_transactions.game, p2p_transactions.time FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_transactions.userid = ' + pool.escape(res.locals.user.userid) + ' ORDER BY `time` DESC LIMIT 10', function(err6, row6) {
			                if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account deposits page (6)' });

                            var pages = Math.ceil(row5.reduce((acc, cur) => acc + cur.count, 0) / 10);

                            res.render('accountDeposits', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        deposits: {
                                            list: row6.map(function(item){
                                                var status = {
                                                    'crypto': item.status == 5 ? 'completed' : item.status == 4 ? 'partially_paid' : item.status < 0 ? 'declined' : 'pending',
                                                    'p2p': item.status == 5 ? 'completed' : item.status == 4 ? 'clearing' : item.status < 0 ? 'declined' : 'pending',
                                                    'steam': item.status == 3 ? 'completed' : item.status == 2 ? 'clearing' : item.status < 0 ? 'declined' : 'pending'
                                                }[item.method];

                                                return {
                                                    id: item.id || '-',
                                                    amount: getFormatAmountString(item.amount),
                                                    paid: getFormatAmountString(item.paid),
                                                    method: item.game,
                                                    status: status,
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountWithdrawals = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/withdrawals');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account withdrawals page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account withdrawals page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account withdrawals page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account withdrawals page (4)' });

                    //WITHDRAW TRANSACTIONS
                    pool.query('SELECT COUNT(*) AS `count` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw" AND `refill` = 0 UNION ALL SELECT COUNT(*) AS `count` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw" UNION ALL SELECT COUNT(*) AS `count` FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_buyers.userid = ' + pool.escape(res.locals.user.userid), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account withdrawals page (5)' });

                        pool.query('SELECT `tradeofferid` AS `id`, `status`, `amount`, "steam" AS `method`, `game`, `time` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw" AND `refill` = 0 UNION ALL SELECT `transactionid` AS `id`, `status`, `amount`, "crypto" AS `method`, `currency` AS `game`, `time` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw" UNION ALL SELECT p2p_transactions.tradeofferid AS `id`, IF(p2p_buyers.canceled = 0, p2p_transactions.status, -1), p2p_transactions.amount, "p2p" AS `method`, p2p_transactions.game, p2p_transactions.time FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_buyers.userid = ' + pool.escape(res.locals.user.userid) + ' ORDER BY `time` DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account withdrawals page (6)' });

                            var pages = Math.ceil(row5.reduce((acc, cur) => acc + cur.count, 0) / 10);

                            res.render('accountWithdrawals', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        withdrawals: {
                                            list: row6.map(function(item){
                                                var status = {
                                                    'crypto': item.status == 4 ? 'completed' : item.status < 0 ? 'declined' : 'pending',
                                                    'p2p': item.status == 5 ? 'completed' : item.status == 4 ? 'clearing' : item.status < 0 ? 'declined' : 'pending',
                                                    'steam': item.status == 3 ? 'completed' : item.status == 2 ? 'clearing' : item.status < 0 ? 'declined' : 'pending'
                                                }[item.method];

                                                return {
                                                    id: item.id || '-',
                                                    amount: getFormatAmountString(item.amount),
                                                    method: item.game,
                                                    status: status,
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesUnset = async (req, res, next) => {
    res.redirect('/account/games/roulette');
};

exports.accountGamesRoulette = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/roulette');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account roulette games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account roulette games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account roulette games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account roulette games history page (4)' });

                    //ROULETTE HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `roulette_bets` INNER JOIN `roulette_rolls` ON roulette_bets.gameid = roulette_rolls.id WHERE roulette_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND roulette_rolls.ended = 1', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account roulette games history page (5)' });

                        pool.query('SELECT roulette_bets.id, roulette_bets.amount, roulette_bets.color, roulette_rolls.roll, roulette_bets.time FROM `roulette_bets` INNER JOIN `roulette_rolls` ON roulette_bets.gameid = roulette_rolls.id WHERE roulette_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND roulette_rolls.ended = 1 ORDER BY roulette_bets.id DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account roulette games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesRoulette', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'roulette',
                                            list: row6.map(function(item){
                                                var colors = [];

                                                if(item.roll == 0) colors.push('green');
                                                else if(item.roll >= 1 && item.roll <= 7) colors.push('red');
                                                else if(item.roll >= 8 && item.roll <= 14) colors.push('black');

                                                if(item.roll == 4 || item.roll == 11) colors.push('bait');

                                                var amount = getFormatAmount(item.amount);
                                                var winnings = 0;
                                                if(colors.includes(item.color)) winnings = getFormatAmount(amount * config.games.games.roulette.multipliers[item.color]);

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    option: item.color,
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: colors.includes(item.color) ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesCrash = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/crash');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account crash games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account crash games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account crash games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account crash games history page (4)' });

                    //CRASH HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `crash_bets` INNER JOIN `crash_rolls` ON crash_bets.gameid = crash_rolls.id WHERE crash_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND crash_rolls.ended = 1', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account crash games history page (5)' });

                        pool.query('SELECT crash_bets.id, crash_bets.amount, crash_bets.cashedout, crash_bets.point, crash_bets.time FROM `crash_bets` INNER JOIN `crash_rolls` ON crash_bets.gameid = crash_rolls.id WHERE crash_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND crash_rolls.ended = 1 ORDER BY crash_bets.id DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account crash games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesCrash', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'crash',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);
                                                var winnings = 0;
                                                if(parseInt(item.cashedout)) winnings = getFormatAmount(amount * roundedToFixed(item.point, 2));

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    multiplier: roundedToFixed(item.point, 2).toFixed(2),
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: parseInt(item.cashedout) ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesJackpot = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/jackpot');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account jackpot games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account jackpot games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account jackpot games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account jackpot games history page (4)' });

                    //JACKPOT HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `jackpot_bets` INNER JOIN `jackpot_games` ON jackpot_bets.gameid = jackpot_games.id INNER JOIN `jackpot_rolls` ON jackpot_games.id = jackpot_rolls.gameid WHERE jackpot_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND jackpot_games.ended = 1 AND jackpot_rolls.removed = 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account jackpot games history page (5)' });

                        pool.query('SELECT jackpot_bets.id, IF(jackpot_bets.id = jackpot_rolls.betid, 1, 0) AS `status`, jackpot_bets.amount, jackpot_rolls.amount AS `winnings`, jackpot_rolls.roll, jackpot_bets.time FROM `jackpot_bets` INNER JOIN `jackpot_games` ON jackpot_bets.gameid = jackpot_games.id INNER JOIN `jackpot_rolls` ON jackpot_games.id = jackpot_rolls.gameid WHERE jackpot_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND jackpot_games.ended = 1 AND jackpot_rolls.removed = 0 ORDER BY jackpot_bets.id DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account jackpot games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesJackpot', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'jackpot',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);
                                                var winnings = 0;
                                                if(parseInt(item.status)) winnings = getFormatAmount(item.winnings);

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    roll: item.roll,
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: parseInt(item.status) ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesCoinflip = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/coinflip');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account coinflip games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account coinflip games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account coinflip games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account coinflip games history page (4)' });

                    //COINFLIP HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `coinflip_bets` INNER JOIN `coinflip_games` ON coinflip_bets.gameid = coinflip_games.id INNER JOIN `coinflip_rolls` ON coinflip_games.id = coinflip_rolls.gameid INNER JOIN `coinflip_winnings` ON coinflip_games.id = coinflip_winnings.gameid WHERE coinflip_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND coinflip_games.ended = 1 AND coinflip_rolls.removed = 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account coinflip games history page (5)' });

                        pool.query('SELECT coinflip_bets.id, IF(coinflip_bets.position = coinflip_winnings.position, 1, 0) AS `status`, coinflip_games.amount, coinflip_winnings.amount AS `winnings`, coinflip_bets.time FROM `coinflip_bets` INNER JOIN `coinflip_games` ON coinflip_bets.gameid = coinflip_games.id INNER JOIN `coinflip_rolls` ON coinflip_games.id = coinflip_rolls.gameid INNER JOIN `coinflip_winnings` ON coinflip_games.id = coinflip_winnings.gameid WHERE coinflip_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND coinflip_games.ended = 1 AND coinflip_rolls.removed = 0 ORDER BY coinflip_bets.id DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account coinflip games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesCoinflip', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'coinflip',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);
                                                var winnings = 0;
                                                if(parseInt(item.status)) winnings = getFormatAmount(item.winnings);

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: parseInt(item.status) ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesDice = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/dice');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account dice games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account dice games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account dice games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account dice games history page (4)' });

                    //DICE HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `dice_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account dice games history page (5)' });

                        pool.query('SELECT `id`, `amount`, `multiplier`, `roll`, `mode`, `chance`, `time` FROM `dice_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' ORDER BY `id` DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account dice games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesDice', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'dice',
                                            list: row6.map(function(item){
                                                var roll = roundedToFixed(item.roll, 2);
                                                var chance = roundedToFixed(item.chance, 2);

                                                var win = false;

                                                if(item.mode == 'under' && roll < chance) win = true;
                                                if(item.mode == 'over' && roll >= roundedToFixed(100 - chance, 2)) win = true;

                                                var amount = getFormatAmount(item.amount);
                                                var winnings = 0;
                                                if(win) winnings = getFormatAmount(amount * roundedToFixed(item.multiplier, 2));

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    roll: roll.toFixed(2),
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: win ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesUnboxing = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/unboxing');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account unboxing games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account unboxing games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account unboxing games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account unboxing games history page (4)' });

                    //UNBOXING HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `unboxing_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account unboxing games history page (5)' });

                        pool.query('SELECT `id`, `amount`, `winning`, `time` FROM `unboxing_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' ORDER BY `id` DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account unboxing games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesUnboxing', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'unboxing',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);
                                                var winning = getFormatAmount(JSON.parse(item.winning)[0].price);

                                                return {
                                                    id: item.id,
                                                    amount: getFormatAmountString(amount),
                                                    winning: getFormatAmountString(winning),
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesCasebattle = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/casebattle');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account case battle games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account case battle games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account case battle games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account case battle games history page (4)' });

                    //CASE BATTLE HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `casebattle_bets` INNER JOIN `casebattle_games` ON casebattle_bets.gameid = casebattle_games.id WHERE casebattle_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND casebattle_bets.canceled = 0 AND casebattle_games.canceled = 0 AND casebattle_games.ended = 1', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account case battle games history page (5)' });

                        pool.query('SELECT casebattle_bets.id, MAX(IF(casebattle_bets.position = casebattle_winnings.position, 1, 0)) AS `status`, casebattle_games.amount, MAX(IF(casebattle_bets.position = casebattle_winnings.position, casebattle_winnings.items, 0)) AS `items`, MAX(IF(casebattle_bets.position = casebattle_winnings.position, casebattle_winnings.amount, 0)) AS `winnings`, casebattle_bets.creator, casebattle_games.mode, casebattle_games.free, casebattle_bets.time FROM `casebattle_bets` INNER JOIN `casebattle_games` ON casebattle_bets.gameid = casebattle_games.id INNER JOIN `casebattle_winnings` ON casebattle_winnings.gameid = casebattle_games.id WHERE casebattle_bets.userid = ' + pool.escape(res.locals.user.userid) + ' AND casebattle_bets.canceled = 0 AND casebattle_games.canceled = 0 AND casebattle_games.ended = 1 GROUP BY casebattle_bets.id ORDER BY casebattle_bets.id DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account case battle games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesCasebattle', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'casebattle',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);

                                                if(parseInt(item.creator) && parseInt(item.free)){
                                                    var total_players = [ 2, 3, 4, 4 ][parseInt(item.mode)];

                                                    amount = getFormatAmount(amount * total_players);
                                                } else if(parseInt(item.free)) amount = 0;

                                                var winning = 0;
                                                if(parseInt(item.status)) winning = getFormatAmount(JSON.parse(item.items).reduce((acc, cur) => getFormatAmount(acc + getFormatAmount(cur.price)), 0) + getFormatAmount(item.winnings));

                                                return {
                                                    id: item.id,
                                                    amount: getFormatAmountString(amount),
                                                    winning: getFormatAmountString(winning),
                                                    status: parseInt(item.status) ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesUpgrader = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/upgrader');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account upgrader games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account upgrader games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account upgrader games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account upgrader games history page (4)' });

                    //UPGRADER HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `upgrader_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account upgrader games history page (5)' });

                        pool.query('SELECT `id`, `items`, `amount`, `winning`, `roll`, `game`, `chance`, `time` FROM `upgrader_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' ORDER BY `id` DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account upgrader games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesUpgrader', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'upgrader',
                                            list: row6.map(function(item){
                                                var roll = roundedToFixed(item.roll, 2);
                                                var chance = roundedToFixed(item.chance, 2);

                                                var win = false;

                                                if(item.game == 'under' && roll < chance) win = true;
                                                if(item.game == 'over' && roll >= roundedToFixed(100 - chance, 2)) win = true;

                                                var amount = getFormatAmount(JSON.parse(item.items).reduce((acc, cur) => getFormatAmount(acc + getFormatAmount(cur.price)), 0) + getFormatAmount(item.amount));
                                                var winnings = 0;
                                                if(win) winnings = JSON.parse(item.winning).reduce((acc, cur) => getFormatAmount(acc + getFormatAmount(cur.price)), 0);

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    roll: roll.toFixed(2),
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: win ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesTower = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/tower');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account tower games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account tower games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account tower games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account tower games history page (4)' });

                    //TOWER HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `tower_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `ended` = 1', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account tower games history page (5)' });

                        pool.query('SELECT `id`, `amount`, `winning`, `difficulty`, `time` FROM `tower_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `ended` = 1 ORDER BY `id` DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account tower games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesTower', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'tower',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);
                                                var winnings = getFormatAmount(item.winning);

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    difficulty: item.difficulty,
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: profit > 0 ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesMinesweeper = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/minesweeper');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account minesweeper games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account minesweeper games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account minesweeper games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account minesweeper games history page (4)' });

                    //MINESWEEPER HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `minesweeper_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `ended` = 1', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account minesweeper games history page (5)' });

                        pool.query('SELECT `id`, `amount`, `winning`, `bombs`, `time` FROM `minesweeper_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `ended` = 1 ORDER BY `id` DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account minesweeper games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesMinesweeper', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'minesweeper',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);
                                                var winnings = getFormatAmount(item.winning);

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    bombs: item.bombs,
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: profit > 0 ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesPlinko = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/plinko');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account plinko games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account plinko games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account plinko games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account plinko games history page (4)' });

                    //PLINKO HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `plinko_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account plinko games history page (5)' });

                        pool.query('SELECT `id`, `amount`, `multiplier`, `difficulty`, `rows`, `time` FROM `plinko_bets` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' ORDER BY `id` DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account plinko games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesPlinko', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'plinko',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);
                                                var winnings = getFormatAmount(amount * roundedToFixed(item.multiplier, 2));

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    difficulty: item.difficulty,
                                                    rows: item.rows,
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: profit > 0 ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountGamesCasino = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/games/casino');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account casino games history page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account casino games history page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account casino games history page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account casino games history page (4)' });

                    //CASINO HISTORY
                    pool.query('SELECT COUNT(*) AS `count` FROM `casino_bets` LEFT JOIN `casino_winnings` ON casino_bets.id = casino_winnings.betid WHERE casino_bets.userid = ' + pool.escape(res.locals.user.userid), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account casino games history page (5)' });

                        pool.query('SELECT casino_bets.id, casino_bets.amount, COALESCE(casino_winnings.amount, 0) AS `winnings`, casino_bets.game, casino_bets.time FROM `casino_bets` LEFT JOIN `casino_winnings` ON casino_bets.id = casino_winnings.betid WHERE casino_bets.userid = ' + pool.escape(res.locals.user.userid) + ' ORDER BY casino_bets.id DESC LIMIT 10', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account casino games history page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountGamesCasino', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        games: {
                                            game: 'casino',
                                            list: row6.map(function(item){
                                                var amount = getFormatAmount(item.amount);
                                                var winnings = getFormatAmount(item.winnings);

                                                var profit = getFormatAmount(winnings - amount);

                                                return {
                                                    id: item.id,
                                                    game: item.game,
                                                    amount: getFormatAmountString(amount),
                                                    profit: getFormatAmountString(profit),
                                                    status: profit > 0 ? 'win': 'loss',
                                                    date: makeDate(new Date(item.time * 1000))
                                                };
                                            }),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountTransactions = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/transactions');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account transactions page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account transactions page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account transactions page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account transactions page (4)' });

                    //TRANSACTIONS
                    pool.query('SELECT COUNT(*) AS `count` FROM `users_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid), function(err5, row5){
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account transactions page (5)' });

                        pool.query('SELECT `id`, `service`, `amount`, `time` FROM `users_transactions` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' ORDER BY `id` DESC LIMIT 10', function(err6, row6){
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account transactions page (6)' });

                            var pages = Math.ceil(row5[0].count / 10);

                            res.render('accountTransactions', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: {
                                    account: {
                                        user: {
                                            userid: res.locals.user.userid,
                                            name: res.locals.user.name,
                                            avatar: res.locals.user.avatar,
                                            rank: config.app.ranks[res.locals.user.rank],
                                            level: {
                                                ...level,
                                                ...{
                                                    tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                    progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                }
                                            },
                                            created: makeDate(new Date(res.locals.user.time_create * 1000))
                                        },
                                        stats: {
                                            deposited: getFormatAmountString(row1[0].deposited),
                                            withdrawn: getFormatAmountString(row2[0].withdrawn),
                                            wagered: getFormatAmountString(row3[0].wagered),
                                            profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                        },
                                        transactions: {
                                            list: row6.map(a => ({
                                                id: a.id,
                                                service: a.service,
                                                amount: getFormatAmountString(a.amount),
                                                date: makeDate(new Date(a.time * 1000))
                                            })),
                                            pages: pages > 0 ? pages : 1,
                                            page: 1
                                        }
                                    }
                                }
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.accountExclusion = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/exclusion');

    var level = calculateLevel(res.locals.user.xp);

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account exclusion page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account exclusion page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account exclusion page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account exclusion page (4)' });

                    res.render('accountExclusion', {
                        page: 'account',
                        name: config.app.pages['account'],
                        response: {
                            account: {
                                user: {
                                    userid: res.locals.user.userid,
                                    name: res.locals.user.name,
                                    avatar: res.locals.user.avatar,
                                    rank: config.app.ranks[res.locals.user.rank],
                                    level: {
                                        ...level,
                                        ...{
                                            tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                            progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                        }
                                    },
                                    created: makeDate(new Date(res.locals.user.time_create * 1000))
                                },
                                stats: {
                                    deposited: getFormatAmountString(row1[0].deposited),
                                    withdrawn: getFormatAmountString(row2[0].withdrawn),
                                    wagered: getFormatAmountString(row3[0].wagered),
                                    profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                },
                                exclusion: {
                                    active: res.locals.user.exclusion > time(),
                                    expire: makeDate(new Date(res.locals.user.exclusion * 1000))
                                }
                            }
                        }
                    });
                });
            });
        });
    });
};

exports.accountSecurity = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/login?returnUrl=/account/security');

    var level = calculateLevel(res.locals.user.xp);

    var agent = req.headers['user-agent'];
    var device = crypto.createHash('sha256').update(agent).digest('hex');

    //DEPOSITED
    pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "deposit"', function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (1)' });

        //WITHDRAWN
        pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `type` = "withdraw"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (2)' });

            //WAGERED
            pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` < 0', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (3)' });

                //WINNINGS
                pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `amount` > 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (4)' });

                    pool.query('SELECT * FROM `users_security_requests` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `device` = ' + pool.escape(device) + ' AND `removed` = 0 AND `expire` > ' + pool.escape(time()), function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (5)' });

                        var response = {
                            account: {
                                user: {
                                    userid: res.locals.user.userid,
                                    name: res.locals.user.name,
                                    avatar: res.locals.user.avatar,
                                    rank: config.app.ranks[res.locals.user.rank],
                                    level: {
                                        ...level,
                                        ...{
                                            tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                            progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                        }
                                    },
                                    created: makeDate(new Date(res.locals.user.time_create * 1000))
                                },
                                stats: {
                                    deposited: getFormatAmountString(row1[0].deposited),
                                    withdrawn: getFormatAmountString(row2[0].withdrawn),
                                    wagered: getFormatAmountString(row3[0].wagered),
                                    profit: getFormatAmountString(getFormatAmount(row4[0].winnings) - getFormatAmount(row3[0].wagered))
                                },
                                security: {
                                    request: false,
                                    email: null,
                                    twofactor_authentication: {
                                        authenticator_app: {
                                            enabled: false,
                                            primary: false
                                        },
                                        email_verification: {
                                            enabled: false,
                                            primary: false
                                        }
                                    },
                                    sessions: []
                                }
                            }
                        }

                        if(row5.length <= 0){
                            return res.render('accountSecurity', {
                                page: 'account',
                                name: config.app.pages['account'],
                                response: response
                            });
                        }

                        //TWO FACTOR AUTHENTICATION APP
                        pool.query('SELECT * FROM `authenticator_app` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `removed` = 0 AND `activated` = 1', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (6)' });

                            //TWO FACTOR AUTHENTICATION EMAIL VERIFICATION
                            pool.query('SELECT * FROM `email_verification` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `removed` = 0', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (7)' });

                                //TWO FACTOR AUTHENTICATION PRIMARY METHOD
                                pool.query('SELECT `method` FROM `twofactor_authentication` WHERE `userid` = ' + pool.escape(res.locals.user.userid) + ' AND `removed` = 0', function(err8, row8) {
                                    if(err8) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (8)' });

                                    //SESSIONS
                                    pool.query('SELECT users_sessions.id, users_sessions.session, users_logins.agent, users_logins.location, users_logins.time FROM `users_sessions` INNER JOIN `users_logins` ON users_sessions.userid = users_logins.userid AND users_sessions.id = users_logins.sessionid WHERE users_logins.id = (SELECT users_logins_test.id FROM `users_logins` `users_logins_test` WHERE users_logins.sessionid = users_logins_test.sessionid ORDER BY users_logins_test.time DESC LIMIT 1) AND users_sessions.userid = ' + pool.escape(res.locals.user.userid) + ' AND users_sessions.removed = 0 AND users_sessions.expire > ' + pool.escape(time()), function(err9, row9) {
                                        if(err9) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account security page (9)' });

                                        var { session } = req.cookies;

                                        var twofactor_authentication_method = null;
                                        if(row8.length > 0) twofactor_authentication_method = row8[0].method;

                                        response.account.security.request = true;
                                        response.account.security.email = res.locals.user.email;

                                        response.account.security.twofactor_authentication.email_verification.enabled = row7.length > 0;
                                        response.account.security.twofactor_authentication.email_verification.primary = twofactor_authentication_method == 'email_verification';

                                        response.account.security.twofactor_authentication.authenticator_app.enabled = row6.length > 0;
                                        response.account.security.twofactor_authentication.authenticator_app.primary = twofactor_authentication_method == 'authenticator_app';

                                        response.account.security.sessions = row9.map(a => ({
                                            id: a.id,
                                            current: a.session == session,
                                            device: getUserDevice(a.agent),
                                            location: a.location,
                                            date: makeDate(new Date(a.time * 1000))
                                        }))

                                        res.render('accountSecurity', {
                                            page: 'account',
                                            name: config.app.pages['account'],
                                            response: response
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};
