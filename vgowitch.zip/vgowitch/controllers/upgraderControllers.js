var { pool } = require('@/lib/database.js');

var itemsService = (({ items }) => ({ items }))(require('@/services/itemsService.js'));

var { haveRankPermission } = require('@/utils/utils.js');

var config = require('@/config/config.js');

exports.upgrader = async (req, res, next) => {
    if(!config.settings.games.games.original.upgrader.enable && !haveRankPermission('play_disabled', res.locals.user ? res.locals.user.rank : 0)) return next();

    var item = null;

    if(req.session.upgraderItem) {
        item = req.session.upgraderItem;
        delete req.session.upgraderItem;
    }

    res.render('upgrader', {
        page: 'upgrader',
        name: config.app.pages['upgrader'],
        response: {
            upgrader: {
                item
            }
        }
    });
};

exports.upgraderItem = async (req, res, next) => {
    if(!res.locals.user) return res.redirect('/upgrader');

    var itemid = req.params.itemid;

    pool.query('SELECT `itemid` FROM `users_items` WHERE `id` = ' + pool.escape(itemid) + ' AND `status` = 0 AND `userid` = ' + pool.escape(res.locals.user.userid), function(err1, row1){
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering upgrader page (1)' });

        if(row1.length > 0) {
            req.session.upgraderItem = {
                itemid: itemid,
                game: itemsService.items[row1[0].itemid].game
            };
        }

        res.redirect('/upgrader');
    });
};