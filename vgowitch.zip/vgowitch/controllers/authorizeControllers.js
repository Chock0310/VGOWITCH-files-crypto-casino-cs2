var config = require('@/config/config.js');

exports.authorize = async (req, res) => {
    var returnUrl = req.query.returnUrl || '/';

    var authorized = false;

    if(req.session.identityAuthorized) {
        authorized = req.session.identityAuthorized;
        delete req.session.identityAuthorized;
    }

    if(authorized) return res.redirect(returnUrl);

    res.render('auth/authorize', {
        layout: 'layouts/auth',
        name: config.app.pages['authorize'],
        response: { returnUrl }
    });
};