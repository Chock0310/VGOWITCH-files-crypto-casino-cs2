var { pool } = require('@/lib/database.js');

var { haveRankPermission, calculateLevel } = require('@/utils/utils.js');
var { roundedToFixed, getFormatAmount, getFormatAmountString } = require('@/utils/formatAmount.js');
var { makeDate } = require('@/utils/formatDate.js');

var config = require('@/config/config.js');

exports.userUnset = async (req, res, next) => {
    var userid = req.params.userid;

    res.redirect('/user/' + userid + '/inventory');
};

exports.userPrivate = async (req, res, next) => {
    res.render('userPrivate', {
        page: 'user',
        name: config.app.pages['user']
    });
};

exports.userInventory = async (req, res, next) => {
    var userid = req.params.userid;

    pool.query('SELECT `private`, `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (1)' });

        if(row1.length <= 0) return next();

        var private = parseInt(row1[0].private);

        if(private && !haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return res.redirect('/user/private');

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (5)' });

                        res.render('userInventory', {
                            page: 'user',
                            name: config.app.pages['user'],
                            response: {
                                user: {
                                    user: {
                                        userid: row1[0].userid,
                                        name: row1[0].name,
                                        avatar: row1[0].avatar,
                                        rank: config.app.ranks[row1[0].rank],
                                        level: {
                                            ...level,
                                            ...{
                                                tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                            }
                                        },
                                        created: makeDate(new Date(row1[0].time_create * 1000))
                                    },
                                    stats: {
                                        deposited: getFormatAmountString(row2[0].deposited),
                                        withdrawn: getFormatAmountString(row3[0].withdrawn),
                                        wagered: getFormatAmountString(row4[0].wagered),
                                        profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                    }
                                }
                            }
                        });
                    });
                });
            });
        });
    });
}

exports.userDeposits = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (5)' });

                        //DEPOSIT TRANSACTIONS
                        pool.query('SELECT COUNT(*) AS `count` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit" AND `refill` = 0 UNION ALL SELECT COUNT(*) AS `count` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit" UNION ALL SELECT COUNT(*) AS `count` FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_transactions.userid = ' + pool.escape(row1[0].userid), function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (6)' });

                            pool.query('SELECT `tradeofferid` AS `id`, `status`, `amount`, IF(status = 3, amount, 0) AS `paid`, "steam" AS `method`, `game`, `time` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit" AND `refill` = 0 UNION ALL SELECT `transactionid` AS `id`, `status`, `amount`, `paid` * `exchange` AS `paid`, "crypto" AS `method`, `currency` AS `game`, `time` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit" UNION ALL SELECT p2p_transactions.tradeofferid AS `id`, p2p_transactions.status, p2p_transactions.amount, IF(p2p_transactions.status = 5, p2p_transactions.amount, 0) AS `paid`, "p2p" AS `method`, p2p_transactions.game, p2p_transactions.time FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_transactions.userid = ' + pool.escape(row1[0].userid) + ' ORDER BY `time` DESC LIMIT 10', function(err7, row7) {
			                    if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (7)' });

                                var pages = Math.ceil(row6.reduce((acc, cur) => acc + cur.count, 0) / 10);

                                res.render('userDeposits', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            deposits: {
                                                list: row7.map(function(item){
                                                    var status = {
                                                        'crypto': item.status == 5 ? 'completed' : item.status == 4 ? 'partially_paid' : item.status < 0 ? 'declined' : 'pending',
                                                        'p2p': item.status == 5 ? 'completed' : item.status == 4 ? 'clearing' : item.status < 0 ? 'declined' : 'pending',
                                                        'steam': item.status == 3 ? 'completed' : item.status == 2 ? 'clearing' : item.status < 0 ? 'declined' : 'pending'
                                                    }[item.method];

                                                    return {
                                                        id: item.id || '-',
                                                        amount: getFormatAmountString(item.amount),
                                                        paid: getFormatAmountString(item.paid),
                                                        method: item.game,
                                                        status: status,
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userWithdrawals = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user withdrawals page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user withdrawals page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user withdrawals page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user withdrawals page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user withdrawals page (5)' });

                        //WITHDRAW TRANSACTIONS
                        pool.query('SELECT COUNT(*) AS `count` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw" AND `refill` = 0 UNION ALL SELECT COUNT(*) AS `count` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw" UNION ALL SELECT COUNT(*) AS `count` FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_buyers.userid = ' + pool.escape(row1[0].userid), function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account withdrawals page (6)' });

                            pool.query('SELECT `tradeofferid` AS `id`, `status`, `amount`, "steam" AS `method`, `game`, `time` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw" AND `refill` = 0 UNION ALL SELECT `transactionid` AS `id`, `status`, `amount`, "crypto" AS `method`, `currency` AS `game`, `time` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw" UNION ALL SELECT p2p_transactions.tradeofferid AS `id`, IF(p2p_buyers.canceled = 0, p2p_transactions.status, -1), p2p_transactions.amount, "p2p" AS `method`, p2p_transactions.game, p2p_transactions.time FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_buyers.userid = ' + pool.escape(row1[0].userid) + ' ORDER BY `time` DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering account withdrawals page (7)' });

                                var pages = Math.ceil(row6.reduce((acc, cur) => acc + cur.count, 0) / 10);

                                res.render('userWithdrawals', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            withdrawals: {
                                                list: row7.map(function(item){
                                                    var status = {
                                                        'crypto': item.status == 4 ? 'completed' : item.status < 0 ? 'declined' : 'pending',
                                                        'p2p': item.status == 5 ? 'completed' : item.status == 4 ? 'clearing' : item.status < 0 ? 'declined' : 'pending',
                                                        'steam': item.status == 3 ? 'completed' : item.status == 2 ? 'clearing' : item.status < 0 ? 'declined' : 'pending'
                                                    }[item.method];

                                                    return {
                                                        id: item.id || '-',
                                                        amount: getFormatAmountString(item.amount),
                                                        method: item.game,
                                                        status: status,
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesUnset = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    res.redirect('/user/' + userid + '/games/roulette');
};

exports.userGamesRoulette = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user roulette games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user roulette games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user roulette games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user roulette games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user roulette games history page (5)' });

                        //ROULETTE HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `roulette_bets` INNER JOIN `roulette_rolls` ON roulette_bets.gameid = roulette_rolls.id WHERE roulette_bets.userid = ' + pool.escape(row1[0].userid) + ' AND roulette_rolls.ended = 1', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user roulette games history page (6)' });

                            pool.query('SELECT roulette_bets.id, roulette_bets.amount, roulette_bets.color, roulette_rolls.roll, roulette_bets.time FROM `roulette_bets` INNER JOIN `roulette_rolls` ON roulette_bets.gameid = roulette_rolls.id WHERE roulette_bets.userid = ' + pool.escape(row1[0].userid) + ' AND roulette_rolls.ended = 1 ORDER BY roulette_bets.id DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user roulette games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesRoulette', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'roulette',
                                                list: row7.map(function(item){
                                                    var colors = [];

                                                    if(item.roll == 0) colors.push('green');
                                                    else if(item.roll >= 1 && item.roll <= 7) colors.push('red');
                                                    else if(item.roll >= 8 && item.roll <= 14) colors.push('black');

                                                    if(item.roll == 4 || item.roll == 11) colors.push('bait');

                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = 0;
                                                    if(colors.includes(item.color)) winnings = getFormatAmount(amount * config.games.games.roulette.multipliers[item.color]);

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        option: item.color,
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: colors.includes(item.color) ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesCrash = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user crash games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user crash games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposcrash games historyits page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user crash games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user crash games history page (5)' });

                        //CRASH HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `crash_bets` INNER JOIN `crash_rolls` ON crash_bets.gameid = crash_rolls.id WHERE crash_bets.userid = ' + pool.escape(row1[0].userid) + ' AND crash_rolls.ended = 1', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user crash games history page (6)' });

                            pool.query('SELECT crash_bets.id, crash_bets.amount, crash_bets.cashedout, crash_bets.point, crash_bets.time FROM `crash_bets` INNER JOIN `crash_rolls` ON crash_bets.gameid = crash_rolls.id WHERE crash_bets.userid = ' + pool.escape(row1[0].userid) + ' AND crash_rolls.ended = 1 ORDER BY crash_bets.id DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user crash games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesCrash', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'crash',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = 0;
                                                    if(parseInt(item.cashedout)) winnings = getFormatAmount(amount * roundedToFixed(item.point, 2));

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        multiplier: roundedToFixed(item.point, 2).toFixed(2),
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: parseInt(item.cashedout) ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesJackpot = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user jackpot games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user jackpot games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user jackpot games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user jackpot games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user jackpot games history page (5)' });

                        //JACKPOT HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `jackpot_bets` INNER JOIN `jackpot_games` ON jackpot_bets.gameid = jackpot_games.id INNER JOIN `jackpot_rolls` ON jackpot_games.id = jackpot_rolls.gameid WHERE jackpot_bets.userid = ' + pool.escape(row1[0].userid) + ' AND jackpot_games.ended = 1 AND jackpot_rolls.removed = 0', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user jackpot games history page (6)' });

                            pool.query('SELECT jackpot_bets.id, IF(jackpot_bets.id = jackpot_rolls.betid, 1, 0) AS `status`, jackpot_bets.amount, jackpot_rolls.amount AS `winnings`, jackpot_rolls.roll, jackpot_bets.time FROM `jackpot_bets` INNER JOIN `jackpot_games` ON jackpot_bets.gameid = jackpot_games.id INNER JOIN `jackpot_rolls` ON jackpot_games.id = jackpot_rolls.gameid WHERE jackpot_bets.userid = ' + pool.escape(row1[0].userid) + ' AND jackpot_games.ended = 1 AND jackpot_rolls.removed = 0 ORDER BY jackpot_bets.id DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user jackpot games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesJackpot', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'jackpot',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = 0;
                                                    if(parseInt(item.status)) winnings = getFormatAmount(item.winnings);

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        roll: item.roll,
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: parseInt(item.status) ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesCoinflip = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user coinflip games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user coinflip games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user coinflip games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user coinflip games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user coinflip games history page (5)' });

                        //COINFLIP HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `coinflip_bets` INNER JOIN `coinflip_games` ON coinflip_bets.gameid = coinflip_games.id INNER JOIN `coinflip_rolls` ON coinflip_games.id = coinflip_rolls.gameid INNER JOIN `coinflip_winnings` ON coinflip_games.id = coinflip_winnings.gameid WHERE coinflip_bets.userid = ' + pool.escape(row1[0].userid) + ' AND coinflip_games.ended = 1 AND coinflip_rolls.removed = 0', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user coinflip games history page (6)' });

                            pool.query('SELECT coinflip_bets.id, IF(coinflip_bets.position = coinflip_winnings.position, 1, 0) AS `status`, coinflip_games.amount, coinflip_winnings.amount AS `winnings`, coinflip_bets.time FROM `coinflip_bets` INNER JOIN `coinflip_games` ON coinflip_bets.gameid = coinflip_games.id INNER JOIN `coinflip_rolls` ON coinflip_games.id = coinflip_rolls.gameid INNER JOIN `coinflip_winnings` ON coinflip_games.id = coinflip_winnings.gameid WHERE coinflip_bets.userid = ' + pool.escape(row1[0].userid) + ' AND coinflip_games.ended = 1 AND coinflip_rolls.removed = 0 ORDER BY coinflip_bets.id DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user coinflip games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesCoinflip', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'coinflip',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = 0;
                                                    if(parseInt(item.status)) winnings = getFormatAmount(item.winnings);

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: parseInt(item.status) ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesDice = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user dice games history page page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user dice games history page page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user dice games history page page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user dice games history page page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user dice games history page page (5)' });

                        //DICE HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `dice_bets` WHERE `userid` = ' + pool.escape(row1[0].userid), function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user dice games history page (6)' });

                            pool.query('SELECT `id`, `amount`, `multiplier`, `roll`, `mode`, `chance`, `time` FROM `dice_bets` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' ORDER BY `id` DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user dice games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesDice', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'dice',
                                                list: row7.map(function(item){
                                                    var roll = roundedToFixed(item.roll, 2);
                                                    var chance = roundedToFixed(item.chance, 2);

                                                    var win = false;

                                                    if(item.mode == 'under' && roll < chance) win = true;
                                                    if(item.mode == 'over' && roll >= roundedToFixed(100 - chance, 2)) win = true;

                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = 0;
                                                    if(win) winnings = getFormatAmount(amount * roundedToFixed(item.multiplier, 2));

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        roll: roll.toFixed(2),
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: win ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesUnboxing = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user unboxing games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user unboxing games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user unboxing games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user unboxing games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user unboxing games history page (5)' });

                        //UNBOXING HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `unboxing_bets` WHERE `userid` = ' + pool.escape(row1[0].userid), function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user unboxing games history page (6)' });

                            pool.query('SELECT `id`, `amount`, `winning`, `time` FROM `unboxing_bets` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' ORDER BY `id` DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user unboxing games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesUnboxing', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'unboxing',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);
                                                    var winning = getFormatAmount(JSON.parse(item.winning)[0].price);

                                                    return {
                                                        id: item.id,
                                                        amount: getFormatAmountString(amount),
                                                        winning: getFormatAmountString(winning),
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesCasebattle = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user case battle games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user case battle games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user case battle games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user case battle games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user case battle games history page (5)' });

                        //CASE BATTLE HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `casebattle_bets` INNER JOIN `casebattle_games` ON casebattle_bets.gameid = casebattle_games.id WHERE casebattle_bets.userid = ' + pool.escape(row1[0].userid) + ' AND casebattle_bets.canceled = 0 AND casebattle_games.canceled = 0 AND casebattle_games.ended = 1', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user case battle games history page (6)' });

                            pool.query('SELECT casebattle_bets.id, MAX(IF(casebattle_bets.position = casebattle_winnings.position, 1, 0)) AS `status`, casebattle_games.amount, MAX(IF(casebattle_bets.position = casebattle_winnings.position, casebattle_winnings.items, 0)) AS `items`, MAX(IF(casebattle_bets.position = casebattle_winnings.position, casebattle_winnings.amount, 0)) AS `winnings`, casebattle_bets.creator, casebattle_games.mode, casebattle_games.free, casebattle_bets.time FROM `casebattle_bets` INNER JOIN `casebattle_games` ON casebattle_bets.gameid = casebattle_games.id INNER JOIN `casebattle_winnings` ON casebattle_winnings.gameid = casebattle_games.id WHERE casebattle_bets.userid = ' + pool.escape(row1[0].userid) + ' AND casebattle_bets.canceled = 0 AND casebattle_games.canceled = 0 AND casebattle_games.ended = 1 GROUP BY casebattle_bets.id ORDER BY casebattle_bets.id DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user case battle games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesCasebattle', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'casebattle',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);

                                                    if(parseInt(item.creator) && parseInt(item.free)){
                                                        var total_players = [ 2, 3, 4, 4 ][parseInt(item.mode)];

                                                        amount = getFormatAmount(amount * total_players);
                                                    } else if(parseInt(item.free)) amount = 0;

                                                    var winning = 0;
                                                    if(parseInt(item.status)) winning = getFormatAmount(JSON.parse(item.items).reduce((acc, cur) => getFormatAmount(acc + getFormatAmount(cur.price)), 0) + getFormatAmount(item.winnings));

                                                    return {
                                                        id: item.id,
                                                        amount: getFormatAmountString(amount),
                                                        winning: getFormatAmountString(winning),
                                                        status: parseInt(item.status) ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesUpgrader = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user upgrader games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user upgrader games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user upgrader games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user upgrader games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user upgrader games history page (5)' });

                        //UPGRADER HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `upgrader_bets` WHERE `userid` = ' + pool.escape(row1[0].userid), function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user upgrader games history page (6)' });

                            pool.query('SELECT `id`, `items`, `amount`, `winning`, `roll`, `game`, `chance`, `time` FROM `upgrader_bets` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' ORDER BY `id` DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user upgrader games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesUpgrader', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'upgrader',
                                                list: row7.map(function(item){
                                                    var roll = roundedToFixed(item.roll, 2);
                                                    var chance = roundedToFixed(item.chance, 2);

                                                    var win = false;

                                                    if(item.game == 'under' && roll < chance) win = true;
                                                    if(item.game == 'over' && roll >= roundedToFixed(100 - chance, 2)) win = true;

                                                    var amount = getFormatAmount(JSON.parse(item.items).reduce((acc, cur) => getFormatAmount(acc + getFormatAmount(cur.price)), 0) + getFormatAmount(item.amount));
                                                    var winnings = 0;
                                                    if(win) winnings = JSON.parse(item.winning).reduce((acc, cur) => getFormatAmount(acc + getFormatAmount(cur.price)), 0);

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        roll: roll.toFixed(2),
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: win ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesTower = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user tower games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user tower games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user tower games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user tower games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user tower games history page (5)' });

                        //TOWER HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `tower_bets` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `ended` = 1', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user tower games history page (6)' });

                            pool.query('SELECT `id`, `amount`, `winning`, `difficulty`, `time` FROM `tower_bets` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `ended` = 1 ORDER BY `id` DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user tower games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesTower', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'tower',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = getFormatAmount(item.winning);

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        difficulty: item.difficulty,
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: profit > 0 ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesMinesweeper = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user minesweeper games history page page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user minesweeper games history page page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user minesweeper games history page page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user minesweeper games history page page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user minesweeper games history page page (5)' });

                        //MINESWEEPER HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `minesweeper_bets` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `ended` = 1', function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user minesweeper games history page (6)' });

                            pool.query('SELECT `id`, `amount`, `winning`, `bombs`, `time` FROM `minesweeper_bets` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `ended` = 1 ORDER BY `id` DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user minesweeper games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesMinesweeper', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'minesweeper',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = getFormatAmount(item.winning);

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        bombs: item.bombs,
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: profit > 0 ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesPlinko = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user deposits page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user plinko games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user plinko games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user plinko games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user plinko games history page (5)' });

                        //PLINKO HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `plinko_bets` WHERE `userid` = ' + pool.escape(row1[0].userid), function(err6, row6) {
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user plinko games history page (6)' });

                            pool.query('SELECT `id`, `amount`, `multiplier`, `difficulty`, `rows`, `time` FROM `plinko_bets` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' ORDER BY `id` DESC LIMIT 10', function(err7, row7) {
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user plinko games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesPlinko', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'plinko',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = getFormatAmount(amount * roundedToFixed(item.multiplier, 2));

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        difficulty: item.difficulty,
                                                        rows: item.rows,
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: profit > 0 ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userGamesCasino = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user casino games history page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user casino games history page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user casino games history page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user casino games history page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user casino games history page (5)' });

                        //CASINO HISTORY
                        pool.query('SELECT COUNT(*) AS `count` FROM `casino_bets` LEFT JOIN `casino_winnings` ON casino_bets.id = casino_winnings.betid WHERE casino_bets.userid = ' + pool.escape(row1[0].userid), function(err6, row6) {
                            if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user casino games history page (6)' });

                            pool.query('SELECT casino_bets.id, casino_bets.amount, COALESCE(casino_winnings.amount, 0) AS `winnings`, casino_bets.game, casino_bets.time FROM `casino_bets` LEFT JOIN `casino_winnings` ON casino_bets.id = casino_winnings.betid WHERE casino_bets.userid = ' + pool.escape(row1[0].userid) + ' ORDER BY casino_bets.id DESC LIMIT 10', function(err7, row7) {
                                if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user casino games history page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userGamesCasino', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            games: {
                                                game: 'casino',
                                                list: row7.map(function(item){
                                                    var amount = getFormatAmount(item.amount);
                                                    var winnings = getFormatAmount(item.winnings);

                                                    var profit = getFormatAmount(winnings - amount);

                                                    return {
                                                        id: item.id,
                                                        game: item.game,
                                                        amount: getFormatAmountString(amount),
                                                        profit: getFormatAmountString(profit),
                                                        status: profit > 0 ? 'win': 'loss',
                                                        date: makeDate(new Date(item.time * 1000))
                                                    };
                                                }),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

exports.userTransactions = async (req, res, next) => {
    if(!haveRankPermission('view_user', res.locals.user ? res.locals.user.rank : 0)) return next();

    var userid = req.params.userid;

    pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `time_create` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
        if(err1) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user transactions page (1)' });

        if(row1.length <= 0) return next();

        var level = calculateLevel(row1[0].xp);

        //DEPOSITED
        pool.query('SELECT SUM(`amount`) AS `deposited` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "deposit"', function(err2, row2) {
            if(err2) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user transactions page (2)' });

            //WITHDRAWN
            pool.query('SELECT SUM(`amount`) AS `withdrawn` FROM `users_trades` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' AND `type` = "withdraw"', function(err3, row3) {
                if(err3) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user transactions page (3)' });

                //WAGERED
                pool.query('SELECT -SUM(`amount`) AS `wagered` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` < 0', function(err4, row4) {
                    if(err4) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user transactions page (4)' });

                    //WINNINGS
                    pool.query('SELECT SUM(`amount`) AS `winnings` FROM `users_transactions` WHERE (' + [ ...Object.keys(config.settings.games.games.original), ...Object.keys(config.settings.games.games.classic) ].map(a => '`service` LIKE "' + a + '_%"').join(' OR ') + ') AND `userid` = ' + pool.escape(row1[0].userid) + ' AND `amount` > 0', function(err5, row5) {
                        if(err5) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user transactions page (5)' });

                        //TRANSACTIONS
                        pool.query('SELECT COUNT(*) AS `count` FROM `users_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid), function(err6, row6){
                            if(err6) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user transactions page (6)' });

                            pool.query('SELECT `id`, `service`, `amount`, `time` FROM `users_transactions` WHERE `userid` = ' + pool.escape(row1[0].userid) + ' ORDER BY `id` DESC LIMIT 10', function(err7, row7){
                                if(err7) return res.status(409).render('409', { layout: 'layouts/error', error: 'An error occurred while rendering user transactions page (7)' });

                                var pages = Math.ceil(row6[0].count / 10);

                                res.render('userTransactions', {
                                    page: 'user',
                                    name: config.app.pages['user'],
                                    response: {
                                        user: {
                                            user: {
                                                userid: row1[0].userid,
                                                name: row1[0].name,
                                                avatar: row1[0].avatar,
                                                rank: config.app.ranks[row1[0].rank],
                                                level: {
                                                    ...level,
                                                    ...{
                                                        tier: [ 'steel', 'bronze', 'silver', 'gold', 'diamond' ][Math.floor(level.level / 25)],
                                                        progress: roundedToFixed((level.have - level.start) / (level.next - level.start) * 100, 2).toFixed(2)
                                                    }
                                                },
                                                created: makeDate(new Date(row1[0].time_create * 1000))
                                            },
                                            stats: {
                                                deposited: getFormatAmountString(row2[0].deposited),
                                                withdrawn: getFormatAmountString(row3[0].withdrawn),
                                                wagered: getFormatAmountString(row4[0].wagered),
                                                profit: getFormatAmountString(getFormatAmount(row5[0].winnings) - getFormatAmount(row4[0].wagered))
                                            },
                                            transactions: {
                                                list: row7.map(a => ({
                                                    id: a.id,
                                                    service: a.service,
                                                    amount: getFormatAmountString(a.amount),
                                                    date: makeDate(new Date(a.time * 1000))
                                                })),
                                                pages: pages > 0 ? pages : 1,
                                                page: 1
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};