var { haveRankPermission } = require('@/utils/utils.js');

var config = require('@/config/config.js');

exports.casebattleUnset = async (req, res) => {
    res.redirect('/casebattle/list/active');
};

exports.casebattleLobby = async (req, res, next) => {
    if(!config.settings.games.games.original.casebattle.enable && !haveRankPermission('play_disabled', res.locals.user ? res.locals.user.rank : 0)) return next();

    res.render('casebattleLobby', {
        page: 'casebattle',
        name: config.app.pages['casebattle']
    });
};

exports.casebattleCreate = async (req, res, next) => {
    if(!config.settings.games.games.original.casebattle.enable && !haveRankPermission('play_disabled', res.locals.user ? res.locals.user.rank : 0)) return next();

    res.render('casebattleCreate', {
        page: 'casebattle',
        name: config.app.pages['casebattle']
    });
};

exports.casebattleGame = async (req, res, next) => {
    if(!config.settings.games.games.original.casebattle.enable && !haveRankPermission('play_disabled', res.locals.user ? res.locals.user.rank : 0)) return next();

    if(req.params.id === undefined) return res.redirect('/casebattle/list/active');

    res.render('casebattleGame', {
        page: 'casebattle',
        name: config.app.pages['casebattle'] + ' #' + req.params.id
    });
};